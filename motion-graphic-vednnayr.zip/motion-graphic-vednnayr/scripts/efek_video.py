# efek_video.py - 20 Video Effects: registry (manifest), perangkat dasar (primitif), dan perender untuk efek yang berbasis primitif.
# ATURAN (MASTER 7.5): hanya bila user memintanya (fxlib.IZIN: video_effect). Tampilan tiap efek mengikuti VIDEO REFERENSI, bukan nama efeknya:
# terapkan() menolak efek yang catatan referensinya (efek/<nama>.md) belum ada. Primitif di bawah boleh dipakai bebas karena hanya alat (zoom, mask, layer, kaca), bukan keputusan visual.
import json, math, os, re
import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter
from scipy.ndimage import map_coordinates
import fxlib as F

# ---------------- registry: 20 efek (deskripsi dari user, tetap) ----------------
EFEK = {
    "orbit": ("Orbit", "efek pergerakan elemen mengelilingi subjek dengan komposisi visual yang dinamis", ["orbit_pos", "Layer"], "perender"),
    "chat-takeover": ("Chat Takeover", "tampilan antarmuka percakapan mengambil alih layar dan menjadi elemen utama dalam video", ["Layer", "komposit", "fxlib.draw_chat_bubble"], "primitif"),
    "frame-escape": ("Frame Escape", "efek subjek yang terlihat keluar atau menembus batas frame", ["Layer", "komposit", "potong_kertas"], "primitif"),
    "snap-zoom": ("Snap Zoom", "perbesaran kamera secara cepat dan tegas untuk memberikan penekanan pada subjek", ["kamera", "kurva_snap"], "perender"),
    "checklist-pop": ("Checklist Pop", "elemen checklist muncul secara bertahap dengan animasi pop", ["centang"], "perender"),
    "headline-storm": ("Headline Storm", "kumpulan headline atau teks bergerak dan bertumpuk secara dinamis memenuhi komposisi video", ["Layer", "komposit"], "primitif"),
    "zoom-portal": ("Zoom Portal", "efek portal visual yang menghubungkan subjek dengan tampilan atau lapisan visual lainnya", ["kamera", "Layer", "komposit"], "primitif"),
    "growth-curve": ("Growth Curve", "animasi grafik pertumbuhan dengan garis kurva yang bergerak dan berkembang", ["garis_tumbuh"], "perender"),
    "studio-reveal": ("Studio Reveal", "efek pengungkapan suasana studio dengan elemen pencahayaan dan tampilan siaran", ["Layer", "komposit", "fxlib.light_pass"], "primitif"),
    "b-roll-overlay": ("B-Roll Overlay", "menggabungkan footage tambahan sebagai lapisan visual di atas video utama", ["Layer", "komposit"], "primitif"),
    "paper-cutout": ("Paper Cutout", "efek subjek yang dipisahkan dari latar belakang dan dikomposisikan seperti potongan kertas", ["maske_subjek", "potong_kertas", "komposit"], "perender"),
    "dolly-zoom": ("Dolly Zoom", "efek perubahan perspektif dengan pergerakan zoom dan penyesuaian skala latar belakang", ["dolly"], "perender"),
    "magazine-cover": ("Magazine Cover", "mengubah komposisi video menjadi tampilan sampul majalah dengan tipografi dan elemen editorial", ["Layer", "komposit"], "primitif"),
    "liquid-glass": ("Liquid Glass", "efek material kaca transparan dengan distorsi dan tampilan reflektif", ["kaca_cair"], "perender"),
    "zoom-through-cut": ("Zoom Through Cut", "transisi zoom yang bergerak menembus satu adegan menuju adegan berikutnya", ["zoom_tembus"], "perender"),
    "green-screen": ("Green Screen", "menggunakan latar hijau untuk memisahkan subjek dan menggantinya dengan latar visual lain", ["kunci_hijau", "komposit"], "perender"),
    "frame-break": ("Frame Break", "efek visual seolah-olah frame pecah atau terbelah dengan elemen yang keluar dari batas komposisi", ["pecah_frame"], "perender"),
    "digital-zoom": ("Digital Zoom", "perbesaran digital yang memberikan penekanan pada bagian tertentu dari video", ["kamera"], "perender"),
    "phone-mockup": ("Phone Mockup", "menampilkan konten di dalam mockup perangkat smartphone", ["ponsel"], "perender"),
    "checklist": ("Checklist", "menampilkan daftar checklist dengan susunan elemen dan animasi yang terorganisasi", ["centang"], "perender"),
}
assert len(EFEK) == 20
KUNCI_REFERENSI = ("timing", "easing", "layering", "masking", "komposisi", "gerak")        # yang WAJIB dicatat dari video referensi (MASTER 7.5)

class ReferensiDiperlukan(RuntimeError): pass

def daftar():
    """Manifest 20 efek: nama, deskripsi, primitif yang dipakai, dan apakah sudah ada perender ('perender') atau baru primitif ('primitif'; susunannya HARUS mengikuti referensi)."""
    return [dict(slug=k, nama=v[0], deskripsi=v[1], primitif=v[2], implementasi=v[3]) for k, v in EFEK.items()]

def siap(slug, folder="efek"):
    """Efek siap dibuat bila catatan referensi efek/<slug>.md ada dan memuat semua kunci (timing, easing, layering, masking, komposisi, gerak) plus blok ```json parameter. -> (bool, alasan, parameter)."""
    p = os.path.join(folder, slug + ".md")
    if slug not in EFEK: return False, f"'{slug}' bukan salah satu dari 20 efek", None
    if not os.path.isfile(p): return False, f"belum ada {p}: minta user mengunggah video referensi efek '{EFEK[slug][0]}' atau deskripsi acuan; jangan mengarang detailnya", None
    t = open(p, encoding="utf-8").read(); hilang = [k for k in KUNCI_REFERENSI if k not in t.lower()]
    if hilang: return False, f"{p} belum memuat: {', '.join(hilang)}", None
    m = re.search(r"```json\s*(\{.*?\})\s*```", t, re.S)
    if not m: return False, f"{p} belum punya blok ```json berisi parameter efek", None
    return True, "ok", json.loads(m.group(1))

def terapkan(slug, fungsi_args=None, folder="efek", **kw):
    """Jalankan perender efek. Syarat: user memintanya (IZIN video_effect) DAN catatan referensinya lengkap (siap). Parameter diambil dari blok json di catatan, bukan dari tebakan."""
    F.IZIN.butuh("video_effect"); ok, why, par = siap(slug, folder)
    if not ok: raise ReferensiDiperlukan(why)
    fn = PERENDER.get(slug)
    if fn is None: raise ReferensiDiperlukan(f"'{EFEK[slug][0]}' baru punya primitif; susun dari primitif mengikuti catatan {slug}.md (Layer, komposit, ...)")
    return fn(par, **kw)

# ---------------- primitif ----------------
def _pil(a): return a if isinstance(a, Image.Image) else Image.fromarray(np.asarray(a))

def kamera(img, zoom=1.0, cx=None, cy=None, rot=0.0, keluar=None):
    """Kamera digital: perbesar `zoom` kali di sekitar titik (cx, cy) (default tengah), putar `rot` derajat. Ukuran keluaran tetap."""
    img = _pil(img).convert("RGB"); W, H = img.size; keluar = keluar or (W, H); cx = W / 2 if cx is None else cx; cy = H / 2 if cy is None else cy
    w, h = W / zoom, H / zoom; x0 = min(max(0, cx - w / 2), W - w); y0 = min(max(0, cy - h / 2), H - h)
    out = img.transform(keluar, Image.AFFINE, (w / keluar[0], 0, x0, 0, h / keluar[1], y0), Image.BICUBIC)
    return out.rotate(rot, Image.BICUBIC, center=(keluar[0] / 2, keluar[1] / 2)) if rot else out

def kurva_snap(t, t0, naik=0.16, tahan=0.5, turun=0.35, zoom=1.4):
    """Faktor zoom per waktu: naik cepat dan tegas (ease-out kuat), tertahan, lalu kembali halus."""
    if t < t0: return 1.0
    u = t - t0
    if u < naik: return 1 + (zoom - 1) * (1 - (1 - u / naik) ** 4)
    if u < naik + tahan: return zoom
    return 1 + (zoom - 1) * (1 - F.e_io(F.clamp((u - naik - tahan) / turun)))

def dolly(fg_rgba, bg_rgb, p, kuat=0.6):
    """Dolly zoom: subjek (fg, RGBA) tetap berukuran sama sedangkan latar (bg) membesar/mengecil sehingga perspektif terasa berubah. p 0..1; kuat = tambahan skala latar pada p=1."""
    bg = kamera(bg_rgb, 1 + kuat * p); fg = _pil(fg_rgba).convert("RGBA"); out = bg.convert("RGBA"); out.alpha_composite(fg); return out.convert("RGB")

def zoom_tembus(a, b, p, zoom_a=3.2, zoom_b=0.45, cx=None, cy=None):
    """Zoom menembus: adegan A membesar cepat sambil memudar, adegan B muncul dari kecil ke ukuran penuh. p 0..1."""
    a = _pil(a).convert("RGB"); b = _pil(b).convert("RGB"); e = F.e_io(p); A = kamera(a, 1 + (zoom_a - 1) * e ** 2, cx, cy)
    sb = zoom_b + (1 - zoom_b) * e; W, H = b.size; small = b.resize((max(1, int(W * sb)), max(1, int(H * sb))), Image.BICUBIC)
    B = A.copy(); B.paste(small, ((W - small.width) // 2, (H - small.height) // 2))                     # B muncul dari kecil di tengah, A masih membesar di sekelilingnya
    return Image.blend(A, B, F.clamp((e - 0.35) / 0.4))

def kunci_hijau(img, hue=(80, 175), min_s=0.28, min_v=0.18, lembut=2.0):
    """Mask alpha (L) dari latar hijau (chroma key di ruang HSV) + despill hijau pada tepi. -> (rgba, mask)."""
    im = _pil(img).convert("RGB"); hsv = np.asarray(im.convert("HSV"), np.float32); h = hsv[..., 0] * 360 / 255; s = hsv[..., 1] / 255; v = hsv[..., 2] / 255
    bg = ((h >= hue[0]) & (h <= hue[1]) & (s >= min_s) & (v >= min_v)); m = Image.fromarray((~bg * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(lembut))
    a = np.asarray(im, np.float32); g = a[..., 1]; lim = np.maximum(a[..., 0], a[..., 2]); a[..., 1] = np.minimum(g, lim)        # despill
    out = Image.fromarray(a.astype(np.uint8)).convert("RGBA"); out.putalpha(m); return out, m

def maske_subjek(img, latar_rgb, toleransi=28, lembut=1.5):
    """Mask subjek bila latar berwarna datar yang diketahui (hasil render sendiri): selisih warna terhadap latar > toleransi."""
    a = np.asarray(_pil(img).convert("RGB"), np.int16); d = np.abs(a - np.array(latar_rgb, np.int16)).max(-1); m = Image.fromarray(((d > toleransi) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(lembut)); return m

def potong_kertas(rgba, tebal=10, warna=(255, 255, 255), bayangan=(0, 0, 0, 90), offset=(8, 12), blur=10):
    """Gaya potongan kertas: tepi putih tebal di sekeliling bentuk + bayangan jatuh. rgba = RGBA subjek. -> RGBA (lebih besar tepi ke segala arah bila ada ruang kosong di kanvas)."""
    im = _pil(rgba).convert("RGBA"); a = im.getchannel("A"); sz = tebal * 2 + 1; tepi = a.filter(ImageFilter.MaxFilter(sz if sz % 2 else sz + 1)); out = Image.new("RGBA", im.size, (0, 0, 0, 0))
    sh = Image.new("RGBA", im.size, bayangan[:3] + (0,)); sh.putalpha(tepi.point(lambda v: v * bayangan[3] // 255).filter(ImageFilter.GaussianBlur(blur))); out.alpha_composite(sh, offset)
    fill = Image.new("RGBA", im.size, tuple(warna) + (255,)); fill.putalpha(tepi); out.alpha_composite(fill); out.alpha_composite(im); return out

def kaca_cair(img, mask, kekuatan=14.0, tebal=18.0, t=0.0, kilau=0.35, aberasi=1.6, tint=(255, 255, 255), tint_alpha=0.10):
    """Material kaca cair di area mask (L): latar di dalamnya terdistorsi seperti lensa (pembiasan di tepi), ada kilau pada tepi menghadap cahaya, aberasi kromatik halus, dan tint tipis; permukaan bergelombang pelan menurut t."""
    im = np.asarray(_pil(img).convert("RGB"), np.float32); H, W = im.shape[:2]; m = _pil(mask).convert("L"); sm = np.asarray(m.filter(ImageFilter.GaussianBlur(tebal)), np.float32) / 255
    gy, gx = np.gradient(sm); yy, xx = np.mgrid[0:H, 0:W].astype(np.float32); w1 = 0.6 * np.sin(xx / 70 + t * 1.3) + 0.4 * np.sin(yy / 55 - t); inside = np.asarray(m, np.float32) / 255
    ch = []
    for k, e in enumerate((-aberasi, 0.0, aberasi)):
        dx = (-gx * kekuatan * (1 + e / 10) * 18 + w1 * 2.0) * inside; dy = (-gy * kekuatan * (1 + e / 10) * 18 + w1 * 2.0) * inside
        ch.append(map_coordinates(im[..., k], [np.clip(yy + dy, 0, H - 1), np.clip(xx + dx, 0, W - 1)], order=1, mode="nearest"))
    out = np.stack(ch, -1); edge = np.hypot(gx, gy); edge = edge / (edge.max() + 1e-6); light = np.clip(-(gx * 0.7 + gy * 0.7) / (np.hypot(gx, gy) + 1e-6), 0, 1) * edge
    out = out + 255 * kilau * np.clip(light * 2.2, 0, 1)[..., None] * inside[..., None] + (np.array(tint, np.float32) - out) * tint_alpha * inside[..., None]
    res = im * (1 - inside[..., None]) + out * inside[..., None]; return Image.fromarray(np.clip(res, 0, 255).astype(np.uint8))

def pecah_frame(img, p, n=14, seed=3, jarak=220, rot=18):
    """Frame pecah: layar dibelah n serpihan (Voronoi), tiap serpihan bergeser keluar dari pusat dan berputar sedikit sesuai p 0..1; celah tampil hitam."""
    from scipy.spatial import cKDTree
    im = np.asarray(_pil(img).convert("RGB")); H, W = im.shape[:2]; rng = np.random.default_rng(seed); pts = rng.uniform([0, 0], [W, H], (n, 2)); lab = cKDTree(pts).query(np.stack(np.mgrid[0:H:2, 0:W:2][::-1], -1).reshape(-1, 2).astype(float))[1].reshape(H // 2, W // 2)
    lab = np.kron(lab, np.ones((2, 2), int))[:H, :W]; out = Image.new("RGB", (W, H), (0, 0, 0)); e = F.e_out(p)
    for i in range(n):
        m = Image.fromarray(((lab == i) * 255).astype(np.uint8)); piece = Image.composite(Image.fromarray(im), Image.new("RGB", (W, H)), m)
        d = np.array(pts[i]) - np.array([W / 2, H / 2]); d = d / (np.linalg.norm(d) + 1e-6) * jarak * e; pr = piece.rotate((i % 2 * 2 - 1) * rot * e, Image.BICUBIC, center=tuple(pts[i])); mr = m.rotate((i % 2 * 2 - 1) * rot * e, Image.BICUBIC, center=tuple(pts[i]))
        out.paste(pr, (int(d[0]), int(d[1])), mr)
    return out

def ponsel(isi, ukuran=(520, 1060), warna=(26, 26, 30), radius=70, bezel=18, poni=True):
    """Mockup smartphone (RGBA): bodi membulat, layar berisi `isi` (di-crop menutupi), poni kamera. Bentuk orisinal, tanpa merek."""
    w, h = ukuran; out = Image.new("RGBA", (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(out); d.rounded_rectangle([0, 0, w - 1, h - 1], radius, fill=warna + (255,))
    sw, sh = w - 2 * bezel, h - 2 * bezel; src = _pil(isi).convert("RGB"); sc = max(sw / src.width, sh / src.height); src = src.resize((int(src.width * sc) + 1, int(src.height * sc) + 1), Image.BICUBIC)
    src = src.crop(((src.width - sw) // 2, (src.height - sh) // 2, (src.width - sw) // 2 + sw, (src.height - sh) // 2 + sh)).convert("RGBA"); mk = Image.new("L", (sw, sh), 0); ImageDraw.Draw(mk).rounded_rectangle([0, 0, sw - 1, sh - 1], radius - bezel, fill=255)
    out.paste(src, (bezel, bezel), mk)
    if poni: d.rounded_rectangle([w / 2 - 70, bezel + 8, w / 2 + 70, bezel + 40], 16, fill=warna + (255,))
    return out

def garis_tumbuh(c, titik, p, tebal=10, warna=(80, 200, 140), titik_akhir=True):
    """Gambar kurva (Cv) yang tumbuh dari kiri ke kanan sebesar p 0..1; ujungnya diberi titik bila titik_akhir."""
    n = len(titik) - 1; q = F.clamp(p) * n; i = int(q); pts = list(titik[:i + 1])
    if i < n: f = q - i; a, b = titik[i], titik[i + 1]; pts.append((a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f))
    if len(pts) >= 2: c.line(pts, tebal, warna)
    if titik_akhir and pts: c.circ(pts[-1][0], pts[-1][1], tebal * 1.1, warna)

def centang(c, x, y, ukuran, t, t0, warna=(80, 200, 140), kotak=(250, 250, 250), tinta=(40, 40, 50)):
    """Kotak centang yang pop-in (overshoot) lalu tanda centang tergambar. Mengembalikan skala pop (0 bila belum muncul)."""
    s = F.popin(t, t0, 0.35)
    if s <= 0: return 0.0
    r = ukuran * s / 2; c.rr(x - r, y - r, x + r, y + r, r * 0.28, kotak); c.line([(x - r * 0.9, y - r * 0.9), (x + r * 0.9, y - r * 0.9), (x + r * 0.9, y + r * 0.9), (x - r * 0.9, y + r * 0.9), (x - r * 0.9, y - r * 0.9)], 4, tinta)
    q = F.prog(t, t0 + 0.12, 0.25)
    if q > 0:
        a, b, d = (x - r * 0.5, y + r * 0.02), (x - r * 0.1, y + r * 0.45), (x + r * 0.55, y - r * 0.4); pts = [a, b] if q < 0.5 else [a, b, (b[0] + (d[0] - b[0]) * (q - 0.5) * 2, b[1] + (d[1] - b[1]) * (q - 0.5) * 2)]
        if q < 0.5: pts = [a, (a[0] + (b[0] - a[0]) * q * 2, a[1] + (b[1] - a[1]) * q * 2)]
        c.line(pts, max(5, ukuran * 0.1), warna)
    return s

def orbit_pos(cx, cy, rx, ry, t, periode, fase=0.0, miring=0.0):
    """Posisi (x, y, kedalaman 0..1) benda yang mengorbit subjek pada elips rx*ry; kedalaman dipakai untuk skala dan urutan tumpukan (belakang digambar dulu)."""
    a = 2 * math.pi * (t / periode) + fase; x = rx * math.cos(a); y = ry * math.sin(a); c, s = math.cos(miring), math.sin(miring); return cx + x * c - y * s, cy + x * s + y * c, 0.5 + 0.5 * math.sin(a)

class Layer:
    """Layer komposit: gambar RGBA + transformasi (skala, rotasi, posisi), opasitas, dan mode campur (normal | multiply | screen | add)."""
    def __init__(self, img, x=0, y=0, skala=1.0, rot=0.0, opasitas=1.0, mode="normal", pusat=False): self.img = _pil(img).convert("RGBA"); self.x, self.y, self.skala, self.rot, self.op, self.mode, self.pusat = x, y, skala, rot, opasitas, mode, pusat

def komposit(layers, ukuran, latar=(0, 0, 0)):
    """Tumpuk Layer dari bawah ke atas (urutan list = urutan tumpukan). -> RGB."""
    base = Image.new("RGBA", ukuran, tuple(latar) + (255,))
    for L in layers:
        im = L.img
        if L.skala != 1.0: im = im.resize((max(1, int(im.width * L.skala)), max(1, int(im.height * L.skala))), Image.BICUBIC)
        if L.rot: im = im.rotate(L.rot, Image.BICUBIC, expand=True)
        if L.op < 1.0: im = im.copy(); im.putalpha(im.getchannel("A").point(lambda v: int(v * L.op)))
        x, y = int(L.x - (im.width / 2 if L.pusat else 0)), int(L.y - (im.height / 2 if L.pusat else 0)); lay = Image.new("RGBA", ukuran, (0, 0, 0, 0)); lay.paste(im, (x, y), im)
        if L.mode == "normal": base.alpha_composite(lay)
        else:
            a = np.asarray(base, np.float32)[..., :3]; b = np.asarray(lay, np.float32)[..., :3]; al = np.asarray(lay, np.float32)[..., 3:] / 255
            r = {"multiply": a * b / 255, "screen": 255 - (255 - a) * (255 - b) / 255, "add": np.minimum(255, a + b)}[L.mode]; out = a * (1 - al) + r * al; base = Image.fromarray(np.dstack([out, np.full(out.shape[:2] + (1,), 255)]).astype(np.uint8), "RGBA")
    return base.convert("RGB")

# ---------------- perender (parameter dari catatan referensi) ----------------
def _p(par, k, d): return par.get(k, d)
def r_snap_zoom(par, img, t): return kamera(img, kurva_snap(t, par["t0"], _p(par, "naik", .16), _p(par, "tahan", .5), _p(par, "turun", .35), par["zoom"]), par.get("cx"), par.get("cy"))
def r_digital_zoom(par, img, t): z = 1 + (par["zoom"] - 1) * F.e_io(F.prog(t, par["t0"], par["durasi"])); return kamera(img, z, par.get("cx"), par.get("cy"))
def r_dolly(par, fg, bg, t): return dolly(fg, bg, F.e_io(F.prog(t, par["t0"], par["durasi"])), par.get("kuat", .6))
def r_zoom_tembus(par, a, b, t): return zoom_tembus(a, b, F.prog(t, par["t0"], par["durasi"]), par.get("zoom_a", 3.2), par.get("zoom_b", .45))
def r_green(par, img, bg): rgba, _ = kunci_hijau(img, tuple(par.get("hue", (80, 175)))); out = _pil(bg).convert("RGBA"); out.alpha_composite(rgba); return out.convert("RGB")
def r_paper(par, rgba): return potong_kertas(rgba, par.get("tebal", 10), tuple(par.get("warna", (255, 255, 255))))
def r_glass(par, img, mask, t): return kaca_cair(img, mask, par.get("kekuatan", 14), par.get("tebal", 18), t)
def r_break(par, img, t): return pecah_frame(img, F.e_io(F.prog(t, par["t0"], par["durasi"])), par.get("n", 14), par.get("seed", 3), par.get("jarak", 220))
def r_phone(par, isi): return ponsel(isi, tuple(par.get("ukuran", (520, 1060))))
def r_growth(par, c, titik, t): garis_tumbuh(c, titik, F.e_io(F.prog(t, par["t0"], par["durasi"])), par.get("tebal", 10))
def r_checklist(par, c, items, t): return [centang(c, x, y, par.get("ukuran", 70), t, par["t0"] + i * par.get("jeda", .35)) for i, (x, y) in enumerate(items)]
def r_orbit(par, cx, cy, t, n): return [orbit_pos(cx, cy, par["rx"], par["ry"], t, par["periode"], 2 * math.pi * i / n, par.get("miring", 0)) for i in range(n)]
PERENDER = {"snap-zoom": r_snap_zoom, "digital-zoom": r_digital_zoom, "dolly-zoom": r_dolly, "zoom-through-cut": r_zoom_tembus, "green-screen": r_green, "paper-cutout": r_paper, "liquid-glass": r_glass,
            "frame-break": r_break, "phone-mockup": r_phone, "growth-curve": r_growth, "checklist": r_checklist, "checklist-pop": r_checklist, "orbit": r_orbit}
