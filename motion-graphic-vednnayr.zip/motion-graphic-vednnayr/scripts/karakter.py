# karakter.py - karakter dengan OUTFIT berlapis dan gerak bertenaga (tidak kaku, tidak letoy).
# Tubuh tetap kokoh: lengan/kaki cukup tebal, postur tegak, gerak punya tenaga (antisipasi, hentak, tenang).
# Kehidupan datang dari pakaian: kerah, manset, sabuk, lipatan, sol sepatu, syal yang tertinggal saat bergerak.
import math
import fxlib as F
import ekspresi as E

INK, SKIN, HAIR, PINK, WHITE, SHADOW = (52, 34, 28), (244, 196, 150), (70, 44, 32), (240, 120, 120), (255, 251, 243), (20, 28, 60)
JACKET, JACKET_D, TEE, TRIM = (244, 144, 58), (208, 106, 38), (255, 241, 220), (58, 38, 32)
PANTS, PANTS_D, CUFF = (62, 84, 140), (44, 62, 108), (170, 188, 224)
SOLE, SHOE, SCARF = (250, 246, 240), (196, 62, 62), (229, 72, 77)

def warga(c, t, x, y, act="diam", t0=0.0, seed=2, mulut=None, ekspresi=None, efek=True):
    """x, y = titik pijakan kaki. act: diam | lompat (mulai di t0, 1 detik) | kaget. Panggil tiap frame dengan t = waktu video.
    mulut = None (mulut diam sesuai ekspresi) atau 0..1 bukaan mulut saat BICARA (ambil dari F.mouth_env, hanya untuk pembicara yang aktif).
    ekspresi = salah satu dari ekspresi.NAMA (netral, senang, tertawa, sedih, menangis, marah, kaget, takut, bingung, teriak, malu, mikir, ngantuk, jatuh_cinta, bangga, curiga, pusing, lega, kagum, jahil); efek=True menambah ikon melayang di atas kepala (mulai di t0)."""
    me = F.idle(t, seed); sx, sy, dy = me["sx"], me["sy"], me["dy"]; hop = 0.0; lift = 0.0; sp = 0.0
    if act == "lompat":
        p = F.prog(t, t0, 1.0); fly = F.clamp((p - 0.25) / 0.6); hop = -math.sin(math.pi * fly) * 170; lift = math.sin(math.pi * p)
        v = 0.6 * math.sin(math.pi * fly) - (0.7 * F.e_io(p / 0.25) if p < 0.25 else 0) + F.jelly(t, t0 + 0.88, 0.5)
        sx, sy = F.squash(v); dy = 0; sp = math.sin(math.pi * fly)                    # sp = kecepatan lompat (untuk syal)
    if act == "kaget": dy = 0
    k = min(1, -hop / 170); c.ell(x, y + 8, 120 * (1 - .35 * k), 26 * (1 - .35 * k), SHADOW)
    by = y + hop + dy; cx, cy = x, by - 330
    for s in (-1, 1):                                                                 # kaki: celana + lipatan + manset + sepatu bersol
        hip = (x + s * 34, by - 230); knee, foot = F.ik2(*hip, x + s * (48 + (14 if act == "kaget" else 0)), y + hop * 0.4, 120, 118, bend=-0.15 * s)
        F.limb(c, [hip, knee, foot], 70, 56, PANTS)
        F.limb(c, [(hip[0] + s * 18, hip[1] + 14), (knee[0] + s * 20, knee[1]), (foot[0] + s * 16, foot[1] - 24)], 8, 8, PANTS_D)      # jahitan samping
        c.line([(knee[0] - 26, knee[1] + 6), (knee[0], knee[1] + 18), (knee[0] + 26, knee[1] + 6)], 6, PANTS_D)                         # lipatan lutut
        c.ell(foot[0], foot[1] - 22, 31, 12, CUFF)                                                                                     # manset celana
        c.poly(F.smooth([(foot[0] - s * 30, foot[1] - 14), (foot[0] + s * 40, foot[1] - 8), (foot[0] + s * 52, foot[1] + 14), (foot[0] - s * 30, foot[1] + 14)], 6, True), SHOE)
        c.ell(foot[0] + s * 8, foot[1] + 18, 52, 10, SOLE)                                                                             # sol sepatu putih
        c.line([(foot[0] + s * 18, foot[1] - 6), (foot[0] + s * 34, foot[1] + 2)], 5, SOLE)                                            # tali
    # TORSO TEGAS (bukan telur/oval): bahu lebar, dada terisi, pinggang sedikit mengecil, ujung jaket melebar. Sudut dibulatkan F.smooth, tubuh tetap kokoh.
    def tor(pts, dx=0.0): return [(cx + (px + dx) * sx, cy + py * sy) for px, py in pts]
    c.poly(F.smooth(tor([(-44, -148), (-82, -144), (-108, -120), (-116, -76), (-108, -14), (-96, 50), (-98, 100), (-94, 142), (-70, 154), (-20, 150), (30, 156), (72, 148), (88, 134), (97, 100), (90, 46), (101, -4), (110, -56), (104, -98), (84, -128), (46, -146), (0, -142)]), 6, True), JACKET)
    c.poly(F.smooth(tor([(36, -132), (84, -122), (108, -80), (104, -8), (94, 48), (100, 100), (94, 140), (74, 150), (30, 153), (26, 100), (38, 40), (34, -30), (30, -90)]), 6, True), JACKET_D)      # sisi teduh: beri volume
    c.poly(F.smooth([(cx - 48 * sx, cy - 150 * sy), (cx - 30 * sx, cy - 157 * sy), (cx + 10 * sx, cy - 159 * sy), (cx + 46 * sx, cy - 150 * sy), (cx + 44 * sx, cy - 112 * sy), (cx + 30 * sx, cy - 76 * sy), (cx + 8 * sx, cy - 50 * sy), (cx - 12 * sx, cy - 46 * sy), (cx - 30 * sx, cy - 74 * sy), (cx - 42 * sx, cy - 110 * sy)], 6, True), TEE)   # kaus dalam (V membulat)
    c.line([(cx, cy - 70 * sy), (cx, cy + 110 * sy)], 8, TRIM)                                                                    # resleting
    for s in (-1, 1): c.line([(cx + s * 4, cy - 70 * sy), (cx + s * 50 * sx, cy - 148 * sy)], 12, TRIM)                            # kerah
    c.line([(cx - 60 * sx, cy + 118 * sy), (cx + 60 * sx, cy + 118 * sy)], 20, TRIM); c.rr(cx - 16, cy + 106 * sy, cx + 16, cy + 130 * sy, 4, (240, 200, 90))   # sabuk + gesper
    for s in (-1, 1): c.line([(cx + s * 60 * sx, cy + 36 * sy), (cx + s * 28 * sx, cy + 44 * sy)], 6, JACKET_D)                    # lipatan di pinggang
    for s in (-1, 1):                                                                 # lengan: lengan baju panjang + manset + tangan
        sh = (cx + s * 100 * sx, cy - 96 * sy)
        if act == "kaget": tg = (cx + s * 150 + 6 * math.sin(t * 30), cy - 250)
        elif act == "lompat": tg = (cx + s * 170, cy - 150 - 120 * lift)
        else: tg = (cx + s * (118 + 6 * math.sin(t * 1.1 + s)), cy + 120 + 5 * math.sin(t * 0.9))
        elbow, hand = F.ik2(*sh, *tg, 105, 100, bend=-s)
        F.limb(c, [sh, elbow, (elbow[0] + (hand[0] - elbow[0]) * 0.85, elbow[1] + (hand[1] - elbow[1]) * 0.85)], 64, 52, JACKET)
        c.line([(elbow[0] - 18, elbow[1] + 10 * s), (elbow[0] + 4, elbow[1] + 22), (elbow[0] + 20, elbow[1] + 8)], 6, JACKET_D)         # lipatan siku
        wr = (elbow[0] + (hand[0] - elbow[0]) * 0.85, elbow[1] + (hand[1] - elbow[1]) * 0.85); F.limb(c, [wr, hand], 40, 36, TRIM)      # manset gelap
        c.circ(*hand, 25, SKIN); c.circ(hand[0] + s * 18, hand[1] - 8, 11, SKIN)                                                       # tangan + jempol
    sw = F.lag(lambda tt: 22 * F.sway(tt, 1.0, 1.1) + (30 * math.sin(math.pi * F.clamp(tt - t0)) if act == "lompat" else 0), t, 0.14)
    nk = (cx - 6, cy - 150 * sy)
    c.poly(F.smooth([(nk[0] - 72, nk[1] - 10), (nk[0] - 58, nk[1] + 10), (nk[0] - 26, nk[1] + 26), (nk[0] + 8, nk[1] + 30), (nk[0] + 46, nk[1] + 20), (nk[0] + 72, nk[1] - 6), (nk[0] + 60, nk[1] - 24), (nk[0] + 20, nk[1] - 34), (nk[0] - 30, nk[1] - 30), (nk[0] - 62, nk[1] - 24)], 6, True), SCARF)   # syal melingkar
    ty = nk[1] + 40 + 30 * (1 if act == "lompat" else 0) * sp                         # ekor syal: tertinggal dan berayun saat gerak
    c.poly(F.smooth([(nk[0] + 26, nk[1] + 4), (nk[0] + 48 + sw * 0.4, nk[1] + 26), (nk[0] + 72 + sw, nk[1] + 64), (nk[0] + 80 + sw * 1.2, ty + 84), (nk[0] + 72 + sw * 1.4, ty + 106), (nk[0] + 54 + sw * 1.5, ty + 114), (nk[0] + 34 + sw * 1.1, ty + 100), (nk[0] + 12 + sw * 0.6, ty + 62), (nk[0] + 4, nk[1] + 36), (nk[0] + 8, nk[1] + 16)], 6, True), SCARF)
    hx, hy = cx + 4, cy - 235 * sy
    c.poly(F.blob_pts(hx - sw * 0.5, hy - 25, 118, 100, t, seed + 3, 0.02), HAIR)
    c.poly(F.blob_pts(hx, hy, 104 * sx ** 0.5, 98 * sy ** 0.5, t * 0.7, seed + 5, 0.012, rot=0.05), SKIN)
    c.poly(F.smooth([(hx - 104, hy - 10), (hx - 90, hy - 90), (hx - 20, hy - 118), (hx + 70, hy - 98), (hx + 104, hy - 20),
                     (hx + 60, hy - 62), (hx - 20, hy - 70), (hx - 80, hy - 40)], 8, True), HAIR)
    nama = ekspresi or ("kaget" if act == "kaget" else "netral")                       # act="kaget" tetap memakai wajah kaget (kompatibel)
    E.wajah(c, hx, hy, nama, t, op=me["eye"], lk=me["look"], mulut=None if nama == "kaget" else mulut, t0=t0, efek=efek)
