# subtitle_gaya.py - Subtitle per gaya visual (bagian 7.2 dan 0.6). Subtitle HANYA dibuat bila user memintanya (aturan 7); modul ini menentukan TAMPILANNYA agar sama karakternya dengan video contoh.
# Detail diambil dengan memeriksa frame contoh per gaya (2026-11-09): bentuk dan bahan kotak teks, font, tiga keadaan kata (sudah diucapkan / sedang diucapkan / belum), hiasan kecil.
# Tiga keadaan kata di SEMUA gaya contoh: kata yang SEDANG diucapkan diberi warna atau sorotan; kata yang SUDAH diucapkan berwarna normal; kata yang BELUM diucapkan diredupkan.
# Font memakai berkas nyata di folder fonts/ (Google Fonts, lisensi OFL, lihat fonts/LISENSI-OFL.txt); tidak ada penggantian diam-diam: `font_gaya` melempar galat bila berkasnya hilang.
import os, random, functools
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import gradien as G

SC = 2
import fonts_gaya as FG
FONT = {g: (FG.PERAN[g]["caption"]["utama"][0], FG.PERAN[g]["caption"]["utama"][1].get("wght")) for g in FG.PERAN}   # ringkasan berkas caption per gaya; sumber kebenaran: fonts_gaya.PERAN (cocokkan dengan frame contoh)

# warna per gaya: past (sudah), aktif (sedang), nanti (belum), teks_aktif (warna huruf di atas sorotan)
WARNA = dict(
    KLIPING=dict(past=(30, 26, 24), nanti=(172, 168, 158), sorot=(245, 184, 0), teks_aktif=(24, 20, 18)),
    ARSIP=dict(past=(28, 26, 24), nanti=(150, 140, 120), sorot=(255, 226, 122), teks_aktif=(24, 22, 20)),
    BLUEPRINT=dict(past=(236, 244, 255), nanti=(112, 146, 190), sorot=(245, 213, 71), teks_aktif=(245, 213, 71)),
    SKETSA=dict(past=(34, 34, 44), nanti=(150, 156, 172), sorot=(251, 226, 122), teks_aktif=(30, 30, 40)),
    GEOMETRIK=dict(past=(255, 255, 255), nanti=(122, 122, 122), sorot=(245, 197, 24), teks_aktif=(20, 20, 20)),
    HIKAYAT=dict(past=(50, 30, 20), nanti=(160, 136, 108), sorot=(200, 66, 30), teks_aktif=(200, 66, 30)),
    TERMINAL=dict(past=(110, 240, 150), nanti=(40, 110, 70), sorot=(60, 230, 140), teks_aktif=(4, 20, 12)),
    CAIR=dict(past=(255, 255, 255), nanti=(255, 255, 255, 96), sorot=(255, 79, 163), teks_aktif=(255, 255, 255)),
    FLATLIFE=dict(past=(34, 40, 78), nanti=(165, 170, 186), sorot=(238, 91, 69), teks_aktif=(255, 255, 255)),
    LANTANG=dict(past=(255, 255, 255), nanti=(120, 120, 120), sorot=(255, 75, 31), teks_aktif=(255, 75, 31)),
    PETA=dict(past=(255, 255, 255), nanti=(150, 156, 162), sorot=(245, 205, 60), teks_aktif=(245, 205, 60)),
    MIDNIGHT=dict(past=(255, 255, 255), nanti=(132, 142, 188), sorot=(255, 201, 60), teks_aktif=(255, 201, 60)),
    MINIATUR=dict(past=(255, 255, 255), nanti=(176, 182, 206), sorot=(255, 206, 66), teks_aktif=(255, 206, 66)),
)
# sorotan kata aktif: 'bar' = batang stabilo di setengah bawah kata, 'kotak' = kotak penuh di belakang kata, 'garis' = garis bawah, 'warna' = hanya warna huruf, 'pil' = kapsul gradien
SOROT = dict(KLIPING="bar", ARSIP="kotak", BLUEPRINT="garis", SKETSA="kotak", GEOMETRIK="kotak", HIKAYAT="warna", TERMINAL="blok", CAIR="pil", FLATLIFE="pil", LANTANG="warna", PETA="warna", MIDNIGHT="warna", MINIATUR="warna")
UKURAN = dict(KLIPING=62, ARSIP=48, BLUEPRINT=40, SKETSA=54, GEOMETRIK=44, HIKAYAT=60, TERMINAL=42, CAIR=50, FLATLIFE=54, LANTANG=66, PETA=54, MIDNIGHT=48, MINIATUR=46)


def font_gaya(gaya, px, peran="caption"):
    """Font caption gaya itu dari fonts_gaya.PERAN (berkas nyata di fonts/; tidak ada penggantian diam-diam)."""
    return FG.font_peran(gaya, peran, int(px))


def _tata(gaya, kata, px, lebar_maks, spasi):
    """Bagi kata ke baris (maks 2 baris disarankan) -> [[(idx, kata, lebar)...], ...]"""
    f = font_gaya(gaya, px * SC); baris = [[]]; x = 0; sp = f.getlength(" ") * spasi
    for i, w in enumerate(kata):
        wl = f.getlength(w)
        if baris[-1] and x + wl > lebar_maks * SC: baris.append([]); x = 0
        baris[-1].append((i, w, wl)); x += wl + sp
    return baris, sp


def caption(gaya, kata, aktif=None, lebar_maks=900, skala=1.0, seed=3, kursor=True):
    """Gambar satu keadaan subtitle. kata: list kata satu cue; aktif: indeks kata yang sedang diucapkan (None = semua sudah diucapkan). -> RGBA (tepi transparan, sudah dengan bayangan bila gayanya punya).
    Panggil per frame dengan `aktif` berganti sesuai waktu (cache hasil per (gaya, kata, aktif))."""
    if gaya not in FONT: raise KeyError(gaya)
    return _caption(gaya, tuple(kata), aktif, int(lebar_maks), float(skala), int(seed), bool(kursor))


@functools.lru_cache(maxsize=512)
def _caption(gaya, kata, aktif, lebar_maks, skala, seed, kursor):
    px = UKURAN[gaya] * skala; W = WARNA[gaya]; spasi = dict(pil=1.9, kotak=1.45, blok=1.45, bar=1.3, garis=1.1).get(SOROT[gaya], 1.0) * (0.7 if gaya == "LANTANG" else 1.0)
    baris, sp = _tata(gaya, kata, px, lebar_maks - 100, spasi); f = font_gaya(gaya, px * SC); asc, desc = f.getmetrics(); lh = int((asc + desc) * 1.08)
    isi_w = max(sum(w for _, _, w in b) + sp * (len(b) - 1) for b in baris); isi_h = lh * len(baris); padx, pady = int(34 * SC * skala), int(22 * SC * skala)
    if gaya == "TERMINAL": padx += int(40 * SC * skala)
    bw, bh = int(isi_w + 2 * padx), int(isi_h + 2 * pady); m = int(40 * SC); im = Image.new("RGBA", (bw + 2 * m, bh + 2 * m), (0, 0, 0, 0)); rng = random.Random(seed)
    kotak = _kotak(gaya, bw, bh, rng, skala); im.alpha_composite(kotak, (m - (kotak.width - bw) // 2, m - (kotak.height - bh) // 2))
    d = ImageDraw.Draw(im, "RGBA"); y = m + pady
    for b in baris:
        lw = sum(w for _, _, w in b) + sp * (len(b) - 1); x = m + (bw - lw) / 2 + (padx - 34 * SC * skala if gaya == "TERMINAL" else 0) / 2; xs = x
        for i, w, wl in b:
            st = "nanti" if aktif is not None and i > aktif else ("aktif" if aktif is not None and i == aktif else "past")
            fg = W["past"] if st == "past" else (W["nanti"] if st == "nanti" else W["teks_aktif"])
            if st == "aktif": _sorot(gaya, im, d, x, y, wl, lh, asc, W, skala, rng)
            d.text((x, y), w, font=f, fill=fg if len(fg) == 4 else fg + (255,))
            if gaya == "TERMINAL" and st == "past": pass
            x += wl + sp
        y += lh
    if gaya == "TERMINAL":
        d.text((m + 22 * SC * skala, m + pady), ">", font=f, fill=W["past"] + (255,))
        if kursor: d.rectangle([x + 6 * SC, y - lh + asc * 0.12, x + 6 * SC + asc * 0.42, y - lh + asc * 0.92], fill=W["sorot"] + (230,))
    out = im.resize((im.width // SC, im.height // SC), Image.LANCZOS); return out


def _sorot(gaya, im, d, x, y, wl, lh, asc, W, skala, rng):
    tipe = SOROT[gaya]; s = W["sorot"]; pad = int((6 if tipe == "pil" else 10) * SC * skala)
    if tipe == "bar":                                                                  # KLIPING: batang stabilo kuning di setengah bawah kata, sedikit miring dan tidak rata
        top = y + asc * 0.42; poly = [(x - pad, top + rng.uniform(-3, 3) * SC), (x + wl + pad, top - rng.uniform(0, 5) * SC), (x + wl + pad, y + lh * 0.92 + rng.uniform(-2, 3) * SC), (x - pad, y + lh * 0.95)]
        g = Image.new("RGBA", im.size, (0, 0, 0, 0)); m = Image.new("L", im.size, 0); ImageDraw.Draw(m).polygon(poly, fill=235); im.alpha_composite(G.isi(m, stops=G.stops_dari(s, terang=0.07, gelap=0.06), sudut=10))
    elif tipe == "kotak":                                                              # ARSIP, SKETSA: stabilo kotak penuh, tepi sedikit tidak rata
        m = Image.new("L", im.size, 0); jit = lambda: rng.uniform(-2, 2) * SC
        ImageDraw.Draw(m).polygon([(x - pad + jit(), y + lh * 0.12 + jit()), (x + wl + pad + jit(), y + lh * 0.10 + jit()), (x + wl + pad + jit(), y + lh * 0.92 + jit()), (x - pad + jit(), y + lh * 0.94 + jit())], fill=230)
        if gaya == "GEOMETRIK": m = Image.new("L", im.size, 0); ImageDraw.Draw(m).rectangle([x - pad, y + lh * 0.10, x + wl + pad, y + lh * 0.92], fill=255)
        im.alpha_composite(G.isi(m, stops=G.stops_dari(s, terang=0.06, gelap=0.07), sudut=90))
    elif tipe == "garis":                                                              # BLUEPRINT: garis bawah kuning tebal
        d.rectangle([x, y + lh * 0.92, x + wl, y + lh * 0.92 + 4 * SC * skala], fill=s + (255,))
    elif tipe == "blok":                                                               # TERMINAL: blok hijau penuh dengan garis pindai (scanline)
        m = Image.new("L", im.size, 0); dm = ImageDraw.Draw(m); dm.rectangle([x - 4 * SC, y + lh * 0.08, x + wl + 4 * SC, y + lh * 0.94], fill=255)
        im.alpha_composite(G.isi(m, stops=[(0, G.campur(s, (255, 255, 255), 0.15)), (1, G.campur(s, (0, 0, 0), 0.12))], sudut=90))
        for yy in range(int(y + lh * 0.08), int(y + lh * 0.94), 3 * SC): d.line([x - 4 * SC, yy, x + wl + 4 * SC, yy], fill=(0, 0, 0, 38), width=1)
    elif tipe == "pil":                                                                # CAIR: pil gradien merah muda -> ungu; FLATLIFE: pil koral bergradien
        m = Image.new("L", im.size, 0); ImageDraw.Draw(m).rounded_rectangle([x - pad * 1.2, y + lh * 0.08, x + wl + pad * 1.2, y + lh * 0.94], radius=int(lh * 0.42), fill=255)
        stops = [(0, (255, 79, 163)), (1, (139, 92, 255))] if gaya == "CAIR" else [(0, (246, 112, 86)), (1, (222, 70, 50))]
        im.alpha_composite(G.isi(m, stops=stops, sudut=20 if gaya == "CAIR" else 90, kilap=0.3))
    # 'warna': hanya warna huruf (diatur lewat teks_aktif)


def _kotak(gaya, bw, bh, rng, skala):
    """Kotak/bahan latar subtitle tiap gaya (RGBA, boleh lebih besar dari bw x bh untuk bayangan)."""
    mg = int(40 * SC); size = (bw + 2 * mg, bh + 2 * mg); out = Image.new("RGBA", size, (0, 0, 0, 0))
    def bayang(topeng, a=0.38, blur=10, dy=8):
        sh = Image.new("RGBA", size, (0, 0, 0, 0)); sh.putalpha(topeng.point(lambda v: int(v * a))); sh = sh.filter(ImageFilter.GaussianBlur(blur * SC)); return sh.transform(size, Image.AFFINE, (1, 0, 0, 0, 1, -dy * SC))
    L = lambda: Image.new("L", size, 0)
    if gaya in ("KLIPING", "ARSIP"):                                                  # kertas lecek bertepi sobek (atas dan bawah bergerigi), miring tipis
        m = L(); dm = ImageDraw.Draw(m); ps = []; n = max(10, bw // (14 * SC)); amp = (6 if gaya == "KLIPING" else 9) * SC * skala
        for i in range(n + 1): ps.append((mg + bw * i / n, mg + rng.uniform(0, amp)))
        for j in range(1, 4): ps.append((mg + bw + rng.uniform(-2, 2) * SC, mg + bh * j / 4))
        for i in range(n, -1, -1): ps.append((mg + bw * i / n, mg + bh - rng.uniform(0, amp)))
        for j in range(3, 0, -1): ps.append((mg + rng.uniform(-2, 2) * SC, mg + bh * j / 4))
        dm.polygon(ps, fill=255); kertas = G.isi(m, stops=[(0, (255, 252, 242) if gaya == "KLIPING" else (244, 233, 205)), (1, (234, 226, 208) if gaya == "KLIPING" else (222, 205, 170))], sudut=80)
        a = np.asarray(kertas).astype(np.float32); nz = np.random.default_rng(rng.randint(0, 9999)).normal(0, 3.2, a.shape[:2]).astype(np.float32); a[..., :3] = np.clip(a[..., :3] + nz[..., None], 0, 255)   # serat dan lecek halus
        kertas = Image.fromarray(a.astype(np.uint8), "RGBA"); kertas.putalpha(m); out = Image.alpha_composite(bayang(m), kertas)
        return out.rotate(rng.uniform(-1.4, 1.4), expand=False, resample=Image.BICUBIC, center=(size[0] / 2, size[1] / 2))
    if gaya == "BLUEPRINT":
        m = L(); ImageDraw.Draw(m).rectangle([mg, mg, mg + bw, mg + bh], fill=255); box = G.isi(m, stops=[(0, (14, 52, 104)), (1, (8, 34, 76))], sudut=90); box.putalpha(m.point(lambda v: int(v * 0.94)))
        d = ImageDraw.Draw(box); d.rectangle([mg, mg, mg + bw, mg + bh], outline=(36, 92, 160, 255), width=2 * SC); c = (116, 196, 255, 255); k = int(18 * SC * skala)
        for cx, cy, sx, sy in ((mg, mg, 1, 1), (mg + bw, mg, -1, 1), (mg, mg + bh, 1, -1), (mg + bw, mg + bh, -1, -1)):
            d.line([cx, cy, cx + sx * k, cy], fill=c, width=3 * SC); d.line([cx, cy, cx, cy + sy * k], fill=c, width=3 * SC)
        return Image.alpha_composite(bayang(m, 0.3, 8, 6), box)
    if gaya == "SKETSA":                                                               # tanpa kotak: pendar kertas lembut di belakang tulisan tangan
        m = L(); ImageDraw.Draw(m).rounded_rectangle([mg, mg, mg + bw, mg + bh], radius=int(30 * SC), fill=150); m = m.filter(ImageFilter.GaussianBlur(16 * SC)); g = Image.new("RGBA", size, (255, 251, 238, 255)); g.putalpha(m); return g
    if gaya == "GEOMETRIK":
        m = L(); ImageDraw.Draw(m).rectangle([mg, mg, mg + bw, mg + bh], fill=255); box = G.isi(m, stops=[(0, (38, 38, 40)), (1, (16, 16, 18))], sudut=90); return Image.alpha_composite(bayang(m, 0.28, 6, 5), box)
    if gaya == "HIKAYAT":                                                              # kapsul emas-perkamen bergradien dengan pantulan atas, tepi tipis, bayangan lembut
        m = L(); ImageDraw.Draw(m).rounded_rectangle([mg, mg, mg + bw, mg + bh], radius=min(bh // 2, 62 * SC), fill=255)
        box = G.isi(m, stops=[(0, (248, 226, 176)), (0.5, (236, 202, 140)), (1, (206, 160, 96))], sudut=90, kilap=0.4); ring = L(); ImageDraw.Draw(ring).rounded_rectangle([mg + 3 * SC, mg + 3 * SC, mg + bw - 3 * SC, mg + bh - 3 * SC], radius=min(bh // 2, 62 * SC) - 3 * SC, outline=255, width=2 * SC)
        rg = Image.new("RGBA", size, (255, 247, 224, 0)); rg.putalpha(ring.point(lambda v: int(v * 0.6))); box.alpha_composite(rg); return Image.alpha_composite(bayang(m, 0.45, 12, 9), box)
    if gaya == "TERMINAL":
        m = L(); ImageDraw.Draw(m).rectangle([mg, mg, mg + bw, mg + bh], fill=255); box = G.isi(m, stops=[(0, (8, 22, 16)), (1, (3, 12, 9))], sudut=90); box.putalpha(m.point(lambda v: int(v * 0.92)))
        d = ImageDraw.Draw(box); d.rectangle([mg, mg, mg + bw, mg + bh], outline=(46, 180, 108, 210), width=2 * SC); gl = bayang(m, 0.0); glow = Image.new("RGBA", size, (60, 230, 140, 0)); glow.putalpha(m.filter(ImageFilter.GaussianBlur(10 * SC)).point(lambda v: int(v * 0.18)))
        return Image.alpha_composite(glow, box)
    if gaya == "CAIR":                                                                 # kaca buram: isi putih transparan bergradien, tepi terang, pendar
        m = L(); ImageDraw.Draw(m).rounded_rectangle([mg, mg, mg + bw, mg + bh], radius=min(bh // 2, 62 * SC), fill=255)
        box = G.isi(m, stops=[(0, (255, 255, 255)), (1, (214, 196, 255))], sudut=60); box.putalpha(m.point(lambda v: int(v * 0.17))); ring = L(); ImageDraw.Draw(ring).rounded_rectangle([mg, mg, mg + bw, mg + bh], radius=min(bh // 2, 62 * SC), outline=255, width=2 * SC)
        rg = Image.new("RGBA", size, (255, 255, 255, 0)); rg.putalpha(ring.point(lambda v: int(v * 0.42))); box.alpha_composite(rg); return Image.alpha_composite(bayang(m, 0.25, 12, 6), box)
    if gaya == "FLATLIFE":
        m = L(); ImageDraw.Draw(m).rounded_rectangle([mg, mg, mg + bw, mg + bh], radius=min(bh // 2, 62 * SC), fill=255); box = G.isi(m, stops=[(0, (255, 255, 255)), (1, (244, 240, 232))], sudut=90); return Image.alpha_composite(bayang(m, 0.26, 8, 6), box)
    if gaya == "LANTANG":
        return out                                                                     # contoh LANTANG tidak memakai kotak subtitle; teks tebal langsung di latar
    if gaya == "PETA":
        m = L(); ImageDraw.Draw(m).rounded_rectangle([mg, mg, mg + bw, mg + bh], radius=int(8 * SC), fill=255); box = G.isi(m, stops=[(0, (50, 58, 68)), (1, (30, 36, 44))], sudut=90); box.putalpha(m.point(lambda v: int(v * 0.9))); return Image.alpha_composite(bayang(m, 0.3, 8, 6), box)
    if gaya == "MIDNIGHT":
        m = L(); ImageDraw.Draw(m).rounded_rectangle([mg, mg, mg + bw, mg + bh], radius=int(26 * SC), fill=255); box = G.isi(m, stops=[(0, (34, 40, 100)), (1, (18, 22, 62))], sudut=90, kilap=0.2); return Image.alpha_composite(bayang(m, 0.4, 12, 8), box)
    if gaya == "MINIATUR":
        m = L(); ImageDraw.Draw(m).rounded_rectangle([mg, mg, mg + bw, mg + bh], radius=int(22 * SC), fill=255); box = G.isi(m, stops=[(0, (52, 58, 90)), (1, (30, 34, 58))], sudut=90); box.putalpha(m.point(lambda v: int(v * 0.78))); return Image.alpha_composite(bayang(m, 0.3, 10, 7), box)
    return out


def plakat_hikayat(teks, lebar=900, skala=1.0, seed=4):
    """Plakat judul HIKAYAT: perkamen/kulit dengan gradien vertikal, bercak kulit, serat horizontal halus, dua paku bulat di ujung, huruf kapital serif tebal berjarak lebar (corak kulit wayang)."""
    rng = np.random.default_rng(seed); px = 40 * skala; f = font_gaya("HIKAYAT", px * SC); tx = " ".join(teks.upper()); l, t, r, b = f.getbbox(tx)
    pw, ph = int(max(r - l + 160 * SC, lebar * SC // 2)), int((b - t) + 70 * SC); mg = 30 * SC; size = (pw + 2 * mg, ph + 2 * mg)
    m = Image.new("L", size, 0); ImageDraw.Draw(m).rounded_rectangle([mg, mg, mg + pw, mg + ph], radius=int(ph * 0.42), fill=255)
    kulit = G.isi(m, stops=[(0, (236, 206, 150)), (0.5, (214, 172, 112)), (1, (176, 128, 76))], sudut=90, kilap=0.35); a = np.asarray(kulit).astype(np.float32)
    def _noise(k): return np.asarray(Image.fromarray((rng.random((size[1] // k + 1, size[0] // k + 1)) * 255).astype(np.uint8)).resize(size, Image.BICUBIC).filter(ImageFilter.GaussianBlur(k / 4)), np.float32) / 255 - 0.5
    nz = _noise(46) * 1.0 + _noise(14) * 0.45                                                                                                                           # bercak kulit besar + kecil, halus
    yy = np.arange(size[1])[:, None] * np.ones((1, size[0])); serat = np.sin(yy * 0.9 + rng.random() * 6) * 2.5                                                           # serat horizontal halus
    a[..., :3] = np.clip(a[..., :3] + (nz * 70 + serat)[..., None] * np.array([1.0, 0.9, 0.7]), 0, 255); kulit = Image.fromarray(a.astype(np.uint8), "RGBA"); kulit.putalpha(m)
    d = ImageDraw.Draw(kulit, "RGBA"); d.text((mg + pw / 2 - (r - l) / 2 - l, mg + ph / 2 - (b - t) / 2 - t), tx, font=f, fill=(52, 30, 18, 255))
    for cx in (mg + int(ph * 0.42), mg + pw - int(ph * 0.42)): d.ellipse([cx - 7 * SC, mg + ph / 2 - 7 * SC, cx + 7 * SC, mg + ph / 2 + 7 * SC], fill=(60, 36, 22, 255)); d.ellipse([cx - 4 * SC, mg + ph / 2 - 6 * SC, cx + 2 * SC, mg + ph / 2 - 1 * SC], fill=(150, 110, 80, 200))
    sh = Image.new("RGBA", size, (0, 0, 0, 0)); sh.putalpha(m.point(lambda v: int(v * 0.4))); sh = sh.filter(ImageFilter.GaussianBlur(9 * SC)).transform(size, Image.AFFINE, (1, 0, 0, 0, 1, -8 * SC))
    out = Image.alpha_composite(sh, kulit); out = out.resize((out.width // SC, out.height // SC), Image.LANCZOS); return out


def contoh_semua(kata=("Twitter", "dari", "tahun", "2006", "sampai", "2017"), aktif=2, lebar=860):
    """Lembar contoh seluruh gaya (untuk dicocokkan dengan frame referensi sebelum dipakai)."""
    names = list(FONT); sheet = Image.new("RGB", (lebar + 40, 190 * len(names)), (120, 120, 130)); y = 0
    for n in names:
        bg = {"BLUEPRINT": (10, 40, 86), "TERMINAL": (5, 12, 10), "MIDNIGHT": (13, 16, 64), "CAIR": (36, 20, 76), "HIKAYAT": (140, 70, 30), "KLIPING": (255, 126, 182), "LANTANG": (20, 20, 22), "MINIATUR": (205, 226, 240)}.get(n, (240, 236, 224))
        ImageDraw.Draw(sheet).rectangle([0, y, lebar + 40, y + 190], fill=bg); im = caption(n, kata, aktif, lebar_maks=lebar - 40); sheet.paste(im, ((sheet.width - im.width) // 2, y + (190 - im.height) // 2), im); y += 190
    return sheet
