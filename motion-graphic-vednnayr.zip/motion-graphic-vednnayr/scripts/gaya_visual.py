# gaya_visual.py - Pustaka 13 gaya visual (tampilan) untuk video motion graphic penjelas. Dipakai DI ATAS dua gaya utama (Animasi Cerita Berkarakter dan Reel Tipografi Bergerak): gaya utama menentukan
# STRUKTUR (karakter + cerita, atau tipografi + ketukan), gaya visual menentukan TAMPILAN (palet, bentuk, bahan, gerak, aksen SFX).
# Sumber: tangkapan layar halaman "Motion Graphics" milik kreatorlab.id yang diberikan user (frame diam). Video aslinya BELUM ditonton (situs diblokir dari workspace dan halaman tidak memuat tautan videonya),
# jadi gerak di bawah adalah penafsiran dari frame diam, bukan hasil menonton. Palet = perkiraan: warna dominan hasil sampling tangkapan layar (yang cenderung 5-10 persen lebih gelap dari aslinya) lalu disesuaikan dengan mata;
# cocokkan lagi bila referensi asli tersedia. Bila sesi punya browser atau user melampirkan videonya: tonton, lalu perbaiki deskripsi di sini (jangan dibiarkan salah).
import re

GAYA_UTAMA = ("Animasi Cerita Berkarakter", "Reel Tipografi Bergerak")
# Ciri bersama semua contoh: (1) keterangan (caption) di bawah berupa kapsul dengan KATA KUNCI disorot warna; (2) chip label kecil di sudut (kategori, "SIMULASI", "FAKTA & ANGKA");
# (3) satu ide besar per adegan dengan banyak ruang kosong; (4) angka atau objek utama sangat besar. Penekanan kata mengikuti 6.9.

GAYA = {
 "ARSIP": dict(
    ciri="kalender dan dokumen cetak usang: halaman kalender krem miring dengan kepala merah dan lingkaran merah gambar tangan di satu angka, stempel merah di sudut, keterangan di strip kertas dengan huruf mesin tik.",
    palet=dict(latar="#1d1917", kertas="#c0bbb5", aksen="#c0392b", teks="#2a211c"), huruf="mesin tik atau monospace tebal untuk keterangan; serif tebal untuk judul bulan atau tahun",
    elemen=["halaman kalender", "stempel", "lingkaran penanda gambar tangan", "serat dan lipatan kertas", "bayangan jatuh lembut"],
    gerak=["kertas jatuh dan miring masuk", "stempel menghantam (skala besar ke normal)", "lingkaran digambar bertahap", "angka disorot"], sfx=["benturan", "muncul", "sapuan"],
    cocok="Reel Tipografi Bergerak", sinyal=["archive", "arsip", "kalender", "dokumen", "tanggal", "sejarah", "stempel", "kertas usang"]),
 "BLUEPRINT": dict(
    ciri="cetak biru teknik: latar biru tua berkisi tipis, gambar garis putih-biru muda (lingkaran, garis dimensi, panah, label kecil monospace seperti penanda lantai atau kabel), keterangan di kotak gelap bersudut membulat.",
    palet=dict(latar="#0c315e", garis="#8fb4d9", aksen="#6fcf97", teks="#e8f1fb"), huruf="monospace tipis untuk anotasi; sans bersih untuk keterangan",
    elemen=["kisi", "garis dimensi dan panah", "lingkaran dan penampang", "label anotasi kecil", "bingkai gambar teknik"],
    gerak=["garis digambar bertahap (draw-on)", "angka dimensi bertambah", "anotasi muncul satu per satu", "zoom pelan ke detail"], sfx=["digital", "ritme", "muncul"],
    cocok="Reel Tipografi Bergerak", sinyal=["blueprint", "cetak biru", "teknik", "mesin", "arsitektur", "cara kerja", "lift", "rancangan"]),
 "SKETSA": dict(
    ciri="buku catatan bergaris dengan gambar tangan: tokoh stik dan lampu dengan kerucut cahaya kuning, judul tulisan tangan dengan stabilo kuning, tag kecil hijau (mis. nama topik), keterangan tulisan tangan.",
    palet=dict(latar="#c7c4bf", garis="#2b2b2b", aksen="#f4d03f", tag="#7bb661", teks="#2b2b2b"), huruf="tulisan tangan untuk judul dan keterangan; garis tidak rata",
    elemen=["kertas bergaris", "tokoh stik", "kerucut cahaya", "stabilo", "tag topik", "panah dan lingkaran coretan"],
    gerak=["coretan digambar bertahap dengan goyangan kecil", "stabilo menyapu kata", "tokoh stik bergerak sederhana"], sfx=["muncul", "sapuan", "lucu"],
    cocok="Animasi Cerita Berkarakter", sinyal=["sketch", "sketsa", "gambar tangan", "coretan", "buku catatan", "psikologi", "doodle"]),
 "GEOMETRIK": dict(
    ciri="angka atau bentuk geometris raksasa: latar abu terang, angka hitam sangat tebal di atas lingkaran kuning mustard, chip label kecil di bawah dan teks kecil di sudut (mis. kategori fakta), elemen sangat sedikit.",
    palet=dict(latar="#dedbd5", hitam="#2f2717", aksen="#d4b13e", chip="#d2ec62"), huruf="sans hitam ekstra tebal dan rapat untuk angka; monospace kecil untuk label",
    elemen=["angka raksasa", "lingkaran atau bentuk dasar", "chip label", "ruang kosong lebar"],
    gerak=["angka naik hitung (count-up)", "lingkaran tumbuh", "angka menghantam masuk", "potongan di ketukan"], sfx=["benturan", "sukses", "ritme"],
    cocok="Reel Tipografi Bergerak", sinyal=["geometric", "geometrik", "angka", "statistik", "fakta dan angka", "persen", "bentuk dasar"]),
 "HIKAYAT": dict(
    ciri="siluet cerita rakyat atau sejarah: gradien oranye sampai cokelat tua seperti sepia, siluet gaya wayang kulit dan gunung berlapis berlubang, label kecil bertema (mis. LEGENDA), keterangan di kapsul emas.",
    palet=dict(latar="#1b0e0b", tengah="#ac733b", cahaya="#e0b060", aksen="#c2ab50"), huruf="serif atau display berkarakter untuk judul; keterangan di kapsul emas",
    elemen=["siluet wayang kulit", "gunung berlapis berpola lubang", "cahaya hangat dari belakang", "ombak atau awan bergaris", "label bertema"],
    gerak=["paralaks lapisan", "siluet melayang pelan", "cahaya berdenyut halus"], sfx=["tegang", "sapuan", "muncul"],
    cocok="Animasi Cerita Berkarakter", sinyal=["silhouette", "history", "hikayat", "legenda", "dongeng", "cerita rakyat", "wayang", "siluet", "sejarah", "mitos"]),
 "TERMINAL": dict(
    ciri="antarmuka baris perintah ala peretas: latar hampir hitam, teks hijau terminal monospace, jendela berbingkai (merah atau hijau), kotak kode OTP, banner hijau seperti ACCESS GRANTED, baris prompt dengan kursor, hujan kode samar.",
    palet=dict(latar="#0b0c11", hijau="#59b458", terang="#7dff7d", merah="#e5484d"), huruf="monospace tebal",
    elemen=["jendela terminal", "baris prompt >_ dengan kursor", "kotak OTP", "banner status", "hujan kode samar"],
    gerak=["ketikan huruf demi huruf", "kursor berkedip", "glitch singkat", "status berganti merah lalu hijau"], sfx=["digital", "ritme", "sukses", "gagal"],
    cocok="Reel Tipografi Bergerak", sinyal=["terminal", "hacker", "peretas", "command line", "kode", "password", "keamanan", "login", "cyber"]),
 "CAIR": dict(
    ciri="fluida dan cairan di latar gelap: gradien ungu-biru tua, gumpalan atau gelembung berkilau berisi angka besar dan keterangan kecil, tetesan merah muda, kapsul keterangan semi-transparan dengan kata kunci berlatar ungu.",
    palet=dict(latar="#0d0c21", tengah="#331836", cair="#8a7cb0", aksen="#e86aa6"), huruf="sans tebal membulat",
    elemen=["gumpalan berkilau", "gelembung dan tetesan", "kilap dan pantulan", "kapsul semi-transparan"],
    gerak=["gumpalan berubah bentuk (morph)", "tetesan jatuh dan riak", "mengambang naik turun pelan"], sfx=["muncul", "sapuan", "lucu"],
    cocok="Reel Tipografi Bergerak", sinyal=["liquid", "cair", "air", "darah", "cairan", "fluida", "liter", "tubuh", "biologi"]),
 "FLATLIFE": dict(
    ciri="ilustrasi flat tokoh sehari-hari: latar pastel (krem, hijau muda), tokoh sederhana membawa kotak, grafik batang berblok dengan label harga, kapsul putih dengan kata kunci berlatar merah muda.",
    palet=dict(latar="#d9c5ae", hijau="#cfd1aa", merah="#c0504d", biru="#a5bdc5", ungu="#9d8398"), huruf="sans tebal ramah",
    elemen=["tokoh flat sehari-hari", "kotak dan barang", "grafik batang berblok", "label harga", "kapsul keterangan"],
    gerak=["tokoh memantul dan berjalan", "batang naik bergantian", "barang berpindah tangan"], sfx=["muncul", "sukses", "lucu", "benturan"],
    cocok="Animasi Cerita Berkarakter", sinyal=["flat life illustration", "everyday life", "flatlife", "sehari-hari", "ilustrasi", "harga", "ekonomi", "kehidupan", "orang"]),
 "KLIPING": dict(
    ciri="kolase guntingan koran atau majalah: latar merah muda berpola halftone, potongan kertas bertepi sobek, huruf tempel campur-campur seperti surat kaleng, foto dengan lingkaran penanda, stempel merah (mis. BOHONG), bar hitam sensor, stiker keterangan.",
    palet=dict(latar="#d86a9a", kertas="#e8e2c9", hitam="#2c2423", merah="#d93a2f", kuning="#f2c230"), huruf="campuran: serif, slab, condensed, huruf tempel; tiap kata bisa beda",
    elemen=["kertas sobek", "huruf tempel", "halftone", "stempel", "bar sensor hitam", "foto dengan lingkaran"],
    gerak=["tempel ala stop-motion (8-12 fps, goyang kecil)", "stempel menghantam", "bar sensor menutup kata"], sfx=["benturan", "sapuan", "kaget"],
    cocok="Reel Tipografi Bergerak", sinyal=["clipping", "collage", "kliping", "koran", "majalah", "kolase", "hoaks", "bohong", "berita", "fakta atau hoaks"]),
 "LANTANG": dict(
    ciri="tipografi raksasa: latar hampir hitam, kata putih atau abu sangat tebal dan rapat, angka merah menyala sebesar layar, tanpa dekorasi lain.",
    palet=dict(latar="#0e0d12", putih="#f1efe8", abu="#9b988f", merah="#d63a2f"), huruf="sans atau condensed ekstra tebal, jarak huruf rapat",
    elemen=["kata raksasa", "angka merah raksasa", "garis tipis pemisah", "ruang gelap"],
    gerak=["kata menghantam bergantian", "angka berganti cepat", "pemotongan tepat di ketukan"], sfx=["benturan", "ritme", "kaget"],
    cocok="Reel Tipografi Bergerak", sinyal=["bold typography", "lantang", "tipografi", "kinetic typography", "teks besar", "tahun", "judul", "tegas"]),
 "PETA": dict(
    ciri="visualisasi peta dan lokasi: latar abu-biru pucat, peta wilayah berwarna kuning mustard dengan label wilayah kecil, judul serif dengan kata ditekan (miring, bergaris bawah), skala di sudut kanan atas, pin lokasi, keterangan di kapsul gelap.",
    palet=dict(latar="#b9c3c6", peta="#d9b95a", garis="#5b5b52", aksen="#c0392b", teks="#1f2a30"), huruf="serif editorial untuk judul; monospace kecil untuk label dan skala",
    elemen=["peta wilayah (data asli)", "pin lokasi", "label wilayah", "skala", "garis rute atau jarak"],
    gerak=["kamera menyusur dan zoom", "garis rute menggambar diri", "pin jatuh dan berdenyut"], sfx=["muncul", "sapuan", "sukses"],
    cocok="keduanya", sinyal=["map", "peta", "lokasi", "wilayah", "negara", "pulau", "jarak", "geografi"]),
 "MIDNIGHT": dict(
    ciri="latar navy sangat gelap dengan antarmuka dan diagram: chip kecil seperti SIMULASI atau KALAU BESOK, mockup ponsel dengan daftar notifikasi, judul putih tebal dengan kata kunci kuning dan garis bawah; varian lain berupa pintu-pintu dengan persentase.",
    palet=dict(latar="#0d102f", panel="#161a3c", teks="#f3f1e8", aksen="#e8c75a", merah="#e5484d"), huruf="sans tebal untuk judul; monospace kecil untuk chip",
    elemen=["mockup ponsel atau jendela UI", "daftar notifikasi", "bubble persentase", "pintu atau kartu pilihan", "chip kategori"],
    gerak=["daftar bergulir", "angka naik", "pintu terbuka", "kartu masuk bergantian"], sfx=["digital", "muncul", "sukses"],
    cocok="Reel Tipografi Bergerak", sinyal=["midnight", "dark mode", "simulasi", "kalau besok", "aplikasi", "ponsel", "notifikasi", "peluang", "keputusan", "malam"]),
 "MINIATUR": dict(
    ciri="diorama isometrik seperti miniatur: latar langit pucat, kota atau ruang kecil tiga dimensi semu dengan bangunan, jalan, dan orang kecil, bintang rating atau lencana, keterangan di kapsul gelap dengan kata kunci kuning.",
    palet=dict(latar="#d6cfc4", langit="#8dafb3", atap="#8b6f6f", aksen="#e8c75a", teks="#2b2b2b"), huruf="sans tebal ramah",
    elemen=["lantai atau kota isometrik", "bangunan kecil", "orang kecil", "awan", "bintang rating"],
    gerak=["diorama berputar atau zoom pelan", "bangunan tumbuh dari tanah", "orang kecil berjalan"], sfx=["muncul", "sukses", "lucu"],
    cocok="Animasi Cerita Berkarakter", sinyal=["miniature", "isometric", "miniatur", "diorama", "isometrik", "kota", "3d", "rating", "dunia mini"],
    catatan="isometrik tiga dimensi semu: aturan 0.2 nomor 6 berlaku (coba dulu, nyatakan batas hanya setelah upaya nyata)."),
}
assert len(GAYA) == 13
# Metode penekanan kata (6.9) bawaan tiap gaya, dari cara keterangan di tangkapan layar menyorot kata kunci (latar warna, garis bawah, atau warna huruf).
TEKAN = dict(ARSIP="stabilo", BLUEPRINT="garis", SKETSA="stabilo", GEOMETRIK="warna", HIKAYAT="garis", TERMINAL="warna", CAIR="stabilo", FLATLIFE="stabilo", KLIPING="stabilo", LANTANG="warna", PETA="garis", MIDNIGHT="warna", MINIATUR="stabilo")
assert set(TEKAN) == set(GAYA)

# Kata kunci DUA gaya utama (struktur video). "flat animation" = Animasi Cerita Berkarakter; "showreel" atau "reel" = Reel Tipografi Bergerak. Frasa dicocokkan utuh ("flat animation"), bukan kata "flat" saja,
# karena "flat life illustration" adalah gaya visual FLATLIFE.
KATA_KUNCI_UTAMA = {
    "Animasi Cerita Berkarakter": ["flat animation", "animasi flat", "motion graphic bercerita", "ceritakan", "karakter", "edukasi dengan voice over"],
    "Reel Tipografi Bergerak": ["showreel", "reel", "kinetic typography", "typography animation", "motion design", "teks bergerak", "tanpa karakter", "mengikuti beat"],
}
def pilih_gaya_utama(teks):
    """Cocokkan permintaan ke gaya utama. Tepat satu gaya cocok -> dict(nama, kata); tidak ada atau keduanya cocok -> None (JANGAN menebak: tanya lewat kartu gaya, 0.2)."""
    t = teks.lower(); hit = {n: [k for k in ks if re.search(r"\b" + re.escape(k) + r"\b", t)] for n, ks in KATA_KUNCI_UTAMA.items()}; ada = {n: v for n, v in hit.items() if v}
    return dict(nama=next(iter(ada)), kata=next(iter(ada.values()))) if len(ada) == 1 else None
def daftar_kata_kunci():
    """Salinan daftar kata kunci terbaru (dua gaya utama + 13 gaya visual) untuk ditampilkan ke user di laporan, terutama bila ada yang diganti. -> dict nama -> list."""
    return {**{n: list(k) for n, k in KATA_KUNCI_UTAMA.items()}, **{n: list(g["sinyal"]) for n, g in GAYA.items()}}
def daftar(): return list(GAYA)
def gaya(nama):
    n = nama.strip().upper()
    if n not in GAYA: raise KeyError(f"gaya visual '{nama}' tidak ada. Pilihan: {', '.join(GAYA)}")
    return dict(nama=n, tekan=TEKAN[n], **GAYA[n])
def pilih(teks):
    """Cocokkan permintaan user ke gaya visual. Nama gaya disebut langsung = pasti; tanpa nama, hitung kecocokan kata sinyal. -> dict(nama, alasan) atau None bila tidak ada yang jelas (jangan menebak: pilih sendiri yang paling cocok dengan topik dan SEBUT di kalimat pertama laporan)."""
    t = teks.lower()
    for n in GAYA:
        if re.search(r"\b" + n.lower() + r"\b", t): return dict(nama=n, alasan="disebut langsung oleh user")
    skor = {n: sum(1 for s in g["sinyal"] if re.search(r"\b" + re.escape(s) + r"\b", t)) for n, g in GAYA.items()}
    n, v = max(skor.items(), key=lambda kv: kv[1])
    if v >= 1 and sorted(skor.values())[-2] < v: return dict(nama=n, alasan=f"cocok dengan {v} kata sinyal: " + ", ".join(s for s in GAYA[n]["sinyal"] if re.search(r"\b" + re.escape(s) + r"\b", t)))
    return None
def cek_gaya_utama(nama, gaya_utama):
    """Gaya visual yang dipilih harus bisa dikerjakan dalam gaya utama yang aktif. -> dict(lolos, saran)."""
    g = gaya(nama); ok = g["cocok"] in ("keduanya", gaya_utama)
    return dict(lolos=ok, saran=None if ok else f"{g['nama']} paling cocok dengan {g['cocok']}; dalam {gaya_utama} adaptasi: tetap ambil palet, bahan, dan gerak, tetapi struktur mengikuti gaya utama")
