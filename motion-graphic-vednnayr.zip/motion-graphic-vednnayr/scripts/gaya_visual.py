# gaya_visual.py - Pustaka 13 gaya visual (tampilan) untuk video motion graphic penjelas. Dipakai DI ATAS dua gaya utama (Animasi Cerita Berkarakter dan Reel Tipografi Bergerak): gaya utama menentukan
# STRUKTUR (karakter + cerita, atau tipografi + ketukan), gaya visual menentukan TAMPILAN (palet, bentuk, bahan, gerak, aksen SFX).
# Sumber: (1) tangkapan layar halaman Motion Graphics kreatorlab.id dari user, lalu (2) 15 video contoh dari user (folder Example-Vid, 720x1280, 60 fps, 55-80 detik, semuanya bersuara dan berketerangan),
# dilihat 2026-11-08 lewat 18 frame per video (satu frame tiap 3-4 detik) dari tiap video. Yang sudah dilihat: palet, bahan, tata letak, bentuk keterangan, dan alur adegan. Yang BELUM dinilai: gerak antar-frame, easing, dan
# audio (musik, SFX, suara narator), karena Claude tidak bisa mendengar dan hanya melihat frame diam; bagian gerak di bawah tetap penafsiran. Bagian _KOREKSI di bawah menimpa deskripsi dari tangkapan layar dengan hasil melihat video.
import re

GAYA_UTAMA = ("Animasi Cerita Berkarakter", "Reel Tipografi Bergerak")
# Ciri bersama semua contoh: (1) keterangan (caption) di bawah berupa kapsul dengan KATA KUNCI disorot warna; (2) chip label kecil di sudut (kategori, "SIMULASI", "FAKTA & ANGKA");
# (3) satu ide besar per adegan dengan banyak ruang kosong; (4) angka atau objek utama sangat besar. Penekanan kata mengikuti 6.9.

GAYA = {
 "ARSIP": dict(
    ciri="kalender dan dokumen cetak usang: halaman kalender krem miring dengan kepala merah dan lingkaran merah gambar tangan di satu angka, stempel merah di sudut, keterangan di strip kertas dengan huruf mesin tik.",
    palet=dict(latar="#1d1917", kertas="#c0bbb5", aksen="#c0392b", teks="#2a211c"), huruf="mesin tik atau monospace tebal untuk keterangan; serif tebal untuk judul bulan atau tahun",
    elemen=["halaman kalender", "stempel", "lingkaran penanda gambar tangan", "serat dan lipatan kertas", "bayangan jatuh lembut"],
    gerak=["kertas jatuh dan miring masuk", "stempel menghantam (skala besar ke normal)", "lingkaran digambar bertahap", "angka disorot"], sfx=["benturan", "muncul", "sapuan"],
    cocok="Reel Tipografi Bergerak", sinyal=["archive", "arsip", "kalender", "dokumen", "tanggal", "sejarah", "stempel", "kertas usang"]),
 "BLUEPRINT": dict(
    ciri="cetak biru teknik: latar biru tua berkisi tipis, gambar garis putih-biru muda (lingkaran, garis dimensi, panah, label kecil monospace seperti penanda lantai atau kabel), keterangan di kotak gelap bersudut membulat.",
    palet=dict(latar="#0c315e", garis="#8fb4d9", aksen="#6fcf97", teks="#e8f1fb"), huruf="monospace tipis untuk anotasi; sans bersih untuk keterangan",
    elemen=["kisi", "garis dimensi dan panah", "lingkaran dan penampang", "label anotasi kecil", "bingkai gambar teknik"],
    gerak=["garis digambar bertahap (draw-on)", "angka dimensi bertambah", "anotasi muncul satu per satu", "zoom pelan ke detail"], sfx=["digital", "ritme", "muncul"],
    cocok="Reel Tipografi Bergerak", sinyal=["blueprint", "cetak biru", "teknik", "mesin", "arsitektur", "cara kerja", "lift", "rancangan"]),
 "SKETSA": dict(
    ciri="buku catatan bergaris dengan gambar tangan: tokoh stik dan lampu dengan kerucut cahaya kuning, judul tulisan tangan dengan stabilo kuning, tag kecil hijau (mis. nama topik), keterangan tulisan tangan.",
    palet=dict(latar="#c7c4bf", garis="#2b2b2b", aksen="#f4d03f", tag="#7bb661", teks="#2b2b2b"), huruf="tulisan tangan untuk judul dan keterangan; garis tidak rata",
    elemen=["kertas bergaris", "tokoh stik", "kerucut cahaya", "stabilo", "tag topik", "panah dan lingkaran coretan"],
    gerak=["coretan digambar bertahap dengan goyangan kecil", "stabilo menyapu kata", "tokoh stik bergerak sederhana"], sfx=["muncul", "sapuan", "lucu"],
    cocok="Animasi Cerita Berkarakter", sinyal=["sketch", "sketsa", "gambar tangan", "coretan", "buku catatan", "psikologi", "doodle"]),
 "GEOMETRIK": dict(
    ciri="angka atau bentuk geometris raksasa: latar abu terang, angka hitam sangat tebal di atas lingkaran kuning mustard, chip label kecil di bawah dan teks kecil di sudut (mis. kategori fakta), elemen sangat sedikit.",
    palet=dict(latar="#dedbd5", hitam="#2f2717", aksen="#d4b13e", chip="#d2ec62"), huruf="sans hitam ekstra tebal dan rapat untuk angka; monospace kecil untuk label",
    elemen=["angka raksasa", "lingkaran atau bentuk dasar", "chip label", "ruang kosong lebar"],
    gerak=["angka naik hitung (count-up)", "lingkaran tumbuh", "angka menghantam masuk", "potongan di ketukan"], sfx=["benturan", "sukses", "ritme"],
    cocok="Reel Tipografi Bergerak", sinyal=["geometric", "geometrik", "angka", "statistik", "fakta dan angka", "persen", "bentuk dasar"]),
 "HIKAYAT": dict(
    ciri="siluet cerita rakyat atau sejarah: gradien oranye sampai cokelat tua seperti sepia, siluet gaya wayang kulit dan gunung berlapis berlubang, label kecil bertema (mis. LEGENDA), keterangan di kapsul emas.",
    palet=dict(latar="#1b0e0b", tengah="#ac733b", cahaya="#e0b060", aksen="#c2ab50"), huruf="serif atau display berkarakter untuk judul; keterangan di kapsul emas",
    elemen=["siluet wayang kulit", "gunung berlapis berpola lubang", "cahaya hangat dari belakang", "ombak atau awan bergaris", "label bertema"],
    gerak=["paralaks lapisan", "siluet melayang pelan", "cahaya berdenyut halus"], sfx=["tegang", "sapuan", "muncul"],
    cocok="Animasi Cerita Berkarakter", sinyal=["silhouette", "history", "hikayat", "legenda", "dongeng", "cerita rakyat", "wayang", "siluet", "sejarah", "mitos"]),
 "TERMINAL": dict(
    ciri="antarmuka baris perintah ala peretas: latar hampir hitam, teks hijau terminal monospace, jendela berbingkai (merah atau hijau), kotak kode OTP, banner hijau seperti ACCESS GRANTED, baris prompt dengan kursor, hujan kode samar.",
    palet=dict(latar="#0b0c11", hijau="#59b458", terang="#7dff7d", merah="#e5484d"), huruf="monospace tebal",
    elemen=["jendela terminal", "baris prompt >_ dengan kursor", "kotak OTP", "banner status", "hujan kode samar"],
    gerak=["ketikan huruf demi huruf", "kursor berkedip", "glitch singkat", "status berganti merah lalu hijau"], sfx=["digital", "ritme", "sukses", "gagal"],
    cocok="Reel Tipografi Bergerak", sinyal=["terminal", "hacker", "peretas", "command line", "kode", "password", "keamanan", "login", "cyber"]),
 "CAIR": dict(
    ciri="fluida dan cairan di latar gelap: gradien ungu-biru tua, gumpalan atau gelembung berkilau berisi angka besar dan keterangan kecil, tetesan merah muda, kapsul keterangan semi-transparan dengan kata kunci berlatar ungu.",
    palet=dict(latar="#0d0c21", tengah="#331836", cair="#8a7cb0", aksen="#e86aa6"), huruf="sans tebal membulat",
    elemen=["gumpalan berkilau", "gelembung dan tetesan", "kilap dan pantulan", "kapsul semi-transparan"],
    gerak=["gumpalan berubah bentuk (morph)", "tetesan jatuh dan riak", "mengambang naik turun pelan"], sfx=["muncul", "sapuan", "lucu"],
    cocok="Reel Tipografi Bergerak", sinyal=["liquid", "cair", "air", "darah", "cairan", "fluida", "liter", "tubuh", "biologi"]),
 "FLATLIFE": dict(
    ciri="ilustrasi flat tokoh sehari-hari: latar pastel (krem, hijau muda), tokoh sederhana membawa kotak, grafik batang berblok dengan label harga, kapsul putih dengan kata kunci berlatar merah muda.",
    palet=dict(latar="#d9c5ae", hijau="#cfd1aa", merah="#c0504d", biru="#a5bdc5", ungu="#9d8398"), huruf="sans tebal ramah",
    elemen=["tokoh flat sehari-hari", "kotak dan barang", "grafik batang berblok", "label harga", "kapsul keterangan"],
    gerak=["tokoh memantul dan berjalan", "batang naik bergantian", "barang berpindah tangan"], sfx=["muncul", "sukses", "lucu", "benturan"],
    cocok="Animasi Cerita Berkarakter", sinyal=["flat life illustration", "everyday life", "flatlife", "sehari-hari", "ilustrasi", "harga", "ekonomi", "kehidupan", "orang"]),
 "KLIPING": dict(
    ciri="kolase guntingan koran atau majalah: latar merah muda berpola halftone, potongan kertas bertepi sobek, huruf tempel campur-campur seperti surat kaleng, foto dengan lingkaran penanda, stempel merah (mis. BOHONG), bar hitam sensor, stiker keterangan.",
    palet=dict(latar="#d86a9a", kertas="#e8e2c9", hitam="#2c2423", merah="#d93a2f", kuning="#f2c230"), huruf="campuran: serif, slab, condensed, huruf tempel; tiap kata bisa beda",
    elemen=["kertas sobek", "huruf tempel", "halftone", "stempel", "bar sensor hitam", "foto dengan lingkaran"],
    gerak=["tempel ala stop-motion (8-12 fps, goyang kecil)", "stempel menghantam", "bar sensor menutup kata"], sfx=["benturan", "sapuan", "kaget"],
    cocok="Reel Tipografi Bergerak", sinyal=["clipping", "collage", "kliping", "koran", "majalah", "kolase", "hoaks", "bohong", "berita", "fakta atau hoaks"]),
 "LANTANG": dict(
    ciri="tipografi raksasa: latar hampir hitam, kata putih atau abu sangat tebal dan rapat, angka merah menyala sebesar layar, tanpa dekorasi lain.",
    palet=dict(latar="#0e0d12", putih="#f1efe8", abu="#9b988f", merah="#d63a2f"), huruf="sans atau condensed ekstra tebal, jarak huruf rapat",
    elemen=["kata raksasa", "angka merah raksasa", "garis tipis pemisah", "ruang gelap"],
    gerak=["kata menghantam bergantian", "angka berganti cepat", "pemotongan tepat di ketukan"], sfx=["benturan", "ritme", "kaget"],
    cocok="Reel Tipografi Bergerak", sinyal=["bold typography", "lantang", "tipografi", "kinetic typography", "teks besar", "tahun", "judul", "tegas"]),
 "PETA": dict(
    ciri="visualisasi peta dan lokasi: latar abu-biru pucat, peta wilayah berwarna kuning mustard dengan label wilayah kecil, judul serif dengan kata ditekan (miring, bergaris bawah), skala di sudut kanan atas, pin lokasi, keterangan di kapsul gelap.",
    palet=dict(latar="#b9c3c6", peta="#d9b95a", garis="#5b5b52", aksen="#c0392b", teks="#1f2a30"), huruf="serif editorial untuk judul; monospace kecil untuk label dan skala",
    elemen=["peta wilayah (data asli)", "pin lokasi", "label wilayah", "skala", "garis rute atau jarak"],
    gerak=["kamera menyusur dan zoom", "garis rute menggambar diri", "pin jatuh dan berdenyut"], sfx=["muncul", "sapuan", "sukses"],
    cocok="keduanya", sinyal=["map", "peta", "lokasi", "wilayah", "negara", "pulau", "jarak", "geografi"]),
 "MIDNIGHT": dict(
    ciri="latar navy sangat gelap dengan antarmuka dan diagram: chip kecil seperti SIMULASI atau KALAU BESOK, mockup ponsel dengan daftar notifikasi, judul putih tebal dengan kata kunci kuning dan garis bawah; varian lain berupa pintu-pintu dengan persentase.",
    palet=dict(latar="#0d102f", panel="#161a3c", teks="#f3f1e8", aksen="#e8c75a", merah="#e5484d"), huruf="sans tebal untuk judul; monospace kecil untuk chip",
    elemen=["mockup ponsel atau jendela UI", "daftar notifikasi", "bubble persentase", "pintu atau kartu pilihan", "chip kategori"],
    gerak=["daftar bergulir", "angka naik", "pintu terbuka", "kartu masuk bergantian"], sfx=["digital", "muncul", "sukses"],
    cocok="Reel Tipografi Bergerak", sinyal=["midnight", "dark mode", "simulasi", "kalau besok", "aplikasi", "ponsel", "notifikasi", "peluang", "keputusan", "malam"]),
 "MINIATUR": dict(
    ciri="diorama isometrik seperti miniatur: latar langit pucat, kota atau ruang kecil tiga dimensi semu dengan bangunan, jalan, dan orang kecil, bintang rating atau lencana, keterangan di kapsul gelap dengan kata kunci kuning.",
    palet=dict(latar="#d6cfc4", langit="#8dafb3", atap="#8b6f6f", aksen="#e8c75a", teks="#2b2b2b"), huruf="sans tebal ramah",
    elemen=["lantai atau kota isometrik", "bangunan kecil", "orang kecil", "awan", "bintang rating"],
    gerak=["diorama berputar atau zoom pelan", "bangunan tumbuh dari tanah", "orang kecil berjalan"], sfx=["muncul", "sukses", "lucu"],
    cocok="Animasi Cerita Berkarakter", sinyal=["miniature", "isometric", "miniatur", "diorama", "isometrik", "kota", "3d", "rating", "dunia mini"],
    catatan="isometrik tiga dimensi semu: aturan 0.2 nomor 6 berlaku (coba dulu, nyatakan batas hanya setelah upaya nyata)."),
}
assert len(GAYA) == 13
# ---- KOREKSI hasil melihat 15 video contoh (2026-11-08). Menimpa ciri/palet dari tangkapan layar; menambah `video` (berkas contoh) dan `subtitle` (bentuk keterangan dan cara kata disorot).
# Pemetaan video ke gaya: arsip, blueprint, cair, flatlife, geometrik, hikayat, kliping, lantang, peta, sketsa, terminal = gaya yang sama namanya.
# MIDNIGHT = peluang + stalking (latar navy, seri "Kalau Besok · Simulasi"); MINIATUR = rating + demo-tiktok (diorama isometrik, seri yang sama). Pemetaan empat video terakhir adalah KESIMPULAN dari tampilan, bukan label resmi.
SUBTITLE_UMUM = ("Semua contoh memakai keterangan satu kalimat di bagian bawah (sekitar 12 persen dari bawah layar) dengan TIGA keadaan kata: kata yang sedang diucapkan disorot (warna atau latar), "
                 "kata yang sudah diucapkan tampil normal, kata yang belum diucapkan REDUP (abu atau transparan). Bentuk kapsul dan warna sorot mengikuti gaya. Catatan: aturan user untuk subtitle ('Kopi hangat') menyebut kata lain putih; "
                 "contoh referensi membuat kata yang belum diucapkan redup. Pilihan bawaan skill tetap aturan user; redup hanya bila user memintanya.")
_KOREKSI = {
 "ARSIP": dict(video="galeri-mograph-arsip.mp4 (bahasan: kenapa Februari 28 hari)",
    ciri="meja investigasi: papan kraft cokelat dengan foto tersangka berupa siluet hitam (polaroid, pin merah, benang merah), kalender krem berkepala merah, gulungan perkamen, kliping koran berjudul serif, kartu tulisan mesin tik, stempel merah miring (SIAL, MITOS, DIRAMPOK, HABIS), pembuka berupa map kraft di latar hampir hitam, chip merah kecil di kanan atas.",
    palet=dict(latar="#1d1917", papan="#b07a45", kertas="#efe6d2", aksen="#c0392b", teks="#2a211c", sorot="#f4d03f"),
    subtitle="strip kertas sobek berhuruf mesin tik; kata aktif diberi stabilo kuning, kata belum terucap redup"),
 "BLUEPRINT": dict(video="galeri-mograph-blueprint.mp4 (bahasan: cara kerja lift)",
    ciri="gambar teknik di kertas biru berkisi: potongan lift, kabel, bobot, penampang kabel, panel 'DETAIL A/B/C' berbingkai, label lantai LT 3/4/5, garis anotasi bernomor, pegas, tokoh orang berupa garis putih; kotak peringatan kuning atau merah muncul di momen penting; judul lembar kecil di atas.",
    palet=dict(latar="#0c315e", garis="#8fb4d9", aksen="#f4c430", bahaya="#e5484d", teks="#e8f1fb"),
    subtitle="kotak bersudut siku (bracket) di bawah, huruf monospace; kata aktif kuning dengan garis bawah, kata belum terucap redup"),
 "SKETSA": dict(video="galeri-mograph-sketsa.mp4 (bahasan: Spotlight Effect, psikologi)",
    ciri="halaman buku catatan krem bergaris dengan margin merah: tokoh stik berjambul merah, lampu gantung dengan kerucut cahaya kuning, awan pikiran, eksperimen (labu kimia), judul tulisan tangan dengan stabilo kuning dan garis merah, tag hijau 'PSIKOLOGI' di kanan atas, nomor halaman kecil di kanan bawah, lipatan kertas saat pindah bagian.",
    palet=dict(latar="#f3edda", garis="#2b2b2b", aksen="#f4d03f", tag="#a8d8b0", merah="#e8735a", biru="#4a7bd0", teks="#2b2b2b"),
    subtitle="teks tulisan tangan polos di bawah (tanpa kapsul); kata aktif ber-stabilo kuning, kata belum terucap redup"),
 "GEOMETRIK": dict(video="galeri-mograph-geometrik.mp4 (bahasan: aturan 72, bunga berbunga, inflasi)",
    ciri="Bauhaus: latar krem berkisi tipis, lingkaran kuning, kotak merah dan biru, angka hitam ekstra tebal raksasa, grafik batang berblok, panah putih di atas latar merah penuh, bagian layar terbelah biru dan merah; judul kecil kondensed tebal di kiri atas; chip 'FAKTA & ANGKA' di kanan atas.",
    palet=dict(latar="#efece2", hitam="#111111", kuning="#f5c11a", merah="#e23e2c", biru="#1f45a8", teks="#111111"),
    subtitle="kapsul hitam persegi; kata aktif berlatar kuning bertinta hitam, kata belum terucap redup"),
 "HIKAYAT": dict(video="galeri-mograph-hikayat.mp4 (bahasan: legenda Danau Toba lalu sains letusan Toba)",
    ciri="teater bayangan wayang: langit gradien oranye ke cokelat tua, siluet berlubang-lubang kecil (pola titik) untuk tokoh, rumah adat, ikan, gunung berlapis, matahari atau bulan bulat berpola; tokoh bertangan batang tipis seperti wayang kulit; plakat judul krem bertepi emas di atas (mis. LEGENDA, SAINS); adegan gelap saat bencana, hujan garis tipis.",
    palet=dict(latar="#1b0e0b", tengah="#ac733b", cahaya="#e8b45f", plakat="#e9d8ae", aksen="#c9532b"),
    subtitle="plakat krem bertepi emas dengan huruf serif; kata aktif berwarna oranye-merah, kata belum terucap redup"),
 "TERMINAL": dict(video="galeri-mograph-terminal.mp4 (bahasan: penipuan kode OTP)",
    ciri="layar peretas: latar hitam dengan hujan kode samar, bingkai ponsel garis hijau neon berpendar, jendela terminal bertajuk (hijau untuk korban, merah-pink untuk penyerang), kotak OTP angka amber, ikon gembok, banner hijau besar ACCESS GRANTED, daftar aturan bertanda silang dalam kotak amber; status kecil di sudut ('kamu@hp:~$', 'EDUKASI · KEAMANAN').",
    palet=dict(latar="#06090a", hijau="#3ddc84", terang="#7dff7d", amber="#f0a030", bahaya="#ff3b6b", teks="#d8ffe0"),
    subtitle="baris perintah di bawah diawali '>' dengan kursor blok; kata aktif berupa blok hijau terang bertinta gelap, kata belum terucap redup"),
 "CAIR": dict(video="galeri-mograph-cair.mp4 (bahasan: ginjal menyaring 180 liter per hari)",
    ciri="latar gradien ungu-biru tua dengan bercak cahaya, kapsul judul kaca semi-transparan di atas, objek berbahan kaca (botol, tabung reaksi, ginjal, gelas) berisi cairan ungu, merah muda, atau biru dengan permukaan bergelombang, tetesan dan titik partikel, angka raksasa di panel kaca, satu adegan penuh gradien ungu-pink untuk kejutan.",
    palet=dict(latar="#0d0c21", tengah="#331836", cair="#8a7cb0", aksen="#e86aa6", biru="#3fd0ff", kuning="#ffd166"),
    subtitle="kapsul gelap semi-transparan; kata aktif berlatar gradien pink-ungu bertinta putih, kata belum terucap redup"),
 "FLATLIFE": dict(video="galeri-mograph-flatlife.mp4 (bahasan: efek IKEA)",
    ciri="ilustrasi flat bergaya karakter: tokoh bernama (Dimas) berkulit hangat berbaju hijau teal, perabot dan benda sehari-hari (rak buku, jam, kotak), lingkaran latar besar berwarna lembut di belakang tokoh, latar solid berganti per adegan (krem, ungu, kuning, navy dengan sorot lampu), panel terbelah dua untuk perbandingan, balok harga dengan label, bintik dan tanda plus kecil sebagai dekorasi, ekspresi wajah jelas (senang, kesal, bingung).",
    palet=dict(latar="#fbf1e0", teal="#1fa38a", koral="#ff6b57", ungu="#8b7be8", navy="#1f2a56", kuning="#ffc93c", biru="#bfe3f0"),
    subtitle="kapsul putih bulat; kata aktif berlatar koral atau kuning bertinta putih atau gelap, kata belum terucap redup"),
 "KLIPING": dict(video="galeri-mograph-kliping.mp4 (bahasan: kenapa hoaks cepat menyebar)",
    ciri="kolase kertas: latar penuh warna jenuh yang berganti per adegan (biru, pink, kuning, merah, hijau mint, hitam, krem koran), halftone titik, potongan kertas bertepi sobek, huruf tempel campur gaya seperti surat kaleng, stiker bintang berisi kata (BARU!, TAHAN!), stempel miring, foto siluet dengan lingkaran spidol merah, tokoh kecil bersiluet, ponsel dengan grup chat, kartu pers, gunting dan jam di tepi.",
    palet=dict(latar="#2f4bff", pink="#ff7eb6", kuning="#f1b400", merah="#e8402a", hijau="#4cc9a0", hitam="#141414", kertas="#f2ecd9"),
    subtitle="label putih bertepi sobek di bawah dengan huruf tulisan tangan; kata aktif ber-stabilo kuning, kata belum terucap redup"),
 "LANTANG": dict(video="galeri-mograph-lantang.mp4 (bahasan: Hukum Parkinson)",
    ciri="tipografi kinetik murni: latar berganti tegas antara krem, hitam, oranye menyala, dan biru; kata ekstra tebal dan lebar (extended black) memenuhi layar, kata outline, blok warna di belakang kata (label miring biru dan putih), daftar baris dengan batang oranye bertumbuh, penghitung angka besar, teks terpotong atau tersambung; chip judul kecil di kiri atas. TIDAK memakai kapsul keterangan di bawah: teks di layar adalah narasinya.",
    palet=dict(krem="#f1eee6", hitam="#0c0c0c", oranye="#ff4d1a", biru="#2d4cff", teks="#0c0c0c"),
    subtitle="tidak ada keterangan terpisah; kata muncul dan dipotong tepat di ketukan sebagai bagian dari tipografi"),
 "PETA": dict(video="galeri-mograph-peta.mp4 (bahasan: Garis Wallace)",
    ciri="peta editorial: laut biru-abu pucat berkisi halus, daratan krem, dataran dangkal berwarna lebih muda, wilayah ditandai warna (biru kelabu untuk Asia, oranye untuk Australia, kuning untuk Bali dan Lombok), satu garis merah tipis bergerak sebagai batas, pin merah, lencana hewan bulat bergaris, judul serif besar dengan kata ditekan warna, kartu putih untuk tokoh atau fakta, skala dan panah utara di kanan atas, kamera menyusur dan zoom keluar dari selat sampai satu benua.",
    palet=dict(latar="#c7d9dc", daratan="#e6ddc8", asia="#7f9bb0", australia="#e7a98a", aksen="#e23d2a", kuning="#f2c94c", teks="#1f2a30"),
    subtitle="kapsul gelap bersudut kecil; kata aktif berwarna kuning, kata belum terucap redup"),
 "MIDNIGHT": dict(video="galeri-mograph-peluang.mp4 dan galeri-mograph-stalking.mp4 (seri 'Kalau Besok · Simulasi')",
    ciri="latar navy gelap dengan angka dan persen raksasa samar di belakang: pintu-pintu 3D krem berpersentase, kartu antarmuka (lowongan, notifikasi, daftar pengunjung), ponsel layar kunci dengan notifikasi, lingkaran progres kuning, ratusan titik orang kecil memenuhi layar saat 'semua orang', bubble komentar, tombol pilihan besar (PANIK atau PENASARAN); chip 'SIMULASI' di kiri atas dan 'Dunia Nabel · Kalau Besok' di kanan atas; sebagian adegan berganti latar kuning, krem, atau pink untuk kontras.",
    palet=dict(latar="#0b1040", panel="#161a3c", teks="#f3f1e8", aksen="#f2c94c", merah="#ff5a5f", krem="#efe4c8"),
    subtitle="teks putih polos di bawah (tanpa kapsul) pada latar gelap, atau kapsul gelap pada latar terang; kata aktif kuning, kata belum terucap redup"),
 "MINIATUR": dict(video="galeri-mograph-rating.mp4 dan galeri-mograph-demo-tiktok.mp4 (seri 'Kalau Besok · Simulasi')",
    ciri="diorama isometrik pulau melayang: ubin berpetak krem dan rumput hijau, rumah dan gedung warna-warni, pohon bulat, tokoh kecil dengan pelat nama, bubble bintang rating (kuning tinggi, merah rendah), awan; latar langit pastel yang berpindah dari siang biru ke senja jingga-ungu lalu malam navy seiring cerita; kamera turun dan naik antar pulau, sampai menampilkan banyak pulau sekaligus; adegan demo memakai kota isometrik dengan ponsel di tengah dan latar peach, kuning, atau navy.",
    palet=dict(latar="#9fd3ea", rumput="#7cc35a", ubin="#f2e6cf", senja="#f4a582", malam="#171a4a", aksen="#f2c94c", merah="#e5484d"),
    subtitle="kapsul gelap di bawah; kata aktif kuning, kata belum terucap redup"),
}
for _n, _k in _KOREKSI.items(): GAYA[_n].update(_k)
assert set(_KOREKSI) == set(GAYA)

# ---- DETAIL KECIL hasil pemeriksaan ulang frame contoh (2026-11-09): frame penuh dan potongan keterangan diperbesar 1,5-2x untuk 15 video. Ini PENGAMATAN dari gambar diam (bentuk, bahan, warna, huruf);
# nama font adalah identifikasi TERDEKAT dari bentuk huruf (bukan label resmi) dan semuanya berkas nyata di fonts/ (OFL). Gerak dan audio tetap belum dinilai.
# Tiap gaya: `subtitle_spek` (bahan kotak, huruf, tiga keadaan kata), `detail` (hal kecil yang sering terlewat), `gradien` (isi elemen, bagian 6.12), `stempel` (bahan stempel, bagian 6.11).
# Subtitle jadi lewat subtitle_gaya.caption(nama_gaya, kata, aktif); stempel lewat stempel.stempel(kata, nama_gaya, latar=...).
_DETAIL = {
    "KLIPING": dict(
        subtitle_spek="strip kertas putih-krem lecek, tepi atas dan bawah sobek bergerigi, miring sekitar 1 derajat, bayangan lembut; huruf spidol tulisan tangan miring (Kalam Bold; BUKAN Caveat Brush); kata SEDANG diucapkan = stabilo kuning di setengah bawah kata dengan huruf hitam, kata sudah = hitam, kata belum = abu terang",
        detail=["strip kertas tidak persegi: tepi sobek, sedikit miring, tebal bayangan kecil", "stabilo kuning hanya menutup setengah bawah kata dan tidak rata, bukan kotak penuh", "latar jenuh berganti tiap adegan (biru, merah muda, kuning, merah, hijau, hitam) dengan pola halftone", "huruf tempel campur-campur ala surat kaleng, tiap huruf di ubin warna berbeda dengan tepi putih tipis", "stempel merah bertinta tidak rata, label putih sobek, stiker"],
        gradien="kertas krem terang ke krem gelap; ubin huruf, stiker, label, dan batang grafik semuanya bergradien turunan palet (terang atas, dalam bawah), bukan satu warna; latar jenuh boleh bergradien lembut dengan halftone di atasnya",
        stempel="tinta karet bingkai ganda, bercak aus, tekanan tidak rata; miring sekitar -9 derajat"),
    "ARSIP": dict(
        subtitle_spek="strip kertas krem-kecokelatan bertepi sobek lebih tidak rata, huruf mesin tik tebal (CourierPrime Bold); kata aktif = stabilo kuning kotak penuh, sudah = hitam, belum = cokelat-abu",
        detail=["latar kardus atau papan gabus cokelat gelap dengan tepi menggelap", "foto polaroid bersama selotip dan pin merah dengan benang", "stempel merah miring bertinta (contoh: kata vonis pendek) dan lingkaran merah gambar tangan di kalender", "kalender krem miring berkepala merah", "label sudut kecil bergaya stempel (mis. BERKAS)"],
        gradien="kertas dan foto bergradien krem ke cokelat muda dengan serat; kepala kalender merah bergradien; benang dan pin punya sorot terang",
        stempel="tinta karet merah tema; miring sekitar -9 derajat"),
    "BLUEPRINT": dict(
        subtitle_spek="kotak navy 94 persen dengan garis tepi biru dan SUDUT SIKU cyan di empat sudut (corner bracket), huruf mono semitebal (IBM Plex Mono SemiBold) (IBMPlexMono Bold); aktif = kuning dengan garis bawah tebal, sudah = putih, belum = biru-abu",
        detail=["kisi tipis dua tingkat (mayor dan minor) di latar", "header kecil mono di sudut (nama proyek, LEMBAR 01/02)", "kotak callout garis kuning dengan panah dan garis dimensi", "gambar hanya garis putih-biru muda, tanpa isi warna", "kotak merah kecil untuk skenario atau peringatan"],
        gradien="latar navy bergradien vertikal tipis; garis dan kotak isi (callout, label) bergradien biru; garis gambar boleh memudar di ujung",
        stempel="garis teknik: bingkai ganda dengan tanda silang sudut, huruf mono, tanpa tekstur karet"),
    "SKETSA": dict(
        subtitle_spek="tanpa kotak: hanya pendar kertas lembut di belakang tulisan tangan (PatrickHand); aktif = stabilo kuning kotak sedikit tidak rata, sudah = hitam kebiruan, belum = abu-biru",
        detail=["buku catatan bergaris biru pucat dengan garis margin merah", "nomor halaman kecil di sudut (hal. N)", "tag miring hijau berisi nama topik", "tokoh stik dan lampu dengan kerucut cahaya kuning", "judul tulisan tangan berstabilo kuning"],
        gradien="kertas krem bergradien tipis dan bertekstur; kerucut cahaya kuning memudar; tag hijau dan stabilo bergradien halus",
        stempel="spidol tangan: bingkai bergoyang dua putaran dan huruf tulisan tangan"),
    "GEOMETRIK": dict(
        subtitle_spek="kotak hitam siku TANPA sudut membulat, huruf sans geometris ekstra tebal (PlusJakartaSans 800); aktif = kotak kuning dengan huruf hitam, sudah = putih, belum = abu",
        detail=["angka hitam raksasa di atas lingkaran kuning mustard", "chip label kecil di bawah dan teks kecil di sudut (FAKTA & ANGKA dengan bujur sangkar merah dan titik kuning)", "elemen sangat sedikit, banyak ruang kosong"],
        gradien="referensi tampak datar, tetapi aturan 6.12 tetap berlaku: lingkaran dan blok bergradien halus (selisih terang 8-12 persen) dan bayangan tipis supaya tetap bersih namun tidak satu warna mati",
        stempel="blok label bergradien dengan huruf condensed tebal, miring ringan"),
    "HIKAYAT": dict(
        subtitle_spek="kapsul perkamen-emas bergradien vertikal (krem terang ke emas tua) dengan pantulan di atas, cincin tipis, bayangan lembut; huruf serif tua tebal sedang (EB Garamond Bold) dan judul kapital Cinzel Bold; aktif = oranye-merah, sudah = cokelat tua, belum = cokelat pudar",
        detail=["plakat judul dari perkamen/kulit: gradien vertikal, bercak kulit tidak rata, serat horizontal halus, DUA PAKU bulat di ujung, huruf kapital serif tebal berjarak lebar (subtitle_gaya.plakat_hikayat)", "siluet bergaya wayang kulit dengan lubang-lubang kecil berseling yang menyala hangat dan gapit (batang) tipis ke bawah", "gunung berlapis berlubang, pita ombak, vignette gelap di tepi", "cakram matahari besar dengan pendar radial", "chip kategori kecil (LEGENDA, SAINS) berbentuk kapsul perkamen dengan dua titik"],
        gradien="langit oranye ke cokelat sepia (radial), perkamen bergradien dengan bercak, siluet dengan sorot hangat di balik lubang; tidak ada bidang cokelat rata",
        stempel="timbul: kartus perkamen-emas dengan huruf serif cokelat-merah tema yang menonjol (seperti segel)"),
    "TERMINAL": dict(
        subtitle_spek="kotak hampir hitam bertepi hijau 2 px dengan pendar, prompt `>` di kiri, huruf mono tebal, kursor blok di ujung; aktif = BLOK hijau penuh bergaris pindai dengan huruf gelap, sudah = hijau terang, belum = hijau gelap",
        detail=["hujan kode samar di latar", "jendela berbingkai merah atau hijau dengan bilah judul", "banner status besar (ACCESS GRANTED / DENIED) dan kotak kode OTP", "teks hijau dengan glow tipis, garis pindai halus"],
        gradien="glow hijau memudar di tepi jendela; isi blok bergradien hijau muda ke hijau tua; banner merah atau hijau bergradien dengan garis pindai",
        stempel="garis teknik hijau atau merah: bingkai ganda ala banner status, huruf mono"),
    "CAIR": dict(
        subtitle_spek="kapsul KACA buram: isi putih sekitar 17 persen bergradien ungu muda, tepi terang tipis, pendar bawah; huruf sans bulat dengan a satu lantai (Outfit SemiBold); aktif = PIL GRADIEN merah muda ke ungu dengan huruf putih, sudah = putih, belum = putih 38 persen",
        detail=["gumpalan dan gelembung berkilau berisi angka besar dan keterangan kecil", "latar gradien ungu-navy dengan pendar (blob) lembut", "tetesan merah muda", "kartu kaca dengan tepi terang"],
        gradien="semua elemen bergradien: cairan, gelembung (radial dengan sorot), kapsul kaca, pil kata aktif; ini gaya paling gradien di seluruh pustaka",
        stempel="kaca: kapsul bergradien warna tema dengan tepi putih dan huruf putih"),
    "FLATLIFE": dict(
        subtitle_spek="kapsul putih sangat bulat dengan bayangan, huruf sans bulat tebal dengan a satu lantai (Outfit Bold); aktif = pil koral bergradien dengan huruf putih, sudah = navy, belum = abu",
        detail=["latar pastel (krem, hijau muda)", "tokoh sederhana membawa kotak", "grafik batang berblok dengan label harga", "tekstur sangat sedikit, bentuk bersih"],
        gradien="bentuk flat tetap diberi gradien lembut dan sorot atas; batang grafik berwarna bergradien, bukan blok satu warna",
        stempel="blok label bergradien, sudut siku, huruf condensed"),
    "LANTANG": dict(
        subtitle_spek="contoh TIDAK memakai kotak subtitle: tipografi raksasa itu sendiri adalah narator; bila subtitle diminta: huruf Archivo ExtraCondensed Black dengan jarak antarhuruf rapat (alt Anton) putih tanpa kotak, aktif = oranye menyala, belum = abu",
        detail=["header kecil dengan garis kemajuan tipis di atas", "latar blok warna penuh bergantian (hitam, oranye menyala, biru, krem)", "kata putih sangat tebal dan rapat, angka seukuran layar, teks kontur", "tanpa dekorasi lain"],
        gradien="blok warna boleh bergradien halus; huruf raksasa berwarna bergradien turunan; teks putih tetap putih",
        stempel="blok label bergradien dengan huruf condensed"),
    "PETA": dict(
        subtitle_spek="kotak slate 90 persen bersudut kecil (radius sekitar 4), huruf sans condensed (BarlowCondensed SemiBold); aktif = kuning, sudah = putih, belum = abu",
        detail=["tanda kecil merah `— NAMA TOPIK` di atas, panah utara, skala di sudut", "peta kuning mustard dengan label wilayah kecil", "judul serif dengan kata ditekan miring dan bergaris bawah", "latar abu-biru pucat"],
        gradien="peta mustard bergradien (terang di tengah, dalam di tepi); laut bergradien tipis; pin dengan sorot",
        stempel="blok label bergradien bersudut siku"),
    "MIDNIGHT": dict(
        subtitle_spek="kotak navy bergradien (radius sekitar 26) dengan bayangan, huruf sans bulat ekstra tebal (Nunito ExtraBold); aktif = kuning, sudah = putih, belum = biru-abu",
        detail=["chip kecil mono dengan titik kuning (SIMULASI, KALAU BESOK)", "mockup ponsel dengan daftar notifikasi", "judul putih tebal dengan kata kunci kuning dan garis bawah", "diagram sederhana di latar navy sangat gelap"],
        gradien="latar navy ke ungu-navy; kartu dan ponsel bergradien; pendar tipis di belakang elemen utama",
        stempel="kaca: kapsul bergradien warna tema, huruf putih"),
    "MINIATUR": dict(
        subtitle_spek="kotak gelap tembus 78 persen (radius sekitar 22), huruf sans geometris tebal (PlusJakartaSans Bold); aktif = kuning, sudah = putih, belum = abu-biru",
        detail=["langit bergradien (krem-persik pagi, ungu-jingga senja, navy malam)", "awan putih gembung", "pulau atau ruang isometrik melayang: sisi atas terang, sisi samping gelap", "bintang rating atau lencana, chip di sudut"],
        gradien="langit, tanah, dan sisi bangunan isometrik semuanya bergradien (atas terang, sisi gelap); awan bergradien putih ke biru muda",
        stempel="kaca: lencana bergradien warna tema"),
}
for _n, _d in _DETAIL.items(): GAYA[_n].update(_d)
GRADIEN_UMUM = ("Aturan 6.12: tidak ada elemen berwarna yang hanya satu warna datar. Tiap huruf-blok, stiker, label, batang, lingkaran, bentuk, kertas, dan karakter memakai gradien turunan dari warna palet "
                "(`gradien.stops_dari(warna)`: sisi cahaya lebih terang dan sedikit ke kuning, sisi bayangan lebih dalam dan sedikit ke magenta). Selisih terang minimal sekitar 8 persen agar terlihat; `gradien.audit_gradien` menandai bidang rata.")


# Metode penekanan kata (6.9) bawaan tiap gaya, dari cara keterangan di tangkapan layar menyorot kata kunci (latar warna, garis bawah, atau warna huruf).
TEKAN = dict(ARSIP="stabilo", BLUEPRINT="garis", SKETSA="stabilo", GEOMETRIK="warna", HIKAYAT="garis", TERMINAL="warna", CAIR="stabilo", FLATLIFE="stabilo", KLIPING="stabilo", LANTANG="warna", PETA="garis", MIDNIGHT="warna", MINIATUR="stabilo")
assert set(TEKAN) == set(GAYA)

# Kata kunci DUA gaya utama (struktur video). "flat animation" = Animasi Cerita Berkarakter; "showreel" atau "reel" = Reel Tipografi Bergerak. Frasa dicocokkan utuh ("flat animation"), bukan kata "flat" saja,
# karena "flat life illustration" adalah gaya visual FLATLIFE.
KATA_KUNCI_UTAMA = {
    "Animasi Cerita Berkarakter": ["flat animation", "animasi flat", "motion graphic bercerita", "ceritakan", "karakter", "edukasi dengan voice over"],
    "Reel Tipografi Bergerak": ["showreel", "reel", "kinetic typography", "typography animation", "motion design", "teks bergerak", "tanpa karakter", "mengikuti beat"],
}
def pilih_gaya_utama(teks):
    """Cocokkan permintaan ke gaya utama. Tepat satu gaya cocok -> dict(nama, kata); tidak ada atau keduanya cocok -> None (JANGAN menebak: tanya lewat kartu gaya, 0.2)."""
    t = teks.lower(); hit = {n: [k for k in ks if re.search(r"\b" + re.escape(k) + r"\b", t)] for n, ks in KATA_KUNCI_UTAMA.items()}; ada = {n: v for n, v in hit.items() if v}
    return dict(nama=next(iter(ada)), kata=next(iter(ada.values()))) if len(ada) == 1 else None
def daftar_kata_kunci():
    """Salinan daftar kata kunci terbaru (dua gaya utama + 13 gaya visual) untuk ditampilkan ke user di laporan, terutama bila ada yang diganti. -> dict nama -> list."""
    return {**{n: list(k) for n, k in KATA_KUNCI_UTAMA.items()}, **{n: list(g["sinyal"]) for n, g in GAYA.items()}}
def daftar(): return list(GAYA)
def gaya(nama):
    n = nama.strip().upper()
    if n not in GAYA: raise KeyError(f"gaya visual '{nama}' tidak ada. Pilihan: {', '.join(GAYA)}")
    return dict(nama=n, tekan=TEKAN[n], **GAYA[n])
def pilih(teks):
    """Cocokkan permintaan user ke gaya visual. Nama gaya disebut langsung = pasti; tanpa nama, hitung kecocokan kata sinyal. -> dict(nama, alasan) atau None bila tidak ada yang jelas (jangan menebak: pilih sendiri yang paling cocok dengan topik dan SEBUT di kalimat pertama laporan)."""
    t = teks.lower()
    for n in GAYA:
        if re.search(r"\b" + n.lower() + r"\b", t): return dict(nama=n, alasan="disebut langsung oleh user")
    skor = {n: sum(1 for s in g["sinyal"] if re.search(r"\b" + re.escape(s) + r"\b", t)) for n, g in GAYA.items()}
    n, v = max(skor.items(), key=lambda kv: kv[1])
    if v >= 1 and sorted(skor.values())[-2] < v: return dict(nama=n, alasan=f"cocok dengan {v} kata sinyal: " + ", ".join(s for s in GAYA[n]["sinyal"] if re.search(r"\b" + re.escape(s) + r"\b", t)))
    return None
def cek_gaya_utama(nama, gaya_utama):
    """Gaya visual yang dipilih harus bisa dikerjakan dalam gaya utama yang aktif. -> dict(lolos, saran)."""
    g = gaya(nama); ok = g["cocok"] in ("keduanya", gaya_utama)
    return dict(lolos=ok, saran=None if ok else f"{g['nama']} paling cocok dengan {g['cocok']}; dalam {gaya_utama} adaptasi: tetap ambil palet, bahan, dan gerak, tetapi struktur mengikuti gaya utama")


# ---- font per PERAN tiap gaya (fonts_gaya.PERAN): dicocokkan dengan merender kandidat berdampingan dengan crop frame contoh. Ambil lewat gaya(nama)["font"] atau fonts_gaya.font_peran(nama, peran, px).
import fonts_gaya as _FG
for _g in GAYA:
    GAYA[_g]["font"] = {pr: dict(utama=d["utama"][0][:-4] + ("".join(f" {k}={v}" for k, v in d["utama"][1].items())), alt=[a[0][:-4] for a in d["alt"][:3]], yakin=d["yakin"], ciri=d["ciri"]) for pr, d in _FG.PERAN[_g].items()}


# Aturan karakter dan objek (2026-11-11): di KLIPING dan ARSIP karakter flat atau objek dibungkus papan benang merah (dekor_kliping.py), siluet boleh abu penuh (rahasia atau privasi).
for _g in ("KLIPING", "ARSIP"):
    GAYA[_g]["karakter"] = "Jangan menempel karakter flat atau objek langsung ke kolase. Bungkus dengan papan benang merah (papan gabus berbingkai kayu, foto polaroid ber-pin, benang merah) lewat dekor_kliping.susun_papan, lalu masukkan siluet karakter (flat-life atau lainnya) atau objek (ponsel, amplop, kaca pembesar) ke foto polaroid. Siluet boleh abu penuh = rahasia atau privasi; beri warna hanya bila peran perlu dibedakan."
