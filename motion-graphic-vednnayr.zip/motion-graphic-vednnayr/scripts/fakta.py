# fakta.py - Lembar fakta: SETIAP hal yang punya acuan di dunia nyata (warna rumput, bentuk pulau, nama negara, warna merek, ciri aplikasi) dicek dulu lewat
# pencarian web (hasil Google/WebSearch + WebFetch halaman sumbernya), BUKAN dari GitHub atau repositori kode, lalu dicatat di sini beserta sumbernya.
import json, os

class Fakta:
    def __init__(self, path="riset/fakta-visual.json"): self.path = path; self.items = {}; os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    def add(self, kunci, klaim, nilai, sumber, status="terverifikasi", catatan=""):
        """kunci = nama elemen visual (mis. 'bumi.laut'); nilai = yang dipakai di gambar (mis. hex warna); sumber = URL halaman hasil pencarian.
        status: terverifikasi (>= 1 sumber, idealnya 2 yang cocok) | belum-terverifikasi | bervariasi (fakta memang beragam, sebutkan rentangnya di catatan)."""
        if status == "terverifikasi" and not sumber: raise ValueError(f"{kunci}: terverifikasi wajib punya sumber")
        self.items[kunci] = dict(klaim=klaim, nilai=nilai, sumber=sumber if isinstance(sumber, list) else [sumber] if sumber else [], status=status, catatan=catatan)
        json.dump(self.items, open(self.path, "w"), ensure_ascii=False, indent=1); return self
    def pakai(self, kunci):
        """Panggil saat elemen digambar: mengembalikan nilai. Menolak elemen yang tidak ada di lembar atau belum terverifikasi (kecuali sudah ditandai bervariasi)."""
        it = self.items.get(kunci)
        if not it: raise KeyError(f"{kunci}: belum ada di lembar fakta, cari dulu lewat pencarian web")
        if it["status"] == "belum-terverifikasi": raise ValueError(f"{kunci}: belum terverifikasi, cari dulu atau nyatakan ke user")
        return it["nilai"]
    def laporan(self):
        """Ringkasan untuk laporan akhir: jumlah fakta, daftar yang belum terverifikasi, dan 'Sumber:' berupa tautan."""
        bv = [k for k, v in self.items.items() if v["status"] == "belum-terverifikasi"]; src = sorted({u for v in self.items.values() for u in v["sumber"]})
        return dict(jumlah=len(self.items), belum_terverifikasi=bv, sumber=src)
    def beda(self, kunci, nilai_lain, sumber_lain):
        """Bila permintaan user atau isi script BERBEDA dari fakta: kembalikan teks penjelasan beserta sumber agar user bisa memeriksa sendiri."""
        it = self.items[kunci]; return f"Tidak sesuai fakta: {kunci}. Permintaan: {nilai_lain}. Hasil pencarian: {it['nilai']} ({it['klaim']}). Sumber: " + ", ".join(it["sumber"] + ([sumber_lain] if sumber_lain else []))


# ---- fakta berurutan, pola, kronologi, klasifikasi, dan hubungan beraturan ----
def _urut_add(self, kunci, klaim, daftar, sumber, status="terverifikasi", catatan=""):
    """Urutan atau kronologi dari pencarian web (mis. planet dari Matahari, peristiwa menurut tahun). Disimpan sebagai daftar terurut."""
    return self.add(kunci, klaim, list(daftar), sumber, status, catatan)

def _urut_cek(self, kunci, dipakai):
    """Bandingkan urutan yang DIGAMBAR/DITULIS (dipakai) dengan urutan fakta. -> dict(sesuai, salah=[(posisi, dipakai, seharusnya)], hilang, lebih). Tolak bila belum terverifikasi."""
    fakta = self.pakai(kunci); salah = [(i + 1, d, f) for i, (d, f) in enumerate(zip(dipakai, fakta)) if d != f]
    return dict(sesuai=not salah and len(dipakai) == len(fakta), salah=salah, hilang=[f for f in fakta if f not in dipakai], lebih=[d for d in dipakai if d not in fakta],
                sumber=self.items[kunci]["sumber"])

def _kelas_add(self, kunci, klaim, kelas, sumber, status="terverifikasi", catatan=""):
    """Klasifikasi: kelas = {'Planet dalam': ['Merkurius', ...], 'Planet luar': [...]}."""
    return self.add(kunci, klaim, {k: list(v) for k, v in kelas.items()}, sumber, status, catatan)

def _kelas_cek(self, kunci, item, kelas_dipakai):
    """Apakah `item` benar masuk `kelas_dipakai` menurut fakta? -> dict(sesuai, seharusnya)."""
    peta = self.pakai(kunci); asli = next((k for k, v in peta.items() if item in v), None)
    return dict(sesuai=asli == kelas_dipakai, seharusnya=asli, sumber=self.items[kunci]["sumber"])

def _relasi_add(self, kunci, klaim, relasi, sumber, status="terverifikasi", catatan=""):
    """Hubungan beraturan: relasi = [(a, 'mengorbit', b), ...] (induk-anak, sebab-akibat, bagian-keseluruhan, dsb.)."""
    return self.add(kunci, klaim, [tuple(r) for r in relasi], sumber, status, catatan)

def _relasi_cek(self, kunci, a, rel, b):
    ada = (a, rel, b) in [tuple(r) for r in self.pakai(kunci)]
    return dict(sesuai=ada, sumber=self.items[kunci]["sumber"])

def cek_pola(daftar):
    """Deteksi pola deret angka (aritmetika, geometri, bergantian) dan beri suku berikutnya. Untuk memeriksa pola yang disebut di script; bukan pengganti sumber untuk fakta dunia nyata."""
    d = list(daftar)
    if len(d) < 3: return dict(jenis="tidak cukup data")
    df = [b - a for a, b in zip(d, d[1:])]
    if all(abs(x - df[0]) < 1e-9 for x in df): return dict(jenis="aritmetika", selisih=df[0], berikutnya=d[-1] + df[0])
    if all(a != 0 for a in d[:-1]):
        rt = [b / a for a, b in zip(d, d[1:])]
        if all(abs(x - rt[0]) < 1e-9 for x in rt): return dict(jenis="geometri", rasio=rt[0], berikutnya=d[-1] * rt[0])
    if all(d[i] == d[i % 2] for i in range(len(d))): return dict(jenis="bergantian", berikutnya=d[len(d) % 2])
    return dict(jenis="tidak beraturan")

Fakta.add_urut = _urut_add; Fakta.cek_urut = _urut_cek; Fakta.add_kelas = _kelas_add; Fakta.cek_kelas = _kelas_cek; Fakta.add_relasi = _relasi_add; Fakta.cek_relasi = _relasi_cek
Fakta.cek_pola = staticmethod(cek_pola)
