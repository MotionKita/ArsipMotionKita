# ekspresi.py - wajah dengan BANYAK ekspresi (mata, alis, mulut, pipi, tanda di wajah) + ikon efek melayang di atas kepala.
# Semua digambar dari bentuk (tanpa font), jadi aman untuk Cara 3. Dipakai oleh karakter.warga(..., ekspresi="senang"),
# tetapi bisa dipanggil langsung: wajah(c, hx, hy, "marah", t, ...) untuk karakter buatan sendiri (hx, hy = pusat kepala).
import math
import fxlib as F
from canvas import heart_pts

INK, WHITE, PINK, BLUSH, RED, TEAR, SKIN, GOLD = (52, 34, 28), (255, 251, 243), (240, 120, 120), (244, 160, 150), (226, 70, 70), (130, 196, 240), (244, 196, 150), (250, 205, 80)

# nama -> (mata, alis, mulut, tanda). mata: buka | senang | tutup | lebar | sedih | sipit | marah | hati | pusing | curiga | bintang
# alis: (dalam, luar) pergeseran tinggi alis kiri/kanan, positif = turun; 'k' = hanya satu alis naik. mulut: lihat _mulut. tanda: pipi merah, air mata, keringat, urat, dll.
EKSPRESI = {
    "netral":      ("buka",   (0, 0),     "senyum",       ()),
    "senang":      ("senang", (-4, -6),   "senyum_lebar", ("pipi",)),
    "tertawa":     ("senang", (-6, -8),   "tertawa",      ("pipi", "air_mata_senang")),
    "sedih":       ("sedih",  (-12, 4),   "cemberut",     ()),
    "menangis":    ("sedih",  (-14, 6),   "cemberut_besar", ("air_mata",)),
    "marah":       ("marah",  (12, -6),   "geram",        ("urat",)),
    "kaget":       ("lebar",  (-18, -18), "o",            ()),
    "takut":       ("lebar",  (-10, -4),  "bergetar",     ("keringat",)),
    "bingung":     ("buka",   ("k", -16), "miring",       ()),
    "teriak":      ("sipit",  (-10, -10), "teriak",       ("keringat",)),
    "malu":        ("sedih",  (-6, 2),    "senyum_kecil", ("pipi_besar",)),
    "mikir":       ("curiga", (-2, -10),  "datar_miring", ()),
    "ngantuk":     ("tutup",  (0, 2),     "o_kecil",      ()),
    "jatuh_cinta": ("hati",   (-6, -6),   "senyum_lebar", ("pipi",)),
    "bangga":      ("sipit",  (-6, -2),   "nyengir",      ()),
    "curiga":      ("curiga", (6, -2),    "datar",        ()),
    "pusing":      ("pusing", (0, 0),     "bergelombang", ()),
    "lega":        ("tutup",  (-4, -4),   "senyum",       ("keringat_kecil",)),
    "kagum":       ("bintang", (-14, -14), "o",           ("pipi",)),
    "jahil":       ("senang", (-2, 6),    "lidah",        ()),
}
NAMA = list(EKSPRESI)

def _arc(cx, cy, rx, ry, a0, a1, n=16):
    return [(cx + rx * math.cos(math.radians(a0 + (a1 - a0) * i / n)), cy + ry * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]

def _bintang(c, x, y, r, col):
    ps = []
    for i in range(8): a = math.pi / 4 * i - math.pi / 2; q = r if i % 2 == 0 else r * 0.32; ps.append((x + q * math.cos(a), y + q * math.sin(a)))
    c.poly(ps, col)

def _tanya(c, x, y, h, col=INK, w=9):
    c.line(F.smooth(_arc(x, y - h * 0.3, h * 0.28, h * 0.24, 200, 440, 12) + [(x, y + h * 0.1)], 6), w, col); c.circ(x, y + h * 0.42, w * 0.7, col)

def _z(c, x, y, s, col=INK):
    c.line([(x - s, y - s), (x + s, y - s), (x - s, y + s), (x + s, y + s)], max(4, s * 0.32), col)

def _mata(c, jenis, s, ex, ey, op, lk, t):
    if jenis == "buka":
        c.ell(ex, ey, 15, 22 * max(0.08, op), INK)
        if op > 0.5: c.circ(ex + lk[0] * 0.2 + 4, ey - 7, 5, WHITE)
    elif jenis == "senang": c.line(_arc(ex, ey + 8, 15, 14, 200, 340), 7, INK)
    elif jenis == "tutup": c.line(_arc(ex, ey - 6, 15, 10, 20, 160), 6, INK)
    elif jenis == "lebar": c.ell(ex, ey, 31, 39, INK); c.ell(ex, ey, 27, 35, WHITE); c.circ(ex + lk[0] * 0.3, ey + 3, 8, INK)
    elif jenis == "sedih":
        c.ell(ex, ey, 16, 22 * max(0.08, op), INK)
        if op > 0.5: c.circ(ex + 4, ey - 6, 7, WHITE); c.circ(ex - 5, ey + 7, 3, WHITE)
    elif jenis == "sipit": c.line([(ex - s * 16, ey - 10), (ex + s * 12, ey + 2), (ex - s * 16, ey + 14)], 7, INK)
    elif jenis == "marah": c.ell(ex, ey + 4, 15, 15 * max(0.2, op), INK); c.circ(ex + 3, ey, 4, WHITE)
    elif jenis == "hati": c.poly(heart_pts(ex, ey - 2, 21 + 2 * math.sin(t * 6)), RED)
    elif jenis == "bintang": c.ell(ex, ey, 24, 28, INK); _bintang(c, ex + 2, ey - 2, 17 + 2 * math.sin(t * 7), (255, 236, 150)); c.circ(ex + 9, ey - 9, 4, WHITE)
    elif jenis == "curiga": c.ell(ex, ey + 6, 15, 10, INK); c.circ(ex + lk[0] * 0.2 + 4, ey + 3, 4, WHITE); c.line([(ex - 18, ey - 4), (ex + 18, ey - 4)], 6, INK)
    elif jenis == "pusing":
        pts = [(ex + (3 + 1.7 * k) * math.cos(k * 0.9 + t * 8 * s), ey + (3 + 1.7 * k) * math.sin(k * 0.9 + t * 8 * s)) for k in range(0, 14)]; c.line(pts, 5, INK)

def _alis(c, hx, hy, spec, t):
    a, b = spec
    for s in (-1, 1):
        if a == "k": di, lu = (-16, -16) if s == -1 else (0, 2)                         # bingung: alis kiri naik, kanan turun sedikit
        else: di, lu = a, b
        if di == 0 and lu == 0: continue
        inner = (hx + s * 16, hy - 24 + di); outer = (hx + s * 60, hy - 28 + lu); mid = (hx + s * 38, hy - 34 + (di + lu) / 2 - (6 if (di < -8 and lu < -8) else 0))
        c.line(F.smooth([inner, mid, outer], 6), 8, INK)

def _mulut(c, hx, hy, jenis, mulut, t, lebar=1.0):
    y = hy + 60; m = 0.0 if mulut is None else min(1.0, mulut)
    if jenis == "teriak": c.ell(hx, y + 10, 30, 22 + 24 * (0.55 + 0.45 * m), INK); c.ell(hx, y + 28 + 8 * m, 20, 11, PINK); return
    if jenis == "tertawa": c.poly(_arc(hx, y - 2, 36, 24 + 14 * m, 0, 180, 14) + [(hx + 36, y - 2)], INK); c.ell(hx, y + 14 + 6 * m, 20, 8 + 4 * m, PINK); return
    if mulut is not None and mulut > 0.04 and jenis not in ("bergetar",):             # bicara: bukaan mengikuti suara, lebar ikut ekspresi
        c.ell(hx, y + 2 + 6 * m, (14 + 8 * m) * lebar, 4 + 26 * m, INK)
        if m > 0.45: c.ell(hx, y + 2 + 16 * m, (9 + 5 * m) * lebar, 5 + 8 * m, PINK)
        return
    if jenis == "senyum": c.line(F.smooth([(hx - 22, hy + 56), (hx, hy + 68), (hx + 24, hy + 54)], 8), 7, INK)
    elif jenis == "senyum_lebar": c.poly(_arc(hx, y - 4, 30, 26, 0, 180, 14), INK); c.ell(hx, y + 14, 16, 8, PINK); c.rr(hx - 26, y - 5, hx + 26, y + 2, 3, WHITE)
    elif jenis == "senyum_kecil": c.line(F.smooth([(hx - 14, hy + 62), (hx, hy + 68), (hx + 14, hy + 60)], 8), 6, INK)
    elif jenis == "cemberut": c.line(F.smooth([(hx - 22, hy + 72), (hx, hy + 60), (hx + 22, hy + 72)], 8), 7, INK)
    elif jenis == "cemberut_besar": c.line(_arc(hx, y + 22, 22, 14, 190, 350, 12), 9, INK)
    elif jenis == "geram": c.line([(hx - 24, hy + 70), (hx - 12, hy + 62), (hx, hy + 70), (hx + 12, hy + 62), (hx + 24, hy + 70)], 7, INK)
    elif jenis == "o": c.ell(hx, y + 6, 20 * lebar, 30, INK); c.ell(hx, y + 18, 12, 12, PINK)
    elif jenis == "o_kecil": c.ell(hx, y + 8, 11, 13 + 5 * math.sin(t * 2.2), INK)
    elif jenis == "bergetar": c.line([(hx - 26 + 4.3 * i, hy + 66 + 4 * math.sin(i * 1.7 + t * 40) * (1 if i % 2 else -1)) for i in range(13)], 6, INK)
    elif jenis == "miring": c.line(F.smooth([(hx - 22, hy + 66), (hx, hy + 62), (hx + 24, hy + 72)], 8), 7, INK)
    elif jenis == "datar": c.line([(hx - 20, hy + 66), (hx + 20, hy + 66)], 7, INK)
    elif jenis == "datar_miring": c.line([(hx - 18, hy + 68), (hx + 6, hy + 64), (hx + 20, hy + 58)], 7, INK)
    elif jenis == "nyengir": c.poly(_arc(hx, y - 2, 34, 20, 0, 180, 14), INK); c.rr(hx - 30, y - 3, hx + 30, y + 5, 3, WHITE); c.line([(hx, y - 3), (hx, y + 6)], 3, INK)
    elif jenis == "bergelombang": c.line([(hx - 26 + 4.3 * i, hy + 66 + 7 * math.sin(i * 1.3 + t * 5)) for i in range(13)], 6, INK)
    elif jenis == "lidah": c.line(F.smooth([(hx - 24, hy + 56), (hx, hy + 68), (hx + 24, hy + 54)], 8), 7, INK); c.poly(_arc(hx + 6, hy + 66, 12, 20, 0, 180, 10), PINK)

def _tanda(c, hx, hy, tanda, t):
    for tg in tanda:
        if tg in ("pipi", "pipi_besar"):
            for s in (-1, 1):
                c.ell(hx + s * 52, hy + 46, 26 if tg == "pipi_besar" else 20, 14 if tg == "pipi_besar" else 10, (238, 120, 120) if tg == "pipi_besar" else BLUSH)
                if tg == "pipi_besar":
                    for k in range(3): c.line([(hx + s * (40 + 8 * k), hy + 42), (hx + s * (36 + 8 * k), hy + 54)], 3, (214, 84, 84))
        elif tg in ("air_mata", "air_mata_senang"):
            for s in (-1, 1):
                p = (t * 1.6 + (0.5 if s > 0 else 0)) % 1.0; yy = hy + 28 + 78 * p
                c.ell(hx + s * 46, yy, 8, 12, TEAR)
                if tg == "air_mata": c.line([(hx + s * 40, hy + 24), (hx + s * 46, yy)], 6, TEAR)
        elif tg in ("keringat", "keringat_kecil"):
            p = (t * 1.1) % 1.0; sz = 1.0 if tg == "keringat" else 0.6
            c.poly([(hx + 92, hy - 40 + 40 * p), (hx + 80, hy - 14 + 40 * p), (hx + 104, hy - 14 + 40 * p)], TEAR); c.circ(hx + 92, hy - 12 + 40 * p, 13 * sz + 3, TEAR)
        elif tg == "urat":
            x, y = hx + 70, hy - 66; k = 1 + 0.18 * math.sin(t * 14)
            for sx, sy in ((1, 1), (-1, 1), (1, -1), (-1, -1)): c.line(_arc(x + sx * 9 * k, y + sy * 9 * k, 12 * k, 12 * k, 0 if sx * sy > 0 else 180, 90 if sx * sy > 0 else 270, 6), 6, RED)
        elif tg == "pucat":
            for s in (-1, 1): c.line([(hx + s * 30, hy - 60), (hx + s * 30, hy - 10)], 5, (150, 130, 150))

def _efek(c, hx, hy, nama, t, t0):
    d = F.clamp((t - t0) / 0.35); k = F.e_back(d) if d < 1 else 1.0; x, y = hx + 118, hy - 118
    if k <= 0: return
    if nama == "bingung": _tanya(c, x, y - 20, 70 * k, INK, 10)
    elif nama == "kaget": F.fx_exclaim(c, x, y - 20, 90 * k, t, t0, 1)
    elif nama == "teriak": F.fx_exclaim(c, x, y - 20, 90 * k, t, t0, 2)
    elif nama == "ngantuk":
        for i, s in enumerate((16, 24, 32)): _z(c, x + 24 * i, y - 30 * i + 10 * math.sin(t * 2 + i), s * 0.6 * k, (90, 110, 170))
    elif nama == "jatuh_cinta":
        for i in range(3): p = ((t * 0.7 + i / 3) % 1.0); c.poly(heart_pts(hx - 60 + 60 * i + 14 * math.sin(t * 3 + i), hy - 130 - 90 * p, 18 * (1 - p * 0.5) * k), (240, 90, 120))
    elif nama in ("senang", "tertawa", "kagum", "bangga"):
        for i, (dx, dy, r) in enumerate(((100, -100, 20), (-96, -90, 14), (124, -40, 11))): _bintang(c, hx + dx, hy + dy + 6 * math.sin(t * 5 + i), r * k * (0.8 + 0.2 * math.sin(t * 7 + i)), GOLD)
    elif nama == "mikir":
        for i, r in enumerate((6, 10, 16)): c.circ(x - 40 + 30 * i, y + 60 - 28 * i, r * k, (210, 214, 224))
        c.circ(x + 40, y - 20, 0, (210, 214, 224))
    elif nama == "pusing":
        for i in range(3): a = t * 4 + i * 2.09; _bintang(c, hx + 100 * math.cos(a), hy - 120 + 22 * math.sin(a), 11, GOLD)
    elif nama == "marah":
        for i in range(2): c.ell(x - 40 + 60 * i, y + 20 - 40 * ((t * 1.3 + i * 0.5) % 1.0), 14, 20, (214, 214, 220))      # uap dari kepala

def wajah(c, hx, hy, nama="netral", t=0.0, op=1.0, lk=(0, 0), mulut=None, t0=0.0, efek=True):
    """Gambar wajah (mata, alis, pipi, mulut, tanda) di pusat kepala (hx, hy), lalu ikon efek melayang bila efek=True.
    nama: salah satu dari NAMA. op = bukaan mata 0..1 (kedip, dari F.idle), lk = arah lirik, mulut = None atau 0..1 saat bicara, t0 = waktu ekspresi mulai (pop-in efek)."""
    mata, alis, bibir, tanda = EKSPRESI[nama]
    kedip = op if mata in ("buka", "sedih", "marah") else 1.0
    for s in (-1, 1):
        ex, ey = hx + s * 38, hy + 8
        if "pipi" not in tanda and "pipi_besar" not in tanda: c.ell(ex + s * 14, ey + 38, 18, 11, BLUSH)
        _mata(c, mata, s, ex, ey, kedip, lk, t)
    _alis(c, hx, hy, alis, t); _tanda(c, hx, hy, tanda, t)
    _mulut(c, hx, hy, bibir, mulut, t, lebar=1.25 if nama in ("senang", "jatuh_cinta") else 0.85 if nama in ("sedih", "menangis", "malu") else 1.0)
    if efek: _efek(c, hx, hy, nama, t, t0)
