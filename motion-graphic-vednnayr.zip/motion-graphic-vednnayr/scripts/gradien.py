# gradien.py - Gradien untuk semua elemen visual (bagian 6.12). Aturan: jangan ada bentuk besar yang hanya satu warna datar (satu blok, satu huruf, satu stiker, satu batang grafik).
# Tiap elemen berwarna memakai gradien halus: lebih terang di sisi cahaya, lebih dalam di sisi lawan, dengan sedikit pergeseran hue; warna dasar tetap dari palet gaya.
# Dibuat dengan numpy + Pillow saja (tanpa dependensi lain). Audit `audit_gradien` memeriksa sprite RGBA dan menandai bidang rata (datar) yang terlalu besar.
import colorsys
import numpy as np
from PIL import Image


def _rgb(c):
    if isinstance(c, str): c = c.lstrip("#"); return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
    return tuple(int(v) for v in c[:3])


def hls(c):
    r, g, b = (v / 255 for v in _rgb(c)); h, l, s = colorsys.rgb_to_hls(r, g, b); return h * 360, l, s


def dari_hls(h, l, s):
    r, g, b = colorsys.hls_to_rgb((h % 360) / 360, min(1, max(0, l)), min(1, max(0, s))); return (round(r * 255), round(g * 255), round(b * 255))


def campur(a, b, t):
    a, b = _rgb(a), _rgb(b); return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def _arah(h, target):
    """Arah terpendek (+1 / -1) dari hue h menuju hue target."""
    d = (target - h) % 360; return 1 if d <= 180 else -1


def turunan(warna, terang=0.09, gelap=0.085, geser_hue=7):
    """Dua warna gradien dari SATU warna palet: (atas terang, bawah dalam). Sisi cahaya bergeser sedikit ke kuning hangat (55 derajat), sisi bayangan ke magenta (300 derajat), seperti bahan nyata;
    jenuh sisi gelap naik sedikit hanya bila warnanya belum sangat jenuh (supaya tidak jadi 'biru murni' yang keruh). Hitam hanya naik terang tipis; putih/krem hanya turun hangat."""
    h, l, s = hls(warna)
    if l < 0.12: return dari_hls(h, l + terang * 0.45, s), dari_hls(h, max(0.0, l - gelap * 0.2), s)
    atas = dari_hls(h + _arah(h, 55) * geser_hue * 0.6, l + terang, s)
    bawah = dari_hls(h + _arah(h, 300) * geser_hue, l - gelap * (0.8 if l > 0.9 else 1.0), min(1, s + (0.08 if s < 0.6 else (-0.05 if s > 0.9 else 0.0))))
    return atas, bawah


def stops_dari(warna, **k):
    a, b = turunan(warna, **k); return [(0.0, a), (1.0, b)]


def linear(ukuran, stops, sudut=90):
    """Gradien linear RGBA penuh. stops = [(posisi 0..1, warna), ...]; sudut derajat: 90 = atas ke bawah, 0 = kiri ke kanan, 45 = kiri-atas ke kanan-bawah."""
    w, h = ukuran; a = np.deg2rad(sudut); dx, dy = np.cos(a), np.sin(a)
    xs, ys = np.meshgrid(np.linspace(-0.5, 0.5, w), np.linspace(-0.5, 0.5, h))
    p = xs * dx * (w / max(w, h)) + ys * dy * (h / max(w, h)); p = (p - p.min()) / max(1e-9, p.max() - p.min())
    pos = [s[0] for s in stops]; out = np.zeros((h, w, 4), np.float32); out[..., 3] = 255
    for i in range(3): out[..., i] = np.interp(p, pos, [_rgb(s[1])[i] for s in stops])
    return Image.fromarray(out.astype(np.uint8), "RGBA")


def radial(ukuran, stops, pusat=(0.5, 0.4), radius=0.75):
    w, h = ukuran; xs, ys = np.meshgrid(np.linspace(0, 1, w), np.linspace(0, 1, h))
    d = np.sqrt(((xs - pusat[0]) * w / max(w, h)) ** 2 + ((ys - pusat[1]) * h / max(w, h)) ** 2) / radius; p = np.clip(d, 0, 1)
    pos = [s[0] for s in stops]; out = np.zeros((h, w, 4), np.float32); out[..., 3] = 255
    for i in range(3): out[..., i] = np.interp(p, pos, [_rgb(s[1])[i] for s in stops])
    return Image.fromarray(out.astype(np.uint8), "RGBA")


def isi(bentuk, stops=None, warna=None, sudut=90, kilap=0.0, jenis="linear"):
    """Isi sebuah bentuk (RGBA atau mode L sebagai topeng) dengan gradien. Berikan `stops` atau satu `warna` (gradien turunannya dibuat otomatis). Alpha bentuk dipertahankan.
    kilap 0..1 menambah pantulan cahaya lembut di sepertiga atas (untuk stiker, stempel timbul, huruf blok)."""
    if bentuk.mode != "RGBA": m = bentuk.convert("L"); bentuk = Image.new("RGBA", m.size, (255, 255, 255, 255)); bentuk.putalpha(m)
    st = stops or stops_dari(warna if warna is not None else (128, 128, 128))
    g = linear(bentuk.size, st, sudut) if jenis == "linear" else radial(bentuk.size, st)
    if kilap:
        a = np.asarray(g).astype(np.float32); h = a.shape[0]; y = np.linspace(0, 1, h)[:, None]; lift = np.clip(1 - y / 0.38, 0, 1) ** 1.6 * 255 * kilap * 0.35
        a[..., :3] = np.clip(a[..., :3] + lift[..., None], 0, 255); g = Image.fromarray(a.astype(np.uint8), "RGBA")
    g.putalpha(bentuk.split()[3]); return g


def isi_pada(tujuan, topeng, **k):
    """Tempel isi gradien ke gambar `tujuan` (RGBA) hanya pada area topeng L. Praktis untuk lingkaran, batang, huruf."""
    g = isi(topeng, **k); tujuan.alpha_composite(g); return tujuan


def blok(w, h, warna=None, stops=None, sudut=90, radius=0, kilap=0.12, tepi=True):
    """Persegi (atau persegi membulat) berisi gradien dengan tepi bawah sedikit lebih gelap (tebal kertas / bahan). Pengganti `rectangle(fill=satu_warna)`."""
    from PIL import ImageDraw
    m = Image.new("L", (w, h), 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, w - 1, h - 1], radius=radius, fill=255) if radius else ImageDraw.Draw(m).rectangle([0, 0, w - 1, h - 1], fill=255)
    im = isi(m, stops=stops, warna=warna, sudut=sudut, kilap=kilap)
    if tepi and h > 12:
        a = np.asarray(im).astype(np.float32); e = max(2, h // 28); a[-e:, :, :3] *= 0.86; im = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA")
    return im


# ---------- audit ----------
def _lum(a): return 0.299 * a[..., 0] + 0.587 * a[..., 1] + 0.114 * a[..., 2]


def cek_datar(sprite, min_luas=3200, selisih_min=7.0, kontinu=2.0, abaikan_gelap=0.08):
    """Cari bidang rata satu warna di sprite RGBA. Bidang = komponen piksel opak yang saling bersambung (selisih tetangga <= `kontinu` tingkat). Rata = luas >= min_luas piksel DAN rentang luminans (persentil 2-98) < selisih_min.
    Bidang hampir hitam atau hampir putih murni (teks, garis) diabaikan. -> dict(datar=[(luas, rentang, warna)], ada_gradien=bool)."""
    from scipy import ndimage as ndi
    a = np.asarray(sprite.convert("RGBA")).astype(np.float32); op = a[..., 3] > 235; L = _lum(a)
    dx = np.abs(np.diff(a[..., :3], axis=1)).max(axis=2); dy = np.abs(np.diff(a[..., :3], axis=0)).max(axis=2)
    stop = np.zeros(op.shape, bool); stop[:, :-1] |= dx > kontinu; stop[:-1, :] |= dy > kontinu; ok = op & ~stop
    lab, n = ndi.label(ok); datar = []; ada = False
    if n == 0: return dict(datar=[], ada_gradien=False)
    luas = ndi.sum(ok, lab, range(1, n + 1))
    for i in np.argsort(-luas)[:12]:
        if luas[i] < min_luas: break
        px = L[lab == i + 1]; r = float(np.percentile(px, 98) - np.percentile(px, 2)); wr = a[..., :3][lab == i + 1].mean(axis=0)
        if wr.mean() < 255 * abaikan_gelap or wr.min() > 250: continue
        if r < selisih_min: datar.append((int(luas[i]), round(r, 1), tuple(int(v) for v in wr)))
        else: ada = True
    return dict(datar=datar, ada_gradien=ada)


def audit_gradien(sprites, min_luas=3200, selisih_min=7.0, boleh_datar=()):
    """sprites: dict nama -> gambar RGBA (sprite dasar tiap elemen berwarna: huruf tempel, label, stiker, batang, lingkaran, kertas). Lolos bila tidak ada bidang rata besar di satu pun sprite.
    boleh_datar: nama sprite yang sengaja datar (mis. foto, bar sensor hitam) dan harus disebut di laporan."""
    buruk = {}
    for n, im in sprites.items():
        if n in boleh_datar: continue
        r = cek_datar(im, min_luas, selisih_min)
        if r["datar"]: buruk[n] = r["datar"][:3]
    return dict(lolos=not buruk, datar=buruk, diperiksa=len(sprites), dikecualikan=list(boleh_datar))
