# universe_kit.py - Bumi, negara, pulau, dan seluruh tata surya (planet, Bulan, Matahari) dari data terverifikasi, bukan karangan.
# Bagian 1 = geografi (Bumi, negara, pulau). Bagian 2 (tata surya) ada di bawah: posisi planet dari unsur orbit JPL, ukuran dari lembar fakta NASA, warna dari deskripsi sumber.
# Alur: fakta dicari lewat pencarian web (bukan GitHub/repo); find_geo() hanya mencari berkas peta yang SUDAH ada (kiriman user / sudah ada di sesi) -> load_geo() -> geo_selfcheck() -> draw_globe(). Bila data peta asli tidak bisa didapat:
# pakai country_points() (koordinat nyata dari database zona waktu, offline) dan pin(); JANGAN menggambar bentuk negara dari ingatan.
import glob, json, math, os, re, subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

# ---------- fakta visual Bumi (NASA Blue Marble, Visible Earth): laut ~71%, daratan ~29%, awan, es kutub, tepi atmosfer biru tipis ----------
OCEAN_DEEP, OCEAN_MID, OCEAN_SHALLOW = (9, 44, 98), (22, 84, 150), (52, 150, 196)
ATMOSPHERE, ICE = (120, 178, 255), (246, 249, 252)
LAND_BANDS = [(0, (38, 102, 56)), (12, (72, 122, 62)), (22, (190, 165, 105)), (32, (150, 150, 92)), (45, (92, 136, 72)),
              (58, (112, 134, 88)), (66, (150, 156, 136)), (75, (236, 241, 247)), (90, (250, 252, 255))]   # hutan hujan, sabana, gurun, hijau sedang, taiga, tundra, es

# ---------- proyeksi ortografis ----------
def ortho(lon, lat, lon0, lat0):
    """(lon, lat) derajat -> (x, y, tampak). x ke kanan, y ke atas, rentang -1..1. tampak = sisi Bumi yang menghadap kamera."""
    l, p, l0, p0 = map(math.radians, (lon - lon0, lat, 0.0, lat0))
    x = math.cos(p) * math.sin(l); y = math.cos(p0) * math.sin(p) - math.sin(p0) * math.cos(p) * math.cos(l)
    return x, y, math.sin(p0) * math.sin(p) + math.cos(p0) * math.cos(p) * math.cos(l) >= 0

# ---------- memuat data ----------
def _topo_arcs(tp):
    tr = tp.get("transform"); arcs = []
    for a in tp["arcs"]:
        x = y = 0; out = []
        for pt in a:
            if tr: x += pt[0]; y += pt[1]; out.append((x * tr["scale"][0] + tr["translate"][0], y * tr["scale"][1] + tr["translate"][1]))
            else: out.append((pt[0], pt[1]))
        arcs.append(out)
    return arcs

def _topo_ring(idx, arcs):
    pts = []
    for i in idx:
        a = arcs[i] if i >= 0 else arcs[~i][::-1]
        pts.extend(a if not pts else a[1:])
    return pts

def load_geo(path, obj=None):
    """-> dict nama -> list poligon; tiap poligon = [cincin_luar, lubang...]; titik (lon, lat). Mendukung GeoJSON dan TopoJSON (world-atlas, Natural Earth)."""
    d = json.load(open(path)); geo = {}
    def add(name, polys): geo.setdefault(name, []).extend(polys)
    if d.get("type") == "Topology":
        arcs = _topo_arcs(d); key = obj if obj in d["objects"] else ("countries" if "countries" in d["objects"] else next(iter(d["objects"])))
        def poly(rings): return [_topo_ring(r, arcs) for r in rings]
        def walk(g):
            nm = (g.get("properties") or {}).get("name") or (g.get("properties") or {}).get("NAME") or g.get("id") or "?"
            if g["type"] == "Polygon": add(nm, [poly(g["arcs"])])
            elif g["type"] == "MultiPolygon": add(nm, [poly(p) for p in g["arcs"]])
            elif g["type"] == "GeometryCollection":
                for s in g["geometries"]: walk(s)
        walk(d["objects"][key])
    else:
        for f in (d["features"] if d.get("type") == "FeatureCollection" else [d]):
            pr = f.get("properties") or {}; nm = next((pr[k] for k in ("name", "NAME", "ADMIN", "NAME_EN", "name_en") if k in pr), "?"); g = f["geometry"]
            if g["type"] == "Polygon": add(nm, [[[tuple(p[:2]) for p in r] for r in g["coordinates"]]])
            elif g["type"] == "MultiPolygon": add(nm, [[[tuple(p[:2]) for p in r] for r in pl] for pl in g["coordinates"]])
    return geo

def find_geo(extra=()):
    """Cari berkas peta yang SUDAH ada (kiriman user, folder project, env GEO_FILE). Tidak mengunduh dari GitHub/repo. -> path atau None."""
    pats = [os.environ.get("GEO_FILE", "")] + list(extra) + ["./**/countries-50m.json", "./**/countries-110m.json", "./**/*.topojson", "./**/*countries*.geojson",
            "/mnt/user-data/uploads/*.*json"]
    for p in pats:
        for f in (glob.glob(p, recursive=True) if p else []):
            if os.path.isfile(f) and os.path.getsize(f) > 20000: return f
    return None

# ---------- pemeriksaan data (WAJIB sebelum dipakai) ----------
def _area(ring):          # luas pada bidang (lambda, sin phi): sebanding persis dengan luas bola (total 4*pi)
    s = 0.0
    for (x0, y0), (x1, y1) in zip(ring, ring[1:] + ring[:1]):
        s += math.radians(x0) * math.sin(math.radians(y1)) - math.radians(x1) * math.sin(math.radians(y0))
    return s / 2

def land_fraction(geo):
    tot = 0.0
    for polys in geo.values():
        for pl in polys: tot += abs(_area(pl[0])) - sum(abs(_area(h)) for h in pl[1:])
    return tot / (4 * math.pi)

def _inside(ring, lon, lat):
    c = False; n = len(ring)
    for i in range(n):
        (x0, y0), (x1, y1) = ring[i], ring[(i + 1) % n]
        if (y0 > lat) != (y1 > lat) and lon < (x1 - x0) * (lat - y0) / (y1 - y0 + 1e-12) + x0: c = not c
    return c

def contains(geo, name, lat, lon):
    return any(_inside(pl[0], lon, lat) and not any(_inside(h, lon, lat) for h in pl[1:]) for pl in geo.get(name, []))

def find_name(geo, query):
    """Cocokkan nama (boleh Indonesia, lihat ID_NAMA) ke kunci data. -> nama di data atau None."""
    q = ID_NAMA.get(query.strip().lower(), query).strip().lower()
    for k in geo:
        if k.lower() == q: return k
    return next((k for k in geo if q in k.lower() or k.lower() in q), None)

def geo_selfcheck(geo, anchors=(("Indonesia", -6.2, 106.8), ("Japan", 35.7, 139.7), ("Brazil", -15.8, -47.9), ("Australia", -35.3, 149.1), ("France", 48.9, 2.35))):
    """Bukti bahwa data BENAR sebelum dipakai: porsi daratan 24-34% (fakta ~29%), kota acuan jatuh DI DALAM negaranya, tidak ada cincin lintas garis 180 yang belum dipotong."""
    lf = land_fraction(geo); bad = []
    for nm, la, lo in anchors:
        k = find_name(geo, nm)
        if k and not contains(geo, k, la, lo): bad.append(nm)
    wrap = sum(1 for polys in geo.values() for pl in polys if any(abs(a[0] - b[0]) > 180 for a, b in zip(pl[0], pl[0][1:])))
    return dict(negara=len(geo), porsi_daratan=round(lf, 3), kota_di_luar_negara=bad, cincin_lintas_180=wrap, lolos=0.24 <= lf <= 0.34 and not bad and wrap == 0)

# ---------- tanpa peta: koordinat nyata dari database zona waktu (offline) ----------
ID_NAMA = {"amerika serikat": "United States", "amerika": "United States", "inggris": "United Kingdom", "jepang": "Japan", "tiongkok": "China", "cina": "China", "korea selatan": "South Korea",
           "korea utara": "North Korea", "jerman": "Germany", "perancis": "France", "prancis": "France", "spanyol": "Spain", "italia": "Italy", "belanda": "Netherlands", "rusia": "Russia",
           "brasil": "Brazil", "meksiko": "Mexico", "kanada": "Canada", "mesir": "Egypt", "afrika selatan": "South Africa", "arab saudi": "Saudi Arabia", "turki": "Turkey", "yunani": "Greece",
           "swiss": "Switzerland", "swedia": "Sweden", "norwegia": "Norway", "selandia baru": "New Zealand", "filipina": "Philippines", "thailand": "Thailand", "vietnam": "Vietnam",
           "malaysia": "Malaysia", "singapura": "Singapore", "india": "India", "pakistan": "Pakistan", "australia": "Australia", "argentina": "Argentina", "nigeria": "Nigeria", "iran": "Iran", "irak": "Iraq"}

def _dms(s):
    m = re.match(r"([+-])(\d+)([+-])(\d+)$", s); a, b = m.group(2), m.group(4); sg = lambda c: -1 if c == "-" else 1
    f = lambda t, n: int(t[:n]) + int(t[n:n + 2] or 0) / 60 + int(t[n + 2:] or 0) / 3600
    return sg(m.group(1)) * f(a, 2), sg(m.group(3)) * f(b, 3)

def country_points(name):
    """-> list (lat, lon, zona) titik nyata untuk sebuah negara dari /usr/share/zoneinfo (zone.tab + iso3166.tab). Untuk pin/penanda, BUKAN bentuk negara."""
    q = ID_NAMA.get(name.strip().lower(), name).strip().lower(); code = None
    for ln in open("/usr/share/zoneinfo/iso3166.tab"):
        if ln.startswith("#"): continue
        c, n = ln.rstrip("\n").split("\t")
        if n.lower() == q or q in n.lower(): code = c; break
    out = []
    for ln in open("/usr/share/zoneinfo/zone.tab"):
        if ln.startswith("#"): continue
        f = ln.rstrip("\n").split("\t")
        if f[0] == code: la, lo = _dms(f[1]); out.append((round(la, 3), round(lo, 3), f[2]))
    return out

# ---------- menggambar ----------
def _noise3(p, seed, k=22, fr=(2.0, 9.0)):                 # derau mulus di permukaan bola: jumlah gelombang sinus acak pada vektor posisi 3D
    r = np.random.default_rng(seed); v = r.standard_normal((k, 3)); v /= np.linalg.norm(v, axis=1)[:, None]; f = r.uniform(fr[0], fr[1], k); ph = r.uniform(0, 6.28, k)
    s = sum(np.sin((p[0] * v[i, 0] + p[1] * v[i, 1] + p[2] * v[i, 2]) * f[i] + ph[i]) / (0.55 + f[i] * 0.25) for i in range(k)); return s / (k ** 0.5)

def draw_globe(c, cx, cy, R, geo, lon0, lat0, hi=(), hi_col=(244, 144, 58), clouds=0.0, t=0.0, seed=3, sun=(-0.55, 0.5, 0.7), q=0.5):
    """Gambar Bumi di kanvas Cv `c` (titik tengah cx, cy; jari-jari R, koordinat logis). geo dari load_geo (DATA ASLI). lon0, lat0 = titik yang menghadap kamera.
    hi = nama negara yang disorot. q = skala hitung lapisan (0,5 = resolusi keluaran pada kanvas 2x; cukup halus dan ~4x lebih cepat). clouds 0..1 = awan prosedural (dekorasi, bergeser pelan menurut t). Warna daratan per garis lintang, laut dangkal di pesisir, es kutub, atmosfer.
    -> dict(ditemukan=[...], hilang=[...]) untuk negara di hi."""
    px, py = c.P(cx, cy); Rf = R * c.K(); Rp = Rf * q; N = int(2 * Rp * 1.12) + 2; h = N / 2
    yy, xx = np.mgrid[0:N, 0:N].astype(np.float32); u = (xx - h) / Rp; v = -(yy - h) / Rp; r2 = u * u + v * v; disc = r2 <= 1.0
    z = np.sqrt(np.clip(1 - r2, 0, 1)); p0 = math.radians(lat0)
    lat = np.degrees(np.arcsin(np.clip(z * math.sin(p0) + v * math.cos(p0), -1, 1))); lon = lon0 + np.degrees(np.arctan2(u, z * math.cos(p0) - v * math.sin(p0)))
    def proj(ring):
        pts = []; prev = None
        for lo, la in ring:
            if prev is not None:                                           # rapatkan sisi panjang agar lengkung di limb halus
                n = int(max(abs(lo - prev[0]), abs(la - prev[1])) // 2)
                for k in range(1, n + 1): pts.append((prev[0] + (lo - prev[0]) * k / (n + 1), prev[1] + (la - prev[1]) * k / (n + 1)))
            pts.append((lo, la)); prev = (lo, la)
        out = []; anyv = False
        for lo, la in pts:
            x, y, vis = ortho(lo, la, lon0, lat0); anyv |= vis
            if not vis: m = math.hypot(x, y) or 1; x, y = x / m, y / m      # titik di sisi belakang dijepit ke limb
            out.append((h + x * Rp, h - y * Rp))
        return out if anyv else None
    def mask(names=None, w=2):
        m = Image.new("L", (N * w, N * w), 0); d = ImageDraw.Draw(m)
        for k, polys in geo.items():
            if names is not None and k not in names: continue
            for pl in polys:
                a = proj(pl[0])
                if a:
                    d.polygon([(x * w, y * w) for x, y in a], fill=255)
                    for ho in pl[1:]:
                        b = proj(ho)
                        if b: d.polygon([(x * w, y * w) for x, y in b], fill=0)
        return m.resize((N, N), Image.LANCZOS)
    M = mask(); Ma = np.asarray(M, np.float32) / 255
    found, miss = [], []; H = None
    for q in hi:
        k = find_name(geo, q); (found if k else miss).append(k or q)
    if found: H = mask(set(found)); Ha = np.asarray(H, np.float32) / 255
    sh = np.asarray(M.filter(ImageFilter.GaussianBlur(Rp * 0.035)), np.float32) / 255       # kedekatan ke pesisir -> laut dangkal
    P = np.stack([np.cos(np.radians(lat)) * np.sin(np.radians(lon)), np.sin(np.radians(lat)), np.cos(np.radians(lat)) * np.cos(np.radians(lon))])
    al = np.abs(lat); lb = np.zeros((N, N, 3), np.float32)
    for ch in range(3): lb[..., ch] = np.interp(al, [b for b, _ in LAND_BANDS], [col[ch] for _, col in LAND_BANDS])
    tex = 1 + 0.11 * np.kron(_noise3(P[:, ::2, ::2], seed), np.ones((2, 2)))[:N, :N, None]
    land = np.clip(lb * tex, 0, 255)
    deep = np.array(OCEAN_DEEP, np.float32); mid = np.array(OCEAN_MID, np.float32); shl = np.array(OCEAN_SHALLOW, np.float32)
    sea = deep + (mid - deep) * (0.5 + 0.5 * z[..., None]); sea = sea + (shl - sea) * np.clip(sh * 2.2, 0, 1)[..., None] * 0.9
    ice = np.clip((al - 70) / 8, 0, 1) * (0.7 + 0.3 * np.kron(_noise3(P[:, ::2, ::2], seed + 1), np.ones((2, 2)))[:N, :N]); sea = sea + (np.array(ICE, np.float32) - sea) * np.clip(ice, 0, 1)[..., None]
    col = sea * (1 - Ma[..., None]) + land * Ma[..., None]
    if H is not None:
        eroded = np.asarray(H.filter(ImageFilter.MinFilter(3)), np.float32) / 255; edge = np.clip(Ha - eroded, 0, 1)[..., None]
        col = col * (1 - 0.72 * Ha[..., None]) + np.array(hi_col, np.float32) * 0.72 * Ha[..., None]; col = col * (1 - edge) + np.array((255, 255, 255), np.float32) * edge
    if clouds > 0:
        Q = np.stack([P[0], P[1], P[2]])[:, ::2, ::2]; Qr = np.stack([Q[0] * math.cos(t * 0.05) + Q[2] * math.sin(t * 0.05), Q[1], -Q[0] * math.sin(t * 0.05) + Q[2] * math.cos(t * 0.05)])
        cn = _noise3(Qr, seed + 7, 30); belt = 0.35 + 0.65 * np.exp(-((np.abs(lat[::2, ::2]) - 8) / 12) ** 2) + 0.5 * np.exp(-((np.abs(lat[::2, ::2]) - 52) / 14) ** 2)
        cl = np.clip((cn * belt - (1.15 - clouds)) * 2.4, 0, 1); cl = np.kron(cl, np.ones((2, 2)))[:N, :N]; col = col + (np.array((255, 255, 255), np.float32) - col) * (cl * 0.78)[..., None]
    sv = np.array(sun, np.float32); sv /= np.linalg.norm(sv); lam = np.clip(u * sv[0] + v * sv[1] + z * sv[2], 0, 1); col = col * (0.42 + 0.62 * lam[..., None]) * (0.78 + 0.22 * z[..., None])
    rim = np.clip((r2 - 0.86) / 0.14, 0, 1) * disc; col = col + (np.array(ATMOSPHERE, np.float32) - col) * (rim ** 2 * 0.55)[..., None]      # tepi biru tipis
    rr = np.sqrt(r2); halo = np.clip(1 - (rr - 1) / 0.1, 0, 1) ** 2.2 * (rr > 1)
    a = np.where(disc, 1.0, halo * 0.75).astype(np.float32); colo = np.where(disc[..., None], col, np.array(ATMOSPHERE, np.float32))
    lay = Image.fromarray(np.dstack([np.clip(colo, 0, 255).astype(np.uint8), (a * 255).astype(np.uint8)]), "RGBA")
    NF = int(2 * Rf * 1.12) + 2; lay = lay.resize((NF, NF), Image.BICUBIC); base = c.im.convert("RGBA"); base.alpha_composite(lay, (int(px - NF / 2), int(py - NF / 2))); c.im.paste(base.convert("RGB")); return dict(ditemukan=found, hilang=miss)

def pin(c, lon, lat, lon0, lat0, cx, cy, R, col=(229, 72, 77), r=14):
    """Penanda di koordinat NYATA (untuk negara tanpa data bentuk). -> True bila tampak dari kamera."""
    x, y, vis = ortho(lon, lat, lon0, lat0)
    if vis: c.circ(cx + x * R, cy - y * R, r + 6, (255, 255, 255)); c.circ(cx + x * R, cy - y * R, r, col)
    return vis


# =====================================================================================================================
# BAGIAN 2: TATA SURYA. Sumber (hasil pencarian web, terverifikasi):
#  - unsur orbit: JPL "Keplerian Elements for Approximate Positions of the Major Planets" (ssd.jpl.nasa.gov/planets/approx_pos.html), berlaku 1800-2050
#  - ukuran, jarak, periode, rotasi, kemiringan, jumlah bulan: NASA NSSDCA Planetary Fact Sheet (nssdc.gsfc.nasa.gov/planetary/factsheet/)
#  - warna: Universe Today "What Are The Colors of the Planets?" dan Planetary Society "Why the true colors of the planets aren't what you think"
#  - cincin Saturnus: Wikipedia "Rings of Saturn" (jari-jari cincin dari pusat Saturnus)
#  Hal yang berasal dari ingatan (bukan hasil pencarian) ditandai status "belum-terverifikasi" di fakta_universe().
# =====================================================================================================================
SUMBER_U = dict(orbit="https://ssd.jpl.nasa.gov/planets/approx_pos.html", lembar="https://nssdc.gsfc.nasa.gov/planetary/factsheet/",
                warna=["https://www.universetoday.com/33642/the-colors-of-the-planets/", "https://www.planetary.org/articles/why-the-true-colors-of-the-planets-arent-what-you-think"],
                cincin="https://en.wikipedia.org/wiki/Rings_of_Saturn")

# unsur orbit JPL (J2000): a, e, I, L, long.peri, long.node dan lajunya per abad (da, de, dI, dL, dw, dN)
_EL = {
 "merkurius": ((0.38709927, 0.20563593, 7.00497902, 252.25032350, 77.45779628, 48.33076593), (0.00000037, 0.00001906, -0.00594749, 149472.67411175, 0.16047689, -0.12534081)),
 "venus":     ((0.72333566, 0.00677672, 3.39467605, 181.97909950, 131.60246718, 76.67984255), (0.00000390, -0.00004107, -0.00078890, 58517.81538729, 0.00268329, -0.27769418)),
 "bumi":      ((1.00000261, 0.01671123, -0.00001531, 100.46457166, 102.93768193, 0.0), (0.00000562, -0.00004392, -0.01294668, 35999.37244981, 0.32327364, 0.0)),
 "mars":      ((1.52371034, 0.09339410, 1.84969142, -4.55343205, -23.94362959, 49.55953891), (0.00001847, 0.00007882, -0.00813131, 19140.30268499, 0.44441088, -0.29257343)),
 "jupiter":   ((5.20288700, 0.04838624, 1.30439695, 34.39644051, 14.72847983, 100.47390909), (-0.00011607, -0.00013253, -0.00183714, 3034.74612775, 0.21252668, 0.20469106)),
 "saturnus":  ((9.53667594, 0.05386179, 2.48599187, 49.95424423, 92.59887831, 113.66242448), (-0.00125060, -0.00050991, 0.00193609, 1222.49362201, -0.41897216, -0.28867794)),
 "uranus":    ((19.18916464, 0.04725744, 0.77263783, 313.23810451, 170.95427630, 74.01692503), (-0.00196176, -0.00004397, -0.00242939, 428.48202785, 0.40805281, 0.04240589)),
 "neptunus":  ((30.06992276, 0.00859048, 1.77004347, -55.12002969, 44.96476227, 131.78422574), (0.00026291, 0.00005105, 0.00035372, 218.45945325, -0.32241464, -0.00508664)),
}
URUTAN = ["merkurius", "venus", "bumi", "mars", "jupiter", "saturnus", "uranus", "neptunus"]       # urut jarak dari Matahari (terverifikasi: lembar fakta NASA)
# lembar fakta NASA: diameter km, periode orbit hari, rotasi jam (negatif = retrograde), kemiringan sumbu derajat, jumlah bulan, bercincin
DATA_U = {
 "merkurius": dict(en="Mercury", d_km=4879, periode_hr=88.0, rot_jam=1407.6, miring=0.034, bulan=0, cincin=False),
 "venus":     dict(en="Venus", d_km=12104, periode_hr=224.7, rot_jam=-5832.5, miring=177.4, bulan=0, cincin=False),
 "bumi":      dict(en="Earth", d_km=12756, periode_hr=365.2, rot_jam=23.9, miring=23.4, bulan=1, cincin=False),
 "bulan":     dict(en="Moon", d_km=3475, periode_hr=27.3, rot_jam=655.7, miring=6.7, bulan=0, cincin=False),
 "mars":      dict(en="Mars", d_km=6792, periode_hr=687.0, rot_jam=24.6, miring=25.2, bulan=2, cincin=False),
 "jupiter":   dict(en="Jupiter", d_km=142984, periode_hr=4331, rot_jam=9.9, miring=3.1, bulan=95, cincin=True),
 "saturnus":  dict(en="Saturn", d_km=120536, periode_hr=10747, rot_jam=10.7, miring=26.7, bulan=274, cincin=True),
 "uranus":    dict(en="Uranus", d_km=51118, periode_hr=30589, rot_jam=-17.2, miring=97.8, bulan=28, cincin=True),
 "neptunus":  dict(en="Neptune", d_km=49528, periode_hr=59800, rot_jam=16.1, miring=28.3, bulan=16, cincin=True),
 "matahari":  dict(en="Sun", d_km=1391400, periode_hr=None, rot_jam=None, miring=7.25, bulan=0, cincin=False),
}
# warna: "asli" = tampak bagi mata manusia (Planetary Society); "populer" = gaya gambar yang umum (Neptunus biru tua). Semua RGB.
WARNA_U = {
 "merkurius": dict(asli=(146, 134, 122), populer=(150, 140, 130)),     # abu-abu agak kecokelatan, mirip Bulan
 "venus":     dict(asli=(236, 222, 184), populer=(232, 204, 130)),     # putih terang dengan nuansa kuning-beige (awan asam sulfat)
 "bumi":      dict(asli=(58, 112, 186), populer=(58, 112, 186)),      # titik di tampilan sistem saja; bola Bumi digambar draw_globe
 "mars":      dict(asli=(172, 98, 64), populer=(184, 92, 52)),         # merah-oranye-cokelat (besi oksida), tudung kutub putih
 "jupiter":   dict(asli=(214, 186, 150), populer=(214, 186, 150)),     # pita putih, krem, kuning, cokelat, oranye
 "saturnus":  dict(asli=(222, 202, 156), populer=(228, 204, 140)),     # kuning-beige pucat, pita pastel
 "uranus":    dict(asli=(166, 216, 220), populer=(150, 226, 232)),     # biru-hijau pucat (metana), hampir tanpa corak
 "neptunus":  dict(asli=(112, 154, 214), populer=(48, 84, 198)),       # asli: biru pucat sedikit kehijauan, sedikit lebih biru dari Uranus; populer: biru tua
 "bulan":     dict(asli=(168, 166, 162), populer=(168, 166, 162)),
 "matahari":  dict(asli=(255, 250, 235), populer=(255, 214, 110)),     # warna asli hampir putih; kuning-oranye = gaya populer
}
# cincin Saturnus (km dari pusat; Wikipedia) dibagi jari-jari khatulistiwa Saturnus 60.268 km (lembar fakta: diameter 120.536 km)
_RS = 60268.0
CINCIN = {"saturnus": [(66900, 74658, (120, 112, 100), 0.12), (74658, 92000, (132, 120, 104), 0.38), (92000, 117580, (222, 204, 168), 0.92),
                       (117580, 122170, (110, 100, 90), 0.06), (122170, 136775, (200, 182, 150), 0.74), (139900, 140500, (190, 176, 150), 0.35)],
          "uranus": [(41837, 51149, (96, 100, 106), 0.28)]}                      # Uranus: cincin sempit gelap (jari-jari dari ingatan, ditandai belum-terverifikasi); jari-jari ekuator 25.559 km
_RU = 25559.0
PIPIH = {"jupiter": 0.065, "saturnus": 0.098, "uranus": 0.023, "neptunus": 0.017, "mars": 0.006, "bumi": 0.0034}           # pemipihan kutub (dari ingatan; belum-terverifikasi, kecil kecuali Jupiter/Saturnus)

def jd(y, m, d, jam=0.0):
    """Hari Julian dari tanggal kalender Gregorian."""
    if m <= 2: y -= 1; m += 12
    A = y // 100; B = 2 - A + A // 4
    return int(365.25 * (y + 4716)) + int(30.6001 * (m + 1)) + d + B - 1524.5 + jam / 24.0

def posisi(nama, tanggal):
    """Posisi heliosentris bidang ekliptika J2000 (AU) pada tanggal=(tahun, bulan, hari[, jam]) -> dict(x, y, z, r, bujur). Metode JPL (Kepler, 3D). Valid 1800-2050."""
    T = (jd(*tanggal) - 2451545.0) / 36525.0; e0, rate = _EL[nama]; a, e, I, L, w_, N = [e0[i] + rate[i] * T for i in range(6)]
    w = w_ - N; M = (L - w_ + 180) % 360 - 180; Mr = math.radians(M); E = Mr + e * math.sin(Mr)
    for _ in range(30):
        dE = (Mr - (E - e * math.sin(E))) / (1 - e * math.cos(E)); E += dE
        if abs(dE) < 1e-12: break
    xp, yp = a * (math.cos(E) - e), a * math.sqrt(1 - e * e) * math.sin(E); cw, sw, cN, sN, cI, sI = (math.cos(math.radians(w)), math.sin(math.radians(w)), math.cos(math.radians(N)), math.sin(math.radians(N)), math.cos(math.radians(I)), math.sin(math.radians(I)))
    x = (cw * cN - sw * sN * cI) * xp + (-sw * cN - cw * sN * cI) * yp; y = (cw * sN + sw * cN * cI) * xp + (-sw * sN + cw * cN * cI) * yp; z = (sw * sI) * xp + (cw * sI) * yp
    return dict(x=x, y=y, z=z, r=math.sqrt(x * x + y * y + z * z), bujur=math.degrees(math.atan2(y, x)) % 360)

def orbit_pts(nama, n=240, tanggal=(2026, 1, 1)):
    """Titik-titik lintasan orbit (x, y, z AU) pada tanggal tertentu (unsur sesaat)."""
    T = (jd(*tanggal) - 2451545.0) / 36525.0; e0, rate = _EL[nama]; a, e, I, L, w_, N = [e0[i] + rate[i] * T for i in range(6)]; w = math.radians(w_ - N); Nr = math.radians(N); Ir = math.radians(I); out = []
    for k in range(n):
        E = 2 * math.pi * k / n; xp, yp = a * (math.cos(E) - e), a * math.sqrt(1 - e * e) * math.sin(E)
        out.append(((math.cos(w) * math.cos(Nr) - math.sin(w) * math.sin(Nr) * math.cos(Ir)) * xp + (-math.sin(w) * math.cos(Nr) - math.cos(w) * math.sin(Nr) * math.cos(Ir)) * yp,
                    (math.cos(w) * math.sin(Nr) + math.sin(w) * math.cos(Nr) * math.cos(Ir)) * xp + (-math.sin(w) * math.sin(Nr) + math.cos(w) * math.cos(Nr) * math.cos(Ir)) * yp,
                    (math.sin(w) * math.sin(Ir)) * xp + (math.cos(w) * math.sin(Ir)) * yp))
    return out

def info(nama):
    """Fakta ringkas untuk narasi: diameter, jarak rata-rata dari Matahari (AU), periode orbit, rotasi, kemiringan sumbu, jumlah bulan, bercincin, perbandingan dengan Bumi."""
    d = dict(DATA_U[nama]); d["nama"] = nama
    if nama in _EL: d["jarak_au"] = round(_EL[nama][0][0], 3)
    d["banding_bumi"] = round(d["d_km"] / DATA_U["bumi"]["d_km"], 2); return d

def lon_putar(nama, t, kali=1.0):
    """Perubahan bujur permukaan (derajat) setelah t detik video: rotasi nyata x `kali` (kecepatan waktu). Retrograde (Venus, Uranus) berputar berlawanan."""
    h = DATA_U[nama]["rot_jam"]; return 0.0 if not h else -360.0 * (t * kali) / (h * 3600.0)       # tanda: timur bergerak ke kanan pada tampilan biasa

def skala_jarak(a, mode="seni", a_max=30.07):
    """Jarak orbit -> 0..1 untuk tampilan. 'akurat' = linear (planet dalam menumpuk di tengah); 'seni' = akar (dimampatkan, WAJIB disebut 'skala jarak tidak sebenarnya')."""
    return a / a_max if mode == "akurat" else math.sqrt(a / a_max)

def _planet_surface(nama, lat, lon, P, gaya, seed, t):
    """Warna permukaan (H, W, 3) menurut deskripsi sumber. Corak halus (kawah, awan) adalah tekstur prosedural, bukan peta asli; pita Jupiter/Saturnus mengikuti garis lintang."""
    col0 = np.array(WARNA_U[nama][gaya], np.float32); H, W = lat.shape; ones = np.ones((2, 2))
    n_lo = np.kron(_noise3(P[:, ::2, ::2], seed, 24), ones)[:H, :W]; n_hi = np.kron(_noise3(P[:, ::2, ::2], seed + 5, 40, (10, 26)), ones)[:H, :W]
    def band(tab, la):
        xs = [b[0] for b in tab]; return np.stack([np.interp(la, xs, [b[1][i] for b in tab]) for i in range(3)], -1)
    if nama == "merkurius":
        return col0 * (1 + 0.16 * n_lo[..., None] + 0.10 * n_hi[..., None])
    if nama == "venus":
        sw = np.kron(_noise3(P[:, ::2, ::2] * np.array([[[1.0]], [[2.2]], [[1.0]]], np.float32), seed + 2, 20), ones)[:H, :W]; return col0 * (1 + 0.05 * sw[..., None]) + np.array([4, 2, -6]) * sw[..., None]
    if nama == "mars":
        c = col0 * (1 + 0.14 * n_lo[..., None]); c = c + (np.array([206, 142, 92]) - c) * np.clip(n_lo * 1.2 - 0.1, 0, 1)[..., None] * 0.55; c = c + (np.array([110, 68, 50]) - c) * np.clip(-n_lo * 1.4 - 0.05, 0, 1)[..., None] * 0.6
        cap = np.clip((np.abs(lat) - (82 - 3 * n_hi)) / 3, 0, 1) * (lat > 0) + np.clip((np.abs(lat) - (78 - 3 * n_hi)) / 3, 0, 1) * (lat < 0); return c + (np.array([244, 244, 248]) - c) * cap[..., None]
    if nama == "jupiter":
        la = lat + 2.4 * np.kron(_noise3(P[:, ::2, ::2] * np.array([[[0.3]], [[0.3]], [[1.0]]], np.float32), seed + 1, 18), ones)[:H, :W]
        tab = [(-90, (158, 136, 114)), (-65, (180, 154, 124)), (-52, (206, 186, 152)), (-43, (176, 128, 92)), (-36, (226, 210, 180)), (-28, (190, 142, 104)), (-20, (172, 104, 72)), (-12, (214, 190, 152)),
               (-6, (238, 224, 190)), (0, (240, 228, 196)), (6, (232, 214, 178)), (10, (168, 108, 76)), (17, (190, 128, 92)), (22, (234, 220, 190)), (28, (186, 138, 100)), (36, (226, 210, 180)), (45, (186, 150, 116)), (60, (176, 150, 122)), (90, (158, 136, 114))]
        c = band(tab, la) * (1 + 0.05 * n_hi[..., None]); dl = (lon - 25 + 180) % 360 - 180; g = np.exp(-((dl / 12.0) ** 2 + ((lat + 22) / 6.0) ** 2) ** 1.4)      # Bintik Merah Besar ~22 derajat LS
        return c + (np.array([198, 94, 66]) - c) * g[..., None] * 0.85
    if nama == "saturnus":
        tab = [(-90, (170, 160, 130)), (-60, (188, 170, 130)), (-40, (214, 192, 146)), (-25, (200, 176, 128)), (-10, (230, 208, 158)), (0, (236, 216, 168)), (10, (226, 202, 150)), (25, (204, 180, 132)), (40, (216, 194, 148)), (60, (186, 170, 134)), (90, (172, 162, 134))]
        return band(tab, lat + 1.2 * n_lo) * (1 + 0.03 * n_hi[..., None])
    if nama == "uranus":
        return col0 * (1 + 0.025 * n_lo[..., None]) + (np.array([200, 236, 232]) - col0) * np.clip((np.abs(lat) - 50) / 40, 0, 1)[..., None] * 0.35
    if nama == "neptunus":
        c = col0 * (1 + 0.07 * n_lo[..., None]); dl = (lon - 20 + 180) % 360 - 180; g = np.exp(-((dl / 20.0) ** 2 + ((lat + 20) / 8.0) ** 2) ** 1.3); c = c * (1 - 0.35 * g[..., None])      # Bintik Gelap Besar
        wc = np.clip(n_hi * 2.2 - 1.2, 0, 1) * np.exp(-((lat + 40) / 25.0) ** 2); return c + (np.array([236, 240, 250]) - c) * wc[..., None] * 0.5
    if nama == "bulan":
        c = col0 * (1 + 0.08 * n_lo[..., None] + 0.05 * n_hi[..., None])
        for (la0, lo0, rl, ro) in ((32.8, -15.6, 11, 14), (28.0, 17.5, 7, 9), (8.5, 31.4, 8, 12), (17.0, 59.1, 5, 6), (-7.8, 51.3, 6, 8), (-21.3, -16.6, 8, 10), (18.4, -57.4, 14, 22), (-24.4, -38.6, 6, 7), (-15.2, 35.5, 4, 5)):
            g = np.exp(-(((lon - lo0 + 180) % 360 - 180) / ro) ** 2 - ((lat - la0) / rl) ** 2); c = c + (np.array([92, 94, 100]) - c) * np.clip(g * 1.3, 0, 1)[..., None] * 0.7      # maria (posisi dari ingatan)
        return c
    if nama == "matahari":
        return col0 * (1 + 0.05 * n_hi[..., None] + 0.03 * n_lo[..., None])
    return np.tile(col0, (H, W, 1))

def draw_planet(c, nama, cx, cy, R, t=0.0, lon0=0.0, lat0=None, gaya="asli", axis=None, cincin_buka=None, geo=None, sun=(-0.55, 0.5, 0.7), seed=4, q=0.5, **kw):
    """Gambar planet (merkurius, venus, bumi, mars, jupiter, saturnus, uranus, neptunus), bulan, atau matahari di kanvas Cv. R = jari-jari tampilan (koordinat logis).
    gaya: 'asli' (warna yang tampak mata manusia) | 'populer' (mis. Neptunus biru tua). lon0 = bujur yang menghadap kamera (animasi: lon0 = lon_putar(nama, t, kali)).
    lat0 = lintang yang menghadap kamera; axis = sudut sumbu putar di layar (Uranus ~ 82 derajat agar cincin tampak hampir tegak); cincin_buka = lintang pandang cincin (Saturnus ~ 18).
    Bumi memakai draw_globe (kw dan geo diteruskan; tanpa geo = laut dan awan saja). Planet dengan cincin: cincin depan menutupi planet, bagian belakang tersembunyi, bayangan planet jatuh di cincin.
    Bentuk pipih Jupiter dan Saturnus ikut digambar (PIPIH). -> Cv."""
    if nama == "bumi": draw_globe(c, cx, cy, R, geo or {}, lon0, 0 if lat0 is None else lat0, sun=sun, q=q, **kw); return c
    view = dict(saturnus=(18.0, 0.0), uranus=(14.0, 80.0), jupiter=(3.0, 0.0), neptunus=(8.0, 0.0)).get(nama, (5.0, 0.0))
    la0 = view[0] if lat0 is None else lat0; ax = view[1] if axis is None else axis; if_cincin = nama in CINCIN
    if cincin_buka is not None: la0 = cincin_buka
    px, py = c.P(cx, cy); Rf = R * c.K(); Rp = Rf * q; rings = []
    if if_cincin: rr_ = _RS if nama == "saturnus" else _RU; rings = [(a / rr_, b / rr_, col, al) for a, b, col, al in CINCIN[nama]]
    ext = max(1.14, 1.5 if nama == 'matahari' else 0, (max(r[1] for r in rings) * 1.03 if rings else 0)); N = int(2 * Rp * ext) + 2; h = N / 2
    yy, xx = np.mgrid[0:N, 0:N].astype(np.float32); u = (xx - h) / Rp; v = -(yy - h) / Rp; a = math.radians(ax); f = PIPIH.get(nama, 0.0)
    up = u * math.cos(a) + v * math.sin(a); vp = -u * math.sin(a) + v * math.cos(a); vpp = vp / (1 - f); r2 = up * up + vpp * vpp; rr = np.sqrt(r2); disc = r2 <= 1.0
    z = np.sqrt(np.clip(1 - r2, 0, 1)); p0 = math.radians(la0); lat = np.degrees(np.arcsin(np.clip(z * math.sin(p0) + vpp * math.cos(p0), -1, 1))); lon = lon0 + np.degrees(np.arctan2(up, z * math.cos(p0) - vpp * math.sin(p0)))
    P = np.stack([np.cos(np.radians(lat)) * np.sin(np.radians(lon)), np.sin(np.radians(lat)), np.cos(np.radians(lat)) * np.cos(np.radians(lon))])
    col = _planet_surface(nama, lat, lon, P, gaya, seed, t).astype(np.float32)
    nx = up * math.cos(a) - vpp * math.sin(a); ny = up * math.sin(a) + vpp * math.cos(a); sv = np.array(sun, np.float32); sv /= np.linalg.norm(sv); lam = np.clip(nx * sv[0] + ny * sv[1] + z * sv[2], 0, 1)
    if nama == "matahari": col = col * (0.62 + 0.38 * z[..., None] ** 0.6)                                               # bercahaya sendiri: hanya pelembutan tepi
    else: col = col * (0.40 + 0.64 * lam[..., None]) * (0.82 + 0.18 * z[..., None])
    halo = dict(venus=((250, 236, 190), 0.07, 0.55), mars=((226, 150, 110), 0.035, 0.35), uranus=((170, 230, 236), 0.05, 0.4), neptunus=((90, 140, 230), 0.05, 0.4), saturnus=((230, 208, 160), 0.03, 0.25),
                jupiter=((226, 196, 160), 0.025, 0.2), matahari=((255, 200, 90) if gaya == "populer" else (255, 240, 210), 0.45, 0.9)).get(nama)
    aa = np.clip((1 - rr) * Rp + 0.5, 0, 1); alpha = aa.astype(np.float32); colo = col.copy()
    if halo:
        hc, hw, hs = halo; g = np.clip(1 - (rr - 1) / hw, 0, 1) ** 2.2 * (rr > 1) * hs; colo = np.where(disc[..., None], col, np.array(hc, np.float32)); alpha = np.maximum(alpha, g.astype(np.float32))
    if rings:
        s = np.array([-math.sin(a) * math.cos(p0), math.cos(a) * math.cos(p0), math.sin(p0)], np.float32); sz = s[2] if abs(s[2]) > 1e-3 else 1e-3
        w = -(s[0] * u + s[1] * v) / sz; rho = np.sqrt(u * u + v * v + w * w); front = (~disc) | (w > z); ra = np.zeros_like(u); rc = np.zeros(u.shape + (3,), np.float32)
        for r_in, r_out, rcol, ral in rings:
            m = (rho >= r_in) & (rho < r_out); rc[m] = rcol; ra[m] = ral * (1 + 0.07 * np.sin(rho[m] * 220))
        ra = np.clip(ra, 0, 1) * front * (np.abs(s[2]) > 0.02)
        pt = np.stack([u, v, w]); along = pt[0] * sv[0] + pt[1] * sv[1] + pt[2] * sv[2]; perp2 = (pt ** 2).sum(0) - along ** 2; shadow = (along < 0) & (perp2 < 1.0)
        rc = rc * (np.where(shadow, 0.28, 1.0)[..., None]) * (0.62 + 0.38 * abs(float(s @ sv)))
        colo = colo * (1 - ra[..., None]) + rc * ra[..., None]; alpha = np.maximum(alpha, ra.astype(np.float32))
    lay = Image.fromarray(np.dstack([np.clip(colo, 0, 255).astype(np.uint8), (np.clip(alpha, 0, 1) * 255).astype(np.uint8)]), "RGBA")
    NF = int(2 * Rf * ext) + 2; lay = lay.resize((NF, NF), Image.BICUBIC); base = c.im.convert("RGBA"); base.alpha_composite(lay, (int(px - NF / 2), int(py - NF / 2))); c.im.paste(base.convert("RGB")); return c

def draw_sistem(c, cx, cy, Rmax, tanggal=(2026, 11, 6), mode="seni", miring=0.42, label=True, planets=URUTAN, gaya="asli", r_dot=14):
    """Tata surya dilihat dari atas-miring: orbit nyata (bentuk elips dari unsur JPL), planet di posisi PADA TANGGAL itu, Matahari di tengah.
    mode 'seni' = jarak dimampatkan (akar): sebut 'skala jarak tidak sebenarnya'; 'akurat' = linear. Ukuran titik planet TIDAK sebanding dengan ukuran asli. -> dict nama -> (x, y) layar."""
    c.circ(cx, cy, r_dot * 1.9, tuple(WARNA_U["matahari"]["populer"] if gaya == "populer" else (255, 226, 150))); out = {}
    for n in planets:
        pts = orbit_pts(n, 200, tanggal); sc = lambda p: (cx + Rmax * skala_jarak(math.hypot(p[0], p[1]), mode) * math.cos(math.atan2(p[1], p[0])), cy - Rmax * skala_jarak(math.hypot(p[0], p[1]), mode) * math.sin(math.atan2(p[1], p[0])) * miring)
        c.line([sc(p) for p in pts] + [sc(pts[0])], 3, (96, 104, 140))
    for n in planets:
        ps = posisi(n, tanggal); k = skala_jarak(math.hypot(ps["x"], ps["y"]), mode); ang = math.atan2(ps["y"], ps["x"]); x, y = cx + Rmax * k * math.cos(ang), cy - Rmax * k * math.sin(ang) * miring
        col = WARNA_U[n][gaya]; c.circ(x, y, r_dot, tuple(int(v) for v in col)); out[n] = (x, y)
        if n == "saturnus": c.ell(x, y, r_dot * 2.1, r_dot * 0.55, (222, 204, 168))
    return out

def banding_ukuran(c, y, x0, x1, planets=URUTAN, gaya="asli", jup_R=150):
    """Barisan planet dengan ukuran SEBANDING asli (jari-jari relatif dari diameter NASA; Jupiter = jup_R). Jarak antar planet tidak mewakili apa pun. -> dict nama -> (x, R)."""
    rel = {n: DATA_U[n]["d_km"] / DATA_U["jupiter"]["d_km"] for n in planets}; tot = sum(2 * rel[n] * jup_R for n in planets); gap = ((x1 - x0) - tot) / (len(planets) + 1); x = x0 + gap; out = {}
    for n in planets:
        r = max(6, rel[n] * jup_R); x += r; draw_planet(c, n, x, y, r, gaya=gaya, **({"geo": None} if n == "bumi" else {})); out[n] = (x, r); x += r + gap
    return out

def fakta_universe(fk):
    """Isi lembar fakta (fakta.Fakta) dengan semua fakta tata surya beserta sumbernya. Yang berasal dari ingatan diberi status belum-terverifikasi, jadi Fakta.pakai() menolaknya sampai dicek."""
    fk.add_urut("tata_surya.urutan", "Urutan planet dari Matahari", [n.capitalize() for n in URUTAN], [SUMBER_U["lembar"]])
    for n in URUTAN + ["bulan"]:
        d = DATA_U[n]; fk.add(f"{n}.ukuran", f"Diameter {d['en']} (km), kemiringan sumbu, rotasi (jam), jumlah bulan", dict(d_km=d["d_km"], miring=d["miring"], rot_jam=d["rot_jam"], bulan=d["bulan"]), [SUMBER_U["lembar"]])
    for n in URUTAN: fk.add(f"{n}.orbit", f"Unsur orbit {DATA_U[n]['en']} (JPL, J2000)", dict(zip("a e I L w N".split(), _EL[n][0])), [SUMBER_U["orbit"]])
    for n in WARNA_U:
        if n in ("bulan", "matahari", "bumi"): continue
        fk.add(f"{n}.warna", f"Warna {DATA_U[n]['en']}", WARNA_U[n], SUMBER_U["warna"], catatan="asli = mata manusia; populer = gaya umum. Corak halus adalah tekstur prosedural.")
    fk.add("saturnus.cincin", "Jari-jari cincin Saturnus (km dari pusat)", CINCIN["saturnus"], [SUMBER_U["cincin"]])
    for k, kl in (("uranus.cincin", "Cincin Uranus (jari-jari dari ingatan)"), ("pipih", "Pemipihan kutub planet (dari ingatan)"), ("bulan.maria", "Posisi lautan Bulan (dari ingatan)"), ("matahari.warna", "Warna Matahari: putih asli, kuning populer (dari ingatan)")):
        fk.add(k, kl, None, [], status="belum-terverifikasi", catatan="cari lewat pencarian web sebelum dipakai sebagai klaim di video")
    return fk

def universe_selfcheck():
    """Bukti kode benar: (1) hukum Kepler ketiga P^2 = a^3, (2) urutan jarak, (3) posisi saat OPOSISI nyata (Mars 2025-01-16, Saturnus 2025-09-21, Jupiter 2024-12-07, Uranus 2025-11-21, Neptunus 2025-09-23:
    bujur heliosentris planet dan Bumi hampir sama), (4) perbandingan ukuran (Jupiter / Bumi sekitar 11)."""
    res = {}
    res["kepler3"] = max(abs((36525.0 * 360.0 / _EL[n][1][3] / 365.25) ** 2 / (_EL[n][0][0] ** 3) - 1) for n in URUTAN)      # periode dari laju bujur JPL (konsisten internal)
    res["kepler3_lembar_nasa"] = round(max(abs((DATA_U[n]["periode_hr"] / 365.25) ** 2 / (_EL[n][0][0] ** 3) - 1) for n in URUTAN), 4)      # periode lembar fakta NASA (Neptunus selisih ~1,4%: angka NASA dibulatkan/tropis)
    res["urutan"] = sorted(URUTAN, key=lambda n: _EL[n][0][0]) == URUTAN
    opo = {"mars": (2025, 1, 16), "saturnus": (2025, 9, 21), "jupiter": (2024, 12, 7), "uranus": (2025, 11, 21), "neptunus": (2025, 9, 23)}
    res["oposisi_selisih_derajat"] = {n: round(abs((posisi(n, d)["bujur"] - posisi("bumi", d)["bujur"] + 180) % 360 - 180), 2) for n, d in opo.items()}
    res["jupiter_per_bumi"] = round(DATA_U["jupiter"]["d_km"] / DATA_U["bumi"]["d_km"], 2)
    res["lolos"] = res["kepler3"] < 0.01 and res["urutan"] and max(res["oposisi_selisih_derajat"].values()) < 3.0 and 10.5 < res["jupiter_per_bumi"] < 11.5
    return res
