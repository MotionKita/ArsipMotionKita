# huruf_tempel.py - Huruf tempel (ransom) bergaya KLIPING: SATU HURUF SATU UBIN (bagian 6.12 dan 0.6). Dipakai juga untuk judul bertema surat kaleng/kliping di gaya lain.
# Pengamatan contoh (frame KLIPING): ubin persegi berukuran beda-beda, huruf MEMENUHI ubin (tinggi huruf hampir setinggi ubin, jarak ke tepi tipis), tiap ubin berfont sendiri
# (serif tebal, slab tebal, sans bulat tebal; lihat fonts_gaya.RANSOM), miring kecil (-6 sampai +6 derajat), naik-turun kecil, tepi guntingan putih tipis, bayangan lembut.
# Aturan warna (2026-11-11): warna huruf harus SERASI dengan ubinnya: huruf gelap memakai bayangan gelap dari hue ubin itu sendiri (kuning -> cokelat tua, merah muda -> plum, biru langit -> biru tua),
# ubin pekat (hitam, biru, merah, teal) memakai huruf krem atau aksen kuning. Kontras minimal 4.5:1 (WCAG) diuji di audit_ubin. Ubin dan huruf tetap bergradien (6.12).
# Ukuran: tinggi tinta huruf = 80 persen tinggi ubin, lebar ubin = lebar tinta + jarak sisi; audit_ubin memeriksa keduanya untuk huruf DAN angka.
import random, functools, colorsys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import gradien as G
import fonts_gaya as FG

SC = 2
ISI_TINGGI = 0.80   # tinggi tinta huruf / tinggi ubin
# Palet ubin baru (2026-11-11): 12 warna, tiap huruf satu warna berbeda. Nama = warna di contoh yang digeser agar tidak sama dengan versi lama.
TILES = [(255, 210, 24), (255, 128, 32), (208, 36, 40), (255, 132, 190), (170, 142, 255), (92, 190, 255), (44, 72, 235), (84, 214, 164), (186, 228, 60), (250, 242, 222), (24, 24, 30), (0, 110, 122)]
CREAM, INK = (252, 246, 228), (22, 22, 28)
# Pasangan huruf per ubin: gelap serumpun hue (ubin terang) atau krem/aksen (ubin pekat). Pilihan >1 diundi per ubin.
PASANGAN = {
    (255, 210, 24): [(54, 32, 6), (22, 22, 28)], (255, 128, 32): [(58, 22, 4), (22, 22, 28)], (208, 36, 40): [CREAM, (255, 226, 120)],
    (255, 132, 190): [(78, 8, 52), (22, 22, 28)], (170, 142, 255): [(34, 18, 96), (22, 22, 28)], (92, 190, 255): [(6, 28, 92), (22, 22, 28)],
    (44, 72, 235): [CREAM, (255, 214, 40)], (84, 214, 164): [(4, 66, 46), (22, 22, 28)], (186, 228, 60): [(34, 62, 4), (22, 22, 28)],
    (250, 242, 222): [(22, 22, 28), (208, 36, 40), (44, 72, 235)], (24, 24, 30): [CREAM, (255, 210, 24), (84, 214, 164)], (0, 110, 122): [CREAM, (255, 236, 150)],
}


def _lum(c):
    def f(v): v = v / 255.0; return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = c[:3]; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def kontras(a, b):
    """Rasio kontras WCAG antara dua warna RGB."""
    la, lb = _lum(a), _lum(b); hi, lo = max(la, lb), min(la, lb); return (hi + 0.05) / (lo + 0.05)


def warna_huruf(ubin_rgb, rng):
    """Warna dasar huruf yang serasi dengan ubin. Ubin di PASANGAN memakai daftar pasangan; ubin lain: bayangan gelap hue yang sama (ubin terang) atau krem (ubin gelap)."""
    opsi = PASANGAN.get(tuple(ubin_rgb[:3]))
    if not opsi:
        h, s, v = colorsys.rgb_to_hsv(*[x / 255.0 for x in ubin_rgb[:3]])
        if _lum(ubin_rgb) > 0.30: r, g, b = colorsys.hsv_to_rgb(h, min(1.0, s + 0.25), 0.22); opsi = [(int(r * 255), int(g * 255), int(b * 255))]
        else: opsi = [CREAM]
    opsi = [c for c in opsi if kontras(c, ubin_rgb) >= 4.5] or [INK if _lum(ubin_rgb) > 0.30 else CREAM]
    return opsi[rng.randrange(len(opsi))]


def _geser(c, k):
    """k > 0 menerangkan, k < 0 menggelapkan (campur ke putih atau ke hitam)."""
    t = (255, 255, 255) if k > 0 else (0, 0, 0); k = abs(k); return tuple(int(c[i] * (1 - k) + t[i] * k) for i in range(3))


def stops_huruf(dasar):
    """Gradien huruf tipis (atas sedikit lebih terang, bawah sedikit lebih dalam), tetap satu hue dengan warna dasar agar kontras tidak turun di bawah 4.5."""
    gelap = _lum(dasar) < 0.30
    return [(0, _geser(dasar, 0.10 if gelap else 0.16)), (1, _geser(dasar, -0.08 if not gelap else -0.12))]


def stops_ubin(warna):
    """Gradien ubin terlihat jelas (sekitar 25 persen selisih terang), satu keluarga warna. Hitam dan krem punya aturan sendiri agar gradiennya tidak hilang."""
    if sum(warna) < 120: return [(0, (66, 64, 76)), (1, (10, 10, 14))]
    if min(warna) > 235: return [(0, (255, 254, 250)), (1, (224, 218, 204))]
    return G.stops_dari(warna, terang=0.12, gelap=0.13, geser_hue=10)


def _golongan(rng): return rng.choices(["serif", "slab", "bulat"], [3, 3, 4])[0]


def _font_ada(rng, ch, golongan):
    """Pilih font dari golongan yang benar-benar punya glyph untuk ch (angka, ?, !)."""
    for _ in range(8):
        sp = FG.ransom_font(rng, golongan); f = FG.font(sp, 120)
        if f.getmask(ch).getbbox(): return sp
    return FG.ransom_font(rng, golongan)


def _rakit(ch, tinggi, warna, seed, golongan, putar):
    rng = random.Random(seed * 7919 + ord(ch)); tc = warna or TILES[rng.randrange(len(TILES))]; h = int(tinggi * SC * rng.uniform(0.96, 1.14))
    sp = _font_ada(rng, ch, golongan or _golongan(rng)); f120 = FG.font(sp, 120); l0, t0, r0, b0 = f120.getbbox(ch); ih0 = max(1, b0 - t0); cap0 = max(1, f120.getbbox("H")[3] - f120.getbbox("H")[1])
    tanda = ih0 < 0.5 * cap0                      # titik, koma, strip, titik dua: jangan dibesarkan sampai memenuhi ubin (jadi bola raksasa); skalakan menurut tinggi huruf kapital
    px = max(8, int(120 * (h * ISI_TINGGI) / (cap0 if tanda else ih0))); f = FG.font(sp, px); l, t, r, b = f.getbbox(ch); iw, ih = r - l, b - t
    padx = int(h * (0.09 if tanda else 0.11)); w = max(int(h * (0.34 if tanda else 0.52)), iw + 2 * padx)
    sudut = rng.uniform(35, 120); tile = G.blok(w, h, stops=stops_ubin(tc), sudut=sudut, kilap=0.10, tepi=False)
    a = np.asarray(tile).astype(np.float32); nz = (np.random.default_rng(seed * 31 + ord(ch)).standard_normal(a.shape[:2]) * 2.2)[..., None]; a[..., :3] = np.clip(a[..., :3] + nz, 0, 255); tile = Image.fromarray(a.astype(np.uint8), "RGBA")
    hc = warna_huruf(tc, rng); gm = Image.new("L", tile.size, 0); ytop = int(h * (1 - (1 - ISI_TINGGI) / 2)) - ih if (tanda and ch in ".,_") else (h - ih) // 2; ImageDraw.Draw(gm).text(((w - iw) // 2 - l, ytop - t), ch, font=f, fill=255)
    tile.alpha_composite(G.isi(gm, stops=stops_huruf(hc), sudut=80))
    info = dict(tanda=tanda, isi_tinggi=ih / h, isi_lebar=iw / w, kontras=kontras(hc, tc), huruf=hc, ubin=tc, font=sp[0])
    return tile, info, rng, putar


@functools.lru_cache(None)
def ubin_info(ch, tinggi=100, warna=None, seed=0, golongan=None):
    """Ukuran pengisian dan kontras satu ubin (untuk audit): dict(isi_tinggi, isi_lebar, kontras, huruf, ubin, font)."""
    return _rakit(ch, tinggi, warna, seed, golongan, None)[1]


@functools.lru_cache(None)
def ubin(ch, tinggi=100, warna=None, seed=0, golongan=None, putar=None):
    """Satu ubin huruf (RGBA, 2x): ubin bergradien + huruf bergradien serasi dan memenuhi ubin + tepi guntingan putih. warna=None memilih dari TILES."""
    tile, info, rng, putar = _rakit(ch, tinggi, warna, seed, golongan, putar)
    tile = tile.rotate(putar if putar is not None else rng.uniform(-6, 6), expand=True, resample=Image.BICUBIC)
    al = tile.split()[3]; edge = ImageChops.subtract(al.filter(ImageFilter.MaxFilter(5)), al).point(lambda v: 255 if v else 0)
    pad_im = Image.new("RGBA", (tile.width + 8, tile.height + 8), (0, 0, 0, 0)); e2 = Image.new("L", pad_im.size, 0); e2.paste(edge, (4, 4)); t2 = Image.new("RGBA", pad_im.size, (0, 0, 0, 0)); t2.paste(tile, (4, 4))
    out = Image.new("RGBA", pad_im.size, (0, 0, 0, 0)); out.paste(G.isi(e2, stops=[(0, (255, 253, 246)), (1, (222, 212, 196))], sudut=60), (0, 0), e2); out.alpha_composite(t2)
    return out


@functools.lru_cache(None)
def kata(teks, tinggi=100, seed=1, tiles=None):
    """Satu kata atau kalimat huruf tempel -> sprite RGBA (2x, dipotong rapat). Spasi = celah. Tiap huruf satu ubin berwarna BERBEDA (tidak mengulang warna sebelum palet habis)."""
    rng = random.Random(seed); tl = list(tiles) if tiles else list(TILES); parts = []; x = 0; antrean = []
    for i, ch in enumerate(teks):
        if ch == " ": x += int(tinggi * 0.38) * SC; continue
        if not antrean: antrean = tl[:]; rng.shuffle(antrean)
        tc = antrean.pop()
        u = ubin(ch, tinggi, tc, seed * 1000 + i); parts.append((u, x, rng.randint(-int(tinggi * 0.07), int(tinggi * 0.07)) * SC)); x += int(u.width * 0.93)
    Wd = x + 60 * SC; Hd = int(tinggi * 1.8 * SC); sh = Image.new("RGBA", (Wd, Hd), (0, 0, 0, 0)); im = Image.new("RGBA", (Wd, Hd), (0, 0, 0, 0))
    for u, px_, dy in parts:
        pos = (px_ + 30 * SC, Hd // 2 - u.height // 2 + dy); a = u.split()[3]; s_ = Image.new("RGBA", u.size, (0, 0, 0, 95)); sh.paste(s_, (pos[0] + 5 * SC, pos[1] + 6 * SC), a); im.alpha_composite(u, pos)
    sh = sh.filter(ImageFilter.GaussianBlur(4 * SC)); out = Image.alpha_composite(sh, im); return out.crop(out.getbbox())


def audit_ubin(teks="HOAKS DICEK BENAR 2018 1.500 ?!", tinggi=100):
    """Audit ubin hasil render: (1) tiap ubin bergradien (G.cek_datar), (2) tinggi tinta huruf >= 74 persen tinggi ubin dan lebar tinta >= 55 persen lebar ubin (huruf DAN angka),
    (3) kontras huruf terhadap ubin >= 4.5, (4) warna ubin satu kata tidak berulang sebelum palet habis. -> dict(lolos, gradien, isi, kontras, masalah)."""
    cs = [c for c in teks if c != " "]; sp = {f"ubin {c}{i}": ubin(c, tinggi, TILES[i % len(TILES)], i) for i, c in enumerate(cs)}; g = G.audit_gradien(sp); masalah = []
    for i, c in enumerate(cs):
        inf = ubin_info(c, tinggi, TILES[i % len(TILES)], i)
        if not inf["tanda"] and inf["isi_tinggi"] < 0.74: masalah.append(f"{c}{i}: tinta hanya {inf['isi_tinggi']:.2f} tinggi ubin")
        if not inf["tanda"] and inf["isi_lebar"] < 0.55: masalah.append(f"{c}{i}: tinta hanya {inf['isi_lebar']:.2f} lebar ubin")
        if inf["kontras"] < 4.5: masalah.append(f"{c}{i}: kontras {inf['kontras']:.1f}")
    return dict(lolos=bool(g["lolos"]) and not masalah, gradien=g["lolos"], isi=not any("tinta" in m for m in masalah), kontras=not any("kontras" in m for m in masalah), masalah=masalah)
