# ukur_referensi.py - Mengukur video contoh dengan SINYAL (bukan pendengaran, bukan perasaan): porsi ruang kosong per frame (6.14), kontur nada narator dan jeda, onset, dan SFX di titik potong (6.15).
# Pakai: python3 ukur_referensi.py kosong video.mp4 | audio video.mp4 | potongan video.mp4. Butuh ffmpeg; analisis audio butuh scipy. Claude tidak bisa mendengar: angka di sini yang dilaporkan, bukan kesan.
import sys, subprocess, re, json, tempfile, os
import numpy as np

# ---------------------------------------------------------------- ruang kosong (6.14)
def frames(path, fps=1, W=360, H=640):
    """Frame video pada fps tertentu, diperkecil ke WxH -> array (n, H, W, 3) uint8."""
    p = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-vf", f"fps={fps},scale={W}:{H}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True, check=True)
    a = np.frombuffer(p.stdout, np.uint8); n = len(a) // (W * H * 3); return a[:n * W * H * 3].reshape(n, H, W, 3)


def _tepi_kuat(g, ambang):
    gx = np.zeros_like(g); gy = np.zeros_like(g)
    gx[1:-1, 1:-1] = (g[:-2, 2:] + 2 * g[1:-1, 2:] + g[2:, 2:]) - (g[:-2, :-2] + 2 * g[1:-1, :-2] + g[2:, :-2]); gy[1:-1, 1:-1] = (g[2:, :-2] + 2 * g[2:, 1:-1] + g[2:, 2:]) - (g[:-2, :-2] + 2 * g[:-2, 1:-1] + g[:-2, 2:])
    return np.hypot(gx, gy) > ambang


def _blok_terbesar(kosong):
    """Luas (dalam sel) komponen sel kosong bersambung terbesar (4 tetangga), tanpa scipy."""
    h, w = kosong.shape; seen = np.zeros_like(kosong, bool); best = 0
    for y in range(h):
        for x in range(w):
            if kosong[y, x] and not seen[y, x]:
                st = [(y, x)]; seen[y, x] = True; n = 0
                while st:
                    cy, cx = st.pop(); n += 1
                    for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        ny, nx = cy + dy, cx + dx
                        if 0 <= ny < h and 0 <= nx < w and kosong[ny, nx] and not seen[ny, nx]: seen[ny, nx] = True; st.append((ny, nx))
                best = max(best, n)
    return best


def ukur_kosong_frame(fr, sel=20, ambang=110, min_tepi=0.02):
    """-> (porsi sel kosong, porsi blok kosong terbersambung terbesar) untuk satu frame RGB 360x640. Sel kosong = kurang dari 2 persen piksel bertepi kuat."""
    g = fr.astype(np.float32).mean(2); m = _tepi_kuat(g, ambang); H, W = m.shape
    c = m[:H // sel * sel, :W // sel * sel].reshape(H // sel, sel, W // sel, sel).mean((1, 3)); k = c < min_tepi
    return float(k.mean()), _blok_terbesar(k) / k.size


def ukur_kosong(path, fps=1):
    """-> dict(kosong_rata, kosong_p90, blok_rata, blok_p90, per_detik=[...])."""
    r = np.array([ukur_kosong_frame(f) for f in frames(path, fps)])
    return dict(kosong_rata=round(float(r[:, 0].mean()), 2), kosong_p90=round(float(np.percentile(r[:, 0], 90)), 2), blok_rata=round(float(r[:, 1].mean()), 2), blok_p90=round(float(np.percentile(r[:, 1], 90)), 2), per_detik=[round(float(v), 2) for v in r[:, 0]])


def cek_kosong(hasil, acuan_kosong, acuan_blok, toleransi=0.10):
    """Video dianggap seimbang bila porsi kosong rata-rata dalam selisih toleransi dari acuan (video contoh gaya yang sama) dan blok kosong terbesar tidak melebihi acuan + toleransi."""
    ok = abs(hasil["kosong_rata"] - acuan_kosong) <= toleransi and hasil["blok_rata"] <= acuan_blok + toleransi
    return dict(lolos=ok, catatan=f"kosong {hasil['kosong_rata']} (acuan {acuan_kosong}), blok terbesar {hasil['blok_rata']} (acuan {acuan_blok})")


# ---------------------------------------------------------------- audio (6.15)
SR = 16000


def muat_audio(path):
    from scipy.io import wavfile
    with tempfile.TemporaryDirectory() as d:
        w = os.path.join(d, "a.wav"); subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", path, "-vn", "-ac", "1", "-ar", str(SR), w], check=True); _, x = wavfile.read(w)
    return x.astype(np.float32) / 32768.0


def _pitch(x, fl=0.04, hop=0.01, fmin=70, fmax=420):
    n = int(fl * SR); h = int(hop * SR); out = []; kmin = int(SR / fmax); kmax = int(SR / fmin)
    for i in range(0, len(x) - n, h):
        f = x[i:i + n] - x[i:i + n].mean()
        if float(np.sqrt((f ** 2).mean())) < 0.01: out.append(0.0); continue
        w = f * np.hanning(n); ac = np.correlate(w, w, "full")[n - 1:]; ac /= ac[0] + 1e-9; k = kmin + int(np.argmax(ac[kmin:kmax])); out.append(SR / k if ac[k] > 0.45 else 0.0)
    return np.array(out)


def analisis_audio(path):
    """Ukuran narator dan level: porsi bersuara, nada dasar tengah (Hz), sebaran nada (semiton), durasi frasa, jeda antar frasa, porsi frasa yang turun di akhir, level. Hanya sinyal."""
    from scipy.signal import medfilt
    x = muat_audio(path); dur = len(x) / SR; R = dict(durasi=round(dur, 1), rms_dbfs=round(float(20 * np.log10(np.sqrt((x ** 2).mean()) + 1e-9)), 1), puncak_dbfs=round(float(20 * np.log10(np.abs(x).max() + 1e-9)), 1))
    f0 = _pitch(x); v = f0 > 0; R["porsi_bersuara"] = round(float(v.mean()), 2)
    if v.sum() > 50:
        fv = medfilt(f0, 5); st = 12 * np.log2(np.where(fv > 0, fv, np.nan) / 100.0); R["f0_median_hz"] = round(float(np.nanmedian(np.where(fv > 0, fv, np.nan))), 0); R["sebaran_nada_semiton"] = round(float(np.nanstd(st)), 2)
        seg = []; s = None
        for i, vv in enumerate(v):
            if vv and s is None: s = i
            if (not vv) and s is not None and not v[i:i + 8].any(): seg.append((s, i)); s = None
        if s is not None: seg.append((s, len(v)))
        seg = [(a, b) for a, b in seg if b - a >= 40]; R["jumlah_frasa"] = len(seg); tr = []
        for a, b in seg:
            q = st[a:b]; q = q[~np.isnan(q)]
            if len(q) > 30: k = max(3, len(q) // 5); tr.append(float(np.median(q[-k:]) - np.median(q[:k])))
        if tr: R["porsi_frasa_turun_di_akhir"] = round(float(np.mean(np.array(tr) < -0.5)), 2)
        gaps = [(seg[i + 1][0] - seg[i][1]) * 0.01 for i in range(len(seg) - 1)]
        if gaps: R["jeda_median_dtk"] = round(float(np.median(gaps)), 2); R["jeda_maks_dtk"] = round(float(np.max(gaps)), 2)
        if seg: R["durasi_frasa_median_dtk"] = round(float(np.median([(b - a) * 0.01 for a, b in seg])), 2)
    return R


def sfx_di_potongan(path, ambang_scene=0.18):
    """SFX di titik potong gambar: jumlah potongan, berapa yang punya letusan frekuensi tinggi (whoosh, klik) atau dentuman rendah dalam -0.04..+0.25 dtk dari potongan, dibanding jendela acak."""
    from scipy.signal import stft
    x = muat_audio(path); out = subprocess.run(["ffmpeg", "-v", "info", "-i", path, "-vf", f"select='gt(scene,{ambang_scene})',showinfo", "-an", "-f", "null", "-"], capture_output=True, text=True).stderr
    cuts = [float(m) for m in re.findall(r"pts_time:([0-9.]+)", out)]; f, t, Z = stft(x, SR, nperseg=512, noverlap=384); A = np.abs(Z) ** 2
    band = lambda lo, hi: A[(f >= lo) & (f < hi)].sum(0); lf, hf = band(40, 200), band(5000, 8000)
    def rel(b, c): i0, i1 = np.searchsorted(t, c - 0.04), np.searchsorted(t, c + 0.25); return (b[i0:i1].max() if i1 > i0 else 0) / (np.median(b) + 1e-12)
    ac = {}
    for nm, b in (("lf", lf), ("hf", hf)): rng = np.random.default_rng(0); ac[nm] = np.percentile([rel(b, c) for c in rng.uniform(1, t[-1] - 1, 300)], 90)
    lfn = sum(rel(lf, c) > ac["lf"] for c in cuts); hfn = sum(rel(hf, c) > ac["hf"] for c in cuts); dur = len(x) / SR
    return dict(potongan=len(cuts), potongan_per_detik=round(len(cuts) / dur, 2), dentuman_rendah=int(lfn), desis_tinggi=int(hfn), porsi_desis=round(hfn / max(1, len(cuts)), 2))


if __name__ == "__main__":
    fn = dict(kosong=ukur_kosong, audio=analisis_audio, potongan=sfx_di_potongan)[sys.argv[1]]; r = fn(sys.argv[2])
    if isinstance(r, dict): r.pop("per_detik", None)
    print(json.dumps(r, ensure_ascii=False))
