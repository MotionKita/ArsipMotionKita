# audit.py - audit bentuk karakter (keluwesan pakaian/aksesoris, proporsi badan, kestabilan wajah) + GERBANG audit wajib sebelum render final.
# Audit bekerja pada bentuk yang BENAR-BENAR digambar: kanvas dibungkus Rekam, lalu poligon dan garis yang tergambar diukur. Tidak menilai dari niat atau dari nama fungsi.
import math
import numpy as np
from PIL import Image, ImageDraw
import fxlib as F


class Rekam:
    """Pembungkus kanvas Cv: meneruskan semua panggilan dan merekam bentuk yang digambar (poly, line, ell, circ, rr) lengkap dengan warna."""
    def __init__(self, c): self._c = c; self.log = []
    def poly(self, ps, fill): self.log.append(("poly", [tuple(map(float, p)) for p in ps], tuple(fill))); return self._c.poly(ps, fill)
    def line(self, ps, w, fill, cap=True): self.log.append(("line", [tuple(map(float, p)) for p in ps], tuple(fill), float(w))); return self._c.line(ps, w, fill, cap)
    def ell(self, cx, cy, rx, ry, fill): self.log.append(("ell", (float(cx), float(cy), float(rx), float(ry)), tuple(fill))); return self._c.ell(cx, cy, rx, ry, fill)
    def circ(self, x, y, r, fill): self.log.append(("circ", (float(x), float(y), float(r)), tuple(fill))); return self._c.circ(x, y, r, fill)
    def rr(self, x0, y0, x1, y1, r, fill): self.log.append(("rr", (x0, y0, x1, y1, r), tuple(fill))); return self._c.rr(x0, y0, x1, y1, r, fill)
    def __getattr__(self, n): return getattr(self._c, n)


def _area(ps):
    return abs(sum(ps[i][0] * ps[(i + 1) % len(ps)][1] - ps[(i + 1) % len(ps)][0] * ps[i][1] for i in range(len(ps)))) / 2


def _belok(ps, langkah=3.0, jendela=2):
    """Sudut belok (derajat) pada skala tetap: poligon tertutup diambil ulang tiap `langkah` px sepanjang kelilingnya, lalu sudut antara arah ke belakang dan ke depan sejauh `jendela` langkah (= 6 px).
    Sudut 55 derajat pada skala ini berarti jari-jari sudut sekitar 6 px: lebih tajam dari itu terbaca sebagai sudut runcing, tidak peduli berapa banyak titik yang dipakai menggambarnya."""
    P = list(ps) + [ps[0]]; seg = [math.dist(P[i], P[i + 1]) for i in range(len(P) - 1)]; tot = sum(seg)
    if tot < langkah * 2 * jendela + 1: return []
    n = max(8, int(tot / langkah)); out = []; acc = [0.0]
    for d in seg: acc.append(acc[-1] + d)
    def at(u):
        u %= tot; j = max(0, min(len(seg) - 1, next(i for i in range(len(seg)) if acc[i + 1] >= u) if u > 0 else 0)); r = (u - acc[j]) / (seg[j] or 1.0)
        return (P[j][0] + (P[j + 1][0] - P[j][0]) * r, P[j][1] + (P[j + 1][1] - P[j][1]) * r)
    q = [at(tot * i / n) for i in range(n)]
    for i in range(n):
        a, b, c = q[(i - jendela) % n], q[i], q[(i + jendela) % n]; v1 = (b[0] - a[0], b[1] - a[1]); v2 = (c[0] - b[0], c[1] - b[1]); n1, n2 = math.hypot(*v1), math.hypot(*v2)
        if n1 and n2: out.append(math.degrees(math.acos(max(-1, min(1, (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2))))))
    return out


def _simetri(ps, n=64):
    """IoU poligon dengan cerminannya terhadap sumbu vertikal bbox-nya (1.0 = simetris sempurna)."""
    xs = [p[0] for p in ps]; ys = [p[1] for p in ps]; x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys); w, h = x1 - x0, y1 - y0
    if w < 1 or h < 1: return 0.0
    def mask(pp):
        im = Image.new("L", (n, n), 0); ImageDraw.Draw(im).polygon([((x - x0) / w * (n - 1), (y - y0) / h * (n - 1)) for x, y in pp], fill=1); return np.asarray(im, bool)
    a = mask(ps); b = mask([(x1 - (x - x0), y) for x, y in ps]); u = (a | b).sum(); return float((a & b).sum() / u) if u else 0.0


def luwes_audit(log, warna_pakaian, batas_belok=55.0, batas_simetri=0.975, min_lebar=60):
    """Audit KELUWESAN pakaian dan aksesoris (terpisah dari audit proporsi tubuh). Untuk tiap poligon berwarna pakaian/aksesoris:
    (1) tidak ada sudut tajam (belok > batas_belok derajat antar sisi: ciri bangun datar kaku seperti persegi, segitiga, trapesium),
    (2) tidak terlalu simetris (IoU dengan cerminannya <= batas_simetri; hanya untuk bentuk selebar >= min_lebar px),
    (3) kurva berkelanjutan: poligon bertitik sangat sedikit (<= 5) dengan sisi lurus dominan dianggap kaku.
    Garis lurus panjang (resleting, sabuk) hanya dicatat. -> dict(lolos, gagal[list], diperiksa, garis_lurus)."""
    wp = {tuple(w) for w in warna_pakaian}; gagal = []; n = 0; lurus = 0
    for i, e in enumerate(log):
        if e[0] == "poly" and e[2] in wp and len(e[1]) >= 3:
            ps = e[1]; n += 1; bel = _belok(ps); mb = max(bel) if bel else 0.0; why = []
            if mb > batas_belok: why.append(f"sudut tajam {mb:.0f} derajat")
            if len(ps) <= 5: why.append(f"hanya {len(ps)} titik (bangun datar kaku)")
            xs = [p[0] for p in ps]
            if max(xs) - min(xs) >= min_lebar:
                s = _simetri(ps)
                if s > batas_simetri: why.append(f"terlalu simetris ({s:.3f})")
            if why: gagal.append(dict(indeks=i, warna=e[2], bbox=(round(min(xs)), round(min(p[1] for p in ps)), round(max(xs)), round(max(p[1] for p in ps))), alasan=why))
        elif e[0] == "line" and e[2] in wp and len(e[1]) == 2 and math.dist(*e[1]) >= 60: lurus += 1
    return dict(lolos=not gagal, gagal=gagal, diperiksa=n, garis_lurus=lurus)


class _RekamLimb:
    """Konteks: merekam semua pemanggilan fxlib.limb (lengan, kaki) selama audit, lalu memulihkannya."""
    def __enter__(self):
        self.asli = F.limb; self.rec = []
        def w(c, pts, w0, w1, col, *a, **k): self.rec.append((list(pts), float(w0), float(w1), tuple(col))); return self.asli(c, pts, w0, w1, col, *a, **k)
        F.limb = w; return self
    def __exit__(self, *e): F.limb = self.asli


def _lebar_di(ps, frac):
    ys = [p[1] for p in ps]; y0, y1 = min(ys), max(ys); y = y0 + frac * (y1 - y0); xs = []
    for i in range(len(ps)):
        a, b = ps[i], ps[(i + 1) % len(ps)]
        if (a[1] - y) * (b[1] - y) <= 0 and a[1] != b[1]: xs.append(a[0] + (y - a[1]) * (b[0] - a[0]) / (b[1] - a[1]))
    return (max(xs) - min(xs)) if len(xs) >= 2 else 0.0


def proporsi_audit(log, limbs, warna_badan, lebar_kanvas=1080, ref=1080):
    """Audit PROPORSI tubuh (terpisah dari keluwesan pakaian). Badan = poligon terbesar berwarna warna_badan:
    (1) tidak gepeng atau terlalu kurus: lebar/tinggi 0,50-0,95, (2) BUKAN oval/telur: luas poligon / luas elips-dalam-bbox >= 1,06, dan bahu (15 persen dari atas) minimal 85 persen lebar maksimum, ujung bawah (90 persen) minimal 80 persen,
    (3) anggota badan (lengan, kaki dari limb()) tidak letoy: tebal >= 38 px (pada lebar 1080), panjang/tebal <= 6, tekukan sendi >= 45 derajat (tidak terlipat atau bengkok berlebihan). -> dict(lolos, gagal, ukur)."""
    k = lebar_kanvas / ref; gagal = []; ukur = {}
    badan = [e for e in log if e[0] == "poly" and e[2] == tuple(warna_badan)]
    if not badan: return dict(lolos=False, gagal=["badan tidak ditemukan di rekaman"], ukur={})
    ps = max(badan, key=lambda e: _area(e[1]))[1]; xs = [p[0] for p in ps]; ys = [p[1] for p in ps]; w, h = max(xs) - min(xs), max(ys) - min(ys); asp = w / h
    fill = _area(ps) / (math.pi / 4 * w * h); bahu = _lebar_di(ps, 0.15) / w; ujung = _lebar_di(ps, 0.90) / w
    ukur.update(aspek=round(asp, 3), isi_vs_elips=round(fill, 3), bahu=round(bahu, 3), ujung=round(ujung, 3))
    if not 0.50 <= asp <= 0.95: gagal.append(f"badan gepeng atau terlalu kurus (lebar/tinggi {asp:.2f})")
    if fill < 1.06: gagal.append(f"badan oval/telur (isi terhadap elips {fill:.2f} < 1,06)")
    if bahu < 0.85: gagal.append(f"bahu menyempit seperti telur ({bahu:.2f} < 0,85 dari lebar maksimum)")
    if ujung < 0.80: gagal.append(f"ujung bawah badan menyempit ({ujung:.2f} < 0,80)")
    for pts, w0, w1, col in [x for x in limbs if min(x[1], x[2]) >= 45]:          # limb tipis (jahitan, garis detail) bukan anggota badan
        L = sum(math.dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1)); tebal = min(w0, w1)
        if tebal < 38 * k: gagal.append(f"anggota badan terlalu tipis ({tebal:.0f}px) = letoy")
        if L / max(w0, 1) > 6: gagal.append(f"anggota badan seperti mi (panjang/tebal {L / w0:.1f})")
        if len(pts) >= 3:
            a, b, c = pts[0], pts[1], pts[2]; v1 = (a[0] - b[0], a[1] - b[1]); v2 = (c[0] - b[0], c[1] - b[1]); n1, n2 = math.hypot(*v1), math.hypot(*v2)
            if n1 and n2:
                ang = math.degrees(math.acos(max(-1, min(1, (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2)))))
                if ang < 45: gagal.append(f"sendi tertekuk berlebihan ({ang:.0f} < 45 derajat)")
    ukur["anggota_badan"] = len(limbs)
    return dict(lolos=not gagal, gagal=sorted(set(gagal)), ukur=ukur)


def audit_karakter(warga, warna_pakaian, warna_badan, warna_kepala, poses=None, W=1080, H=1920, bg=(236, 238, 246)):
    """Jalankan fungsi karakter `warga(c, t, x, y, act, ...)` pada beberapa pose (diam, lompat di puncak dan saat mendarat/squash, kaget) lalu kumpulkan tiga audit:
    luwes_audit (pakaian/aksesoris), proporsi_audit (badan, anggota badan), wajah_audit (wajah utuh dan stabil saat squash-stretch). -> dict(luwes, proporsi, wajah, lolos)."""
    import canvas as C, ekspresi as E
    poses = poses or [("diam", 1.0), ("lompat", 0.10), ("lompat", 0.45), ("lompat", 0.62), ("lompat", 0.90), ("lompat", 1.02), ("kaget", 1.0)]
    rec_luwes = []; rec_prop = []; rel = []; gagal_w = []
    asli_wajah = E.wajah
    cap = {}
    def pembungkus(c, hx, hy, nama="netral", t=0.0, **kw):
        r = Rekam(c._c if isinstance(c, Rekam) else c); kw = dict(kw, efek=False); asli_wajah(r, hx, hy, nama, t, **kw); cap["hx"], cap["hy"], cap["log"], cap["nama"] = hx, hy, r.log, nama
    for act, tt in poses:
        c = C.Cv(bg); rc = Rekam(c); E.wajah = pembungkus
        try:
            with _RekamLimb() as rl: warga(rc, tt, W / 2, 1500, act, t0=0.0, seed=2)
        finally: E.wajah = asli_wajah
        pa = luwes_audit(rc.log, warna_pakaian); pr = proporsi_audit(rc.log, rl.rec, warna_badan, W)
        rec_luwes.append(pa); rec_prop.append(pr)
        kepala = [e for e in rc.log if e[0] == "poly" and e[2] == tuple(warna_kepala)]
        if kepala and cap:
            hp = max(kepala, key=lambda e: _area(e[1]))[1]; hx0, hx1 = min(p[0] for p in hp), max(p[0] for p in hp); hy0, hy1 = min(p[1] for p in hp), max(p[1] for p in hp)
            fitur = [e for e in cap["log"] if e[0] in ("ell", "poly", "line", "circ") and e[2] in {(52, 34, 28), (255, 251, 243)}]
            for e in fitur:
                pts = [(e[1][0], e[1][1])] if e[0] in ("ell", "circ") else e[1]
                for (x, y) in pts:
                    if not (hx0 + 4 <= x <= hx1 - 4 and hy0 + 4 <= y <= hy1 - 4): gagal_w.append(f"{act}@{tt}: fitur wajah keluar dari kepala di ({x:.0f},{y:.0f})")
            mata = [e for e in cap["log"] if e[0] == "ell" and abs(abs(e[1][0] - cap["hx"]) - 38) < 4 and abs(e[1][1] - (cap["hy"] + 8)) < 14 and e[2] == (52, 34, 28)]
            if mata: rel.append((cap["nama"], act, tt, [(round(e[1][0] - cap["hx"], 1), round(e[1][1] - cap["hy"], 1), round(e[1][2], 1)) for e in mata]))
    # posisi dan lebar mata relatif terhadap pusat kepala harus tetap, berapa pun squash/stretch tubuh
    base = {}
    for nm, act, tt, m in rel:
        if nm not in base: base[nm] = m; continue
        for (a_, b_) in zip(base[nm], m):
            if abs(a_[0] - b_[0]) > 2 or abs(a_[1] - b_[1]) > 2 or abs(a_[2] - b_[2]) > 1: gagal_w.append(f"{nm} {act}@{tt}: mata bergeser/berubah ukuran {a_} -> {b_}")
    luwes = dict(lolos=all(r["lolos"] for r in rec_luwes), gagal=[g for r in rec_luwes for g in r["gagal"]][:12], diperiksa=max(r["diperiksa"] for r in rec_luwes))
    prop = dict(lolos=all(r["lolos"] for r in rec_prop), gagal=sorted({g for r in rec_prop for g in r["gagal"]}), ukur=rec_prop[0]["ukur"])
    wajah = dict(lolos=not gagal_w, gagal=sorted(set(gagal_w))[:12], pose=len(poses))
    return dict(luwes=luwes, proporsi=prop, wajah=wajah, lolos=luwes["lolos"] and prop["lolos"] and wajah["lolos"])


# ---------------- GERBANG: semua audit wajib dalam SATU tempat ----------------
# ---------------- audit komposisi (6.10): objek melayang, landmark terpotong, objek utama tertutup ----------------
def cek_menapak(pangkal, permukaan_y, toleransi=6):
    """Objek yang berdiri (pohon, tiang, rumah, orang) harus MENAPAK. pangkal = [(nama, x, y_pangkal)]; permukaan_y(x) = tinggi permukaan yang sama dengan yang digambar (garis tanah, tepi teras, atap bangunan).
    Gagal bila |y_pangkal - permukaan_y(x)| > toleransi (melayang di atas atau terbenam di bawah permukaan). -> dict(lolos, melayang=[(nama, selisih_px)])."""
    buruk = [(n, round(y - permukaan_y(x), 1)) for n, x, y in pangkal if abs(y - permukaan_y(x)) > toleransi]
    return dict(lolos=not buruk, melayang=buruk)

def cek_komposisi(kotak, zona_terlarang, w=1080, h=1920, maks_tutup=0.0):
    """Objek utama (landmark, gedung, kapal, alat musik) harus UTUH di layar dan tidak tertimpa teks, scrim, equalizer, HUD, atau subtitle.
    kotak = {nama: (x0, y0, x1, y1)} kotak objek utama yang SUDAH dihitung dari gambarnya (bukan tebakan); zona_terlarang = {nama: (x0, y0, x1, y1)} untuk semua lapisan yang digambar di atasnya (scrim, kotak teks, bar, tanah depan).
    Gagal bila objek keluar layar atau bagian yang tertimpa melebihi `maks_tutup` (0 = tidak boleh tertimpa sama sekali). -> dict(lolos, keluar_layar, tertimpa=[(objek, zona, persen)])."""
    keluar = [n for n, (x0, y0, x1, y1) in kotak.items() if x0 < 0 or y0 < 0 or x1 > w or y1 > h]; tindih = []
    for n, (x0, y0, x1, y1) in kotak.items():
        luas = max(1e-9, (x1 - x0) * (y1 - y0))
        for zn, (a0, b0, a1, b1) in zona_terlarang.items():
            ix = max(0, min(x1, a1) - max(x0, a0)); iy = max(0, min(y1, b1) - max(y0, b0))
            if ix * iy / luas > maks_tutup: tindih.append((n, zn, round(100 * ix * iy / luas, 1)))
    return dict(lolos=not (keluar or tindih), keluar_layar=keluar, tertimpa=tindih)

class GerbangGagal(RuntimeError): pass

class Gerbang:
    """Gerbang wajib sebelum render final. Daftar audit yang diwajibkan ditentukan dari fitur yang dipakai; render final BOLEH hanya bila semuanya sudah dijalankan dan lolos.
        g = Gerbang(karakter=True, suara=True, geo=False, universe=False, komposisi=True, tekan=True)       # lighting ikut wajib otomatis bila diminta (F.IZIN)
        g.jalankan("luwes_audit", fungsi, ...)   atau   g.catat("sync_audit", lolos_bool, ringkas)
        g.periksa()                              # raise GerbangGagal bila ada audit belum jalan atau gagal; sebelum ffmpeg final, panggil ini."""
    SELALU = ("motion_report", "sfx_audit")
    def __init__(self, karakter=True, suara=False, geo=False, universe=False, izin=None, komposisi=True, tekan=True):
        izin = izin or F.IZIN; w = list(self.SELALU)
        if karakter: w += ["luwes_audit", "proporsi_audit", "wajah_audit"]
        if suara: w += ["sync_audit"] + (["mouth_check"] if karakter else [])
        if "lighting" in izin.aktif: w.append("light_check")
        if komposisi: w.append("komposisi_audit")                      # 6.10: objek menapak, landmark utuh dan tidak tertimpa
        if tekan: w.append("tekan_audit")                              # 6.9: kata kunci diberi penekanan
        if geo: w.append("geo_selfcheck")
        if universe: w.append("universe_selfcheck")
        self.wajib = w; self.hasil = {}
    def catat(self, nama, lolos, ringkas=""):
        self.hasil[nama] = (bool(lolos), ringkas); return bool(lolos)
    def jalankan(self, nama, fungsi, *a, ok=None, **k):
        r = fungsi(*a, **k)
        if ok is None: ok = (lambda x: x.get("lolos", False)) if isinstance(r, dict) else (lambda x: bool(x))
        self.catat(nama, ok(r), str(r)[:160]); return r
    def laporan(self):
        return {n: ("LOLOS" if n in self.hasil and self.hasil[n][0] else "GAGAL" if n in self.hasil else "BELUM DIJALANKAN") for n in self.wajib}
    def periksa(self):
        lap = self.laporan(); buruk = {n: s for n, s in lap.items() if s != "LOLOS"}
        if buruk: raise GerbangGagal("render final DITOLAK, audit wajib belum beres: " + "; ".join(f"{n}={s}" for n, s in buruk.items()))
        return lap
