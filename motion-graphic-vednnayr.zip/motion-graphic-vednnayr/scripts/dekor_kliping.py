# dekor_kliping.py - Perangkat dekor bergaya KLIPING / ARSIP: papan benang merah (papan investigasi atau konspirasi), foto polaroid berisi siluet abu-abu, pin, benang merah, selotip, bercak halftone (bagian 6.14).
# Aturan (2026-11-11, dari user): karakter flat atau objek TIDAK boleh ditempel langsung ke kolase gaya ini (terasa tidak cocok). Bungkus dulu dengan dekorasi papan benang merah, lalu masukkan karakter (flat-life atau lainnya)
# atau objek ke dalam foto polaroid yang di-pin di papan. Karakter boleh berwarna ABU PENUH: abu penuh berarti rahasia atau privasi (pengirim anonim, sumber yang dirahasiakan); warna dipakai hanya bila peran perlu dibedakan.
# Semua sprite 2x (SC=2), bergradien (6.12), dan memakai font dari fonts_gaya (6.13). put dan pop dipinjam dari render proyek (put(img, sprite, x, y, skala, rotasi), pop(T, t0, durasi) -> skala).
import math, random, functools
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
import gradien as G
import fonts_gaya as FG

SC = 2
KRAFT = (190, 150, 104)
MERAH_BENANG = (206, 34, 44)
ABU = dict(kepala=[(0, (226, 226, 230)), (1, (170, 170, 176))], badan=[(0, (176, 176, 182)), (1, (112, 112, 120))], rambut=[(0, (96, 96, 104)), (1, (44, 44, 52))], latar=[(0, (228, 228, 232)), (1, (184, 184, 190))])


@functools.lru_cache(None)
def tape(w=170, h=52, color=(255, 214, 90), seed=1):
    """Selotip kertas (masking tape) semi transparan bertepi gerigi, bergradien."""
    rng = random.Random(seed); W2, H2 = w * SC, h * SC; m = 10 * SC; im = Image.new("RGBA", (W2 + 2 * m, H2 + 2 * m), (0, 0, 0, 0)); ps = []
    for i in range(7): ps.append((m + rng.uniform(0, 6) * SC, m + H2 * i / 6))
    for i in range(1, 12): ps.append((m + W2 * i / 12, m + H2 + rng.uniform(-1, 1) * SC))
    for i in range(6, -1, -1): ps.append((m + W2 - rng.uniform(0, 6) * SC, m + H2 * i / 6))
    for i in range(11, 0, -1): ps.append((m + W2 * i / 12, m + rng.uniform(-1, 1) * SC))
    _m = Image.new("L", im.size, 0); ImageDraw.Draw(_m).polygon(ps, fill=255); layer = G.isi(_m, warna=color, sudut=20, kilap=0.10); a = layer.split()[3].point(lambda v: int(v * 0.88)); layer.putalpha(a)
    sh = Image.new("RGBA", im.size, (0, 0, 0, 0)); sh.paste(Image.new("RGBA", im.size, (0, 0, 0, 60)), (2 * SC, 3 * SC), _m); sh = sh.filter(ImageFilter.GaussianBlur(3 * SC)); return Image.alpha_composite(sh, layer)


@functools.lru_cache(None)
def titik(w=260, h=200, color=(255, 255, 255), seed=1):
    """Bercak halftone (titik membesar ke satu sisi), bergradien; mengisi ruang tanpa jadi blok datar."""
    W2, H2 = w * SC, h * SC; yy, xx = np.mgrid[0:H2, 0:W2].astype(np.float32); s = 16.0 * SC / 2; cu, cv = (xx % s) - s / 2, (yy % s) - s / 2; dist = np.sqrt(cu ** 2 + cv ** 2)
    r = (0.6 + 4.6 * (xx / W2)) * SC; mk = ((dist < r) & (((xx - W2 / 2) / (W2 / 2)) ** 2 + ((yy - H2 / 2) / (H2 / 2)) ** 2 < 1.0)).astype(np.uint8) * 255
    return G.isi(Image.fromarray(mk, "L"), warna=color, sudut=45, kilap=0.0)


@functools.lru_cache(None)
def pin(warna=MERAH_BENANG, r=13):
    """Paku payung (pin) berkepala bulat bergradien dengan kilap kecil dan bayangan."""
    S = 2 * r * SC + 16 * SC; im = Image.new("RGBA", (S, S), (0, 0, 0, 0)); c = S // 2; m = Image.new("L", (S, S), 0); ImageDraw.Draw(m).ellipse([c - r * SC, c - r * SC, c + r * SC, c + r * SC], fill=255)
    sh = Image.new("RGBA", (S, S), (0, 0, 0, 0)); sh.paste(Image.new("RGBA", (S, S), (0, 0, 0, 110)), (3 * SC, 4 * SC), m); sh = sh.filter(ImageFilter.GaussianBlur(3 * SC)); im.alpha_composite(sh)
    im.alpha_composite(G.isi(m, stops=G.stops_dari(warna, terang=0.30, gelap=0.30, geser_hue=0), sudut=45)); hl = Image.new("RGBA", (S, S), (0, 0, 0, 0)); ImageDraw.Draw(hl).ellipse([c - r * SC // 2, c - r * SC // 2 - 2 * SC, c - r * SC // 8, c - r * SC // 8 - 2 * SC], fill=(255, 255, 255, 170)); im.alpha_composite(hl.filter(ImageFilter.GaussianBlur(SC)))
    return im


@functools.lru_cache(None)
def papan(w=900, h=300, seed=1):
    """Papan gabus atau kraft berbingkai kayu (papan investigasi): bidang kraft bergradien berbintik, bayangan tepi dalam, bingkai kayu bergradien, bayangan jatuh."""
    rng = np.random.default_rng(seed); W2, H2 = w * SC, h * SC; m = 14 * SC; base = G.blok(W2, H2, stops=[(0, (214, 176, 126)), (1, (168, 128, 84))], sudut=65, kilap=0.0, tepi=False)
    a = np.asarray(base).astype(np.float32); nz = rng.standard_normal(a.shape[:2]).astype(np.float32) * 7; bit = (rng.random(a.shape[:2]) < 0.012).astype(np.float32) * -38; a[..., :3] = np.clip(a[..., :3] + (nz + bit)[..., None], 0, 255); base = Image.fromarray(a.astype(np.uint8), "RGBA")
    inner = Image.new("L", (W2, H2), 0); ImageDraw.Draw(inner).rectangle([m, m, W2 - m, H2 - m], fill=255); edge = ImageDraw.Draw(Image.new("L", (1, 1)))
    ish = Image.new("L", (W2, H2), 0); ImageDraw.Draw(ish).rectangle([m - 2, m - 2, W2 - m + 2, H2 - m + 2], outline=255, width=3 * SC); ish = ish.filter(ImageFilter.GaussianBlur(7 * SC)); dark = Image.new("RGBA", (W2, H2), (60, 38, 20, 0)); dark.putalpha(ish.point(lambda v: int(v * 0.55))); base.alpha_composite(dark)
    fr = Image.new("L", (W2, H2), 0); d = ImageDraw.Draw(fr); d.rectangle([0, 0, W2 - 1, H2 - 1], fill=255); d.rectangle([m, m, W2 - m, H2 - m], fill=0); out = Image.new("RGBA", (W2 + 24 * SC, H2 + 24 * SC), (0, 0, 0, 0)); ox = 12 * SC
    sh = Image.new("RGBA", out.size, (0, 0, 0, 0)); full = Image.new("L", (W2, H2), 255); sh.paste(Image.new("RGBA", (W2, H2), (0, 0, 0, 120)), (ox + 4 * SC, ox + 7 * SC), full); out.alpha_composite(sh.filter(ImageFilter.GaussianBlur(7 * SC)))
    board = Image.composite(base, Image.new("RGBA", (W2, H2), (0, 0, 0, 0)), inner); board.alpha_composite(G.isi(fr, stops=[(0, (150, 106, 64)), (1, (84, 56, 32))], sudut=70)); out.alpha_composite(board, (ox, ox)); return out


@functools.lru_cache(None)
def siluet_orang(gaya=0, ukuran=120, baju=None):
    """Busto siluet orang (kepala, bahu, topi atau rambut) TANPA wajah; baju=None memberi ABU PENUH (rahasia atau privasi), baju=warna RGB memberi baju berwarna. gaya: 0 topi, 1 peci, 2 rambut digelung, 3 kacamata."""
    S = ukuran * SC; im = Image.new("RGBA", (S, S), (0, 0, 0, 0)); cx = S // 2; mk = lambda: Image.new("L", im.size, 0)
    def isi_(mask, stops, sd=80): im.alpha_composite(G.isi(mask, stops=stops, sudut=sd))
    b = mk(); ImageDraw.Draw(b).ellipse([cx - int(S * .46), int(S * .66), cx + int(S * .46), int(S * 1.6)], fill=255); isi_(b, ABU["badan"] if baju is None else G.stops_dari(baju, terang=0.12, gelap=0.16), 70)
    n = mk(); ImageDraw.Draw(n).rectangle([cx - int(S * .07), int(S * .56), cx + int(S * .07), int(S * .72)], fill=255); isi_(n, [(0, (190, 190, 196)), (1, (140, 140, 148))])
    if gaya == 2: hb = mk(); ImageDraw.Draw(hb).ellipse([cx - int(S * .14), int(S * .02), cx + int(S * .14), int(S * .26)], fill=255); isi_(hb, ABU["rambut"])
    hd = mk(); ImageDraw.Draw(hd).ellipse([cx - int(S * .25), int(S * .17), cx + int(S * .25), int(S * .73)], fill=255); isi_(hd, ABU["kepala"], 60)
    hr = mk(); d = ImageDraw.Draw(hr)
    if gaya in (0, 2): d.pieslice([cx - int(S * .27), int(S * .13), cx + int(S * .27), int(S * .58)], 180, 360, fill=255)
    if gaya == 0: d.rectangle([cx - int(S * .38), int(S * .26), cx + int(S * .38), int(S * .30)], fill=255)
    if gaya == 1: d.rectangle([cx - int(S * .22), int(S * .05), cx + int(S * .22), int(S * .26)], fill=255)
    if gaya == 3: d.pieslice([cx - int(S * .26), int(S * .14), cx + int(S * .26), int(S * .52)], 190, 350, fill=255)
    isi_(hr, ABU["rambut"], 70)
    if gaya == 3: g_ = ImageDraw.Draw(im); [g_.ellipse([cx + k * int(S * .11) - int(S * .07), int(S * .40), cx + k * int(S * .11) + int(S * .07), int(S * .53)], outline=(40, 40, 48, 255), width=3 * SC) for k in (-1, 1)]; g_.line([(cx - int(S * .04), int(S * .46)), (cx + int(S * .04), int(S * .46))], fill=(40, 40, 48, 255), width=3 * SC)
    return im


@functools.lru_cache(None)
def siluet_objek(kind="ponsel", ukuran=120):
    """Objek siluet abu-abu untuk foto polaroid: ponsel, amplop, kaca (kaca pembesar), megafon. Bergradien abu."""
    S = ukuran * SC; im = Image.new("RGBA", (S, S), (0, 0, 0, 0)); mk = lambda: Image.new("L", im.size, 0)
    def isi_(mask, stops, sd=70): im.alpha_composite(G.isi(mask, stops=stops, sudut=sd))
    if kind == "ponsel":
        a = mk(); ImageDraw.Draw(a).rounded_rectangle([int(S * .28), int(S * .06), int(S * .72), int(S * .94)], int(S * .08), fill=255); isi_(a, ABU["rambut"]); b = mk(); ImageDraw.Draw(b).rounded_rectangle([int(S * .33), int(S * .15), int(S * .67), int(S * .82)], int(S * .03), fill=255); isi_(b, [(0, (214, 214, 220)), (1, (150, 150, 158))])
        c = mk(); ImageDraw.Draw(c).rounded_rectangle([int(S * .38), int(S * .26), int(S * .62), int(S * .34)], int(S * .02), fill=255); ImageDraw.Draw(c).rounded_rectangle([int(S * .38), int(S * .40), int(S * .56), int(S * .47)], int(S * .02), fill=255); isi_(c, [(0, (118, 118, 126)), (1, (86, 86, 94))])
    elif kind == "amplop":
        a = mk(); ImageDraw.Draw(a).rounded_rectangle([int(S * .08), int(S * .22), int(S * .92), int(S * .80)], int(S * .04), fill=255); isi_(a, ABU["kepala"], 60); f = mk(); ImageDraw.Draw(f).polygon([(int(S * .08), int(S * .22)), (int(S * .92), int(S * .22)), (S // 2, int(S * .58))], fill=255); isi_(f, ABU["badan"], 80)
    elif kind == "kaca":
        r = mk(); d = ImageDraw.Draw(r); d.ellipse([int(S * .12), int(S * .10), int(S * .66), int(S * .64)], outline=255, width=int(S * .09)); d.line([(int(S * .60), int(S * .58)), (int(S * .88), int(S * .88))], fill=255, width=int(S * .12)); isi_(r, ABU["rambut"])
        l_ = mk(); ImageDraw.Draw(l_).ellipse([int(S * .17), int(S * .15), int(S * .61), int(S * .59)], fill=255); lens = G.isi(l_, stops=[(0, (240, 240, 244)), (1, (190, 190, 198))], sudut=60); lens.putalpha(lens.split()[3].point(lambda v: int(v * 0.65))); im.alpha_composite(lens)
    else:
        a = mk(); ImageDraw.Draw(a).polygon([(int(S * .16), int(S * .40)), (int(S * .46), int(S * .40)), (int(S * .86), int(S * .16)), (int(S * .86), int(S * .84)), (int(S * .46), int(S * .60)), (int(S * .16), int(S * .60))], fill=255); isi_(a, ABU["rambut"]); h_ = mk(); ImageDraw.Draw(h_).rectangle([int(S * .22), int(S * .58), int(S * .34), int(S * .88)], fill=255); isi_(h_, ABU["badan"])
    return im


_POL = {}


def polaroid(isi=None, label="", seed=1, lebar=150):
    """Foto polaroid (bingkai kertas putih bergradien) berisi siluet abu-abu di bidang foto abu muda, label tulisan tangan (Kalam) di bawah, dan pin merah di atas. -> (sprite 2x, jangkar_pin) dengan jangkar_pin = (dx, dy) piksel 1x dari PUSAT sprite ke pusat pin."""
    kunci = (id(isi), label, seed, lebar)
    if kunci in _POL: return _POL[kunci]
    W1, H1 = lebar, int(lebar * 1.30); W2, H2 = W1 * SC, H1 * SC; m = 12 * SC; im = Image.new("RGBA", (W2 + 2 * m, H2 + 2 * m), (0, 0, 0, 0))
    mm = Image.new("L", (W2, H2), 255); sh = Image.new("RGBA", im.size, (0, 0, 0, 0)); sh.paste(Image.new("RGBA", (W2, H2), (0, 0, 0, 100)), (m + 3 * SC, m + 5 * SC), mm); im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(4 * SC)))
    kertas = G.blok(W2, H2, stops=[(0, (255, 254, 250)), (1, (232, 226, 212))], sudut=70, kilap=0.0, tepi=False); im.alpha_composite(kertas, (m, m))
    px, py, pw = 11 * SC, 24 * SC, W2 - 22 * SC; ph = pw; foto = G.blok(pw, ph, stops=ABU["latar"], sudut=80, kilap=0.0, tepi=False)
    if isi is not None:
        k = min(pw, ph) * 0.86 / max(isi.width, isi.height); s2 = isi.resize((int(isi.width * k), int(isi.height * k)), Image.LANCZOS); foto.alpha_composite(s2, ((pw - s2.width) // 2, (ph - s2.height) // 2 + int(ph * 0.03)))
    im.alpha_composite(foto, (m + px, m + py))
    if label:
        f = FG.font(FG.spek("KLIPING", "catatan"), 24 * SC); l, t, r, b = f.getbbox(label)
        while r - l > pw and f.size > 10 * SC: f = FG.font(FG.spek("KLIPING", "catatan"), f.size - 2); l, t, r, b = f.getbbox(label)
        ImageDraw.Draw(im).text((m + (W2 - (r - l)) // 2 - l, m + py + ph + (H2 - py - ph - (b - t)) // 2 - t - 2 * SC), label, font=f, fill=(40, 36, 44, 255))
    p = pin(); im.alpha_composite(p, (m + W2 // 2 - p.width // 2, m + 12 * SC - p.height // 2))
    _POL[kunci] = (im, (0.0, (m + 12 * SC - im.height / 2) / SC)); return _POL[kunci]


def benang(img, a, b, p=1.0, kendur=34, warna=MERAH_BENANG, tebal=5):
    """Benang merah dari titik a ke b (koordinat frame 1x), melengkung turun seperti tali kendur, tergambar sebanyak p (0..1), dengan bayangan lembut. Bekerja pada gambar RGB atau RGBA."""
    if p <= 0: return
    n = 36; cx, cy = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2 + kendur; pts = [((1 - t) ** 2 * a[0] + 2 * (1 - t) * t * cx + t * t * b[0], (1 - t) ** 2 * a[1] + 2 * (1 - t) * t * cy + t * t * b[1]) for t in [i / n for i in range(n + 1)]]
    pts = pts[:max(2, int(len(pts) * min(1.0, p)))]; lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.line([(x + 2, y + 4) for x, y in pts], fill=(0, 0, 0, 70), width=tebal + 1); d.line(pts, fill=warna + (255,), width=tebal); d.line([(x - 1, y - 1) for x, y in pts], fill=(255, 150, 150, 120), width=1)
    if img.mode == "RGBA": img.alpha_composite(lay)
    else: img.paste(lay, (0, 0), lay)


def susun_papan(img, T, put, pop, cx, cy, w, h, kartu, tali=(), t0=0.0, seed=1, kendur=30):
    """Papan benang merah utuh: papan (cx, cy, w, h pada frame 1x), foto polaroid ber-pin, benang merah antar pin.
    kartu: [dict(isi=sprite siluet, label='', dx=, dy=, rot=, lebar=150)], dx dan dy dari pusat papan; tali: [(i, j)] indeks kartu yang dihubungkan; kemunculan bertahap mulai t0."""
    put(img, papan(w, h, seed), cx, cy, pop(T, t0, .45), 0); jang = []; waktu = []
    for n, k in enumerate(kartu):
        sp, (ax, ay) = polaroid(k.get("isi"), k.get("label", ""), seed * 10 + n, k.get("lebar", 150)); x, y, rot = cx + k["dx"], cy + k["dy"], k.get("rot", 0); tk = t0 + 0.30 + 0.25 * n; put(img, sp, x, y, pop(T, tk, .4), rot)
        th = math.radians(rot); jang.append((x + ax * math.cos(th) + ay * math.sin(th), y - ax * math.sin(th) + ay * math.cos(th))); waktu.append(tk + 0.35)
    for i, j in tali: benang(img, jang[i], jang[j], max(0.0, min(1.0, (T - max(waktu[i], waktu[j])) / 0.5)), kendur)
    return jang
