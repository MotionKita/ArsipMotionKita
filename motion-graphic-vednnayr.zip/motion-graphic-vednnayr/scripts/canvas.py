# canvas.py - kanvas Cv (Pillow, supersampling 2x) + easing + geometri. Dipakai oleh karakter.py, universe_kit.py, dan scene video.
# Ubah W, H, FPS di bawah sesuai rasio video (9:16 = 1080x1920). Cv.out() mengembalikan frame RGB ukuran W x H.
import math
from contextlib import contextmanager
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont

W, H, S, FPS = 1080, 1920, 2, 30          # ubah sesuai rasio/fps video; S = supersampling
FONT = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"



@lru_cache(None)
def font(px):
    return ImageFont.truetype(FONT, max(4, int(px)))


# ---------- easing ----------
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def prog(t, t0, d): return clamp((t - t0) / d)
def e_out(p): return 1 - (1 - p) ** 3
def e_in(p): return p ** 3
def e_io(p): return 0.5 - 0.5 * math.cos(math.pi * p)
def e_back(p, s=1.70158):
    p -= 1
    return p * p * ((s + 1) * p + s) + 1
def lerp(a, b, p): return a + (b - a) * p
def mix(c1, c2, a): return tuple(int(c1[i] + (c2[i] - c1[i]) * a) for i in range(3))
def popin(t, t0, d=0.45):
    p = prog(t, t0, d)
    return e_back(p) if p > 0 else 0.0


# ---------- geometry ----------
def rrect_pts(x0, y0, x1, y1, r, n=8):
    r = max(0, min(r, (x1 - x0) / 2, (y1 - y0) / 2))
    ps = []
    for cx, cy, a0 in [(x1 - r, y0 + r, -90), (x1 - r, y1 - r, 0), (x0 + r, y1 - r, 90), (x0 + r, y0 + r, 180)]:
        for i in range(n + 1):
            a = math.radians(a0 + 90 * i / n)
            ps.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return ps


def circle_pts(x, y, r, n=48):
    return [(x + r * math.cos(2 * math.pi * i / n), y + r * math.sin(2 * math.pi * i / n)) for i in range(n + 1)]


def arc_pts(x, y, r, a0, a1, n=24):
    return [(x + r * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
             y + r * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]


def heart_pts(x, y, r):
    ps = []
    for i in range(64):
        t = 2 * math.pi * i / 64
        hx = 16 * math.sin(t) ** 3
        hy = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        ps.append((x + hx * r / 16, y + (hy - 2.5) * r / 16))
    return ps


def partial(pts, frac):
    segs = [math.dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1)]
    target = sum(segs) * clamp(frac)
    out = [pts[0]]
    acc = 0.0
    for i, sl in enumerate(segs):
        if acc + sl <= target:
            out.append(pts[i + 1]); acc += sl
        else:
            r = (target - acc) / sl if sl else 0
            out.append((pts[i][0] + (pts[i + 1][0] - pts[i][0]) * r, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * r))
            break
    return out


# ---------- canvas ----------
class Cv:
    def __init__(self, bg, cam=(540, 960, 1.0)):
        self.im = Image.new("RGB", (W * S, H * S), bg)
        self.d = ImageDraw.Draw(self.im)
        self.st = []
        self.cam = cam

    def push(self, tx=0, ty=0, s_=1.0, rot=0.0, px=0.0, py=0.0):
        self.st.append((tx, ty, s_, math.radians(rot), px, py))

    def pull(self):
        self.st.pop()

    @contextmanager
    def xf(self, **kw):
        self.push(**kw)
        try:
            yield
        finally:
            self.pull()

    def P(self, x, y):
        for (tx, ty, sc, rot, px, py) in reversed(self.st):
            dx, dy = (x - px) * sc, (y - py) * sc
            if rot:
                cr, sr = math.cos(rot), math.sin(rot)
                dx, dy = dx * cr - dy * sr, dx * sr + dy * cr
            x, y = px + dx + tx, py + dy + ty
        cx, cy, z = self.cam
        return ((x - cx) * z + W / 2) * S, ((y - cy) * z + H / 2) * S

    def K(self):
        k = self.cam[2] * S
        for t in self.st:
            k *= t[2]
        return k

    def poly(self, ps, fill):
        self.d.polygon([self.P(x, y) for x, y in ps], fill=fill)

    def ell(self, cx, cy, rx, ry, fill):
        m = max(rx, ry)
        n = 24 if m < 30 else 40 if m < 120 else 72
        self.poly([(cx + rx * math.cos(2 * math.pi * i / n), cy + ry * math.sin(2 * math.pi * i / n)) for i in range(n)], fill)

    def circ(self, x, y, r, fill):
        self.ell(x, y, r, r, fill)

    def rr(self, x0, y0, x1, y1, r, fill):
        self.poly(rrect_pts(x0, y0, x1, y1, r), fill)

    def line(self, ps, w, fill, cap=True):
        sp = [self.P(x, y) for x, y in ps]
        wk = w * self.K()
        for i in range(len(sp) - 1):
            (x0, y0), (x1, y1) = sp[i], sp[i + 1]
            dx, dy = x1 - x0, y1 - y0
            L = math.hypot(dx, dy) or 1e-6
            nx, ny = -dy / L * wk / 2, dx / L * wk / 2
            self.d.polygon([(x0 + nx, y0 + ny), (x1 + nx, y1 + ny), (x1 - nx, y1 - ny), (x0 - nx, y0 - ny)], fill=fill)
        if cap:
            for (x, y) in sp:
                self.d.ellipse([x - wk / 2, y - wk / 2, x + wk / 2, y + wk / 2], fill=fill)

    def text(self, x, y, t, size, fill, anchor="mm"):
        px, py = self.P(x, y)
        self.d.text((px, py), t, font=font(size * self.K()), fill=fill, anchor=anchor)

    def out(self):
        return self.im.reduce(S)

