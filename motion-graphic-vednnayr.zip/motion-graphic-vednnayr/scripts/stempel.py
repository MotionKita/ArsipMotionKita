# stempel.py - Smart Stempel (bagian 6.11). Stempel = vonis visual atas SATU klaim: HOAKS, SALAH, BETUL, TERBUKTI, dan sejenisnya.
# Tiga keputusan otomatis: (1) KAPAN stempel dipakai (hanya bila naskah memberi vonis atas klaim yang sudah diperiksa di lembar Fakta), (2) KATA apa (HOAKS/SALAH/BOHONG/MITOS/KELIRU, BENAR/BETUL/FAKTA/TERBUKTI/ASLI, atau netral),
# (3) WARNA apa: diambil dari palet gaya visual yang aktif (merah tema untuk vonis negatif, hijau tema untuk positif, dst.), bukan merah/hijau generik, dan dijaga kontras terhadap latar tempat stempel jatuh.
# Bahan stempel mengikuti gaya visual (tinta karet, garis teknik, timbul emas, kaca, blok label, spidol tangan). Semua bahan memakai gradien atau variasi tinta, bukan satu warna datar (bagian 6.12).
import os, re, random, functools
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import gradien as G

# ---------- kosakata vonis ----------
NEGATIF = ("HOAKS", "SALAH", "BOHONG", "PALSU", "MITOS", "KELIRU", "DITOLAK", "DIBATALKAN", "TIDAK TERBUKTI", "MENYESATKAN")
POSITIF = ("BENAR", "BETUL", "FAKTA", "TERBUKTI", "ASLI", "TERVERIFIKASI", "DISETUJUI", "AMAN", "DICEK")
NETRAL = ("ILUSTRASI", "SIMULASI", "BELUM TERVERIFIKASI", "DIPERIKSA", "KLAIM", "PENTING", "RAHASIA", "ARSIP", "CONTOH")
VOKAB = {**{k: "negatif" for k in NEGATIF}, **{k: "positif" for k in POSITIF}, **{k: "netral" for k in NETRAL}}

# pemicu di teks naskah (frasa -> kata stempel). Urutan = prioritas. Pemicu hanya mengusulkan; `cek_stempel` tetap menuntut dasar di lembar Fakta.
PEMICU = [
    (r"\b(itu|ini|kabar itu|pesan itu|klaim itu)\s+(adalah\s+)?hoaks\b|\bhoaks\b", "HOAKS"),
    (r"\bternyata\s+(salah|keliru)\b|\bfaktanya\s+(salah|keliru)\b|\bkeliru\b", "SALAH"),
    (r"\bbohong\b|\bdusta\b", "BOHONG"),
    (r"\bmitos\b|\bkata orang\b.*\btidak (benar|terbukti)\b", "MITOS"),
    (r"\btidak terbukti\b|\bbelum terbukti\b", "TIDAK TERBUKTI"),
    (r"\bmenyesatkan\b", "MENYESATKAN"),
    (r"\bterbukti\b", "TERBUKTI"),
    (r"\bfaktanya\b|\bnyatanya benar\b", "FAKTA"),
    (r"\b(ternyata|memang|ya)\s+(benar|betul)\b|\bbenar\b|\bbetul\b", "BENAR"),
    (r"\bterverifikasi\b|\bsudah dicek\b", "TERVERIFIKASI"),
]
KONTEKS_VIRAL = re.compile(r"\b(pesan|grup|viral|sebarkan|diteruskan|media sosial|broadcast|berantai|twitter|whatsapp|tiktok|beredar)\b", re.I)
KONTEKS_SANTAI = re.compile(r"\b(nggak|gak|banget|sih|dong|kan|lho|emang|bener|betul)\b", re.I)


def pilih_stempel(teks, status=None, santai=None):
    """Putuskan kata stempel dari kalimat klaim/vonis dan status hasil pemeriksaan (lembar Fakta).
    status: 'salah' | 'benar' | 'mitos' | 'terbukti' | 'belum' | 'ilustrasi' | None (tidak diketahui -> hanya dari kata di teks).
    Bahasa santai (nggak, banget, sih...) memilih BETUL; baku memilih BENAR. Vonis salah pada kabar yang beredar (grup, viral, media sosial) memilih HOAKS; kesalahan fakta biasa memilih SALAH.
    -> dict(kata, polaritas, pemicu, alasan), atau None bila tidak ada vonis (jangan memberi stempel hanya untuk hiasan)."""
    t = teks or ""; santai = bool(KONTEKS_SANTAI.search(t)) if santai is None else santai; viral = bool(KONTEKS_VIRAL.search(t))
    peta = {"salah": "HOAKS" if viral else "SALAH", "mitos": "MITOS", "benar": "BETUL" if santai else "BENAR", "terbukti": "TERBUKTI", "belum": "BELUM TERVERIFIKASI", "ilustrasi": "ILUSTRASI"}
    if status in peta:
        k = peta[status]; return dict(kata=k, polaritas=VOKAB[k], pemicu=f"status pemeriksaan '{status}'", alasan=f"hasil pemeriksaan fakta = {status}" + ("; konteks kabar beredar maka HOAKS" if status == "salah" and viral else ""))
    for pola, k in PEMICU:
        m = re.search(pola, t, re.I)
        if m:
            if k == "BENAR" and santai: k = "BETUL"
            return dict(kata=k, polaritas=VOKAB[k], pemicu=m.group(0), alasan=f"naskah memberi vonis: '{m.group(0)}'")
    return None


# ---------- warna dari tema ----------
TARGET_HUE = {"negatif": 6.0, "positif": 142.0, "netral": 222.0}


def _lum(c):
    def f(v): v /= 255; return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (f(v) for v in G._rgb(c)); return 0.2126 * r + 0.7152 * g + 0.0722 * b


def kontras(a, b):
    la, lb = _lum(a), _lum(b); hi, lo = max(la, lb), min(la, lb); return (hi + 0.05) / (lo + 0.05)


def _selisih_hue(a, b): d = abs(a - b) % 360; return min(d, 360 - d)


def warna_stempel(polaritas, palet=None, latar=None, min_kontras=3.0, toleransi=32):
    """Pilih warna stempel dari palet gaya visual. Merah untuk vonis negatif, hijau untuk positif, biru/tinta untuk netral, TETAPI diambil dari palet bila ada warna dengan hue dekat (<= toleransi derajat);
    bila tidak ada, warna dibuat pada hue target dengan jenuh dan terang meniru warna palet paling jenuh (supaya terasa satu keluarga dengan tema, bukan merah generik).
    latar = warna latar tempat stempel jatuh; kontras dijaga >= min_kontras dengan menggeser terang. -> (rgb, info dict)."""
    palet = palet or {}; cands = []
    for k, v in palet.items():
        try: h, l, s = G.hls(v)
        except Exception: continue
        if s > 0.30 and 0.15 < l < 0.75: cands.append((k, v, h, l, s))
    tgt = TARGET_HUE.get(polaritas, 222.0); dekat = [c for c in cands if _selisih_hue(c[2], tgt) <= toleransi]
    if polaritas == "netral":                                         # netral: tinta tua dari palet (teks atau hitam), bukan warna vonis
        tinta = palet.get("teks") or palet.get("hitam") or palet.get("garis") or "#2a2a33"; warna = G._rgb(tinta); sumber = "palet:tinta"
        if _lum(warna) > 0.5 and latar is not None and _lum(latar) > 0.5: warna = (40, 44, 70)
    elif dekat:
        c = min(dekat, key=lambda c: _selisih_hue(c[2], tgt) - 12 * c[4]); warna = G._rgb(c[1]); sumber = f"palet:{c[0]}"
    else:
        s = float(np.mean([c[4] for c in sorted(cands, key=lambda c: -c[4])[:2]])) if cands else 0.75; l = float(np.mean([c[3] for c in sorted(cands, key=lambda c: -c[4])[:2]])) if cands else 0.45
        warna = G.dari_hls(tgt, min(0.55, max(0.38, l)), min(0.9, max(0.55, s))); sumber = f"hue {tgt:.0f} dengan jenuh dan terang meniru palet"
    ok = True
    if latar is not None and kontras(warna, latar) < min_kontras:
        h, l, s = G.hls(warna); terbaik = None                       # cari terang terdekat (ke arah mana pun) yang memenuhi kontras, hue dan jenuh tetap
        for d in range(1, 21):
            for arah in (-1, 1):
                l2 = l + 0.03 * d * arah
                if not 0.20 <= l2 <= 0.80: continue
                c2 = G.dari_hls(h, l2, s)
                if kontras(c2, latar) >= min_kontras and terbaik is None: terbaik = c2
            if terbaik is not None: break
        if terbaik is not None: warna = terbaik
        else:
            warna = max((G.dari_hls(h, x / 100, s) for x in range(20, 81, 3)), key=lambda c: kontras(c, latar))
        ok = kontras(warna, latar) >= min_kontras
    return warna, dict(sumber=sumber, kontras=round(kontras(warna, latar), 2) if latar is not None else None, perlu_alas=not ok)


# ---------- bahan per gaya ----------
BAHAN_GAYA = dict(ARSIP="tinta", KLIPING="tinta", BLUEPRINT="garis", TERMINAL="garis", HIKAYAT="timbul", CAIR="kaca", MIDNIGHT="kaca", MINIATUR="kaca",
                  GEOMETRIK="blok", LANTANG="blok", PETA="blok", FLATLIFE="blok", SKETSA="tangan")
ROT_SARAN = dict(tinta=-9, garis=0, timbul=-3, kaca=-4, blok=-5, tangan=-6)
import fonts_gaya as FG
_CUR = dict(gaya="KLIPING")   # gaya yang sedang dirender; font stempel diambil dari fonts_gaya.PERAN (peran stempel, lalu judul_lebar, judul, catatan, caption)
SC = 2


def _folder():
    here = os.path.dirname(os.path.abspath(__file__))
    for d in (os.path.join(os.getcwd(), "fonts"), os.path.join(here, "fonts"), os.path.join(os.path.dirname(here), "fonts")):
        if os.path.isdir(d): return d
    raise FileNotFoundError("folder fonts/ tidak ditemukan; stempel butuh berkas font nyata (jangan diganti diam-diam)")


def _spek_stempel(gaya):
    per = FG.PERAN[gaya]
    for r in ("stempel", "judul_lebar", "judul", "catatan", "caption"):
        if r in per:
            b, ax = per[r]["utama"]; ax = dict(ax)
            if "wght" in ax: ax["wght"] = 1000   # stempel selalu memakai bobot paling tebal yang tersedia (dijepit ke maksimum sumbu)
            return (b, ax)


def _fit(teks, kunci, lebar, wght=None, maks=420):
    """Pas-kan ukuran font peran stempel gaya aktif ke lebar. Parameter kunci/wght dipertahankan untuk kompatibilitas; font sebenarnya dari fonts_gaya."""
    sp = _spek_stempel(_CUR["gaya"]); px = 20
    while px < maks:
        f = FG.font(sp, px + 6); l, t, r, b = f.getbbox(teks)
        if r - l > lebar: break
        px += 6
    return FG.font(sp, px)


def _tinta(kata, warna, w, seed, sub):
    rng = np.random.default_rng(seed); W2 = w * SC; f = _fit(kata, "tebal", (w - 170) * SC); l, t, r, b = f.getbbox(kata); tw, th = r - l, b - t
    H2 = th + 150 * SC + (60 * SC if sub else 0); m = 20 * SC; im = Image.new("L", (W2 + 2 * m, H2 + 2 * m), 0); d = ImageDraw.Draw(im)
    d.rounded_rectangle([m, m, m + W2, m + H2], 26 * SC, outline=255, width=14 * SC); d.rounded_rectangle([m + 30 * SC, m + 30 * SC, m + W2 - 30 * SC, m + H2 - 30 * SC], 14 * SC, outline=255, width=5 * SC)
    ty = m + (H2 - (60 * SC if sub else 0)) // 2 - th // 2 - t; d.text((m + W2 // 2 - tw // 2 - l, ty), kata, font=f, fill=255)
    if sub: fs = _fit(sub, "mono", (w - 260) * SC, maks=60); sl, st, sr, sb = fs.getbbox(sub); d.text((m + W2 // 2 - (sr - sl) // 2 - sl, m + H2 - 100 * SC), sub, font=fs, fill=255)
    arr = np.asarray(im, np.float32) / 255; noise = rng.random((arr.shape[0] // 6 + 1, arr.shape[1] // 6 + 1)).astype(np.float32)
    nz = np.asarray(Image.fromarray((noise * 255).astype(np.uint8)).resize((arr.shape[1], arr.shape[0]), Image.BICUBIC), np.float32) / 255
    fine = rng.random(arr.shape).astype(np.float32); keep = ((nz > 0.20) & (fine > 0.035)).astype(np.float32)
    # tekanan tidak rata: sisi yang ditekan lebih pekat (gradien tinta), sisi lain lebih tipis
    yy, xx = np.mgrid[0:arr.shape[0], 0:arr.shape[1]]; tek = 0.5 + 0.5 * np.sin((xx / arr.shape[1] * 1.3 + yy / arr.shape[0] * 0.7 + rng.random() * 6) * 8.0); a = arr * keep           # alpha penuh; tekanan tidak rata diterapkan pada WARNA tinta (sisi tertekan lebih pekat)
    a = Image.fromarray((np.clip(a, 0, 1) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(0.8 * SC / 2)); st = G.stops_dari(warna, terang=0.11, gelap=0.13, geser_hue=6)
    out = G.isi(a, stops=st, sudut=70); rgb = np.asarray(out).astype(np.float32); rgb[..., :3] *= (0.60 + 0.40 * tek)[..., None]; out = Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), "RGBA"); return out.crop(out.getbbox())


def _garis(kata, warna, w, seed, sub):
    W2 = w * SC; f = _fit(kata, "mono", (w - 180) * SC, maks=240); l, t, r, b = f.getbbox(kata); tw, th = r - l, b - t; H2 = th + 120 * SC; m = 16 * SC
    im = Image.new("L", (W2 + 2 * m, H2 + 2 * m), 0); d = ImageDraw.Draw(im); lw = 6 * SC
    d.rectangle([m, m, m + W2, m + H2], outline=255, width=lw); d.rectangle([m + 18 * SC, m + 18 * SC, m + W2 - 18 * SC, m + H2 - 18 * SC], outline=255, width=2 * SC)
    for cx in (m, m + W2):
        for cy in (m, m + H2): d.line([cx - 14 * SC, cy, cx + 14 * SC, cy], fill=255, width=2 * SC); d.line([cx, cy - 14 * SC, cx, cy + 14 * SC], fill=255, width=2 * SC)
    d.text((m + W2 // 2 - tw // 2 - l, m + H2 // 2 - th // 2 - t), kata, font=f, fill=255)
    out = G.isi(im, stops=G.stops_dari(warna, terang=0.07, gelap=0.06, geser_hue=3), sudut=0); return out.crop(out.getbbox())


def _timbul(kata, warna, w, seed, sub):
    W2 = w * SC; f = _fit(kata, "serif", (w - 220) * SC, wght=700, maks=260); l, t, r, b = f.getbbox(kata); tw, th = r - l, b - t; H2 = th + 140 * SC; m = 24 * SC
    ukuran = (W2 + 2 * m, H2 + 2 * m); badan = Image.new("L", ukuran, 0); d = ImageDraw.Draw(badan); d.rounded_rectangle([m, m, m + W2, m + H2], H2 // 2, fill=255)
    kulit = G.isi(badan, stops=[(0, G.campur((246, 224, 176), warna, 0.18)), (0.55, G.campur((232, 196, 134), warna, 0.32)), (1, G.campur((196, 150, 92), warna, 0.45))], sudut=90, kilap=0.5)
    ring = Image.new("L", ukuran, 0); dr = ImageDraw.Draw(ring); dr.rounded_rectangle([m + 10 * SC, m + 10 * SC, m + W2 - 10 * SC, m + H2 - 10 * SC], (H2 - 20 * SC) // 2, outline=255, width=5 * SC)
    kulit.alpha_composite(G.isi(ring, stops=G.stops_dari(warna, terang=0.04, gelap=0.1)))
    teks = Image.new("L", ukuran, 0); ImageDraw.Draw(teks).text((m + W2 // 2 - tw // 2 - l, m + H2 // 2 - th // 2 - t), kata, font=f, fill=255); hh, ll, ss = G.hls(warna); tinta = G.dari_hls(hh, min(ll, 0.30), max(ss, 0.6))
    bayang = Image.new("RGBA", ukuran, (255, 244, 214, 0)); bayang.putalpha(teks.point(lambda v: int(v * 0.8))); bayang = bayang.transform(ukuran, Image.AFFINE, (1, 0, 0, 0, 1, -3 * SC))
    kulit.alpha_composite(bayang); kulit.alpha_composite(G.isi(teks, stops=G.stops_dari(tinta, terang=0.05, gelap=0.04), sudut=90))
    sh = Image.new("RGBA", ukuran, (0, 0, 0, 0)); sh.putalpha(badan.point(lambda v: int(v * 0.35))); sh = sh.filter(ImageFilter.GaussianBlur(6 * SC)).transform(ukuran, Image.AFFINE, (1, 0, 0, 0, 1, -6 * SC))
    out = Image.alpha_composite(sh, kulit); return out.crop(out.getbbox())


def _kaca(kata, warna, w, seed, sub):
    W2 = w * SC; f = _fit(kata, "kaca", (w - 200) * SC, wght=800, maks=240); l, t, r, b = f.getbbox(kata); tw, th = r - l, b - t; H2 = th + 130 * SC; m = 26 * SC
    ukuran = (W2 + 2 * m, H2 + 2 * m); badan = Image.new("L", ukuran, 0); ImageDraw.Draw(badan).rounded_rectangle([m, m, m + W2, m + H2], 46 * SC, fill=255)
    a, b2 = G.turunan(warna, terang=0.12, gelap=0.1, geser_hue=12); st = [(0, a), (1, b2)]; im = G.isi(badan, stops=st, sudut=20, kilap=0.55)
    tepi = Image.new("L", ukuran, 0); ImageDraw.Draw(tepi).rounded_rectangle([m, m, m + W2, m + H2], 46 * SC, outline=255, width=4 * SC); te = Image.new("RGBA", ukuran, (255, 255, 255, 0)); te.putalpha(tepi.point(lambda v: int(v * 0.7))); im.alpha_composite(te)
    tx = Image.new("RGBA", ukuran, (255, 255, 255, 0)); ImageDraw.Draw(tx).text((m + W2 // 2 - tw // 2 - l, m + H2 // 2 - th // 2 - t), kata, font=f, fill=(255, 255, 255, 255)); im.alpha_composite(tx)
    sh = Image.new("RGBA", ukuran, (0, 0, 0, 0)); sh.putalpha(badan.point(lambda v: int(v * 0.45))); sh = sh.filter(ImageFilter.GaussianBlur(10 * SC)).transform(ukuran, Image.AFFINE, (1, 0, 0, 0, 1, -10 * SC))
    out = Image.alpha_composite(sh, im); return out.crop(out.getbbox())


def _blok(kata, warna, w, seed, sub):
    W2 = w * SC; f = _fit(kata, "kond", (w - 150) * SC, maks=320); l, t, r, b = f.getbbox(kata); tw, th = r - l, b - t; H2 = th + 110 * SC; m = 22 * SC
    ukuran = (W2 + 2 * m, H2 + 2 * m); badan = Image.new("L", ukuran, 0); ImageDraw.Draw(badan).rectangle([m, m, m + W2, m + H2], fill=255)
    im = G.isi(badan, stops=G.stops_dari(warna, terang=0.10, gelap=0.10), sudut=75, kilap=0.25)
    tx = Image.new("RGBA", ukuran, (0, 0, 0, 0)); fg = (255, 255, 255, 255) if _lum(warna) < 0.42 else (24, 22, 26, 255); ImageDraw.Draw(tx).text((m + W2 // 2 - tw // 2 - l, m + H2 // 2 - th // 2 - t), kata, font=f, fill=fg); im.alpha_composite(tx)
    sh = Image.new("RGBA", ukuran, (0, 0, 0, 0)); sh.putalpha(badan.point(lambda v: int(v * 0.35))); sh = sh.filter(ImageFilter.GaussianBlur(5 * SC)).transform(ukuran, Image.AFFINE, (1, 0, 0, 0, 1, -7 * SC))
    out = Image.alpha_composite(sh, im); return out.crop(out.getbbox())


def _tangan(kata, warna, w, seed, sub):
    rng = random.Random(seed); W2 = w * SC; f = _fit(kata, "tangan", (w - 200) * SC, maks=300); l, t, r, b = f.getbbox(kata); tw, th = r - l, b - t; H2 = th + 130 * SC; m = 24 * SC
    im = Image.new("L", (W2 + 2 * m, H2 + 2 * m), 0); d = ImageDraw.Draw(im); lw = 8 * SC
    def goyang(p, a=4): return (p[0] + rng.uniform(-a, a) * SC, p[1] + rng.uniform(-a, a) * SC)
    for k in range(2):                                                         # dua putaran spidol, tidak persis berimpit
        pts = [(m, m), (m + W2, m), (m + W2, m + H2), (m, m + H2), (m, m)]; seg = []
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
            for i in range(0, 13): u = i / 12; seg.append(goyang((x0 + (x1 - x0) * u, y0 + (y1 - y0) * u), 5 + k * 3))
        d.line(seg, fill=255, width=lw - k * 2 * SC, joint="curve")
    d.text((m + W2 // 2 - tw // 2 - l, m + H2 // 2 - th // 2 - t), kata, font=f, fill=255)
    out = G.isi(im.filter(ImageFilter.GaussianBlur(0.6 * SC)), stops=G.stops_dari(warna, terang=0.06, gelap=0.06), sudut=100); return out.crop(out.getbbox())


_RENDER = dict(tinta=_tinta, garis=_garis, timbul=_timbul, kaca=_kaca, blok=_blok, tangan=_tangan)


def stempel(kata, gaya="KLIPING", palet=None, latar=None, polaritas=None, w=860, seed=5, sub=None, bahan=None):
    """Buat sprite stempel untuk gaya visual tertentu. polaritas diambil dari VOKAB bila kata dikenal. Warna dari tema lewat warna_stempel. -> dict(img, warna, bahan, rot_saran, info, kata, polaritas).
    Kata di luar VOKAB boleh (mis. 'DIRAMPOK' di contoh referensi) asal polaritas diberikan. Sprite dibuat 2x; kecilkan saat menempel."""
    k = kata.upper(); pol = polaritas or VOKAB.get(k)
    if pol is None: raise ValueError(f"kata '{k}' tidak ada di VOKAB; berikan polaritas='negatif'|'positif'|'netral'")
    if palet is None:
        try: import gaya_visual as GV; palet = GV.GAYA[gaya]["palet"]
        except Exception: palet = {}
    warna, info = warna_stempel(pol, palet, latar); bh = bahan or BAHAN_GAYA.get(gaya, "tinta"); _CUR['gaya'] = gaya; img = _RENDER[bh](k, warna, w, seed, sub)
    return dict(img=img, warna=warna, bahan=bh, rot_saran=ROT_SARAN[bh], info=info, kata=k, polaritas=pol)


# ---------- aturan penggunaan dan audit ----------
ATURAN = ("Stempel hanya untuk VONIS atas klaim yang sudah diperiksa (lembar Fakta), bukan hiasan. Satu stempel per adegan (dua hanya bila berlawanan, mis. HOAKS lalu DICEK), paling banyak satu per 8 detik video dan empat per video. "
          "Stempel jatuh DI ATAS klaim yang divonis (kertas, pesan, judul), menutup sebagian tetapi klaimnya tetap terbaca; ukuran 35-70 persen lebar layar; miring sesuai bahan (ROT_SARAN); tahan minimal 1 detik. "
          "Saat menghantam: SFX benturan (stamp, boom, thud) tepat di frame kena, goyang layar singkat bila gaya mengizinkan. Warna mengikuti tema (warna_stempel), bukan merah atau hijau generik. "
          "Vonis HOAKS/SALAH/BOHONG pada klaim nyata wajib punya sumber pemeriksa; tanpa sumber pakai BELUM TERVERIFIKASI. Klaim hasil rekaan untuk ilustrasi diberi label ILUSTRASI di layar. Tidak distempel di atas wajah atau nama orang nyata.")


def cek_stempel(daftar, durasi, fakta_kunci=None):
    """daftar: list dict(kata, adegan, t, dasar) dengan dasar = kunci di lembar Fakta atau 'ilustrasi'. fakta_kunci: set kunci yang ada di Fakta (opsional; bila diberikan dasar harus ada di situ).
    Lolos bila: kata dikenal; <= 1 per adegan; jumlah <= max(1, durasi // 8) dan <= 4; vonis negatif atau positif punya dasar."""
    masalah = []; per = {}
    for s in daftar:
        k = s.get("kata", "").upper()
        if k not in VOKAB and not s.get("polaritas"): masalah.append(f"kata '{k}' tidak dikenal (beri polaritas)")
        per.setdefault(s.get("adegan"), []).append(k)
        if (s.get("polaritas") or VOKAB.get(k)) in ("negatif", "positif") and not s.get("dasar"): masalah.append(f"stempel {k} tanpa dasar pemeriksaan (isi 'dasar' dengan kunci Fakta atau 'ilustrasi')")
        if fakta_kunci is not None and s.get("dasar") not in (None, "ilustrasi") and s["dasar"] not in fakta_kunci: masalah.append(f"dasar '{s['dasar']}' tidak ada di lembar Fakta")
    pol_adegan = {}
    for s in daftar: pol_adegan.setdefault(s.get("adegan"), []).append(s.get("polaritas") or VOKAB.get(s.get("kata", "").upper()))
    for a, ks in per.items():
        if len(ks) > 2 or (len(ks) == 2 and len(set(pol_adegan[a])) < 2): masalah.append(f"adegan {a} punya {len(ks)} stempel ({', '.join(ks)}); satu saja, atau dua hanya bila berlawanan (vonis lalu hasil periksa)")
    batas = min(4, max(1, int(durasi // 8)))
    if len(daftar) > batas: masalah.append(f"{len(daftar)} stempel untuk {durasi:g} detik; batas {batas}")
    return dict(lolos=not masalah, masalah=masalah)
