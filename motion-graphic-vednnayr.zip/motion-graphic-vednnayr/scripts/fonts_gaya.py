# fonts_gaya.py - Font tiap PERAN huruf di tiap gaya visual (bagian 0.6 dan 7.2). Dicocokkan dengan merender kandidat berdampingan dengan crop frame contoh (2026-11-10).
# JUJUR: ini PADANAN TERDEKAT dari bentuk huruf yang terlihat di frame cuplikan (720x1280), bukan label resmi font di video contoh. Gerak dan audio tidak dinilai.
# Aturan: huruf di video HARUS memakai font peran ini (berkas nyata di folder fonts/, Google Fonts berlisensi OFL), bukan font sistem (DejaVu, Inter, FreeSans). Penggantian dilaporkan, tidak diam-diam.
# 2026-11-11: font PASARAN ("AI slop": Inter, Poppins, Plus Jakarta Sans, Outfit, Nunito, Playfair, Cinzel, EB Garamond, IBM Plex, dst; lihat PASARAN) tidak dipakai lagi dan tidak ada di fonts/; gantinya font berkarakter yang bentuknya tetap mirip contoh.
# Kesalahan nyata yang melahirkan modul ini: caption KLIPING sempat dipasang Caveat Brush padahal contoh = Kalam Bold, dan huruf tempel di video hoaks memakai DejaVu/Inter padahal contoh = serif kontras tinggi, slab, dan sans bulat tebal.
import os, functools
from PIL import ImageFont


def S(berkas, **sumbu):
    """Spesifikasi font: berkas di fonts/ + nilai sumbu variabel (wght, wdth)."""
    return (berkas, dict(sumbu))


def _folder():
    here = os.path.dirname(os.path.abspath(__file__))
    for d in (os.path.join(os.getcwd(), "fonts"), os.path.join(here, "fonts"), os.path.join(os.path.dirname(here), "fonts"), os.environ.get("SKILL_DIR", "") and os.path.join(os.environ["SKILL_DIR"], "fonts")):
        if d and os.path.isdir(d): return d
    raise FileNotFoundError("folder fonts/ tidak ditemukan")


@functools.lru_cache(None)
def muat(spek, px):
    """Muat (berkas, sumbu) pada ukuran px. spek harus hashable: gunakan `font(...)`. Sumbu dipasang berdasarkan NAMA (Weight, Width), bukan urutan."""
    berkas, sumbu = spek; p = os.path.join(_folder(), berkas)
    if not os.path.isfile(p): raise FileNotFoundError(f"font {berkas} tidak ada di fonts/ (jangan diganti diam-diam; catat di laporan bila memakai pengganti)")
    f = ImageFont.truetype(p, int(px)); sumbu = dict(sumbu)
    if sumbu:
        nilai = []
        for a in f.get_variation_axes():
            nm = a["name"].decode() if isinstance(a["name"], bytes) else a["name"]
            k = {"Weight": "wght", "Width": "wdth"}.get(nm, nm); v = sumbu.get(k, a["default"]); nilai.append(min(a["maximum"], max(a["minimum"], v)))
        f.set_variation_by_axes(nilai)
    return f


def _h(spek): return (spek[0], tuple(sorted(spek[1].items())))


def font(spek, px): return muat(_h(spek), px)


# ---------------------------------------------------------------- huruf tempel (ransom) KLIPING: tiap huruf punya font sendiri dari TIGA golongan seperti contoh
# serif kontras tinggi tebal, slab tebal, sans bulat tebal. Semua punya angka dan tanda tanya; hanya font berkarakter (bukan pasaran).
RANSOM = dict(
    serif=[S("Chonburi-Regular.ttf"), S("AbrilFatface-Regular.ttf"), S("Vollkorn-VAR.ttf", wght=900), S("Caprasimo-Regular.ttf"), S("Gloock-Regular.ttf")],
    slab=[S("AlfaSlabOne-Regular.ttf"), S("Bevan-Regular.ttf"), S("Ultra-Regular.ttf")],
    bulat=[S("TitanOne-Regular.ttf"), S("PaytoneOne-Regular.ttf"), S("BowlbyOne-Regular.ttf"), S("LilitaOne-Regular.ttf"), S("DelaGothicOne-Regular.ttf")],
)
RANSOM_SEMUA = [s for g in RANSOM.values() for s in g]

# Font PASARAN ("AI slop"): terlalu sering dipakai, terkesan membosankan; dilarang jadi pilihan utama maupun cadangan, dan tidak disertakan di fonts/.
# Memberi tebal atau miring pada font ini tidak mengubah kesannya.
PASARAN = ["Inter", "Roboto", "OpenSans", "Poppins", "Montserrat", "DMSans", "Manrope", "PlusJakarta", "Outfit", "Nunito", "Lexend", "Figtree", "SpaceGrotesk", "Sora", "Urbanist", "Rubik-", "Quicksand", "Comfortaa",
           "Playfair", "Lora", "Merriweather", "Cormorant", "EBGaramond", "Cinzel-", "Fraunces", "IBMPlex", "JetBrains", "SpaceMono", "Baloo", "Fredoka", "Oswald", "BebasNeue", "Anton-", "DejaVu", "FreeSans", "Arial", "Helvetica", "Times", "Liberation"]

# ---------------------------------------------------------------- peran per gaya
# yakin: tinggi = bentuk cocok jelas pada banyak huruf; sedang = cocok tetapi ada kandidat dekat lain; rendah = tebakan terbaik dari sedikit huruf
# alt = font MIRIP lain (semuanya ada di fonts/). cocok = untuk video bergaya apa font itu paling pas (dipakai panduan font).
PERAN = dict(
    KLIPING=dict(
        caption=dict(utama=S("Kalam-Bold.ttf"), alt=[S("Gaegu-Bold.ttf"), S("GochiHand-Regular.ttf"), S("Itim-Regular.ttf"), S("CaveatBrush-Regular.ttf")], yakin="tinggi", ciri="tulisan tangan spidol miring, g berekor terbuka; BUKAN Caveat Brush", cocok="takarir kolase kertas dan keterangan tulisan tangan"),
        catatan=dict(utama=S("Kalam-Bold.ttf"), alt=[S("Kalam-Regular.ttf"), S("Knewave-Regular.ttf"), S("Mansalva-Regular.ttf")], yakin="tinggi", ciri="kabar!, sering..., Om Heri: tulisan tangan miring; warna biru, merah, atau abu", cocok="catatan coretan di pinggir kliping, tanda seru dan pertanyaan"),
        judul_koran=dict(utama=S("Chonburi-Regular.ttf"), alt=[S("AbrilFatface-Regular.ttf"), S("Vollkorn-VAR.ttf", wght=900), S("Caprasimo-Regular.ttf"), S("Gloock-Regular.ttf"), S("YesevaOne-Regular.ttf")], yakin="tinggi", ciri="di Twitter, HOAKS di kliping: serif tebal kontras tinggi berujung bola", cocok="judul koran, tajuk berita, kalimat tegas pada kertas"),
        label=dict(utama=S("DelaGothicOne-Regular.ttf"), alt=[S("BowlbyOne-Regular.ttf"), S("PaytoneOne-Regular.ttf"), S("GasoekOne-Regular.ttf"), S("ArchivoBlack-Regular.ttf")], yakin="sedang", ciri="BOHONG, BENAR, KAGET: sans ekstra tebal lebar, kapital, putih pada kotak warna", cocok="label vonis, kotak kata kunci kapital tebal"),
        kartu=dict(utama=S("BowlbyOne-Regular.ttf"), alt=[S("LilitaOne-Regular.ttf"), S("DelaGothicOne-Regular.ttf"), S("RussoOne-Regular.ttf")], yakin="sedang", ciri="KARTU PERS: sans tebal agak persegi", cocok="kartu pers, lencana, judul kecil di pita"),
        kapital_renggang=dict(utama=S("Ultra-Regular.ttf"), alt=[S("CourierPrime-Bold.ttf"), S("Bevan-Regular.ttf")], yakin="rendah", ciri="KEBENARAN: slab kapital berjarak lebar, abu", cocok="kapital berjarak lebar sebagai penanda bagian"),
        huruf_tempel=dict(utama=S("Chonburi-Regular.ttf"), alt=RANSOM_SEMUA, yakin="tinggi", ciri="satu huruf satu ubin; font campur: serif tebal, slab, sans bulat; lihat RANSOM", cocok="judul surat kaleng, kata kunci yang ingin menonjol"),
        stempel=dict(utama=S("DelaGothicOne-Regular.ttf"), alt=[S("ArchivoBlack-Regular.ttf"), S("BowlbyOne-Regular.ttf"), S("RussoOne-Regular.ttf")], yakin="sedang", ciri="stempel tinta karet merah: sans tebal kapital", cocok="stempel vonis HOAKS, FAKTA, BETUL"),
    ),
    ARSIP=dict(
        caption=dict(utama=S("CourierPrime-Bold.ttf"), alt=[S("SpecialElite-Regular.ttf"), S("CutiveMono-Regular.ttf"), S("CourierPrime-Regular.ttf")], yakin="tinggi", ciri="mesin tik tebal, slab monospasi", cocok="dokumen investigasi, berkas kasus, laporan polisi, kriminal"),
        judul=dict(utama=S("Vollkorn-VAR.ttf", wght=900), alt=[S("Chonburi-Regular.ttf"), S("Gloock-Regular.ttf"), S("BodoniModa-VAR.ttf", wght=900), S("Caprasimo-Regular.ttf")], yakin="tinggi", ciri="serif tebal kontras sedang untuk judul koran dan kalender", cocok="judul koran lama, kalender, tajuk investigasi"),
        angka=dict(utama=S("Chonburi-Regular.ttf"), alt=[S("Vollkorn-VAR.ttf", wght=900), S("BodoniModa-VAR.ttf", wght=900)], yakin="sedang", ciri="angka tanggal besar serif tebal", cocok="tanggal, tahun, nomor berkas besar"),
        label=dict(utama=S("CourierPrime-Bold.ttf"), alt=[S("SpecialElite-Regular.ttf"), S("Ultra-Regular.ttf")], yakin="tinggi", ciri="DAFTAR TERSANGKA: kapital mesin tik, jarak lebar, merah", cocok="label berkas, cap tanggal, kategori"),
        stempel=dict(utama=S("CourierPrime-Bold.ttf"), alt=[S("SpecialElite-Regular.ttf"), S("DelaGothicOne-Regular.ttf")], yakin="tinggi", ciri="stempel kantor tinta merah", cocok="stempel RAHASIA, TERBUKTI, DITOLAK"),
    ),
    BLUEPRINT=dict(
        caption=dict(utama=S("AzeretMono-VAR.ttf", wght=600), alt=[S("ChivoMono-VAR.ttf", wght=600), S("RedHatMono-VAR.ttf", wght=600), S("SplineSansMono-VAR.ttf", wght=600), S("Sono-VAR.ttf", wght=600), S("MartianMono-VAR.ttf", wght=500)], yakin="sedang", ciri="monospasi semitebal, i berkaki, a dua lantai", cocok="gambar teknik, denah, spesifikasi, penjelasan mesin dan struktur"),
        label=dict(utama=S("AzeretMono-VAR.ttf", wght=500), alt=[S("ChivoMono-VAR.ttf", wght=500)], yakin="sedang", ciri="label kecil di garis ukur", cocok="angka ukuran, label komponen"),
    ),
    SKETSA=dict(
        caption=dict(utama=S("ShantellSans-VAR.ttf", wght=700), alt=[S("Gaegu-Bold.ttf"), S("GochiHand-Regular.ttf"), S("PatrickHand-Regular.ttf"), S("SingleDay-Regular.ttf"), S("Itim-Regular.ttf")], yakin="sedang", ciri="tulisan tangan huruf cetak bulat, tegak, tinta gelap", cocok="buku sketsa, catatan belajar, penjelasan santai yang ramah"),
        catatan=dict(utama=S("Kalam-Bold.ttf"), alt=[S("Mansalva-Regular.ttf"), S("Knewave-Regular.ttf")], yakin="sedang", ciri="coretan tangan miring", cocok="catatan kecil dan panah penjelas"),
        label=dict(utama=S("ShantellSans-VAR.ttf", wght=700), alt=[S("PatrickHand-Regular.ttf")], yakin="sedang", ciri="label tulisan tangan", cocok="label benda pada sketsa"),
    ),
    GEOMETRIK=dict(
        caption=dict(utama=S("Gabarito-VAR.ttf", wght=800), alt=[S("SchibstedGrotesk-VAR.ttf", wght=800), S("BricolageGrotesque-VAR.ttf", wght=800), S("FamiljenGrotesk-VAR.ttf", wght=700), S("Unbounded-VAR.ttf", wght=700), S("Syne-VAR.ttf", wght=800)], yakin="tinggi", ciri="sans geometris tebal, huruf hitam pada kotak kuning", cocok="pertanyaan retoris, kotak teks tegas, bentuk geometris"),
        label=dict(utama=S("Gabarito-VAR.ttf", wght=700), alt=[S("SchibstedGrotesk-VAR.ttf", wght=700)], yakin="sedang", ciri="label kecil geometris", cocok="label di kotak berwarna"),
    ),
    HIKAYAT=dict(
        caption=dict(utama=S("Vollkorn-VAR.ttf", wght=700), alt=[S("Almendra-Bold.ttf"), S("Macondo-Regular.ttf"), S("GideonRoman-Regular.ttf"), S("Metamorphous-Regular.ttf"), S("JacquesFrancois-Regular.ttf")], yakin="sedang", ciri="serif hangat bergaya lama, oranye-cokelat pada perkamen", cocok="dongeng, sejarah, wayang, cerita rakyat, hikayat"),
        judul=dict(utama=S("Vollkorn-VAR.ttf", wght=800), alt=[S("CinzelDecorative-Bold.ttf"), S("UncialAntiqua-Regular.ttf"), S("Almendra-Bold.ttf"), S("Chonburi-Regular.ttf")], yakin="sedang", ciri="SATU SYARAT: kapital serif tebal berjarak", cocok="judul bagian di plakat perkamen"),
    ),
    TERMINAL=dict(
        caption=dict(utama=S("MartianMono-VAR.ttf", wght=600), alt=[S("ShareTechMono-Regular.ttf"), S("Sono-VAR.ttf", wght=700), S("AzeretMono-VAR.ttf", wght=700), S("RedHatMono-VAR.ttf", wght=700)], yakin="sedang", ciri="monospasi persegi hijau di layar hitam, kata aktif dalam kotak hijau", cocok="peretasan, kode, log sistem, teknologi"),
    ),
    CAIR=dict(
        caption=dict(utama=S("SchibstedGrotesk-VAR.ttf", wght=700), alt=[S("FamiljenGrotesk-VAR.ttf", wght=700), S("Gabarito-VAR.ttf", wght=600), S("BricolageGrotesque-VAR.ttf", wght=700)], yakin="sedang", ciri="sans bulat semitebal pada kapsul kaca", cocok="objek kaca, cairan, nuansa ungu-biru yang lembut"),
    ),
    FLATLIFE=dict(
        caption=dict(utama=S("FamiljenGrotesk-VAR.ttf", wght=700), alt=[S("Gabarito-VAR.ttf", wght=700), S("SchibstedGrotesk-VAR.ttf", wght=700), S("BricolageGrotesque-VAR.ttf", wght=700)], yakin="sedang", ciri="sans tebal biru tua di kapsul putih", cocok="ilustrasi flat keseharian, cerita ringan"),
    ),
    LANTANG=dict(
        judul_sempit=dict(utama=S("BigShouldersDisplay-VAR.ttf", wght=900), alt=[S("Antonio-VAR.ttf", wght=700), S("LeagueGothic-VAR.ttf"), S("FjallaOne-Regular.ttf"), S("Staatliches-Regular.ttf")], yakin="sedang", ciri="ITU ADA: kapital ekstra sempit dan tebal, jarak rapat", cocok="kata raksasa memenuhi layar, nada tegas"),
        judul_lebar=dict(utama=S("DelaGothicOne-Regular.ttf"), alt=[S("ArchivoBlack-Regular.ttf"), S("BowlbyOne-Regular.ttf"), S("RubikMonoOne-Regular.ttf")], yakin="sedang", ciri="CYRIL: kapital ekstra tebal lebar", cocok="nama atau kata tunggal yang ingin dipamerkan"),
        caption=dict(utama=S("BigShouldersDisplay-VAR.ttf", wght=900), alt=[S("Antonio-VAR.ttf", wght=700)], yakin="rendah", ciri="subtitle kapital sempit", cocok="takarir pendek berbobot"),
    ),
    PETA=dict(
        caption=dict(utama=S("Antonio-VAR.ttf", wght=600), alt=[S("BarlowCondensed-SemiBold.ttf"), S("FjallaOne-Regular.ttf"), S("BigShouldersDisplay-VAR.ttf", wght=700)], yakin="sedang", ciri="sans sempit semitebal di kartu fakta", cocok="peta, data geografis, fakta ringkas"),
        judul=dict(utama=S("Gloock-Regular.ttf"), alt=[S("Vollkorn-VAR.ttf", wght=700), S("Prata-Regular.ttf"), S("YesevaOne-Regular.ttf")], yakin="sedang", ciri="serif untuk nama wilayah", cocok="nama wilayah dan judul peta editorial"),
        label=dict(utama=S("Antonio-VAR.ttf", wght=600), alt=[S("BarlowCondensed-SemiBold.ttf")], yakin="sedang", ciri="label peta", cocok="label kota dan angka"),
    ),
    MIDNIGHT=dict(
        caption=dict(utama=S("BricolageGrotesque-VAR.ttf", wght=700), alt=[S("SchibstedGrotesk-VAR.ttf", wght=700), S("FamiljenGrotesk-VAR.ttf", wght=700), S("Gabarito-VAR.ttf", wght=700)], yakin="sedang", ciri="sans tebal putih di latar navy, kata aktif kuning", cocok="mode gelap, antarmuka, persentase, penjelasan modern"),
    ),
    MINIATUR=dict(
        caption=dict(utama=S("Grandstander-VAR.ttf", wght=800), alt=[S("Gabarito-VAR.ttf", wght=800), S("PaytoneOne-Regular.ttf"), S("DynaPuff-VAR.ttf", wght=700), S("Sniglet-ExtraBold.ttf")], yakin="sedang", ciri="sans bulat tebal, kata aktif kuning", cocok="diorama isometrik, rating, dunia mini yang ramah"),
    ),
)


def spek(gaya, peran="caption"):
    """Spesifikasi peran; jatuh ke caption bila peran tidak didefinisikan untuk gaya itu."""
    p = PERAN[gaya]; return p.get(peran, p["caption"] if "caption" in p else next(iter(p.values())))["utama"]


def font_peran(gaya, peran, px): return font(spek(gaya, peran), px)


def ransom_font(rng, golongan=None):
    """Pilih font huruf tempel secara acak dari tiga golongan (campur seperti contoh). Kembalikan spesifikasi."""
    g = golongan or rng.choice(["serif", "slab", "bulat", "bulat", "slab"]); return rng.choice(RANSOM[g])


def cek_berkas():
    """Pastikan semua berkas font tiap peran ada di fonts/. -> daftar berkas hilang (kosong = baik)."""
    hilang = set()
    for g, per in PERAN.items():
        for pr, d in per.items():
            for sp in [d["utama"]] + list(d["alt"]):
                if not os.path.isfile(os.path.join(_folder(), sp[0])): hilang.add(sp[0])
    return sorted(hilang)


def laporan():
    """Baris laporan 'gaya / peran: font (keyakinan)' untuk dilampirkan di laporan akhir (padanan terdekat, bukan label resmi)."""
    out = []
    for g, per in PERAN.items():
        for pr, d in per.items():
            b, ax = d["utama"]; out.append(f"{g} / {pr}: {b[:-4]}{' ' + ','.join(f'{k}={v}' for k, v in ax.items()) if ax else ''} ({d['yakin']})")
    return out

GAYA_KESAN = dict(
    KLIPING="kolase kertas sobek, huruf tempel surat kaleng, stiker dan stempel di latar warna jenuh; cocok untuk berita, hoaks dan fakta, topik media sosial, opini dan kampanye.",
    ARSIP="meja investigasi kraft, berkas, kalender, kliping koran dan stempel merah; cocok untuk misteri, kriminal, sejarah, kejadian yang terikat tanggal.",
    BLUEPRINT="gambar teknik biru dengan garis ukur dan kurung sudut; cocok untuk cara kerja mesin, bangunan, rekayasa dan sains teknik.",
    SKETSA="coretan buku catatan di kertas krem; cocok untuk psikologi, belajar santai, penjelasan konsep yang ramah.",
    GEOMETRIK="bentuk geometris dan angka tebal di latar bersih; cocok untuk keuangan, matematika, bisnis, data dan hitungan.",
    HIKAYAT="teater bayangan wayang dan plakat perkamen; cocok untuk legenda, cerita rakyat, sejarah dan asal-usul.",
    TERMINAL="layar peretas hitam dengan hijau neon; cocok untuk penipuan digital, keamanan siber, kode dan sistem.",
    CAIR="objek kaca berisi cairan di latar ungu-biru; cocok untuk tubuh, proses biologis dan kesehatan (tanpa takaran).",
    FLATLIFE="ilustrasi flat keseharian yang hangat; cocok untuk perilaku, ekonomi sehari-hari, psikologi belanja.",
    LANTANG="kata ekstra tebal memenuhi layar; cocok untuk hukum atau prinsip, pernyataan tegas, kutipan pendek.",
    PETA="peta editorial dengan kartu fakta; cocok untuk geografi, hewan dan wilayah, sejarah penjelajahan.",
    MIDNIGHT="mode gelap navy dengan kartu antarmuka; cocok untuk simulasi, skenario 'kalau besok', peluang dan risiko.",
    MINIATUR="diorama isometrik pulau melayang; cocok untuk simulasi, rating, dunia kecil yang ramah.",
)


# ---------------------------------------------------------------- panduan font untuk manusia (jadi berkas fonts/Panduan-Font-Per-Gaya.txt)
def nama_font(spek):
    """Nama enak dibaca dari spesifikasi font: 'Kalam Bold', 'Gabarito (tebal 800)'."""
    import re
    berkas, sumbu = spek; dasar = berkas[:-4].replace("-VAR", "-"); fam, _, gaya = dasar.partition("-"); fam = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", fam).replace("D M ", "DM ")
    if "wght" in sumbu: return f"{fam} (tebal {sumbu['wght']})"
    return f"{fam} {gaya}".strip() if gaya and gaya != "Regular" else fam


def panduan():
    """Teks panduan font: tiap gaya visual (dan video contohnya), font paling mirip per peran, font mirip lain di folder fonts/, dan untuk video bergaya apa font itu cocok. Dibuat dari PERAN, jadi selalu sinkron dengan kode."""
    import textwrap, gaya_visual as GV
    def w(t, ind="", sub=None): return "\n".join(textwrap.wrap(t, 96, initial_indent=ind, subsequent_indent=sub if sub is not None else ind)) + "\n"
    o = ["PANDUAN FONT PER GAYA VISUAL (skill motion-graphic-vednnayr)\n", "=" * 62 + "\n\n"]
    o.append(w("Isi folder ini: AnthropicSerifWebText.ttf (font bawaan dari pemilik skill untuk subtitle dan timer, TIDAK diganti dan TIDAK dihapus) ditambah font Google Fonts berlisensi OFL/Apache (lisensi ada di fonts/lisensi/). Folder ikut disalin ke project: cp -r fonts projects/<nama>/. AnthropicSerifWebText dipakai untuk SUBTITLE dan TIMER (fxlib.anthropic_font() mencarinya berdasarkan nama berkas); boleh diganti HANYA bila tidak cocok dengan visual video, dengan berkas yang benar-benar ada di folder ini dan alasan yang dicatat. Bila berkasnya hilang, kode MENOLAK (tidak memakai font lain diam-diam) dan user diberi tahu."))
    o.append("\n" + w("CATATAN JUJUR: font di bawah ditentukan dengan MEMBANDINGKAN bentuk huruf pada frame cuplikan video contoh (render kandidat berdampingan dengan potongan frame). Hasilnya PADANAN TERDEKAT, bukan nama font asli yang dipakai pembuat video. Yang sekadar mirip tetap sah dipakai. Gerak dan suara contoh tidak dinilai lewat gambar."))
    o.append("\n" + w("FONT PASARAN YANG DIHINDARI (kesan \"AI slop\", terlalu sering dipakai, membosankan; dibuat tebal atau miring tetap sama): " + "Inter, Roboto, Open Sans, Poppins, Montserrat, DM Sans, Manrope, Plus Jakarta Sans, Outfit, Nunito, Lexend, Figtree, Space Grotesk, Sora, Urbanist, Rubik, Quicksand, Comfortaa, Playfair Display, Lora, Merriweather, Cormorant, EB Garamond, Cinzel, Fraunces, IBM Plex, JetBrains Mono, Space Mono, Baloo, Fredoka, Oswald, Bebas Neue, Anton, serta font sistem (DejaVu, FreeSans, Arial, Helvetica, Times, Liberation). Font ini tidak ada di folder dan tidak boleh jadi pilihan utama maupun cadangan. Pilih font berkarakter seperti daftar di bawah."))
    o.append("\n" + "-" * 62 + "\n\n")
    for g, per in PERAN.items():
        try: info = GV.gaya(g); video = info.get("video", ""); cocok = GAYA_KESAN.get(g, "")
        except Exception: video = cocok = ""
        o.append(f"{g}\n"); 
        if video: o.append(w(f"Dilihat di video contoh: {video}", "  "))
        if cocok: o.append(w(f"Cocok untuk video seperti ini: {cocok}", "  "))
        for pr, d in per.items():
            o.append(w(f"* Peran {pr}: {nama_font(d['utama'])} (keyakinan {d['yakin']})", "  ", "      "))
            if d.get("cocok"): o.append(w(f"Cocok untuk: {d['cocok']}.", "      "))
            o.append(w(f"Ciri yang dicocokkan: {d['ciri']}.", "      "))
            alt = [nama_font(a) for a in d["alt"]] if g != "KLIPING" or pr != "huruf_tempel" else ["semua font di bagian HURUF TEMPEL di bawah"]
            if alt: o.append(w("Mirip (ada di fonts/): " + ", ".join(alt) + ".", "      "))
        o.append("\n")
    o.append("HURUF TEMPEL (KLIPING, satu huruf satu ubin)\n")
    for gol, ket in (("serif", "serif tebal kontras tinggi, cocok untuk huruf S, U, H, ? dan kesan koran"), ("slab", "slab tebal bersudut, cocok untuk I, K, Y, E dan kesan cetakan"), ("bulat", "sans bulat tebal, cocok untuk A, P, L, N dan kesan ramah")):
        o.append(w(f"* {gol}: " + ", ".join(nama_font(s) for s in RANSOM[gol]) + f". ({ket})", "  ", "      "))
    o.append("\n" + w("Cara pakai di kode: fonts_gaya.font(fonts_gaya.spek('KLIPING', 'caption'), 48). Berkas hilang = FileNotFoundError, tidak diganti diam-diam. Penggantian font dilaporkan ke user beserta alasannya."))
    return "".join(o)
