# suara_naskah.py - Voice over: (1) NASKAH BERTAG untuk ElevenLabs dan Google AI Studio + saran suara yang benar-benar ada, (2) voice over LANGSUNG hanya bila ada mesin suara yang alami.
# Semua data platform di bawah berasal dari dokumentasi resmi yang dibaca lewat pencarian web (tanggal di VERIFIKASI). Jangan menambah nama suara atau tag dari ingatan.
# Fitur ini hanya aktif bila user memintanya (fxlib.IZIN: voice_over_naskah / voice_over_langsung).
import re, shutil, importlib
import fxlib as F

VERIFIKASI = dict(tanggal="2026-11-07", sumber=[
    "https://elevenlabs.io/blog/v3-audiotags", "https://elevenlabs.io/docs/voices/default-voices", "https://elevenlabs.io/docs/help-center/other/what-languages-do-you-support",
    "https://aistudio.google.com/docs/speech-generation"])

# ---- ElevenLabs: tag dalam [kurung siku], dibaca sebagai arahan performa (bukan kata yang diucapkan). Halaman resmi memberi CONTOH, bukan daftar tertutup.
TAG_ELEVEN = {
    "emosi": ["sad", "angry", "happily", "sorrowful", "excited", "worried", "surprised", "annoyed"],
    "penyampaian dan tempo": ["whispers", "shouts", "softly", "dismissive", "cheeky", "cautiously", "panicking", "sarcastically", "pause", "rushed", "drawn out", "slowly", "dramatic tone"],
    "reaksi manusia": ["laughs", "laughing", "chuckles", "sighs", "sighing", "gasps", "clears throat", "coughing"],
    "contoh dari user (belum terverifikasi di halaman resmi)": ["curious", "sarcastic", "lighthearted", "reflective", "serious tone"],
    "aksen dan karakter": ["French accent", "British accent", "Australian accent", "pirate voice"],
}
TAG_ELEVEN_RESMI = {t for v in TAG_ELEVEN.values() for t in v}
# 17 suara bawaan (halaman Default Voices): nama -> (jenis kelamin, aksen, kegunaan, sifat)
SUARA_ELEVEN = {
    "Alice": ("wanita", "Inggris", "berita", "percaya diri"), "Bill": ("pria", "Amerika", "narasi", "tepercaya"), "Brian": ("pria", "Amerika", "narasi", "dalam"),
    "Callum": ("pria", "Transatlantik", "karakter", "intens"), "Charlie": ("pria", "Australia", "percakapan", "natural"), "Charlotte": ("wanita", "Swedia", "karakter", "memikat"),
    "Chris": ("pria", "Amerika", "percakapan", "santai"), "Daniel": ("pria", "Inggris", "berita", "berwibawa"), "Eric": ("pria", "Amerika", "percakapan", "ramah"),
    "George": ("pria", "Inggris", "narasi", "hangat"), "Jessica": ("wanita", "Amerika", "percakapan", "ekspresif"), "Laura": ("wanita", "Amerika", "media sosial", "ceria"),
    "Liam": ("pria", "Amerika", "narasi", "artikulatif"), "Lily": ("wanita", "Inggris", "narasi", "hangat"), "Matilda": ("wanita", "Amerika", "narasi", "ramah"),
    "Sarah": ("wanita", "Amerika", "berita", "lembut"), "Will": ("pria", "Amerika", "media sosial", "ramah"),
}
BAHASA_ELEVEN = "Bahasa Indonesia didukung Eleven v3, Multilingual v2, dan Flash v2.5 (bukan Flash v2). Suara bawaan beraksen asing; untuk logat Indonesia yang pas, cari di Voice Library dengan filter bahasa Indonesia dan pratinjau dulu."

# ---- Google AI Studio (Gemini TTS): tag di <kurung sudut> untuk kejadian sesaat; gaya satu giliran bicara lewat speech_metadata.style
TAG_GOOGLE = ["short pause", "long pause", "laugh", "gasp", "sigh", "cough", "breath", "throat-clearing"]          # contoh dari dokumentasi; dokumen menyarankan TIDAK memakai efek bunyi non-vokal
SUARA_GOOGLE = {"Zephyr": "Bright", "Puck": "Upbeat", "Charon": "Informative", "Kore": "Firm", "Fenrir": "Excitable", "Leda": "Youthful", "Orus": "Firm", "Aoede": "Breezy", "Callirrhoe": "Easy-going", "Autonoe": "Bright",
                "Enceladus": "Breathy", "Iapetus": "Clear", "Umbriel": "Easy-going", "Algieba": "Smooth", "Despina": "Smooth", "Erinome": "Clear", "Algenib": "Gravelly", "Rasalgethi": "Informative", "Laomedeia": "Upbeat",
                "Achernar": "Soft", "Alnilam": "Firm", "Schedar": "Even", "Gacrux": "Mature", "Pulcherrima": "Forward", "Achird": "Friendly", "Zubenelgenubi": "Casual", "Vindemiatrix": "Gentle", "Sadachbia": "Lively",
                "Sadaltager": "Knowledgeable", "Sulafat": "Warm"}
BAHASA_GOOGLE = "Indonesian tercantum didukung oleh Gemini 3.8 Flash TTS dan Flash-Lite TTS (kode bahasa id-ID tidak disebut eksplisit di halaman itu)."

def saran_suara(platform, kebutuhan="narasi"):
    """Saran suara NYATA untuk narator. platform 'elevenlabs' | 'google'. kebutuhan (ElevenLabs): narasi | berita | percakapan | karakter | media sosial; (Google): kata sifat seperti Warm, Clear, Informative, Friendly.
    -> daftar (nama, keterangan). Hanya nama dari daftar terverifikasi; tidak pernah mengarang."""
    F.IZIN.butuh("voice_over_naskah")
    if platform == "elevenlabs": return [(n, f"{g}, {a}, {k}, {s}") for n, (g, a, k, s) in SUARA_ELEVEN.items() if k == kebutuhan.lower()]
    if platform == "google": return [(n, d) for n, d in SUARA_GOOGLE.items() if d.lower() == kebutuhan.lower()]
    raise ValueError("platform: elevenlabs atau google")

def pilih_suara(platform, kebutuhan, suasana, tempo, pendengar, nama):
    """Pilih suara dengan ALASAN (wajib ditulis di laporan). nama harus ada di daftar terverifikasi untuk platform dan kebutuhan itu; suasana, tempo, pendengar wajib diisi.
    -> dict(nama, platform, alasan). Tidak pernah memilih asal atau mengarang nama."""
    F.IZIN.butuh("voice_over_naskah")
    if not all(str(x).strip() for x in (suasana, tempo, pendengar)): raise ValueError("pilih_suara: suasana, tempo, dan pendengar wajib diisi (pemilihan suara tidak boleh asal)")
    daftar = {n: ket for n, ket in saran_suara(platform, kebutuhan)}
    if nama not in daftar: raise ValueError(f"suara {nama!r} tidak ada di daftar terverifikasi untuk {platform}/{kebutuhan}: {list(daftar)}")
    return dict(nama=nama, platform=platform, alasan=f"{nama} ({daftar[nama]}) dipilih karena naskahnya bersuasana {suasana}, bertempo {tempo}, untuk pendengar {pendengar}.")

def cek_tag_eleven(teks):
    """Periksa naskah ElevenLabs: tag harus [kurung siku]; tag di luar contoh resmi diberi peringatan (bukan ditolak: halaman resmi bukan daftar tertutup); kurung sudut dilarang. -> dict(ok, tag, tidak_dikenal, galat)."""
    tag = re.findall(r"\[([^\]\n]{1,40})\]", teks); asing = [t for t in tag if t.strip().lower() not in {x.lower() for x in TAG_ELEVEN_RESMI}]; g = []
    if re.search(r"<[a-z\- ]{2,20}>", teks): g.append("memakai <kurung sudut> (itu untuk Google AI Studio); ElevenLabs memakai [kurung siku]")
    return dict(ok=not g, tag=tag, tidak_dikenal=asing, galat=g)

def cek_tag_google(teks):
    """Periksa naskah Google AI Studio: kejadian sesaat di <kurung sudut>; [kurung siku] dilarang di sini. Tag di luar contoh dokumentasi diberi peringatan."""
    tag = re.findall(r"<([^>\n]{1,30})>", teks); asing = [t for t in tag if t.strip().lower() not in TAG_GOOGLE]; g = []
    if re.search(r"\[[a-zA-Z ]{2,25}\]", teks): g.append("memakai [kurung siku] (itu untuk ElevenLabs); Google AI Studio memakai <kurung sudut>")
    return dict(ok=not g, tag=tag, tidak_dikenal=asing, galat=g)

def naskah_bersih(teks_bertag):
    """Buang semua tag ([..] dan <..>) dan penanda penekanan *kata* (6.9) -> narasi bersih (aturan bagian 5). Bersihkan juga spasi ganda."""
    t = re.sub(r"\[[^\]\n]{1,40}\]|<[^>\n]{1,30}>", "", teks_bertag); t = t.replace("*", ""); return re.sub(r"[ \t]{2,}", " ", re.sub(r" +([,.!?])", r"\1", t)).strip()

def gaya_google(deskripsi):
    """Bungkus deskripsi gaya narator ke bentuk speech_metadata.style. Wajib deskriptif, mis. 'A warm, professional narrator with clear articulation and a measured pace'."""
    if len(deskripsi.split()) < 5: raise ValueError("deskripsikan gaya narator minimal 5 kata (warna suara, artikulasi, tempo)")
    return {"speech_metadata": {"style": deskripsi}}

# ---- voice over LANGSUNG: hanya bila ada mesin suara yang ALAMI. Suara robot (flite, espeak, sintesis formant sendiri) DITOLAK.
MESIN_ALAMI = [("modul", "piper", "Piper (neural, offline)"), ("modul", "TTS", "Coqui TTS (neural)"), ("modul", "kokoro", "Kokoro (neural)"), ("modul", "f5_tts", "F5-TTS (neural)"), ("cli", "piper", "Piper CLI")]
MESIN_ROBOT = ["espeak", "espeak-ng", "flite", "festival", "pico2wave", "ffmpeg-flite", "formant"]
class SuaraAlamiTidakAda(RuntimeError): pass

def vo_langsung_tersedia():
    """-> dict(ada, mesin[list], alasan). Mencari mesin NEURAL yang terpasang DAN punya model suara Indonesia/natural. Mesin robotik tidak dihitung."""
    ada = []
    for jenis, nama, label in MESIN_ALAMI:
        try:
            if jenis == "modul": importlib.import_module(nama); ada.append(label)
            elif shutil.which(nama): ada.append(label)
        except Exception: pass
    return dict(ada=bool(ada), mesin=ada, alasan="" if ada else "tidak ada mesin suara neural di sesi ini; yang tersedia hanya mesin robotik (ditolak) dan koneksi ke layanan suara luar diblokir")

def vo_langsung(paragraf, out, **kw):
    """Buat voice over langsung (hanya bila diminta). Tanpa mesin alami -> SuaraAlamiTidakAda: katakan di kalimat pertama laporan, lalu tawarkan naskah bertag (ElevenLabs / Google AI Studio) atau Cara 2."""
    F.IZIN.butuh("voice_over_langsung"); st = vo_langsung_tersedia()
    if not st["ada"]: raise SuaraAlamiTidakAda(st["alasan"] + ". Voice over robot tidak dipakai. Tawarkan: naskah bertag untuk ElevenLabs/Google AI Studio, atau user mengirim audionya (Cara 2).")
    raise NotImplementedError("hubungkan mesin " + ", ".join(st["mesin"]) + " di sini; hasil wajib lolos audit sinkron (fxlib.sync_audit) dan didengar user sebelum dipakai")
