# fxlib.py - SFX sintesis + mixer, efek karakter, timer overlay (hanya Pillow + numpy + ffmpeg)
import math, subprocess, wave, inspect
import numpy as np
from PIL import Image, ImageDraw, ImageFont

# ---------------- util ----------------
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def prog(t, t0, d): return clamp((t - t0) / d)
def e_io(p): return 0.5 - 0.5 * math.cos(math.pi * p)
def e_out(p): return 1 - (1 - p) ** 3
def e_back(p, s=1.70158):
    p -= 1
    return p * p * ((s + 1) * p + s) + 1
def popin(t, t0, d=0.45):
    p = prog(t, t0, d)
    return e_back(p) if p > 0 else 0.0
def mixc(c1, c2, a): return tuple(int(c1[i] + (c2[i] - c1[i]) * a) for i in range(3))

# ---------------- izin fitur "HANYA bila diminta" (ditegakkan di kode) + penamaan file ----------------
import functools, os, re as _re
class FiturTidakDiminta(PermissionError): pass
class NamaFileSalah(ValueError): pass

class Izin:
    """Fitur opsional TIDAK bisa dipanggil sebelum diaktifkan. Aktifkan dari kalimat permintaan user: IZIN.dari_teks(permintaan). Fitur: timer, subtitle, transisi, hook, video_effect, watermark, chat_bubble, lighting, voice_over_langsung, voice_over_naskah.
    Pemicu utamanya NAMA fitur; variasi yang jelas bermaksud sama ikut dikenali. Hanya Timer yang boleh diaktifkan AI sendiri (IZIN.aktifkan_sendiri('timer', alasan)), dan alasannya masuk laporan akhir."""
    POLA = {
        "timer": [r"\btimer\b", r"bagaimana (jika|kalau)", r"\bwhat if\b", r"setiap \d+ (detik|menit)", r"selama \d+ (detik|menit)"],
        "subtitle": [r"\bsubtitle", r"teks ucapan", r"teks (narasi|suara) di bawah"],
        "transisi": [r"\btransisi"],
        "hook": [r"\bhook\b.*(perbaik|improve|tingkat|ubah|ganti|lebih)", r"(perbaik|improve|tingkat|ubah|ganti).*\bhook\b", r"hook improvement"],
        "video_effect": [r"video effects?", r"efek video"],
        "watermark": [r"water ?mark", r"tanda air"],
        "chat_bubble": [r"chat bubble", r"bubble chat", r"gelembung (chat|obrolan)", r"balon (chat|obrolan)"],
        "lighting": [r"\blighting", r"pencahayaan", r"\bshadow\b", r"bayangan"],
        "voice_over_langsung": [r"instant voice ?over", r"voice ?over langsung", r"\bvo langsung", r"buatkan (voice ?over|suaranya)", r"suara langsung"],
        "voice_over_naskah": [r"manual voice ?over", r"voice ?over manual", r"tag (voice ?over|elevenlabs|google)", r"naskah voice ?over (ber)?tag", r"saran suara", r"google ai studio", r"eleven ?labs"],
    }
    def __init__(self): self.aktif = set(); self.catatan = []
    def dari_teks(self, teks):
        t = teks.lower()
        for fitur, pola in self.POLA.items():
            if any(_re.search(p, t) for p in pola): self.aktif.add(fitur)
        return set(self.aktif)
    def aktifkan_sendiri(self, fitur, alasan):
        if fitur != "timer": raise FiturTidakDiminta(f"'{fitur}' hanya boleh aktif bila user memintanya; AI tidak boleh mengaktifkannya sendiri")
        if len(alasan.split()) < 4: raise ValueError("alasan harus jelas (minimal 4 kata): kenapa video ini jelas cocok memakai timer")
        self.aktif.add(fitur); self.catatan.append(f"timer dipakai atas keputusan AI: {alasan}")
    def butuh(self, fitur):
        if fitur not in self.aktif: raise FiturTidakDiminta(f"fitur '{fitur}' hanya bila user memintanya. Aktif sekarang: {sorted(self.aktif) or 'tidak ada'}. Tidak diminta = jangan dipakai.")
    def reset(self): self.aktif.clear(); self.catatan.clear()
IZIN = Izin()
def izin_dari_teks(teks): return IZIN.dari_teks(teks)
def butuh(fitur):
    """Dekorator: fungsi hanya jalan bila fitur sudah diminta user (lihat Izin)."""
    def dek(fn):
        @functools.wraps(fn)
        def w(*a, **k): IZIN.butuh(fitur); return fn(*a, **k)
        w.__wrapped_fitur__ = fitur; return w
    return dek

_POLA_VERSI = _re.compile(r"(?i)(?:^|[\s._\-])(v\d+|ver\d+|versi\d*|final\d*|baru\d*|new\d*|copy\d*|salinan\d*|rev\d+|revisi\d*|edit\d*|backup\d*|tmp\d*|\(\d+\))(?=[\s._\-)]|$)")
def nama_file_ok(path):
    """Tolak nama berembel-embel versi (v2, v3, final, final2, baru, copy, revisi2, (1) ...). Nama file deskriptif dan tetap; revisi MENIMPA nama yang sama (versi lama lewat arsipkan())."""
    nama = os.path.splitext(os.path.basename(str(path)))[0]
    m = _POLA_VERSI.search(nama)
    if m: raise NamaFileSalah(f"nama file '{os.path.basename(str(path))}' memuat penanda versi '{m.group(1)}'. Pakai nama deskriptif yang tetap (mis. kucing-cokelat.mp4); revisi menimpa nama yang sama.")
    return path
def arsipkan(path, folder="arsip"):
    """Pindahkan versi lama ke folder arsip (nama berstempel waktu, tidak dikirim ke user) sebelum menimpa file dengan revisi. Tidak ada file -> tidak melakukan apa-apa."""
    import shutil, time
    nama_file_ok(path)
    if not os.path.isfile(path): return None
    os.makedirs(os.path.join(os.path.dirname(os.path.abspath(path)), folder), exist_ok=True)
    b, e = os.path.splitext(os.path.basename(path)); tujuan = os.path.join(os.path.dirname(os.path.abspath(path)), folder, f"{b}.{time.strftime('%Y%m%d-%H%M%S')}{e}"); shutil.move(path, tujuan); return tujuan
def tulis_aman(path):
    """Panggil sebelum menulis file keluaran: cek nama, arsipkan versi lama. Mengembalikan path yang sama."""
    nama_file_ok(path); arsipkan(path); return path

# ---------------- SFX (sintesis, tanpa unduhan) ----------------
SR = 44100
def _t(d): return np.arange(int(SR * d)) / SR
def _norm(x, peak=0.9):
    m = float(np.max(np.abs(x))) or 1.0
    return (x / m * peak).astype(np.float32)
def _phase(f): return 2 * np.pi * np.cumsum(f) / SR

def sfx_pop(f0=700, f1=180, d=0.14):                    # elemen muncul
    t = _t(d); return _norm(np.sin(_phase(f1 + (f0 - f1) * np.exp(-t * 28))) * np.exp(-t * 22))
def sfx_whoosh(d=0.55, up=True, f_lo=300, f_hi=5000, seed=7):   # transisi / sapuan
    n = int(SR * d); x = np.random.default_rng(seed).standard_normal(n); p = np.linspace(0, 1, n)
    fc = f_lo * (f_hi / f_lo) ** (p if up else 1 - p)
    a = 1 - np.exp(-2 * np.pi * fc / SR); y = np.empty(n); s = 0.0
    for i in range(n):
        s += a[i] * (x[i] - s); y[i] = s
    y -= np.convolve(y, np.ones(220) / 220, 'same')
    return _norm(y * np.sin(np.pi * p) ** 2)
def sfx_ding(f=988, d=0.7):                             # sukses / info
    t = _t(d); y = np.sin(2*np.pi*f*t) + .5*np.sin(2*np.pi*f*2.01*t) + .25*np.sin(2*np.pi*f*3.02*t)
    return _norm(y * np.exp(-t * 6) * np.minimum(1, t / 0.003))
def sfx_tick(f=1800, d=0.05):                           # detik timer
    t = _t(d); return _norm(np.sin(2 * np.pi * f * t) * np.exp(-t * 90))
def sfx_beep(f=1200, d=0.12):                           # 3 detik terakhir timer
    t = _t(d); return _norm(np.sin(2*np.pi*f*t) * np.minimum(1, t/0.004) * np.minimum(1, (d-t)/0.01))
def sfx_impact(d=0.8, seed=3):                          # timer nol / kejadian besar
    t = _t(d); body = np.sin(_phase(40 + 110 * np.exp(-t * 18))) * np.exp(-t * 5)
    return _norm(body + np.random.default_rng(seed).standard_normal(len(t)) * np.exp(-t * 30) * .5)
def sfx_alert(d=0.6):                                   # bahaya / teriak
    t = _t(d); f = np.where((t * 6).astype(int) % 2 == 0, 880, 660)
    return _norm(np.sign(np.sin(_phase(f))) * .6 * np.minimum(1, (d - t) / 0.03))
def sfx_boing(d=0.45):                                  # kaget kartun
    t = _t(d); f = 300 + 220 * np.sin(2*np.pi*7*t) * np.exp(-t*5) + 120 * np.exp(-t*8)
    return _norm(np.sin(_phase(f)) * np.exp(-t * 5))
def sfx_riser(d=1.0, seed=5):                           # ketegangan naik
    t = _t(d); q = t / d
    return _norm(np.sin(_phase(200 + 1800 * q ** 2)) * q * .7 + np.random.default_rng(seed).standard_normal(len(t)) * q ** 2 * .3)

# bunyi tambahan supaya satu jenis kejadian punya beberapa "suara" (anti berulang)
def sfx_bubble(d=0.16):                                 # muncul: gelembung naik
    t = _t(d); f = 320 + 900 * (t / d) ** 1.4
    return _norm(np.sin(_phase(f)) * np.exp(-t * 16) * np.minimum(1, t / 0.004))
def sfx_blip(d=0.10):                                   # muncul: dua nada pendek
    t = _t(d); f = np.where(t < d * 0.45, 880, 1320)
    return _norm(np.sin(_phase(f)) * np.exp(-t * 20) * np.minimum(1, t / 0.003))
def sfx_click(d=0.05):                                  # muncul: klik kering
    t = _t(d); x = np.random.default_rng(11).standard_normal(len(t)); x = np.diff(x, prepend=0)
    return _norm((x * .6 + np.sin(2 * np.pi * 2400 * t)) * np.exp(-t * 140))
def sfx_chime(f=1318, d=1.0):                           # sukses: lonceng kecil (partial tidak harmonis)
    t = _t(d); y = sum(a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * k)
                       for a, r, k in ((1, 1, 4), (.5, 2.76, 6), (.3, 5.4, 9)))
    return _norm(y * np.minimum(1, t / 0.002))
def sfx_sparkle(d=0.5, f=1046):                         # sukses: arpeggio kilau naik
    out = np.zeros(int(SR * d), np.float32)
    for i, r in enumerate((1, 1.25, 1.5, 2)):
        s = sfx_ding(f * r, 0.28) * (0.5 + 0.12 * i); j = int(i * 0.07 * SR); out[j:j + len(s)] += s[:len(out) - j]
    return _norm(out)
def sfx_thud(d=0.35):                                   # benturan: tumpul rendah
    t = _t(d); return _norm(np.sin(_phase(45 + 40 * np.exp(-t * 20))) * np.exp(-t * 13) * np.minimum(1, t / 0.002))
def sfx_swish(d=0.25, seed=21): return sfx_whoosh(d, True, 500, 4000, seed)   # sapuan pendek

# ---------------- bank SFX besar: 60+ bunyi, dikelompokkan per jenis kejadian (AI memilih, bukan mengulang yang itu-itu saja) ----------------
def _bp(x, lo, hi):
    """Band-pass lewat FFT (tepi halus). hi=None berarti high-pass, lo=None berarti low-pass."""
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR); m = np.ones_like(f)
    if lo: m *= 1 / (1 + (lo / np.maximum(f, 1e-3)) ** 4)
    if hi: m *= 1 / (1 + (f / hi) ** 4)
    return np.fft.irfft(X * m, len(x))
def _nz(d, seed=1): return np.random.default_rng(seed).standard_normal(int(SR * d))
def _ad(t, a=0.003, k=10): return np.minimum(1, t / a) * np.exp(-t * k)          # attack cepat, decay eksponensial
def _fade(x, ms=8):
    n = min(len(x) // 2, int(SR * ms / 1000)); x = x.copy()
    if n: x[:n] *= np.linspace(0, 1, n); x[-n:] *= np.linspace(1, 0, n)
    return x
def _mix(parts, d):
    y = np.zeros(int(SR * d), np.float32)
    for s, dl, g in parts:
        i = int(dl * SR); s = s * 10 ** (g / 20); y[i:i + len(s)] += s[:max(0, len(y) - i)]
    return y
def _glide(f0, f1, d, curve=1.0, vib=0.0, vf=6.0):
    t = _t(d); q = (t / d) ** curve; f = f0 * (f1 / f0) ** q
    if vib: f = f * (1 + vib * np.sin(2 * np.pi * vf * t))
    return _phase(f)

# --- muncul / UI
def sfx_plop(d=0.2):                                    # tetes air
    t = _t(d); f = 250 + 900 * (1 - np.exp(-t * 60)); return _norm(np.sin(_phase(f)) * _ad(t, 0.002, 17))
def sfx_wood(d=0.14, f=820):                            # ketukan kayu
    t = _t(d); return _norm((np.sin(2*np.pi*f*t) + .6*np.sin(2*np.pi*f*1.5*t)) * _ad(t, 0.001, 48) + _bp(_nz(d, 4), 1500, 5000) * np.exp(-t * 200) * .3)
def sfx_pluck(f=440, d=0.6, seed=2):                    # senar dipetik (Karplus-Strong)
    n = int(SR / f); buf = np.random.default_rng(seed).uniform(-1, 1, n); out = np.empty(int(SR * d))
    for i in range(len(out)):
        out[i] = buf[i % n]; buf[i % n] = 0.5 * (buf[i % n] + buf[(i + 1) % n]) * 0.996
    return _norm(_fade(out, 3))
def sfx_marimba(f=523, d=0.5):                          # marimba / xylophone lembut
    t = _t(d); return _norm((np.sin(2*np.pi*f*t) * np.exp(-t * 7) + .4 * np.sin(2*np.pi*f*4*t) * np.exp(-t * 28)) * np.minimum(1, t / 0.002))
def sfx_snap(d=0.09, seed=5):                           # jentikan jari
    t = _t(d); return _norm(_bp(_nz(d, seed), 1500, 6000) * np.exp(-t * 55) + np.sin(2*np.pi*1100*t) * np.exp(-t * 90) * .4)
def sfx_zip_up(d=0.13):                                 # kicauan naik pendek
    t = _t(d); return _norm(np.sin(_glide(600, 2600, d)) * _ad(t, 0.004, 14))
def sfx_toggle_on(d=0.13): return _norm(_mix([(sfx_blip_tone(680, .06), 0, 0), (sfx_blip_tone(1010, .07), .05, 0)], d))
def sfx_toggle_off(d=0.13): return _norm(_mix([(sfx_blip_tone(1010, .06), 0, 0), (sfx_blip_tone(640, .07), .05, 0)], d))
def sfx_blip_tone(f, d): t = _t(d); return np.sin(2*np.pi*f*t) * _ad(t, 0.003, 22)
def sfx_key(d=0.05, seed=9):                            # ketikan keyboard mekanik
    t = _t(d); return _norm(_bp(_nz(d, seed), 1000, 4500) * np.exp(-t * 170) + np.sin(2*np.pi*230*t) * np.exp(-t * 95) * .7)
def sfx_stamp(d=0.3):                                   # cap / stempel
    return _norm(_mix([(sfx_thud(0.3), 0, 0), (sfx_click(0.05), 0, -3)], d))

# --- sukses / info
def sfx_coin(d=0.45):                                   # koin: dua nada naik
    t = _t(d); f = np.where(t < 0.07, 988, 1319); w = np.sin(_phase(f)) * .8 + np.sign(np.sin(_phase(f))) * .15
    return _norm(w * _ad(t, 0.002, 7) * np.where(t < 0.07, 1, 1))
def sfx_levelup(d=0.7):                                 # arpeggio naik cepat (C-E-G-C)
    return _norm(_mix([(sfx_marimba(f, 0.35), i * 0.09, -i * 1.0) for i, f in enumerate((523, 659, 784, 1047))], d))
def sfx_fmbell(f=880, d=1.0):                           # lonceng FM metalik
    t = _t(d); return _norm(np.sin(2*np.pi*f*t + 3.2 * np.exp(-t * 4) * np.sin(2*np.pi*f*1.41*t)) * _ad(t, 0.002, 3.5))
def sfx_harp(d=0.9):                                    # sapuan harpa naik
    return _norm(_mix([(sfx_pluck(f, 0.5, 20 + i), i * 0.055, -i * 0.8) for i, f in enumerate((392, 494, 587, 784, 988))], d))
def sfx_notify(d=0.5):                                  # notifikasi dua nada
    return _norm(_mix([(sfx_marimba(659, 0.3), 0, 0), (sfx_marimba(988, 0.4), 0.13, -1)], d))
def sfx_cash(d=0.8):                                    # ka-ching
    return _norm(_mix([(sfx_click(0.05), 0, 0), (sfx_fmbell(2093, 0.7), 0.05, -4), (sfx_fmbell(2637, 0.6), 0.12, -6)], d))

# --- benturan
def sfx_boom(d=1.4, seed=6):                            # ledakan rendah panjang
    t = _t(d); return _norm(np.sin(_phase(55 * np.exp(-t * 1.2) + 22)) * np.exp(-t * 2.4) + _bp(_nz(d, seed), None, 400) * np.exp(-t * 3.2) * 1.4)
def sfx_kick(d=0.32):                                   # kick drum
    t = _t(d); return _norm(np.sin(_phase(48 + 130 * np.exp(-t * 38))) * np.exp(-t * 9) + _bp(_nz(d, 8), 1500, 6000) * np.exp(-t * 150) * .12)
def sfx_slam(d=0.5, seed=12):                           # pintu dibanting
    t = _t(d); return _norm(_bp(_nz(d, seed), 70, 900) * np.exp(-t * 14) * 1.3 + np.sin(_phase(60 + 80 * np.exp(-t * 30))) * np.exp(-t * 12))
def sfx_stomp(d=0.25, seed=13):                         # injakan
    t = _t(d); return _norm(np.sin(_phase(70 + 60 * np.exp(-t * 40))) * np.exp(-t * 17) + _bp(_nz(d, seed), 200, 1200) * np.exp(-t * 45) * .6)
def sfx_punch(d=0.2, seed=14):                          # pukulan pendek
    t = _t(d); return _norm(_bp(_nz(d, seed), 100, 800) * np.exp(-t * 32) + np.sin(_phase(110 * np.exp(-t * 14) + 40)) * np.exp(-t * 25))
def sfx_glass(d=1.0, seed=15):                          # kaca pecah
    t = _t(d); r = np.random.default_rng(seed); y = _bp(_nz(d, seed), 3500, 12000) * np.exp(-t * 14)
    for _ in range(14):
        a = r.uniform(0, 0.35); f = r.uniform(3500, 9500); y += np.sin(2*np.pi*f*np.maximum(t - a, 0)) * np.exp(-np.maximum(t - a, 0) * 30) * (t > a) * .35
    return _norm(y)

# --- kaget / lucu
def sfx_stinger(d=0.9):                                 # sengatan tegang (klaster sekunde minor)
    t = _t(d); y = 0
    for f in (196, 207.65, 277.2, 415.3): y = y + sum(np.sin(2*np.pi*f*k*t) / k for k in (1, 2, 3))
    return _norm(y * _ad(t, 0.004, 4.2))
def sfx_hornsting(d=0.7):                               # klakson dramatis dua nada
    t = _t(d); y = 0
    for f in (233, 349): y = y + sum(np.sin(2*np.pi*f*k*t) / k for k in (1, 2, 3, 4, 5))
    return _norm(y * np.minimum(1, t / 0.03) * np.exp(-t * 3))
def sfx_scratch(d=0.4, seed=16):                        # piringan hitam digores
    t = _t(d); m = np.abs(np.sin(2*np.pi*2.5*t)) ** .6; return _norm(_bp(_nz(d, seed), 700, 6500) * m * np.minimum(1, (d - t) / 0.05) + np.sin(_phase(300 + 900 * m)) * .15)
def sfx_gasp(d=0.32, seed=17):                          # tarikan napas kaget
    t = _t(d); q = t / d; return _norm(_bp(_nz(d, seed), 900, 4500) * q ** 1.4 * np.minimum(1, (d - t) / 0.02))
def sfx_buzz(d=0.35):                                   # salah / ditolak
    t = _t(d); s = np.sign(np.sin(2*np.pi*140*t)) * .6 + np.sin(2*np.pi*140*t); return _norm(s * (1 + .5 * np.sin(2*np.pi*30*t)) * np.minimum(1, t / 0.005) * np.minimum(1, (d - t) / 0.03))
def sfx_bonk(d=0.28):                                   # kepala kena benda (kartun)
    t = _t(d); return _norm(np.sin(_phase(330 * np.exp(-t * 6) + 130)) * _ad(t, 0.002, 14) + _bp(_nz(d, 18), 400, 2500) * np.exp(-t * 80) * .5)
def sfx_squeak(d=0.14):                                 # mencicit
    t = _t(d); return _norm(np.sin(_glide(2200, 3600, d)) * _ad(t, 0.005, 12))
def sfx_cork(d=0.17):                                   # sumbat terbuka
    t = _t(d); return _norm(np.sin(_phase(180 + 520 * (1 - np.exp(-t * 50)))) * _ad(t, 0.002, 26) + _bp(_nz(d, 19), 500, 3000) * np.exp(-t * 90) * .4)
def sfx_wobble(d=0.5):                                  # goyang agar-agar
    t = _t(d); return _norm(np.sin(_phase(420 + 170 * np.sin(2*np.pi*9*t) * np.exp(-t * 3))) * np.exp(-t * 4.5) * np.minimum(1, t / 0.005))
def sfx_slide_up(d=0.5):                                # slide whistle naik
    t = _t(d); return _norm(np.sin(_glide(300, 1800, d, 1.0, 0.012, 6)) * np.minimum(1, t / 0.02) * np.minimum(1, (d - t) / 0.04))
def sfx_slide_down(d=0.55):                             # slide whistle turun (lucu / gagal)
    t = _t(d); return _norm(np.sin(_glide(1500, 220, d, 1.0, 0.012, 6)) * np.minimum(1, t / 0.02) * np.minimum(1, (d - t) / 0.06))
def sfx_fail(d=1.1):                                    # "wah-wah" gagal (trombon turun)
    t = _t(d); notes = [(0, .25, 392), (.27, .25, 370), (.54, .25, 349)]; y = np.zeros(len(t))
    for a, ln, f in notes:
        m = (t >= a) & (t < a + ln); tt = t[m] - a; y[m] = sum(np.sin(2*np.pi*f*k*tt) / k for k in (1, 2, 3, 4)) * np.minimum(1, tt / 0.02) * np.minimum(1, (ln - tt) / 0.03)
    m = t >= .81; tt = t[m] - .81; ph = 2*np.pi*np.cumsum(330 * (1 - .35 * tt / (d - .81))) / SR
    y[m] = sum(np.sin(ph * k) / k for k in (1, 2, 3, 4)) * np.minimum(1, (d - .81 - tt) / 0.08)
    return _norm(_bp(y, 120, 3000))

# --- sapuan / transisi
def sfx_whoosh_down(d=0.5, seed=31): return sfx_whoosh(d, False, 400, 5000, seed)
def sfx_air(d=0.9, seed=32):                            # embusan udara lembut
    t = _t(d); return _norm(_bp(_nz(d, seed), 150, 1800) * np.sin(np.pi * t / d) ** 2)
def sfx_rewind(d=0.5):                                  # pita diputar mundur
    t = _t(d); return _norm(np.sin(_glide(3200, 380, d, 0.8)) * .6 + _bp(_nz(d, 33), 1500, 7000) * .5 * (1 + np.sin(2*np.pi*55*t)) / 2)
def sfx_pitchsweep(d=0.4):                              # sapuan bernada (sci-fi ringan)
    t = _t(d); return _norm((np.sin(_glide(250, 1600, d, 1.4)) + .3 * np.sin(_glide(500, 3200, d, 1.4))) * np.sin(np.pi * t / d) ** 1.5)
def sfx_flutter(d=0.3, seed=34):                        # kepakan cepat
    t = _t(d); return _norm(_bp(_nz(d, seed), 800, 5000) * (.5 + .5 * np.sign(np.sin(2*np.pi*32*t))) * np.sin(np.pi * t / d))

# --- ritme (gaya kinetic / beat)
def sfx_snare(d=0.28, seed=40):
    t = _t(d); return _norm(_bp(_nz(d, seed), 1500, None) * np.exp(-t * 20) + np.sin(_phase(190 + 60 * np.exp(-t * 40))) * np.exp(-t * 26) * .8)
def sfx_hat(d=0.07, seed=41):
    t = _t(d); return _norm(_bp(_nz(d, seed), 6500, None) * np.exp(-t * 70))
def sfx_hat_open(d=0.35, seed=42):
    t = _t(d); return _norm(_bp(_nz(d, seed), 5500, None) * np.exp(-t * 11))
def sfx_clap(d=0.28, seed=43):
    t = _t(d); n = _bp(_nz(d, seed), 900, 3800); env = sum(np.exp(-np.maximum(t - a, 0) * 150) * (t >= a) for a in (0, .011, .023)) * .5 + np.exp(-t * 22) * (t >= .03)
    return _norm(n * env)
def sfx_rim(d=0.07):
    t = _t(d); return _norm((np.sin(2*np.pi*1750*t) + .5 * np.sin(2*np.pi*480*t)) * _ad(t, 0.0005, 70))
def sfx_tom(f=120, d=0.4):
    t = _t(d); return _norm(np.sin(_phase(f * (1 + 1.2 * np.exp(-t * 28)))) * _ad(t, 0.002, 9))
def sfx_sub(d=1.0):                                     # jatuhan bas
    t = _t(d); return _norm(np.sin(_phase(70 * np.exp(-t * 1.6) + 30)) * np.exp(-t * 2.2) * np.minimum(1, t / 0.01))
def sfx_clock(d=0.07):                                  # detik jam mekanik
    t = _t(d); return _norm(np.sin(2*np.pi*1350*t) * np.exp(-t * 110) + _bp(_nz(d, 44), 2000, 6000) * np.exp(-t * 200) * .4)

# --- tegang / atmosfer
def sfx_noise_riser(d=1.5, seed=50):                    # riser derau
    n = int(SR * d); x = _nz(d, seed); q = np.linspace(0, 1, n); y = np.zeros(n)
    for a, b in zip(np.linspace(0, .9, 8), np.linspace(.1, 1, 8)):
        i, j = int(a * n), int(b * n); y[i:j] = _bp(x[i:j], 300 + 6000 * ((a + b) / 2) ** 2, 1500 + 9000 * ((a + b) / 2) ** 2)
    return _norm(y * q ** 2)
def sfx_revcym(d=1.3, seed=51):                         # simbal terbalik
    t = _t(d); q = t / d; return _norm(_bp(_nz(d, seed), 3500, None) * q ** 3 * np.minimum(1, (d - t) / 0.01))
def sfx_heartbeat(d=0.85):                              # dag-dug
    return _norm(_mix([(sfx_tom(62, 0.28), 0, 0), (sfx_tom(55, 0.3), 0.27, -3)], d))
def sfx_sonar(d=1.8):                                   # ping sonar + gema
    p = lambda: (lambda t: np.sin(2*np.pi*1250*t) * _ad(t, 0.004, 6))(_t(0.7))
    return _norm(_mix([(p(), 0, 0), (p(), 0.6, -9), (p(), 1.2, -16)], d))
def sfx_pad(d=2.0):                                     # bantalan akor lembut (C mayor 9)
    t = _t(d); y = sum(np.sin(2*np.pi*f*t) + np.sin(2*np.pi*f*1.004*t) for f in (131, 196, 262, 330, 392, 588)) / 12
    return _norm(y * np.sin(np.pi * t / d) ** 2)
def sfx_rumble(d=2.0, seed=52):                         # gemuruh rendah
    t = _t(d); return _norm(_bp(_nz(d, seed), 18, 110) * (.6 + .4 * np.sin(2*np.pi*3.3*t)) * np.sin(np.pi * t / d) ** 1.2)
def sfx_wind(d=2.2, seed=53):                           # angin
    t = _t(d); m = .55 + .45 * np.sin(2*np.pi*.7*t + 1) * np.sin(2*np.pi*.23*t); return _norm(_bp(_nz(d, seed), 250, 2200) * m * np.sin(np.pi * t / d) ** 1.2)

# --- digital / sains
def sfx_glitch(d=0.3, seed=60):                         # glitch: potongan pendek diulang
    r = np.random.default_rng(seed); out = np.zeros(int(SR * d), np.float32); seg = int(SR * 0.022); i = 0
    src = (np.sin(2*np.pi*r.uniform(300, 1800) * _t(0.05)) * .6 + _nz(0.05, seed) * .4)[:seg]
    while i + seg < len(out):
        s = src * (1 if r.random() > .3 else -1); out[i:i + seg] += s * r.uniform(.5, 1); i += seg + int(r.uniform(0, .012) * SR)
        if r.random() < .3: src = np.roll(src, int(r.uniform(5, 200)))
    return _norm(out * np.minimum(1, (d - _t(d)) / 0.03))
def sfx_tapestop(d=0.6):                                # kaset berhenti
    t = _t(d); q = t / d; return _norm(np.sin(2*np.pi*np.cumsum(700 * (1 - q) ** 2) / SR) * (1 - q) ** .5)
def sfx_zap(d=0.28):                                    # sengatan listrik
    t = _t(d); w = 2*np.pi*np.cumsum(3200 * np.exp(-t * 14) + 180) / SR; return _norm((np.sign(np.sin(w)) * .5 + np.sin(w)) * np.exp(-t * 9) + _bp(_nz(d, 61), 2000, 9000) * np.exp(-t * 25) * .3)
def sfx_laser(d=0.38):                                  # laser sci-fi
    t = _t(d); w = np.sin(_glide(2600, 260, d, 0.5)); return _norm((w + .4 * np.sin(2 * _glide(2600, 260, d, 0.5))) * _ad(t, 0.002, 6))
def sfx_static(d=0.4, seed=62):                         # derau statis TV
    t = _t(d); return _norm(_bp(_nz(d, seed), 400, 9000) * (.4 + .6 * (np.sin(2*np.pi*37*t) > 0)) * np.minimum(1, (d - t) / 0.04))
def sfx_powerup(d=1.0):                                 # mesin menyala
    t = _t(d); q = t / d; f = 70 * (6 ** q); y = sum(np.sin(2*np.pi*np.cumsum(f * k) / SR) / k for k in (1, 2, 3)); return _norm(y * q ** .7 * np.minimum(1, (d - t) / 0.02))
def sfx_powerdown(d=1.0):                               # mesin mati
    t = _t(d); q = t / d; f = 420 * (0.17 ** q); y = sum(np.sin(2*np.pi*np.cumsum(f * k) / SR) / k for k in (1, 2, 3)); return _norm(y * (1 - q) ** .8 * np.minimum(1, t / 0.01))
def sfx_teleport(d=0.9):                                # teleportasi: sapuan + kilau
    return _norm(_mix([(sfx_pitchsweep(0.45), 0, 0), (sfx_sparkle(0.5, 1568), 0.4, -3)], d))
def sfx_shutter(d=0.25):                                # rana kamera
    return _norm(_mix([(sfx_click(0.05), 0, 0), (sfx_click(0.05), 0.07, -2), (_bp(_nz(0.12, 63), 1500, 7000) * np.exp(-_t(0.12) * 60), 0.02, -9)], d))

# ---------------- KATALOG: nama -> (fungsi, keluarga, kapan dipakai) ----------------
KATALOG = {
    # muncul / UI
    "pop": (sfx_pop, "muncul", "ikon atau elemen muncul"), "bubble": (sfx_bubble, "muncul", "elemen naik lembut"), "blip": (sfx_blip, "muncul", "dua nada kecil, label muncul"),
    "click": (sfx_click, "muncul", "klik kering"), "plop": (sfx_plop, "muncul", "tetes air, elemen jatuh pelan"), "wood": (sfx_wood, "muncul", "ketukan kayu, kartu atau blok diletakkan"),
    "pluck": (sfx_pluck, "muncul", "petikan senar, daftar muncul berurutan"), "marimba": (sfx_marimba, "muncul", "nada lembut, poin satu per satu"),
    "snap": (sfx_snap, "muncul", "jentikan jari, teks muncul cepat"), "zip_up": (sfx_zip_up, "muncul", "kicau naik pendek"),
    "toggle_on": (sfx_toggle_on, "muncul", "tombol atau opsi aktif"), "key": (sfx_key, "muncul", "ketikan keyboard, teks mengetik"), "stamp": (sfx_stamp, "benturan", "cap, label ditempel"),
    # sukses
    "ding": (sfx_ding, "sukses", "benar, selesai"), "chime": (sfx_chime, "sukses", "lonceng kecil"), "sparkle": (sfx_sparkle, "sukses", "kilau naik"),
    "coin": (sfx_coin, "sukses", "poin atau koin"), "levelup": (sfx_levelup, "sukses", "naik level, pencapaian"), "fmbell": (sfx_fmbell, "sukses", "lonceng metalik"),
    "harp": (sfx_harp, "sukses", "harpa naik, momen indah"), "notify": (sfx_notify, "sukses", "notifikasi dua nada"), "cash": (sfx_cash, "sukses", "ka-ching, uang atau harga"),
    # benturan
    "impact": (sfx_impact, "benturan", "kejadian besar"), "thud": (sfx_thud, "benturan", "tumpul rendah"), "boom": (sfx_boom, "benturan", "ledakan panjang"),
    "kick": (sfx_kick, "ritme", "dentum bersih, ketukan beat"), "slam": (sfx_slam, "benturan", "dibanting"), "stomp": (sfx_stomp, "benturan", "injakan"),
    "punch": (sfx_punch, "benturan", "pukulan pendek"), "glass": (sfx_glass, "benturan", "kaca pecah, hancur"),
    # kaget
    "boing": (sfx_boing, "kaget", "kaget kartun"), "alert": (sfx_alert, "kaget", "bahaya"), "stinger": (sfx_stinger, "kaget", "sengatan tegang"),
    "hornsting": (sfx_hornsting, "kaget", "klakson dramatis"), "scratch": (sfx_scratch, "kaget", "ngerem mendadak, plot twist"), "gasp": (sfx_gasp, "kaget", "tarikan napas"),
    "buzz": (sfx_buzz, "gagal", "salah atau ditolak"), "bonk": (sfx_bonk, "lucu", "kepala terantuk"), "squeak": (sfx_squeak, "lucu", "mencicit"),
    # gagal
    "fail": (sfx_fail, "gagal", "gagal, wah-wah"), "slide_down": (sfx_slide_down, "gagal", "meluncur turun, lucu"), "powerdown": (sfx_powerdown, "gagal", "mati, padam"),
    "tapestop": (sfx_tapestop, "gagal", "berhenti mendadak"), "toggle_off": (sfx_toggle_off, "gagal", "opsi mati"),
    # sapuan
    "whoosh": (sfx_whoosh, "sapuan", "transisi naik"), "swish": (sfx_swish, "sapuan", "sapuan pendek"), "whoosh_down": (sfx_whoosh_down, "sapuan", "transisi turun"),
    "air": (sfx_air, "sapuan", "embusan lembut"), "rewind": (sfx_rewind, "sapuan", "putar mundur, flashback"), "pitchsweep": (sfx_pitchsweep, "sapuan", "sapuan bernada"),
    "flutter": (sfx_flutter, "sapuan", "kepakan"), "slide_up": (sfx_slide_up, "sapuan", "meluncur naik"),
    # ritme
    "snare": (sfx_snare, "ritme", "ketukan snare"), "hat": (sfx_hat, "ritme", "hi-hat tertutup"), "hat_open": (sfx_hat_open, "ritme", "hi-hat terbuka"), "clap": (sfx_clap, "ritme", "tepukan"),
    "rim": (sfx_rim, "ritme", "rim shot kecil"), "tom": (sfx_tom, "ritme", "tom"), "sub": (sfx_sub, "ritme", "jatuhan bas dalam"), "clock": (sfx_clock, "ritme", "jam mekanik"),
    # tegang
    "riser": (sfx_riser, "tegang", "naik, menuju kejadian"), "noise_riser": (sfx_noise_riser, "tegang", "riser derau panjang"), "revcym": (sfx_revcym, "tegang", "simbal terbalik sebelum drop"),
    "heartbeat": (sfx_heartbeat, "tegang", "detak jantung"), "sonar": (sfx_sonar, "tegang", "ping sonar, pencarian"), "pad": (sfx_pad, "tegang", "bantalan akor, takjub"),
    "rumble": (sfx_rumble, "tegang", "gemuruh rendah"), "wind": (sfx_wind, "tegang", "angin, ruang luas"),
    # digital
    "glitch": (sfx_glitch, "digital", "glitch, gangguan"), "zap": (sfx_zap, "digital", "sengatan listrik"), "laser": (sfx_laser, "digital", "laser, tembakan"),
    "static": (sfx_static, "digital", "derau TV"), "powerup": (sfx_powerup, "digital", "mesin menyala"), "teleport": (sfx_teleport, "digital", "berpindah"), "shutter": (sfx_shutter, "digital", "rana kamera"),
    # lucu
    "cork": (sfx_cork, "lucu", "sumbat terbuka"), "wobble": (sfx_wobble, "lucu", "goyang"),
}

def _selesai(fn):
    """Bungkus bunyi KATALOG: fade-in 1 ms dan fade-out 8 ms supaya tidak ada klik di tepi."""
    @functools.wraps(fn)
    def w(*a, **k):
        x = fn(*a, **k).astype(np.float32).copy(); n1 = max(1, int(SR * 0.001)); n2 = min(len(x) // 2, int(SR * 0.008))
        x[:n1] *= np.linspace(0, 1, n1); x[-n2:] *= np.linspace(1, 0, n2); return x
    return w
KATALOG = {k: (_selesai(v[0]), v[1], v[2]) for k, v in KATALOG.items()}

def beat_grid(bpm, dur, start=0.0, per_bar=4):
    """Waktu ketukan untuk video bergaya beat (pemotongan dan SFX jatuh di ketukan). Mengembalikan [(detik, nomor_bar, ketukan_ke)]."""
    s = 60.0 / bpm; n = int((dur - start) / s) + 1
    return [(round(start + i * s, 4), i // per_bar + 1, i % per_bar + 1) for i in range(n) if start + i * s <= dur]

def daftar_sfx(keluarga=None):
    """Daftar SFX untuk dipilih AI: {keluarga: [(nama, kapan dipakai), ...]}. keluarga=None berarti semua."""
    out = {}
    for k, (_, fam, ket) in KATALOG.items():
        if keluarga in (None, fam): out.setdefault(fam, []).append((k, ket))
    return out

# ---------------- variasi: bunyi yang sama tidak boleh terdengar sama ----------------
def vary(snd, rng, semis=1.5, gain_db=1.5):
    """Geser nada +-semis semiton (resampling) dan acak gain +-gain_db. Hasil: (bunyi, gain_db_acak)."""
    r = 2 ** (rng.uniform(-semis, semis) / 12); idx = np.arange(0, len(snd) - 1, r)
    return np.interp(idx, np.arange(len(snd)), snd).astype(np.float32), float(rng.uniform(-gain_db, gain_db))

def layer(parts):
    """Tumpuk beberapa bunyi jadi satu bunyi kaya. parts = [(bunyi, tunda_detik, gain_db), ...]."""
    n = max(int((dl + len(s) / SR) * SR) + 1 for s, dl, _ in parts); y = np.zeros(n, np.float32)
    for s, dl, g in parts:
        i = int(dl * SR); y[i:i + len(s)] += s * 10 ** (g / 20)
    return _norm(y)

def room(snd, wet=0.22):
    """Gema tipis (dua pantulan) agar tidak terdengar kering dan seperti bip komputer."""
    y = np.concatenate([snd, np.zeros(int(0.06 * SR), np.float32)]).copy()
    for dl, g in ((0.021, wet), (0.043, wet * 0.6)):
        i = int(dl * SR); y[i:i + len(snd)] += snd * g
    return _norm(y)

class Sfx:
    """Bank SFX besar (lihat KATALOG, 60+ bunyi). Satu keluarga kejadian (mis. "muncul") punya banyak jenis bunyi. Tiap panggilan memilih jenis yang
    BERBEDA dari dua panggilan terakhir di keluarga itu, lalu mengacak nada, gain, dan derau sedikit. Hasilnya tidak berpola.
    add(keluarga, t) = serahkan pilihan ke bank; add_nama(nama, t) = pilih bunyi tertentu dari KATALOG (mis. "glass", "kick", "snare")."""
    FAM = {}
    for _k, (_f, _fam, _ket) in KATALOG.items(): FAM.setdefault(_fam, []).append(_k)
    FAM = {k: tuple(v) for k, v in FAM.items()}
    KIND = {k: v[0] for k, v in KATALOG.items()}
    def __init__(self, track, seed=1):
        self.tr = track; self.rng = np.random.default_rng(seed); self.last = {}; self.log = []
    def _bunyi(self, kind):
        fn = self.KIND[kind]
        return fn(seed=int(self.rng.integers(1, 9999))) if "seed" in inspect.signature(fn).parameters else fn()
    def add_nama(self, kind, t, db=-14, rise=0.0, semis=1.5, jit=0.012, fam=None):
        snd, g = vary(self._bunyi(kind), self.rng, semis)
        if rise:
            r = 2 ** (rise / 12); snd = np.interp(np.arange(0, len(snd) - 1, r), np.arange(len(snd)), snd).astype(np.float32)
        tt = t + float(self.rng.uniform(-jit, jit)) if jit else t
        self.tr.add(snd, max(0.0, tt), db + g); self.log.append((round(tt, 3), fam or KATALOG[kind][1], kind, round(float(db + g), 2)))
        return kind
    def add(self, fam, t, db=-14, rise=0.0, semis=1.5, jit=0.012):
        """rise = geser nada tetap dalam semiton (mis. 2 * nomor ikon: rangkaian ikon terdengar naik tangga nada).
        jit = acak waktu +-detik (jangan dipakai untuk timer, yang harus tepat)."""
        hist = self.last.setdefault(fam, []); pool = list(self.FAM[fam])
        opts = [k for k in pool if k not in hist[-2:]] or [k for k in pool if k != (hist[-1] if hist else None)] or pool
        kind = opts[int(self.rng.integers(len(opts)))]; hist.append(kind)
        return self.add_nama(kind, t, db, rise, semis, jit, fam)
    def tick(self, t, i, db=-12):
        """Detik timer: tik dan tok bergantian (dua nada), tepat waktu, tiap 5 detik ada aksen. Tanpa acak waktu."""
        f = 1800 if i % 2 == 0 else 1450; self.tr.add(sfx_tick(f), t, db + (2 if i % 5 == 0 else 0)); self.log.append((t, "timer", f"tick{f}", db))
    def audit(self):
        """Laporan variasi: jumlah bunyi, jenis berbeda, dan runtun terpanjang jenis sama dalam satu keluarga."""
        kinds = [k for _, f, k, _ in self.log if f not in ("timer", "ritme")]; run = best = 1 if kinds else 0      # ketukan (keluarga ritme) sengaja berulang: itu iramanya
        for a, b in zip(kinds, kinds[1:]):
            run = run + 1 if a == b else 1; best = max(best, run)
        return dict(total=len(self.log), jenis_berbeda=len(set(kinds)), runtun_sama_terpanjang=best, ketukan=sum(1 for _, f, _, _ in self.log if f == "ritme"))

class Track:
    """Susun SFX di timeline lalu campur ke voice over TANPA mengubah voice over."""
    def __init__(self, dur): self.dur = dur; self.y = np.zeros(int(SR * dur), np.float32)
    def add(self, snd, t, db=-14):
        i = int(t * SR); g = 10 ** (db / 20)
        if 0 <= i < len(self.y):
            j = min(len(self.y), i + len(snd)); self.y[i:j] += snd[:j - i] * g
        return self
    def write(self, path, vo_path=None, duck_db=-12):
        n = len(self.y); vo = np.zeros(0, np.float32)
        if vo_path:
            raw = subprocess.run(["ffmpeg", "-v", "error", "-i", vo_path, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"],
                                 capture_output=True, check=True).stdout
            vo = np.frombuffer(raw, np.float32); n = max(n, len(vo))
        base = np.zeros(n, np.float32); base[:len(vo)] = vo
        sf = np.zeros(n, np.float32); sf[:len(self.y)] = self.y
        if len(vo) and duck_db:                       # RMS SFX tidak boleh melebihi RMS ucapan + duck_db (jendela 250 ms)
            w = int(0.25 * SR); ker = np.ones(w) / w
            ev = np.sqrt(np.convolve(base ** 2, ker, "same")); es = np.sqrt(np.convolve(sf ** 2, ker, "same")) + 1e-9
            lim = np.where(ev > 0.01, np.minimum(1.0, ev * 10 ** (duck_db / 20) / es), 1.0)
            k = int(0.1 * SR); sf *= np.convolve(lim, np.ones(k) / k, "same")     # perubahan gain halus 100 ms
        g = 1.0
        while g > 0.05 and np.max(np.abs(base + sf * g)) > 0.98: g *= 0.9   # hanya SFX yang diturunkan
        out = np.clip(base + sf * g, -1, 1)
        with wave.open(path, "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes((out * 32767).astype(np.int16).tobytes())
        return g

# ---------------- transisi antar adegan (a -> b, p = 0..1, easing cosinus) ----------------
@butuh("transisi")
def transition(kind, a, b, p, cx=540, cy=None, col=(107, 63, 38)):
    """kind: fade | slide | wipe | iris. a, b = gambar PIL ukuran sama."""
    W, H = a.size; e = e_io(clamp(p)); cy = H // 2 if cy is None else cy
    if kind == "fade": return Image.blend(a, b, e)
    if kind == "slide":
        off = int(W * e); out = Image.new("RGB", (W, H)); out.paste(a, (-off, 0)); out.paste(b, (W - off, 0)); return out
    if kind == "wipe":
        y0 = int(H * (1 - e)); out = a.copy()
        if y0 < H:
            out.paste(b.crop((0, y0, W, H)), (0, y0)); ImageDraw.Draw(out).rectangle([0, max(0, y0 - 10), W, y0 + 6], fill=col)
        return out
    R = e * math.hypot(W, H); m = Image.new("L", (W * 2, H * 2), 0)          # iris
    ImageDraw.Draw(m).ellipse([(cx - R) * 2, (cy - R) * 2, (cx + R) * 2, (cy + R) * 2], fill=255)
    out = a.copy(); out.paste(b, (0, 0), m.resize((W, H), Image.LANCZOS)); return out

# ---------------- efek karakter (c = canvas dengan poly/line/circ) ----------------
RED, ORANGE, WHITE = (229, 72, 77), (244, 144, 58), (255, 251, 243)

def shake(t, t0, dur=0.8, amp=12, hz=18):          # offset (dx, dy) untuk karakter atau kamera
    p = (t - t0) / dur
    if p < 0 or p > 1: return 0.0, 0.0
    a = amp * (1 - p); w = 2 * math.pi * (t - t0)
    return a * math.sin(w * hz), a * 0.6 * math.cos(w * hz * 1.3)

def fx_exclaim(c, x, y, h, t, t0, n=1, col=RED):    # tanda seru ! atau !! (tanpa font), pop + goyang
    s = popin(t, t0, 0.35)
    if s <= 0.01: return
    rot = 7 * math.sin(2 * math.pi * 6 * (t - t0)) * (1 - prog(t, t0, 1.0))
    for k in range(n):
        cx = x + (k - (n - 1) / 2) * h * 0.55
        for grow, cc in ((h * 0.05, WHITE), (0, col)):             # outline putih lalu isi
            w = h * 0.15 * s + grow; top = y - h * s - grow; neck = y - h * 0.30 * s
            ox = lambda yy: cx + (yy - y) * math.tan(math.radians(rot))
            c.poly([(ox(top) - w, top), (ox(top) + w, top), (ox(neck) + w * .55, neck), (ox(neck) - w * .55, neck)], cc)
            c.circ(ox(top), top, w, cc); c.circ(ox(neck), neck, w * .55, cc)
            c.circ(ox(y), y, w * .95, cc)

def fx_waves(c, x, y, t, t0, bg, n=3, r0=300, gap=48, span=32, col=ORANGE, w=10, sides=(-1, 1)):
    if t < t0: return                                # busur bergelombang memancar keluar (teriak / getar)
    for sx in sides:
        for k in range(n):
            f = ((t - t0) * 1.8 + k / n) % 1.0
            r = r0 + f * gap * n; cc = mixc(col, bg, f ** 1.5)
            pts = []
            for i in range(25):
                th = math.radians(-span + 2 * span * i / 24)
                rr = r + 9 * math.sin(math.degrees(th) * 0.55 + t * 16 + k * 2)
                pts.append((x + sx * rr * math.cos(th), y + rr * math.sin(th)))
            c.line(pts, w * (1 - 0.5 * f), cc)

def fx_sweat(c, x, y, t, t0, col=(143, 214, 190)):  # tetes keringat jatuh
    for k in range(2):
        f = ((t - t0) * 1.1 + k * 0.5) % 1.0
        if t < t0: return
        dx, dy = x + (k * 2 - 1) * 34 + f * 40 * (k * 2 - 1), y + f * 120
        c.poly([(dx, dy - 34), (dx - 15, dy - 6), (dx + 15, dy - 6)], col); c.circ(dx, dy, 15, col)

def flash(img, t, t0, dur=0.18, col=(255, 255, 255), peak=0.7):   # kilat layar saat kejadian
    p = prog(t, t0, dur)
    return img if p <= 0 or p >= 1 else Image.blend(img, Image.new("RGB", img.size, col), peak * (1 - p) ** 2)

# ---------------- gerak hidup dan karakter luwes (anti kaku) ----------------
from functools import lru_cache

def spring(t, t0, freq=3.0, damp=9.0):
    """0 -> 1 seperti pegas: melewati target, memantul, lalu tenang. Mulai dengan kecepatan nol. Lebih organik dari e_back."""
    if t < t0: return 0.0
    x = t - t0; w = 2 * math.pi * freq
    return 1 - math.exp(-damp * x) * (math.cos(w * x) + damp / w * math.sin(w * x))

def anticipate(p, pull=0.12, over=1.0):
    """Easing dengan antisipasi: tarik sedikit ke arah berlawanan, meluncur, lalu melewati target dan mendarat (p 0..1)."""
    if p <= 0: return 0.0
    if p >= 1: return 1.0
    if p < 0.25: return -pull * e_io(p / 0.25)
    q = (p - 0.25) / 0.75; return -pull + (1 + pull) * e_back(q, 1.70158 * over)

def jelly(t, t0, amp=0.25, hz=3.0, damp=7.0):
    """Getar meredam (bergoyang seperti jeli) setelah ada kejadian di t0: nilai +amp lalu bolak-balik mengecil."""
    if t < t0: return 0.0
    x = t - t0; return amp * math.exp(-damp * x) * math.cos(2 * math.pi * hz * x)

def squash(v, k=0.35):
    """Squash and stretch dengan volume tetap. v > 0 = memanjang (meluncur), v < 0 = memipih (mendarat). Hasil (sx, sy)."""
    sy = max(0.4, 1 + k * v); return 1 / sy, sy

def breathe(t, amp=0.02, hz=0.45, ph=0.0): return 1 + amp * math.sin(2 * math.pi * hz * t + ph)   # napas: skala badan
def sway(t, amp=2.5, hz=0.35, ph=0.0): return amp * math.sin(2 * math.pi * hz * t + ph)         # miring pelan (derajat)

@lru_cache(maxsize=32)
def _blinks(seed):
    rng = np.random.default_rng(seed); t = float(rng.uniform(0.8, 2.0)); out = []
    while t < 900:
        out.append(t)
        if rng.random() < 0.25: out.append(t + 0.24)                  # kadang kedip dua kali
        t += float(rng.uniform(2.2, 4.6))                             # jarak kedip tidak teratur
    return np.array(out)

def blink(t, seed=0):
    """Keterbukaan mata 0..1 (1 = terbuka, 0 = menutup). Kedip acak, bukan berkala, tiap karakter beda seed."""
    b = _blinks(seed); d = float(np.min(np.abs(b - t))); return clamp(d / 0.07) if d < 0.07 else 1.0

def look(t, seed=0, amp=9.0):
    """Arah pandang mata yang melayang pelan (dx, dy). Mata tidak pernah diam menatap lurus."""
    a = seed * 1.7
    return (amp * (math.sin(0.9 * t + a) * 0.6 + math.sin(2.3 * t + a * 2) * 0.4), amp * 0.5 * math.sin(1.3 * t + a * 3))

def idle(t, seed=0):
    """Gerak diam yang hidup untuk karakter yang sedang tidak beraksi: napas, miring, naik turun, kedip, pandangan."""
    sy = breathe(t, 0.022, 0.42, seed); return dict(sx=1 / sy, sy=sy, rot=sway(t, 2.2, 0.31, seed),
        dy=2.5 * math.sin(2 * math.pi * 0.42 * t + seed), eye=blink(t, seed), look=look(t, seed))

def lag(fn, t, delay=0.12):
    """Gerak susulan (overlapping action): bagian sekunder (ekor, rambut, telinga, tangan) meniru gerak utama dengan tertinggal."""
    return fn(t - delay)

def smooth(pts, n=10, closed=False):
    """Kurva Catmull-Rom lewat titik-titik: badan dan kepala bentuk melengkung, bukan persegi atau lingkaran kaku."""
    P = list(pts); out = []
    if closed: P = [P[-1]] + P + [P[0], P[1]]
    else: P = [P[0]] + P + [P[-1]]
    for i in range(1, len(P) - 2):
        p0, p1, p2, p3 = P[i - 1], P[i], P[i + 1], P[i + 2]
        for k in range(n):
            u = k / n; u2, u3 = u * u, u * u * u
            out.append(tuple(0.5 * (2 * p1[j] + (-p0[j] + p2[j]) * u + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * u2
                                    + (-p0[j] + 3 * p1[j] - 3 * p2[j] + p3[j]) * u3) for j in range(2)))
    return out if closed else out + [P[-2]]

def blob_pts(x, y, rx, ry, t=0.0, seed=0, amp=0.035, n=56, rot=0.0):
    """Bentuk organik: elips dengan tepi sedikit tidak rata dan bernapas (bukan lingkaran sempurna)."""
    out = []; a1, a2, a3 = seed * 1.3, seed * 2.1 + 1, seed * 0.7 + 2
    for i in range(n):
        th = 2 * math.pi * i / n
        m = 1 + amp * (math.sin(2 * th + a1 + t * 1.1) + .6 * math.sin(3 * th + a2 - t * 0.8) + .4 * math.sin(5 * th + a3 + t * 1.7))
        px, py = rx * m * math.cos(th), ry * m * math.sin(th); cr, sr = math.cos(rot), math.sin(rot)
        out.append((x + px * cr - py * sr, y + px * sr + py * cr))
    return out

def ik2(x0, y0, tx, ty, l1, l2, bend=1):
    """Lengan atau kaki dua ruas: dari pangkal (x0, y0) ke target; hasil (siku, ujung). Sendi menekuk wajar, bukan garis lurus kaku."""
    dx, dy = tx - x0, ty - y0; d = math.hypot(dx, dy) or 1e-6; d = clamp(d, abs(l1 - l2) + 1e-3, l1 + l2 - 1e-3)
    ux, uy = dx / (math.hypot(dx, dy) or 1e-6), dy / (math.hypot(dx, dy) or 1e-6)
    a = (l1 * l1 - l2 * l2 + d * d) / (2 * d); h = math.sqrt(max(0.0, l1 * l1 - a * a))
    return (x0 + ux * a - uy * h * bend, y0 + uy * a + ux * h * bend), (x0 + ux * d, y0 + uy * d)

def limb(c, pts, w0, w1, col, step=None):
    """Anggota badan meruncing (pangkal tebal, ujung tipis) mengikuti kurva lewat sendi. c = canvas dengan circ()."""
    path = smooth(pts, 8); L = [0.0]
    for a, b in zip(path, path[1:]): L.append(L[-1] + math.hypot(b[0] - a[0], b[1] - a[1]))
    tot = L[-1] or 1.0; step = step or max(2.0, min(w0, w1) / 4); k = 0
    for i in range(int(tot / step) + 1):
        d = i * step
        while k < len(L) - 2 and L[k + 1] < d: k += 1
        seg = (L[k + 1] - L[k]) or 1.0; f = clamp((d - L[k]) / seg); x = path[k][0] + (path[k + 1][0] - path[k][0]) * f
        y = path[k][1] + (path[k + 1][1] - path[k][1]) * f; c.circ(x, y, (w0 + (w1 - w0) * d / tot) / 2, col)

def cam_drift(t, seed=0, amp=7.0, zoom=0.012):
    """Kamera melayang sangat pelan: (dx, dy, zoom). Pakai untuk Cv(cam=(540 + dx, 960 + dy, zoom)) supaya adegan tidak beku."""
    return (amp * math.sin(0.23 * t + seed), amp * 0.7 * math.sin(0.31 * t + seed * 2), 1 + zoom * (0.5 + 0.5 * math.sin(0.17 * t + seed)))

def motion_report(frames, step, min_dead=0.8, thr=0.05):
    """Uji kaku: frames = gambar PIL yang diambil tiap `step` detik. Hitung selisih antar frame (skala 0-255).
    Hasil: (energi, jendela_mati) dengan jendela_mati = [(mulai_detik, selesai_detik)] saat nyaris tidak ada gerak >= min_dead detik."""
    g = [np.asarray(f.convert("L").resize((96, 170)), np.float32) for f in frames]
    e = [float(np.abs(b - a).mean()) for a, b in zip(g, g[1:])]; dead = []; s = None
    for i, v in enumerate(e + [9e9]):
        if v < thr and s is None: s = i
        if v >= thr and s is not None:
            if (i - s) * step >= min_dead: dead.append((round(s * step, 2), round(i * step, 2)))
            s = None
    return e, dead

# ---------------- timer / penjelasan (overlay di frame akhir) ----------------
FONT_B = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"
FONT_M = "/usr/share/fonts/truetype/google-fonts/Poppins-Medium.ttf"
POS = {"kiri-atas": (.07, .11, "l"), "tengah-atas": (.5, .11, "c"), "kanan-atas": (.93, .11, "r"),
       "kiri-tengah": (.07, .45, "l"), "tengah": (.5, .45, "c"), "kanan-tengah": (.93, .45, "r")}

def fmt_time(s):                                    # m:ss.mmm
    ms = int(max(0.0, s) * 1000 + 0.5)
    return f"{ms // 60000}:{(ms // 1000) % 60:02d}.{ms % 1000:03d}"

def timer_value(t, start, end=None, every=None, up=False):
    if every: return every - ((t - start) % every)  # "setiap N detik": reset ke N tiap kejadian
    return max(0.0, t - start) if up else max(0.0, end - t)

def timer_plan(t, plan):
    """plan = [(t0, t1, v0, v1, label, sub), ...]. Nilai timer bergerak linear v0 -> v1 selama t0..t1 (detik video).
    v0 > v1 = hitung mundur. Rasio (v0 - v1) / (t1 - t0) = kecepatan waktu; '{x}' di sub diganti kecepatannya.
    Hasil: (label, nilai, sub) atau None bila t di luar semua fase."""
    for t0, t1, v0, v1, label, sub in plan:
        if t0 <= t < t1:
            x = abs(v0 - v1) / (t1 - t0)
            return label, v0 + (v1 - v0) * (t - t0) / (t1 - t0), (sub or "").replace("{x}", f"{x:g}")
    return None

# ---------------- subtitle (wajib mengikuti voice over) ----------------
import re
FONT_SERIF_I = "/usr/share/fonts/truetype/google-fonts/Lora-Italic-Variable.ttf"

def _syl(w):                                          # taksiran suku kata Indonesia
    w = re.sub(r"[^a-z]", "", w.lower()); n = len(re.findall(r"[aiueo]", w)) - len(re.findall(r"(ai|au|oi)$", w))
    return max(1, n)

def word_times(words, t0, t1):                        # bagi waktu frasa ke tiap kata (sebanding suku kata)
    sy = [_syl(w) for w in words]; tot = sum(sy); out = []; a = t0
    for w, k in zip(words, sy):
        b = a + (t1 - t0) * k / tot; out.append((w, a, b)); a = b
    return out

def _jaga_tekan(ch, buka):
    """Penanda penekanan *...* yang melintasi dua cue ditutup di ujung cue pertama dan dibuka lagi di awal cue berikutnya. -> (kata_baru, masih_terbuka)."""
    out = []; on = buka
    for i, w in enumerate(ch):
        if on and i == 0 and not w.startswith("*"): w = "*" + w
        if w.startswith("*") and len(w.strip("*")) > 0: on = True
        if w.endswith("*") and len(w.strip("*")) > 0: on = False
        out.append(w)
    if on: out[-1] = out[-1].rstrip(",.;:") + "*"
    return out, on

def make_cues(segments, max_words=4):
    """segments = [(teks_script_yang_benar, mulai, selesai)] satu frasa per segmen ucapan (dari celah napas / transkripsi).
    Frasa panjang dipecah rata jadi cue <= max_words kata. Penanda penekanan *kata* (6.9) ikut terjaga. Hasil: [(teks, t0, t1, [(kata, a, b), ...])]."""
    cues = []
    for text, a, b in segments:
        wt = word_times(text.split(), a, b); n = math.ceil(len(wt) / max_words); per = math.ceil(len(wt) / n); buka = False
        for i in range(0, len(wt), per):
            ch = wt[i:i + per]; ch[-1] = (ch[-1][0].rstrip(",.;:"), ch[-1][1], ch[-1][2])      # tanpa koma/titik di ujung
            kata, buka = _jaga_tekan([w for w, _, _ in ch], buka); ch = [(kw, x[1], x[2]) for kw, x in zip(kata, ch)]
            cues.append((" ".join(kata), ch[0][1], ch[-1][2], ch))
    return cues

# ---------------- penekanan kata (WAJIB, bagian 6.9): kata kunci tidak boleh tampil sama seperti teks biasa ----------------
METODE_TEKAN = ("stabilo", "garis", "warna", "tebal")
PENTING = {"jangan", "tidak", "bukan", "hanya", "wajib", "bahaya", "awas", "dilarang", "selalu", "harus", "gratis", "terakhir", "pernah", "satu-satunya"}
def tandai_kata(kata):
    """['*Jangan*', 'merokok'] -> (['Jangan', 'merokok'], [True, False]). Penanda * boleh mencakup beberapa kata ('*sangat', 'berbahaya*'). Penanda yang tidak ditutup -> ValueError."""
    bersih, flag, on = [], [], False
    for w in kata:
        isi = w.strip("*")
        if w.startswith("*") and isi: on = True
        bersih.append(isi); flag.append(on)
        if w.endswith("*") and isi: on = False
    if on: raise ValueError("penanda penekanan * tidak ditutup: " + " ".join(kata))
    return bersih, flag

def gambar_tekan(d, x, y, kata, lebar, font, fg, aksen, ink, metode, k, al):
    """Gambar satu kata yang ditekan di (x, y) pada ImageDraw RGBA. stabilo = latar warna aksen + teks gelap; garis = garis bawah aksen; warna = teks aksen; tebal = huruf ditebalkan + garis bawah."""
    l, t, r, b = font.getbbox(kata)
    if metode == "stabilo":
        d.rounded_rectangle([x - 9 * k, y + t - 5 * k, x + lebar + 9 * k, y + b + 7 * k], 10 * k, fill=tuple(aksen) + (int(235 * al / 255),)); d.text((x, y), kata, font=font, fill=tuple(ink) + (al,))
    elif metode == "garis":
        d.text((x, y), kata, font=font, fill=tuple(fg) + (al,)); d.line([(x, y + b + 8 * k), (x + lebar, y + b + 8 * k)], fill=tuple(aksen) + (al,), width=max(2, int(6 * k)))
    elif metode == "warna":
        d.text((x, y), kata, font=font, fill=tuple(aksen) + (al,))
    elif metode == "tebal":
        d.text((x, y), kata, font=font, fill=tuple(fg) + (al,), stroke_width=max(1, int(2.5 * k)), stroke_fill=tuple(fg) + (al,)); d.line([(x, y + b + 8 * k), (x + lebar, y + b + 8 * k)], fill=tuple(aksen) + (al,), width=max(2, int(5 * k)))
    else: raise ValueError(f"metode penekanan '{metode}' tidak dikenal; pilih dari {METODE_TEKAN}")

def draw_kalimat_tekan(img, kalimat, cx, cy, px=64, fg=(255, 255, 255), aksen=(255, 196, 64), ink=(18, 18, 18), metode="stabilo", ganti=None, alasan="", lebar_maks=0.88, a=1.0):
    """Teks layar (bukan subtitle) dengan kata kunci bertanda *kata* yang diberi penekanan. Dibungkus per baris, rata tengah di (cx, cy). Font awal AnthropicSerifWebText."""
    W, H = img.size; k = W / 1080; font = teks_font(px * k, ganti, fg, None, alasan)
    kata, flag = tandai_kata(kalimat.split()); sp = font.getlength(" "); wl = [font.getlength(w) for w in kata]
    baris, cur, lebar = [], [], 0.0
    for i, w in enumerate(wl):
        if cur and lebar + sp + w > lebar_maks * W: baris.append(cur); cur, lebar = [], 0.0
        lebar += (sp if cur else 0) + w; cur.append(i)
    if cur: baris.append(cur)
    lh = px * k * 1.35; y = cy - lh * len(baris) / 2 + 0.1 * px * k; ov = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(ov); al = int(255 * a)
    for br in baris:
        tw = sum(wl[i] for i in br) + sp * (len(br) - 1); x = (W - tw) / 2
        for i in br:
            if flag[i]: gambar_tekan(d, x, y, kata[i], wl[i], font, fg, aksen, ink, metode, k, al)
            else: d.text((x, y), kata[i], font=font, fill=tuple(fg) + (al,))
            x += wl[i] + sp
        y += lh
    return Image.alpha_composite(img.convert("RGBA"), ov).convert("RGB")

def cek_tekan(kalimat, maks_kelompok=2, maks_kata=3):
    """Audit penekanan kata (6.9). kalimat = daftar teks cue atau teks layar yang memakai penanda *kata*. Lolos bila: (1) kalimat berisi angka atau kata penting (jangan, tidak, hanya, wajib, bahaya, ...)
    punya minimal satu kata bertanda; (2) paling banyak `maks_kelompok` kelompok bertanda per kalimat dan paling banyak `maks_kata` kata per kelompok (semua ditekan = tidak ada yang menonjol); (3) penanda tertutup."""
    tanpa, berlebih, rusak = [], [], []
    for kal in kalimat:
        kata = kal.split()
        try: bersih, flag = tandai_kata(kata)
        except ValueError: rusak.append(kal); continue
        kel = []; run = 0
        for f in flag + [False]:
            if f: run += 1
            elif run: kel.append(run); run = 0
        if len(kel) > maks_kelompok or any(n > maks_kata for n in kel) or (len(kata) >= 3 and sum(flag) > 0.6 * len(kata)): berlebih.append(kal)
        perlu = any(any(ch.isdigit() for ch in w) or w.lower().strip(".,!?;:\"'") in PENTING for w in bersih)
        if len(kata) >= 2 and perlu and not kel: tanpa.append(kal)
    return dict(lolos=not (tanpa or berlebih or rusak), tanpa_tekan=tanpa, berlebih=berlebih, rusak=rusak)

@butuh("subtitle")
def draw_subtitle(img, cues, t, style="pill", fg=(255, 241, 220), bg=(66, 38, 22), accent=(244, 144, 58), pos=0.90, size=52, font=None, font_alasan="", tekan="stabilo", ink=(18, 18, 18)):
    """Penekanan kata (6.9): kata bertanda *kata* di teks cue ditekan dengan metode `tekan` (stabilo | garis | warna | tebal). Font awal AnthropicSerifWebText (wajib sebagai awal). font=<pengganti> HANYA bila tidak cocok dengan video/warna (wajib font_alasan; masuk LAPORAN; tidak pernah ganti diam-diam). style: pill (kartu warna palet) | serif (sinematik, gradien gelap) | pop (kata muncul satu-satu, tebal + outline). Di SEMUA gaya kata yang sedang diucapkan berwarna aksen dan kata lainnya putih (fg): "Kopi hangat" -> saat "Kopi" diucapkan hanya Kopi berwarna, saat "hangat" diucapkan hanya hangat berwarna."""
    W, H = img.size; k = W / 1080
    if style == "serif":                                       # gradien gelap tipis agar teks selalu terbaca
        y0 = int(H * pos - 300 * k); h = H - y0; m = (np.linspace(0, 1, h) ** 1.3 * 215).astype(np.uint8)
        sc = Image.new("RGBA", (W, h), (0, 0, 0, 0)); sc.putalpha(Image.fromarray(np.tile(m[:, None], (1, W))))
        img = img.convert("RGBA"); img.alpha_composite(sc, (0, y0)); img = img.convert("RGB")
    cue = next((c for c in cues if c[1] - 0.04 <= t <= c[2] + 0.22), None)
    if not cue: return img
    text, t0, t1, wt = cue
    a = min(prog(t, t0 - 0.04, 0.14), 1 - prog(t, t1 + 0.06, 0.16))          # fade masuk/keluar
    if a <= 0: return img
    px = int(size * k * {"serif": 1.05, "pop": 0.92}.get(style, 1))
    words, tanda = tandai_kata([w for w, _, _ in wt]); words = [w.upper() if style == "pop" else w for w in words]
    ganti = font                                               # pengganti font dari pemanggil (None = font awal); jangan ditimpa di dalam loop
    for _ in range(2):                                         # kecilkan otomatis bila terlalu lebar untuk layar
        font = teks_font(px, ganti, fg, bg if style == "pill" else (20, 20, 20), font_alasan); sp = font.getlength(" ") + (16 * k if style == "pop" else 0)
        wl = [font.getlength(w) for w in words]; tw = sum(wl) + sp * (len(words) - 1)
        if tw <= 0.88 * W: break
        px = int(px * 0.88 * W / tw)
    x0 = (W - tw) / 2; y = H * pos + (1 - e_out(prog(t, t0 - 0.04, 0.2))) * 14 * k
    ov = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(ov); al = int(255 * a)
    if style == "pill":
        px, py = 34 * k, 18 * k
        d.rounded_rectangle([x0 - px, y - py, x0 + tw + px, y + size * k * 1.25 + py], 30 * k, fill=bg + (int(225 * a),))
    x = x0
    for (w, ws, we), ww, wd, tk_ in zip(wt, words, wl, tanda):
        if style == "pop" and t < ws - 0.03: x += wd + sp; continue          # kata muncul saat diucapkan
        if tk_ and t >= ws - 0.03: gambar_tekan(d, x, y, ww, wd, font, fg, accent, ink, tekan, k, al); x += wd + sp; continue      # kata kunci: ditekan sejak diucapkan, bertahan sampai cue habis
        on = ws <= t < we                                      # kata yang SEDANG diucapkan berwarna aksen, kata lain putih (fg); berlaku di pill, serif, dan pop
        col = accent if on else fg
        if style == "pop":
            d.text((x, y), ww, font=font, fill=col + (al,), stroke_width=int(6 * k), stroke_fill=bg + (al,))
        else:
            if style == "serif": d.text((x + 2 * k, y + 2 * k), ww, font=font, fill=(0, 0, 0, int(150 * a)))
            d.text((x, y), ww, font=font, fill=col + (al,))
        x += wd + sp
    return Image.alpha_composite(img.convert("RGBA"), ov).convert("RGB")

# ---------------- sinkronisasi voice over otomatis (Cara 1, 2, 3; tanpa meminta apa pun dari user) ----------------
def load_audio(path):                                 # float32 mono pada SR
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).copy()

def probe_dur(path):                                  # durasi file media (detik) lewat ffprobe
    o = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path], capture_output=True, text=True, check=True).stdout
    return float(o.strip())

def speech_segments(y, thr_db=-34, min_gap=0.22, min_len=0.12, hop=0.02):
    """Cari bagian ucapan dari celah napas: RMS 20 ms, ambang adaptif (di atas lantai derau), celah < min_gap dianggap satu frasa. -> [(a, b)] detik."""
    h = int(hop * SR); n = len(y) // h
    if n < 2: return []
    db = 20 * np.log10(np.sqrt((y[:n * h].reshape(n, h) ** 2).mean(1)) + 1e-9)
    on = db > max(thr_db, float(np.percentile(db, 10)) + 10); runs = []; i = 0
    while i < n:
        if on[i]:
            j = i
            while j < n and on[j]: j += 1
            runs.append([i, j]); i = j
        else: i += 1
    merged = []
    for a, b in runs:
        if merged and (a - merged[-1][1]) * hop < min_gap: merged[-1][1] = b
        else: merged.append([a, b])
    return [(a * hop, b * hop) for a, b in merged if (b - a) * hop >= min_len]

def align_sentences(sentences, segs):
    """Petakan kalimat script ke waktu ucapan ASLI, berapa pun jumlah segmen suara. Dasar: porsi suku kata kalimat dipetakan ke timeline ucapan
    (celah dibuang), batas kalimat menempel ke celah napas terdekat bila dekat. Hasil [(teks, mulai, selesai)] siap untuk make_cues()."""
    if not segs: raise ValueError("tidak ada ucapan terdeteksi")
    if len(segs) == len(sentences): return [(s, a, b) for s, (a, b) in zip(sentences, segs)]
    sy = [max(1, sum(_syl(w) for w in s.split())) for s in sentences]; tot = sum(sy)
    lens = [b - a for a, b in segs]; sp = sum(lens); cum = np.concatenate([[0.0], np.cumsum(lens)])
    bd = [sum(sy[:i]) / tot * sp for i in range(len(sy) + 1)]
    for i in range(1, len(sy)):
        k = 1 + int(np.argmin(np.abs(cum[1:-1] - bd[i]))) if len(segs) > 1 else None
        if k is not None and abs(cum[k] - bd[i]) <= 0.5 * min(sy[i - 1], sy[i]) / tot * sp and cum[k] > bd[i - 1] + 0.05: bd[i] = float(cum[k])
    def real(s, end):
        i = int(np.searchsorted(cum, s, "left" if end else "right")) - 1; i = max(0, min(i, len(segs) - 1)); return segs[i][0] + (s - cum[i])
    return [(s, real(bd[i], False), real(bd[i + 1], True)) for i, s in enumerate(sentences)]

def fit_voice(src, dst, target, max_tempo=0.08, gap=(0.2, 0.9), head=0.25, tail=0.45, pad=0.04):
    """Pas-kan voice over ke durasi target TANPA mengubah nada: (1) celah antar frasa diskalakan dalam batas gap, (2) bila belum cukup, tempo diubah
    maksimal +-8% (ffmpeg atempo, nada tetap), (3) sisanya DILAPORKAN, bukan dipaksakan (lalu video yang menyesuaikan, lihat video_len_for).
    -> dict(hasil, sisa, tempo, skala_celah, segs_baru). segs_baru = waktu ucapan pada file hasil (pakai langsung untuk subtitle/adegan)."""
    y = load_audio(src); segs = speech_segments(y)
    if not segs: raise ValueError("tidak ada ucapan terdeteksi")
    segs = [(max(0, a - pad), min(len(y) / SR, b + pad)) for a, b in segs]
    for i in range(len(segs) - 1):                       # padding tidak boleh bertabrakan
        if segs[i][1] > segs[i + 1][0]: m = (segs[i][1] + segs[i + 1][0]) / 2; segs[i] = (segs[i][0], m); segs[i + 1] = (m, segs[i + 1][1])
    parts = [y[int(a * SR):int(b * SR)] for a, b in segs]; sp = sum(len(p) for p in parts) / SR
    g0 = [segs[i + 1][0] - segs[i][1] for i in range(len(segs) - 1)]
    k = 1.0
    if g0 and sum(g0) > 0: k = (target - head - tail - sp) / sum(g0)
    g1 = [min(gap[1], max(gap[0], g * k)) for g in g0]; cur = head + sp + sum(g1) + tail
    tempo = min(1 + max_tempo, max(1 - max_tempo, cur / target)) if abs(cur - target) > 0.05 else 1.0
    out = [np.zeros(int(head * SR), np.float32)]; t = head; nsegs = []
    for i, p in enumerate(parts):
        out.append(p); nsegs.append((t, t + len(p) / SR)); t += len(p) / SR
        if i < len(g1): out.append(np.zeros(int(g1[i] * SR), np.float32)); t += g1[i]
    out.append(np.zeros(int(tail * SR), np.float32)); z = np.concatenate(out)
    tmp = dst + ".tmp.wav"
    with wave.open(tmp, "wb") as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(z, -1, 1) * 32767).astype(np.int16).tobytes())
    if abs(tempo - 1) > 1e-3: subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", tmp, "-filter:a", f"atempo={tempo:.5f}", dst], check=True)
    else: subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", tmp, "-c", "copy", dst], check=True)
    import os; os.remove(tmp); res = probe_dur(dst)
    return dict(hasil=round(res, 3), sisa=round(res - target, 3), tempo=round(tempo, 4), skala_celah=round(k, 3), segs_baru=[(a / tempo, b / tempo) for a, b in nsegs])

def video_len_for(src, head=0.25, tail=0.45):
    """Bila durasi video BOLEH mengikuti suara (user tidak mengunci durasi): panjang video = suara + head + tail. Adegan dipotong di tengah celah napas."""
    y = load_audio(src); s = speech_segments(y)
    return round(head + (s[-1][1] - s[0][0]) + tail, 3) if s else round(len(y) / SR, 3)

def scene_cuts(aligned, groups, total):
    """aligned = hasil align_sentences; groups = jumlah kalimat per adegan, mis. [2, 1, 3]. Potongan jatuh di TENGAH celah antar kalimat.
    -> list durasi adegan (jumlah = total). Karena bergantung pada waktu ucapan nyata, pergantian adegan selalu pas dengan suara."""
    cuts = [0.0]; i = 0
    for g in groups[:-1]:
        i += g; cuts.append((aligned[i - 1][2] + aligned[i][1]) / 2)
    cuts.append(total); return [round(b - a, 3) for a, b in zip(cuts, cuts[1:])]

def mouth_env(y, fps, nframes):
    """Amplop suara per frame (0..1) untuk mulut karakter. Serangan cepat, pelepasan lambat, dinormalkan ke ucapan keras (persentil 90)."""
    h = SR / fps; v = np.array([float(np.sqrt(np.mean(y[int(i * h):int((i + 1) * h)] ** 2))) if int(i * h) < len(y) else 0.0 for i in range(nframes)])
    ref = float(np.percentile(v[v > 0.01], 90)) if (v > 0.01).any() else 1.0; v = np.clip(v / ref, 0, 1); o = np.zeros_like(v); c = 0.0
    for i, x in enumerate(v): c = x if x > c else c + (x - c) * 0.35; o[i] = c
    return np.where(o < 0.08, 0.0, o)

def speaker_at(lines, t):
    """lines = [(pembicara, teks, mulai, selesai)] -> nama yang sedang bicara pada t (None bila hening). Karakter lain TIDAK boleh membuka mulut."""
    return next((s for s, _, a, b in lines if a - 0.02 <= t <= b + 0.05), None)

def assign_speakers(script_lines, segs):
    """script_lines = [(pembicara, teks)] dengan urutan sama seperti suara -> [(pembicara, teks, mulai, selesai)] dari waktu ucapan asli."""
    al = align_sentences([t for _, t in script_lines], segs); return [(sp, t, a, b) for (sp, _), (t, a, b) in zip(script_lines, al)]

def sync_audit(cues, segs, fps=30):
    """Cek subtitle terhadap suara asli: porsi tiap cue yang benar-benar ada ucapan (target >= 0.7) dan selisih awal cue dengan awal ucapan terdekat."""
    bad = []; off = []
    for text, a, b, _ in cues:
        ov = sum(max(0.0, min(b, e) - max(a, s)) for s, e in segs) / max(1e-6, b - a)
        if ov < 0.7: bad.append((text, round(ov, 2)))
    for s, _ in segs:
        near = min(abs(c[1] - s) for c in cues) if cues else 9; off.append(near)
    return dict(cue_tanpa_suara=bad, geser_awal_maks=round(max(off), 3) if off else 0.0, lolos=not bad and (not off or max(off) <= max(0.25, 2 / fps) + 0.2))

def mouth_check(env, mouth):
    """env = mouth_env(...); mouth = nilai bukaan mulut yang benar-benar digambar tiap frame. Korelasi tinggi + tidak ada mulut diam saat bicara."""
    e = np.asarray(env, float); m = np.asarray(mouth, float)
    cor = float(np.corrcoef(e, m)[0, 1]) if e.std() > 0 and m.std() > 0 else 0.0
    return dict(korelasi=round(cor, 3), diam_saat_suara=round(float(np.mean((e > 0.5) & (m < 0.15))), 3), buka_saat_hening=round(float(np.mean((e == 0) & (m > 0.3))), 3))

# ---------------- watermark pintar (tidak menghalangi, tidak mengganggu fokus) ----------------
UI_ZONES = {   # perkiraan konservatif area yang biasa tertutup antarmuka aplikasi (fraksi layar x0, y0, x1, y1); bukan angka resmi platform
    "vertikal": [(0, 0, 1, 0.12), (0.84, 0.45, 1, 0.88), (0, 0.78, 1, 1)],
    "landscape": [(0, 0.90, 1, 1)], "kotak": []}

@butuh("watermark")
def text_mark(text, height=44, tone="terang"):
    """Watermark teks -> gambar RGBA. tone: terang (putih, untuk latar gelap) | gelap (tinta, untuk latar terang)."""
    f = ImageFont.truetype(FONT_M, height); w = int(f.getlength(text)) + 8; im = Image.new("RGBA", (w, int(height * 1.4)), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    col, sh = ((255, 255, 255), (0, 0, 0)) if tone == "terang" else ((30, 30, 36), (255, 255, 255))
    d.text((6, 4), text, font=f, fill=sh + (90,)); d.text((4, 2), text, font=f, fill=col + (255,)); return im

@butuh("watermark")
def place_watermark(frames, size, ui="vertikal", reserved=(), margin=0.04, grid=3):
    """Pilih satu posisi TETAP untuk watermark. frames = cuplikan frame video TANPA watermark (PIL/numpy, tiap 0,5 dtk); size = (lebar, tinggi) watermark px
    pada resolusi video; reserved = kotak terlarang (px: x0, y0, x1, y1) mis. subtitle, timer, wajah karakter. Penilaian per kandidat (makin kecil makin baik):
    gerak (persentil 95 antar cuplikan) x3 + keramaian tepi (persentil 90) x2 + dekat tengah x0,4 + penalti 1,5 untuk tengah sisi (sudut diutamakan). Zona UI dan kotak terlarang = dilarang.
    -> dict(x, y, nama, tone, opacity, skor, peringkat). opacity turun ke 0,35 bila tempat terbaik pun masih ramai."""
    fr = [np.asarray(Image.fromarray(f) if isinstance(f, np.ndarray) else f).astype(np.float32) for f in frames]; H, W = fr[0].shape[:2]
    sc = 0.25; sm = [np.asarray(Image.fromarray(f.astype(np.uint8)).convert("L").resize((int(W * sc), int(H * sc)))).astype(np.float32) / 255 for f in fr]
    mw, mh = size; m = margin * W
    zones = [(a * W, b * H, c * W, d * H) for a, b, c, d in UI_ZONES.get(ui, [])] + [tuple(r) for r in reserved]
    sx0, sy0, sx1, sy1 = m, m, W - m, H - m
    if ui == "vertikal": sx0, sy0, sx1, sy1 = 0.05 * W, 0.12 * H, 0.84 * W, 0.78 * H
    if ui == "landscape": sy1 = 0.90 * H
    xs = np.linspace(sx0, sx1 - mw, grid); ys = np.linspace(sy0, sy1 - mh, grid); cand = []
    for yi, y0 in enumerate(ys):
        for xi, x0 in enumerate(xs):
            if not (xi in (0, grid - 1) or yi in (0, grid - 1)): continue          # hanya tepi: tidak di tengah gambar
            r = (x0, y0, x0 + mw, y0 + mh)
            if any(min(r[2], z[2]) > max(r[0], z[0]) and min(r[3], z[3]) > max(r[1], z[1]) for z in zones): continue
            pd = 0.015 * W; a, b, c, d = [max(0, int(v * sc)) for v in (r[0] - pd, r[1] - pd, r[2] + pd, r[3] + pd)]; reg = [s[b:d, a:c] for s in sm]    # nilai juga area di sekitar (jarak aman)
            mot = float(np.percentile([np.abs(p - q).mean() for p, q in zip(reg, reg[1:])] or [0], 95))
            busy = float(np.percentile([np.hypot(*np.gradient(g)).mean() for g in reg], 90))
            cen = 1 - min(1.0, math.hypot((r[0] + mw / 2 - W / 2) / W, (r[1] + mh / 2 - H / 2) / H) / 0.7)
            lum = float(np.mean([g.mean() for g in reg])); sk = 3 * mot * 10 + 2 * busy * 10 + 0.4 * cen + (1.5 if (xi == 1) != (yi == 1) else 0)     # tengah sisi: penalti (sudut lebih tidak mengganggu)
            cand.append(dict(x=int(x0), y=int(y0), nama=("atas" if yi == 0 else "bawah" if yi == grid - 1 else "tengah") + "-" + ("kiri" if xi == 0 else "kanan" if xi == grid - 1 else "tengah"),
                             tone="gelap" if lum > 0.55 else "terang", skor=round(sk, 3), gerak=round(mot, 4), ramai=round(busy, 4)))
    if not cand: return dict(x=int(sx0), y=int(sy0), nama="atas-kiri (semua tempat terlarang)", tone="terang", opacity=0.35, skor=9.9, peringkat=[])
    cand.sort(key=lambda c: c["skor"]); best = dict(cand[0]); best["opacity"] = 0.55 if best["skor"] < 1.0 else 0.35; best["peringkat"] = [(c["nama"], c["skor"]) for c in cand]
    return best

@butuh("watermark")
def draw_watermark(img, mark, pos, t, opacity=0.55, fade=0.5, t0=0.3):
    """Gambar watermark statis: muncul pelan (fade 0,5 dtk), setelah itu DIAM (tidak berkedip, tidak bergerak, tidak berdenyut)."""
    a = opacity * prog(t, t0, fade)
    if a <= 0: return img
    m = mark.copy(); m.putalpha(m.getchannel("A").point(lambda v: int(v * a))); out = img.convert("RGBA"); out.alpha_composite(m, (int(pos[0]), int(pos[1]))); return out.convert("RGB")

# ---------------- timer teks murni (hanya bila diminta) + chat bubble non-full text (hanya bila diminta) ----------------
FONT_CLAUDE = "/usr/share/fonts/truetype/google-fonts/Lora-Variable.ttf"      # font bawaan untuk chat bubble. Anthropic Font untuk elemen selain timer HANYA bila diminta (anthropic=True)
def _fc(px, wght=600):
    f = ImageFont.truetype(FONT_CLAUDE, int(px))
    try: f.set_variation_by_axes([wght])
    except Exception: pass
    return f

def _asset_dirs(nama):
    """Folder aset (fonts): folder project (cwd), di samping fxlib.py, root skill (satu tingkat di atas scripts/), dan SKILL_DIR bila diset."""
    import os
    here = os.path.dirname(os.path.abspath(__file__)); ds = [os.path.join(os.getcwd(), nama), os.path.join(here, nama), os.path.join(os.path.dirname(here), nama)]
    if os.environ.get("SKILL_DIR"): ds.append(os.path.join(os.environ["SKILL_DIR"], nama))
    return [d for d in dict.fromkeys(os.path.realpath(x) for x in ds) if os.path.isdir(d)]

class FontAnthropicTidakAda(RuntimeError): pass

LAPORAN = []       # catatan yang WAJIB disebut di laporan akhir (penggantian font, dll.)
FONT_DEFAULT = "AnthropicSerifWebText"

def _norm_nama(s): return re.sub(r"[^a-z0-9]", "", s.lower())

def font_tersedia():
    """Daftar font yang BENAR-BENAR ada: berkas di folder fonts/ dan font sistem (fc-list). Pilih pengganti hanya dari sini; jangan mengarang nama berkas."""
    import glob
    out = []
    for d in _asset_dirs("fonts"): out += sorted(glob.glob(os.path.join(d, "*.[to]tf")))
    try: out += sorted({ln.split(":")[0].strip() for ln in subprocess.run(["fc-list"], capture_output=True, text=True).stdout.splitlines() if ln.strip()})
    except Exception: pass
    return list(dict.fromkeys(out))

def anthropic_font(px, gaya="serif", wght=None):
    """Font awal untuk SUBTITLE dan TIMER: AnthropicSerifWebText (gaya='serif'). gaya='sans' hanya bila berkas Anthropic Sans memang ada dan user memintanya.
    Font ini berpemilik, tidak bisa diunduh; berkasnya harus ada: env ANTHROPIC_SERIF / ANTHROPIC_SANS, atau berkas di folder fonts/ (prioritas nama 'AnthropicSerifWebText', lalu nama lain yang memuat 'serif' / 'sans'), atau font sistem 'Anthropic ...' (fc-list).
    Tidak ada -> FontAnthropicTidakAda. JANGAN diam-diam memakai font lain: beri tahu user, atau minta penggantian eksplisit lewat teks_font(..., ganti=...)."""
    import glob
    gaya = gaya.lower(); assert gaya in ("serif", "sans"), "gaya: serif atau sans"
    cands = [os.environ.get("ANTHROPIC_" + gaya.upper(), "")]
    for d in _asset_dirs("fonts"):
        fs = sorted(glob.glob(os.path.join(d, "*.[to]tf")))
        if gaya == "serif": cands += [x for x in fs if "anthropicserifwebtext" in _norm_nama(os.path.basename(x))]
        cands += [x for x in fs if gaya in os.path.basename(x).lower() and not (gaya == "sans" and "serif" in os.path.basename(x).lower())]
    try:
        o = subprocess.run(["fc-list"], capture_output=True, text=True).stdout
        cands += [ln.split(":")[0] for ln in o.splitlines() if "anthropic" in ln.lower() and gaya in ln.lower() and not (gaya == "sans" and "serif" in ln.lower())]
    except Exception: pass
    for fl in cands:
        if fl and os.path.isfile(fl):
            ft = ImageFont.truetype(fl, int(px))
            if wght:
                try: ft.set_variation_by_axes([wght])
                except Exception: pass
            return ft
    raise FontAnthropicTidakAda(f"{FONT_DEFAULT if gaya == 'serif' else 'Anthropic Sans'} tidak ditemukan (berpemilik, tidak bisa diunduh). Taruh berkasnya di folder fonts/ atau set ANTHROPIC_{gaya.upper()}. Beri tahu user; jangan diam-diam memakai font lain.")

def kontras(fg, bg):
    """Rasio kontras WCAG 1..21 antara dua warna RGB."""
    def lum(c):
        r = [(v / 255) / 12.92 if v / 255 <= 0.03928 else (((v / 255) + 0.055) / 1.055) ** 2.4 for v in c[:3]]; return 0.2126 * r[0] + 0.7152 * r[1] + 0.0722 * r[2]
    a, b = sorted((lum(fg), lum(bg)), reverse=True); return (a + 0.05) / (b + 0.05)

def _batang(font):
    """Lebar goresan vertikal huruf 'l' di tengah tinggi (tanpa serif) terhadap ukuran font. Diukur dengan merender huruf pada ukuran 240 px."""
    ft = ImageFont.truetype(font.path, 240); im = Image.new("L", (400, 400), 0); ImageDraw.Draw(im).text((100, 40), "l", font=ft, fill=255)
    a = np.asarray(im) > 128; ys = np.where(a.any(1))[0]; y = int(ys.min() + 0.5 * (ys.max() - ys.min())); xs = np.where(a[y])[0]; return float(len(xs)) / 240.0

def font_cocok(font, fg, bg, min_kontras=4.5):
    """Apakah font ini cocok untuk teks fg di atas latar bg? Cek: kontras warna >= 4,5, dan goresan huruf tidak terlalu tipis atau tebal (lebar batang 'l' terhadap ukuran font 4-20 persen).
    -> dict(cocok, alasan[list], kontras, batang). Bila tidak cocok, font BOLEH dan DISARANKAN diganti (teks_font ganti=...)."""
    k = kontras(fg, bg); st = _batang(font); alasan = []
    if k < min_kontras: alasan.append(f"kontras {k:.1f} < {min_kontras} (warna teks dan latar terlalu dekat)")
    if st < 0.04: alasan.append(f"goresan terlalu tipis ({st:.3f} dari ukuran)")
    if st > 0.20: alasan.append(f"goresan terlalu tebal ({st:.3f} dari ukuran)")
    return dict(cocok=not alasan, alasan=alasan, kontras=round(k, 2), batang=round(st, 3))

def teks_font(px, ganti=None, fg=None, bg=None, alasan=""):
    """Font untuk subtitle dan timer. Awal = AnthropicSerifWebText. ganti=None memakai font awal (dan bila fg/bg diberikan serta tidak cocok, mencatat SARAN penggantian di LAPORAN).
    ganti='path atau nama font' memakai pengganti: harus berupa berkas yang ada (lihat font_tersedia()) atau font sistem terpasang; alasan penggantian wajib diisi dan masuk LAPORAN agar user diberi tahu. Tidak pernah mengganti diam-diam."""
    if ganti:
        if not alasan.strip(): raise ValueError("penggantian font wajib disertai alasan (mis. 'kontras kurang di latar kuning')")
        path = ganti if os.path.isfile(ganti) else None
        if path is None:
            for cand in font_tersedia():
                if _norm_nama(ganti) in _norm_nama(os.path.basename(cand)) and os.path.isfile(cand): path = cand; break
        if path is None: raise FileNotFoundError(f"font pengganti '{ganti}' tidak ada di fonts/ maupun sistem. Jangan mengarang nama berkas; pilih dari font_tersedia().")
        LAPORAN.append(f"font diganti: {os.path.basename(path)} (bukan {FONT_DEFAULT}). Alasan: {alasan}"); return ImageFont.truetype(path, int(px))
    ft = anthropic_font(px, "serif")
    if fg is not None and bg is not None:
        r = font_cocok(ft, fg, bg)
        if not r["cocok"]:
            msg = f"SARAN: {FONT_DEFAULT} kurang cocok di sini ({'; '.join(r['alasan'])}); pertimbangkan font pengganti dari font_tersedia() lewat ganti="
            if msg not in LAPORAN: LAPORAN.append(msg)
    return ft

def speed_label(speed):
    """1x -> '' (kosong, waktu nyata); >1 -> 'Dipercepat 10x'; <1 -> 'Diperlambat 11x'."""
    if abs(speed - 1) < 0.02: return ""
    return f"Dipercepat {speed:g}x" if speed > 1 else f"Diperlambat {1 / speed:.0f}x" if abs(1 / speed - round(1 / speed)) < 0.05 else f"Diperlambat {1 / speed:.1f}x"

UKURAN_TIMER = dict(timer=120, penjelasan=56, kecepatan=34, dampak=28)       # px pada lebar 1080
def cek_hierarki(u):
    """Timer >= Penjelasan >= Kecepatan > Dampak. Angka timer paling besar; penjelasan boleh sama dengan timer tetapi tidak boleh lebih kecil dari kecepatan; dampak harus lebih kecil dari kecepatan."""
    if not (u["timer"] >= u["penjelasan"] >= u["kecepatan"] > u["dampak"]): raise ValueError(f"hierarki ukuran teks timer salah: {u}. Wajib timer >= penjelasan >= kecepatan > dampak")
    return u

_SAMBUNG = ("sehingga", "karena", "akibatnya", "yang membuat", "lalu", "hingga", "sampai", "sebab", "maka", "membuat", "menyebabkan", "akhirnya", "jadi", "yang berarti", "dan")
def cek_dampak(teks):
    """Dampak = KALIMAT AKIBAT yang menyambung dari kejadian, bukan label dan bukan frasa menggantung. -> dict(ok, galat[list], saran).
    Salah: 'dampak: menjadi panas', 'Bumi meledak.' (hanya kata kerja tunggal), 'panas'. Benar: 'merasakan panas karena El Nino', 'Bumi meledak sehingga peradaban manusia punah'."""
    t = (teks or "").strip(); g = []
    if not t: return dict(ok=True, galat=[], saran="")
    if _re.match(r"(?i)^\s*dampak\s*[:\-\u2013\u2014]", t) or _re.search(r"(?i)\bdampak\s*:", t): g.append("memakai label 'dampak:'; tulis kalimat akibatnya saja")
    if t.endswith((":", "-", "\u2013", ",")): g.append("berakhir menggantung (tanda ':' '-' ',')")
    n = len(_re.findall(r"\w+", t))
    if n < 4: g.append(f"hanya {n} kata: frasa menggantung, bukan kalimat akibat utuh")
    elif not any(_re.search(r"\b" + s + r"\b", t.lower()) for s in _SAMBUNG): g.append("tidak ada kata sambung akibat (sehingga, karena, akibatnya, yang membuat, lalu ...); jadikan kejadian + akibat lanjutan")
    return dict(ok=not g, galat=g, saran="Contoh: 'Bumi meledak sehingga peradaban manusia punah'" if g else "")

def _bungkus(teks, font, maxw):
    out = []; cur = ""
    for w in teks.split():
        if font.getlength((cur + " " + w).strip()) <= maxw: cur = (cur + " " + w).strip()
        else:
            if cur: out.append(cur)
            cur = w
    if cur: out.append(cur)
    return out or [""]

@butuh("timer")
def draw_timer_teks(img, pos, atas, value, speed=1.0, dampak="", scale=1.0, col=None, hot=(217, 119, 87), hot_below=3.0, font=None, font_alasan="", ukuran=None):
    """TEKS MURNI (tanpa latar, blok, kotak, panel). Font awal AnthropicSerifWebText untuk SEMUA baris (angka, penjelasan, kecepatan, dampak); font=<pengganti> hanya bila tidak cocok dengan video/warna (wajib font_alasan; masuk LAPORAN).
    Susunan atas ke bawah: penjelasan | timer m:ss.mmm | kecepatan ('Dipercepat 10x' / 'Diperlambat 11x'; kosong bila 1x) | dampak (kalimat akibat; di bawah kecepatan, atau jadi baris bawah bila kecepatan kosong).
    Ukuran: timer >= penjelasan >= kecepatan > dampak (cek_hierarki). Dampak ditolak bila berupa label atau frasa menggantung (cek_dampak). Teks panjang dibungkus, tidak dikecilkan di bawah tingkatnya. col=None: warna dari kecerahan latar."""
    u = cek_hierarki(dict(UKURAN_TIMER, **(ukuran or {}))); cd = cek_dampak(dampak)
    if not cd["ok"]: raise ValueError("dampak salah: " + "; ".join(cd["galat"]) + ". " + cd["saran"])
    W, H = img.size; k = W / 1080 * scale; fx, fy, al = POS[pos]; ref = (38, 35, 32) if np.asarray(img.convert("L"), np.float32).mean() > 140 else (250, 247, 240)
    fa, ft, fs, fd = (teks_font(u[n] * k, font, ref, tuple(int(v) for v in np.asarray(img.convert("RGB").resize((1, 1)))[0, 0]), font_alasan) for n in ("penjelasan", "timer", "kecepatan", "dampak"))
    ts = fmt_time(value); cell = max(ft.getlength(c) for c in "0123456789"); wt = sum(cell if c.isdigit() else ft.getlength(c) for c in ts)
    sp = speed_label(speed); maxw = 0.9 * W if al == "c" else 0.86 * W - (W * fx if al == "l" else W - W * fx) * 0 
    ra = _bungkus(atas, fa, maxw); rs = [sp] if sp else []; rd = _bungkus(dampak, fd, maxw) if dampak else []
    bw = max([max(fa.getlength(l) for l in ra), wt] + [fs.getlength(r) for r in rs] + [fd.getlength(r) for r in rd]); x0 = W * fx if al == "l" else W * fx - bw / 2 if al == "c" else W * fx - bw; y0 = H * fy
    hh = len(ra) * 1.25 * u["penjelasan"] * k + 1.15 * u["timer"] * k + len(rs) * 1.35 * u["kecepatan"] * k + len(rd) * 1.3 * u["dampak"] * k
    if col is None:
        reg = np.asarray(img.convert("L").crop((int(max(0, x0)), int(y0), int(min(W, x0 + bw)), int(min(H, y0 + hh)))), np.float32); col = (38, 35, 32) if reg.mean() > 140 else (250, 247, 240)
    d = ImageDraw.Draw(img); cc = col if value > hot_below else mixc(col, hot, 0.5 + 0.5 * abs(math.sin(value * 6)) if value > 0 else 1.0)
    def row(s, f, y, fill, fixed=False):
        w = wt if fixed else f.getlength(s); x = x0 + (bw - w) / 2 if al == "c" else (x0 if al == "l" else x0 + bw - w)
        for ch in s:
            if fixed and ch.isdigit(): d.text((x + (cell - f.getlength(ch)) / 2, y), ch, font=f, fill=fill); x += cell
            else: d.text((x, y), ch, font=f, fill=fill); x += f.getlength(ch)
    y = y0
    for l in ra: row(l, fa, y, col); y += 1.25 * u["penjelasan"] * k
    row(ts, ft, y, cc, True); y += 1.15 * u["timer"] * k
    for r in rs: row(r, fs, y, col); y += 1.35 * u["kecepatan"] * k
    for r in rd: row(r, fd, y, col); y += 1.3 * u["dampak"] * k
    return img

def timer_speed(t, plan):
    """Kecepatan waktu fase aktif pada t (nilai timer per detik video); 1.0 di luar fase."""
    for t0, t1, v0, v1, *_ in plan:
        if t0 <= t < t1: return abs(v0 - v1) / (t1 - t0)
    return 1.0

def find_words(aligned, words=("mengulang", "diulang", "berulang", "ulang", "ulangi")):
    """Cari waktu (mulai, selesai) kata pemicu di narasi bertanda waktu nyata (hasil align_sentences). Mis. 'mengulang' -> ikon loading di chat bubble."""
    out = []
    for text, a, b in aligned:
        for w, ws, we in word_times(text.split(), a, b):
            if re.sub(r"[^a-z]", "", w.lower()) in words: out.append((round(ws, 3), round(we, 3), w))
    return out

def place_box(size, anchor, W, H, reserved=(), ui="vertikal"):
    """Posisi kotak (bubble) dekat pembicara (anchor = x, y kepala) yang tidak menutupi kotak terlarang (teks utama, timer, wajah) dan zona UI aplikasi.
    Coba: atas-kanan, atas-kiri, samping kanan, samping kiri, atas-tengah. -> (x, y) atau None."""
    bw, bh = size; ax, ay = anchor; zs = [(a * W, b * H, c * W, d * H) for a, b, c, d in UI_ZONES.get(ui, [])] + [tuple(r) for r in reserved]
    for dx, dy in ((20, -bh - 40), (-bw - 20, -bh - 40), (240, -bh / 2), (-bw - 240, -bh / 2), (-bw / 2, -bh - 60)):
        x, y = ax + dx, ay + dy
        if x < 0.04 * W or y < 0.02 * H or x + bw > 0.96 * W or y + bh > 0.98 * H: continue
        if any(min(x + bw, z[2]) > max(x, z[0]) and min(y + bh, z[3]) > max(y, z[1]) for z in zs): continue
        return (int(x), int(y))
    return None

def _font_bubble(px):
    """Anthropic Sans bila ada; bila tidak ada, AnthropicSerifWebText dan dicatat di LAPORAN (bukan font asing)."""
    try: return anthropic_font(px, "sans")
    except FontAnthropicTidakAda:
        msg = "chat bubble: Anthropic Sans tidak ada, memakai AnthropicSerifWebText"
        if msg not in LAPORAN: LAPORAN.append(msg)
        return anthropic_font(px, "serif")

@butuh("chat_bubble")
def draw_chat_bubble(img, text, xy, t, t0, t1, loading=None, side="kiri", scale=1.0, fill=(250, 249, 245), ink=(38, 35, 32), accent=(217, 119, 87), anthropic=False):
    """Chat bubble yang MENYESUAIKAN ISI (bukan layar penuh): hanya frasa kunci, maksimal 9 kata, lebar maksimal ~60% layar. pop-in, lalu keluar halus.
    loading = (mulai, selesai) bila narator menyebut 'mengulang': tiga titik/ikon putar muncul DI DALAM bubble pada rentang itu. xy = pojok kiri-atas bubble (lihat place_box)."""
    if len(text.split()) > 9: raise ValueError("chat bubble hanya frasa kunci (<= 9 kata), bukan seluruh teks")
    a = min(popin(t, t0, 0.35), 1.0) * (1 - prog(t, t1 - 0.2, 0.2))
    if t < t0 or t > t1 or a <= 0.01: return img
    W, H = img.size; k = W / 1080 * scale; f = _font_bubble(44 * k) if anthropic else _fc(44 * k, 500); maxw = 0.6 * W - 56 * k; words = text.split(); lines = []; cur = ""
    for w in words:
        if f.getlength((cur + " " + w).strip()) <= maxw: cur = (cur + " " + w).strip()
        else: lines.append(cur); cur = w
    lines.append(cur); show_load = loading and loading[0] <= t <= loading[1]
    tw = max(f.getlength(l) for l in lines); lh = 56 * k; bw = tw + 56 * k + (70 * k if show_load else 0); bh = lh * len(lines) + 40 * k
    x, y = xy; s = 0.6 + 0.4 * a; cx, cy = x + bw / 2, y + bh; ov = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(ov); al = int(255 * min(1, a * 1.3))
    ox = lambda px, py: (cx + (px - cx) * s, cy + (py - cy) * s)                    # skala dari ekor bubble
    d.rounded_rectangle([*ox(x, y), *ox(x + bw, y + bh)], 30 * k * s, fill=fill + (al,))
    tx = x + bw * (0.12 if side == "kiri" else 0.88)
    d.polygon([ox(tx - 18 * k, y + bh - 2), ox(tx + 18 * k, y + bh - 2), ox(tx + (-10 if side == "kiri" else 10) * k, y + bh + 30 * k)], fill=fill + (al,))
    for i, l in enumerate(lines): d.text(ox(x + 28 * k, y + 20 * k + i * lh), l, font=f, fill=ink + (al,)) if s > 0.98 else None
    if show_load:                                                                      # ikon loading: 8 titik berputar, ekor memudar
        lx, ly = x + bw - 52 * k, y + bh / 2; ph = (t - loading[0]) * 8
        for i in range(8):
            an = 2 * math.pi * i / 8; fa = ((i - ph) % 8) / 8; r = (5 + 3 * (1 - fa)) * k
            d.ellipse([lx + 22 * k * math.cos(an) - r, ly + 22 * k * math.sin(an) - r, lx + 22 * k * math.cos(an) + r, ly + 22 * k * math.sin(an) + r], fill=accent + (int(al * (0.25 + 0.75 * (1 - fa))),))
    return Image.alpha_composite(img.convert("RGBA"), ov).convert("RGB")

# ---------------- pencahayaan dan bayangan (hanya bila diminta) ----------------
class Light:
    """Satu sumber cahaya untuk SELURUH adegan (arah, intensitas, gradasi tidak boleh berubah antar objek). angle = arah ASAL cahaya dalam derajat
    (0 = dari kanan, 90 = dari bawah, 180 = dari kiri, 270 = dari atas; layar: y ke bawah). ambient = terang minimum area yang tidak kena cahaya (0..1)."""
    def __init__(self, angle=225, intensity=1.0, ambient=0.5, color=(255, 244, 226), spot=None):
        self.a = math.radians(angle); self.i = intensity; self.amb = ambient; self.col = color; self.spot = spot      # spot = (x, y, radius) untuk lampu titik
    def to_light(self): return (math.cos(self.a), math.sin(self.a))                                                # vektor menuju sumber cahaya
    def factor(self, nx, ny, nz=0.0):
        """Faktor terang untuk permukaan bernormal (nx, ny, nz): 1.0 bila menghadap cahaya, turun halus ke ambient bila membelakangi. Area terkena cahaya TIDAK pernah digelapkan."""
        lx, ly = self.to_light(); d = max(0.0, nx * lx + ny * ly + 0.35 * nz)
        return self.amb + (1 - self.amb) * min(1.0, d * self.i) ** 0.9

def light_col(col, L, nx, ny, nz=0.0):
    """Warna permukaan yang sudah kena cahaya: sisi terang = warna asli (sedikit hangat), sisi gelap = digelapkan dan sedikit biru (bayangan tidak hitam pekat)."""
    f = L.factor(nx, ny, nz); return tuple(int(min(255, col[i] * f + (14 if i == 2 else 0) * (1 - f))) for i in range(3))

@butuh("lighting")
def lit_ball(c, x, y, r, col, L, steps=4):
    """Bola (planet, buah, kepala): dasar gelap lalu lingkaran makin kecil dan makin terang bergeser KE ARAH cahaya; puncak terang = warna asli."""
    lx, ly = L.to_light(); c.circ(x, y, r, light_col(col, L, -lx, -ly))
    for i in range(1, steps + 1):
        ri = r * (1 - 0.2 * i / steps); off = (r - ri) * 0.9; f = i / steps
        c.circ(x + lx * off, y + ly * off, ri, light_col(col, L, lx * f, ly * f) if f < 1 else col)
    return c

@butuh("lighting")
def cast_shadow(c, pts, L, ground_y, ground_col, length=1.0, depth=0.35):
    """Bayangan jatuh bentuk `pts` (titik-titik objek) ke tanah y = ground_y, ARAH berlawanan dengan sumber cahaya; panjang sebanding tinggi dan sudut cahaya.
    Warna = warna tanah digelapkan (bukan hitam), jadi tidak bertentangan dengan latar."""
    lx, ly = L.to_light(); out = []
    for px, py in pts:
        h = max(0.0, ground_y - py)                                   # tinggi titik di atas tanah
        out.append((px - lx * h * length * 0.9, ground_y + (-ly) * h * 0.12 * length if ly < 0 else ground_y))
    shade = tuple(int(g * (1 - depth)) for g in ground_col); c.poly(out, shade); return out

@butuh("lighting")
def light_pass(img, L, strength=0.4, spot_soft=0.6):
    """Lapisan cahaya untuk seluruh frame (latar, objek, karakter sekaligus). Searah: sisi menghadap cahaya tetap terang (faktor 1,0), sisi jauh makin gelap sampai (1 - strength).
    Lampu titik (L.spot = x, y, radius): terang penuh di dalam radius, gelap halus di luar. Gradasi satu arah, tidak ada area terang yang dikorbankan."""
    a = np.asarray(img.convert("RGB")).astype(np.float32); H, W = a.shape[:2]; yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    if L.spot:
        sx, sy, r = L.spot; d = np.hypot(xx - sx, yy - sy) / r; g = np.clip((d - 1) / spot_soft, 0, 1)
    else:
        lx, ly = L.to_light(); pr = (xx - W / 2) * lx + (yy - H / 2) * ly; mx = abs(W / 2 * lx) + abs(H / 2 * ly) + 1e-6; g = np.clip((0.5 - pr / (2 * mx) - 0.25) / 0.75, 0, 1) ** 1.2     # 0 di seperempat sisi cahaya (tetap terang penuh), naik halus ke 1 di sisi jauh
    f = 1 - strength * g
    tint = np.array([1.0, 1.0, 1.0], np.float32) * f[..., None] + np.array([0, 0, 0.05], np.float32) * (1 - f)[..., None]
    return Image.fromarray(np.clip(a * tint, 0, 255).astype(np.uint8))

def light_check(orig, lit, L, min_dark=0.08, max_lit_loss=0.03):
    """Audit pencahayaan: (1) sisi terang tidak lebih gelap dari aslinya (maks 3 persen), (2) sisi jauh jelas lebih gelap (min 8 persen),
    (3) gradasi searah: luminans makin turun menjauhi sumber cahaya (korelasi negatif). orig dan lit = gambar PIL ukuran sama."""
    o = np.asarray(orig.convert("L"), np.float32) + 1; l = np.asarray(lit.convert("L"), np.float32) + 1; H, W = o.shape
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    if L.spot: dist = np.hypot(xx - L.spot[0], yy - L.spot[1])
    else: lx, ly = L.to_light(); dist = -((xx - W / 2) * lx + (yy - H / 2) * ly)
    q1, q3 = np.percentile(dist, 20), np.percentile(dist, 80); near = dist <= (min(q1, L.spot[2]) if L.spot else q1); far = dist >= q3; r = l / o
    dd, rr_ = dist.ravel()[::37], r.ravel()[::37]; cor = float(np.corrcoef(dd, rr_)[0, 1]) if rr_.std() > 1e-9 else 0.0
    res = dict(rugi_sisi_terang=round(float(1 - r[near].mean()), 3), gelap_sisi_jauh=round(float(1 - r[far].mean()), 3), korelasi=round(cor, 3))
    res["lolos"] = res["rugi_sisi_terang"] <= max_lit_loss and res["gelap_sisi_jauh"] >= min_dark and cor < -0.3
    return res

@butuh("lighting")
def lit_rect(c, x0, y0, x1, y1, col, L, r=6):
    """Kotak/dinding/gedung: permukaan utama terang, strip sisi yang membelakangi cahaya lebih gelap (lebar ~22 persen), tepi yang menghadap cahaya diberi garis terang tipis."""
    lx, ly = L.to_light(); c.rr(x0, y0, x1, y1, r, col); w = (x1 - x0) * 0.22; h = (y1 - y0) * 0.16; dk = light_col(col, L, -abs(lx) if lx else 0, -abs(ly) if ly else 0)
    if lx < -0.2: c.rr(x1 - w, y0, x1, y1, r, dk)                  # cahaya dari kiri -> sisi kanan gelap
    elif lx > 0.2: c.rr(x0, y0, x0 + w, y1, r, dk)
    if ly > 0.2: c.rr(x0, y0, x1, y0 + h, r, dk)                   # cahaya dari bawah -> sisi atas gelap
    elif ly < -0.2: c.rr(x0, y1 - h, x1, y1, r, dk)                # cahaya dari atas -> sisi bawah gelap
    return c
