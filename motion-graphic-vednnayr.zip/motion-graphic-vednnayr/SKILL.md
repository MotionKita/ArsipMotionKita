---
name: motion-graphic-vednnayr
description: Bikin video motion graphic/flat animation: script, video, voice over sinkron otomatis; fakta diverifikasi, SFX bervariasi, karakter hidup; timer, subtitle, watermark, chat bubble, pencahayaan bila diminta.
---

# Motion Graphic (vednnayr)

Skill ini mengatur pembuatan video motion graphic dari permintaan user: 3 cara kerja, 3 kartu pilihan, narasi voice over yang bersih, 7 fitur wajib (SFX bervariasi, ekspresi/efek karakter, karakter berpakaian, animasi hidup, verifikasi fakta, sinkronisasi voice over otomatis, penekanan kata), tiga kartu voice over berbahasa Inggris, 13 gaya visual, dan 10 fitur bila diminta (timer, subtitle, transisi, hook improvement, 20 video effects, watermark pintar, timer teks murni, chat bubble, pencahayaan, voice over langsung/naskah bertag). Baca semuanya sebelum mulai. Daftar fitur akhir ada di bagian 0. Kode teruji ada di folder `scripts/` (bagian 13).

## 0. Daftar fitur akhir (ringkasan seluruh skill)

**Fitur WAJIB (7):** lima selalu aktif, dua aktif otomatis bila ada isinya.

1. **SFX bervariasi**, bagian 6.1: bunyi tidak berulang-ulang berpola (jenis, nada, gain, dan irama diacak terkendali).
2. **Ekspresi dan efek karakter**, bagian 6.2 (20 ekspresi di `ekspresi.py`, ikon efek di atas kepala).
3. **Karakter berpakaian dan bertenaga**, bagian 6.3: outfit berlapis dengan detail, tidak kaku dan tidak letoy.
4. **Animasi hidup**, bagian 6.4: antisipasi, overshoot, squash-stretch, gerak susulan, gerak diam yang hidup.
5. **Verifikasi fakta dan informasi**, bagian 6.5 (aktif otomatis bila ada hal nyata: bumi, negara, pulau, warna benda, merek, angka): cari lewat pencarian web dulu, baru gambar, dan tampilkan sumber bila ada ketidaksesuaian.
6. **Sinkronisasi voice over otomatis**, bagian 6.6 (aktif otomatis bila ada voice over, di Cara 1, 2, dan 3): durasi, kalimat, subtitle, dan mulut karakter dipas-kan sendiri tanpa meminta apa pun dari user.
7. **Penekanan kata**, bagian 6.9 (selalu aktif): kata atau frasa kunci tidak boleh tampil sama seperti teks biasa; diberi stabilo, garis bawah, warna, atau huruf tebal.

**Fitur HANYA bila diminta (10):**

1. **Timer + penjelasan kejadian**, bagian 7.1 (kata kunci "timer", "bagaimana jika ...").
2. **Subtitle** yang mengikuti voice over, bagian 7.2 (kata kunci "subtitle").
3. **Transisi bergaya** dengan preview dan Kartu 3, bagian 7.3 (kata kunci "transisi").
4. **Hook Improvement**, bagian 7.4 (kata kunci "hook" dengan maksud memperbaiki hook yang ada).
5. **20 Video Effects** berdasarkan video referensi, bagian 7.5 (kata kunci "video effect" atau nama efeknya).
6. **Watermark pintar**, bagian 7.6 (kata kunci "watermark"): ditaruh di tempat yang tidak menghalangi dan tidak mengganggu fokus penonton.
7. **Timer teks murni**, bagian 7.7 (kata kunci "timer"): teks saja, tanpa kotak; font awal AnthropicSerifWebText (juga untuk subtitle); dampak berupa kalimat akibat; hierarki ukuran timer >= penjelasan >= kecepatan > dampak.
8. **Chat bubble non-full text**, bagian 7.8 (kata kunci "chat bubble"): bubble hanya frasa kunci, ikon loading saat narator bilang "mengulang".
9. **Pencahayaan dan bayangan**, bagian 7.9 (kata kunci "pencahayaan", "bayangan", "lighting", atau suasana visual tertentu): sisi terkena cahaya tetap terang, sisi lain lebih gelap, satu arah cahaya untuk semuanya.
10. **Voice Over langsung dan naskah bertag**, bagian 7.10 (kata kunci "voice over langsung", "tag voice over", "saran suara", "elevenlabs", "google ai studio"): suara natural (bukan robot) atau jujur bila tidak bisa; tag ElevenLabs `[]` dan Google AI Studio `<>` dengan saran suara yang benar-benar ada.

**Alur dan pengaman (selalu berlaku):** tiga kartu voice over berbahasa Inggris yang wajib ditanyakan di awal (0.3), pustaka 13 gaya visual dengan kata kuncinya (0.6), cek komposisi agar objek menapak dan landmark utuh (6.10), gerbang audit wajib di satu tempat (bagian 6.7), penamaan file tanpa v2/v3 (aturan umum 12), fitur bila-diminta ditegakkan di kode (aturan umum 13), satu skill utuh (SKILL.md + folder `scripts/`), tiga cara kerja (bagian 1), tiga kartu pilihan (bagian 4), narasi voice over yang bersih (bagian 5), pengecekan sebelum kirim termasuk audit variasi SFX dan audit gerak (aturan umum nomor 2), jujur soal suara (aturan umum nomor 10), dan laporan akhir singkat (bagian 11).

## 0.1 Status fitur (baca dulu)

**WAJIB ada di setiap video:**

- **SFX (sound effect) bervariasi**, bagian 6.1.
- **Ekspresi dan efek karakter**, bagian 6.2. Bila video tidak punya karakter, terapkan efek setara pada objek utama (goyang, kilau, tanda seru).
- **Karakter berpakaian dan bertenaga**, bagian 6.3. Bila video tidak punya karakter, objek utama tetap diberi detail berlapis, bukan bentuk polos.
- **Animasi hidup**, bagian 6.4. Berlaku untuk semua adegan.
- **Verifikasi fakta dan informasi**, bagian 6.5. Aktif otomatis bila permintaan memuat hal yang punya acuan di dunia nyata, atau user meminta verifikasi, peta, atau pulau.
- **Sinkronisasi voice over otomatis**, bagian 6.6. Aktif otomatis bila ada voice over (Cara 1, 2, 3).
- **Penekanan kata**, bagian 6.9. Selalu aktif untuk teks layar dan subtitle (subtitle sendiri tetap hanya bila diminta).

**HANYA bila user benar-benar meminta:**

- **Timer + penjelasan kejadian**, bagian 7.1. Contoh pemicu: "bagaimana jika ...", "setiap N detik ..." (lihat 7.1). AI juga boleh memakainya sendiri di video yang jelas cocok.
- **Subtitle**, bagian 7.2. Contoh pemicu: "pakai subtitle", "dengan subtitle" (lihat 7.2). Wajib mengikuti voice over.
- **Transisi bergaya**, bagian 7.3. Hanya bila diminta, dan harus lolos preview dulu (Kartu 3). Tanpa permintaan, tidak ada transisi bergaya.
- **Hook Improvement**, bagian 7.4. Hanya bila user memintanya. Jangan mengubah hook secara otomatis.
- **Video Effects (20 efek)**, bagian 7.5. Hanya bila user memintanya dengan menyebut nama efek dari daftar. Acuan utamanya video referensi; tanpa referensi, jangan mengarang.
- **Watermark pintar**, bagian 7.6. Hanya bila user meminta watermark.
- **Timer teks murni**, bagian 7.7. Hanya bila user meminta timer dengan format ini (teks saja, tanpa kotak). Jangan dipakai otomatis.
- **Chat bubble non-full text**, bagian 7.8. Hanya bila user memintanya. Jangan dipakai otomatis.
- **Pencahayaan dan bayangan**, bagian 7.9. Hanya bila user meminta efek pencahayaan, bayangan, atau suasana visual tertentu. Jangan diterapkan otomatis.

**Soal kata kunci:** pemicu utama sebuah fitur adalah NAMA FITURNYA sendiri.

- Kata "subtitle" mengaktifkan Subtitle (7.2). Kata "timer" mengaktifkan Timer (7.1). Kata "transisi" mengaktifkan Transisi (7.3). Kata "hook" mengaktifkan Hook Improvement (7.4). Kata "video effect" atau "video effects" mengaktifkan Video Effects (7.5). Kata "watermark" mengaktifkan Watermark (7.6). "Timer teks" atau "timer tanpa background/kotak" mengaktifkan Timer teks murni (7.7). "Chat bubble" mengaktifkan 7.8. "Pencahayaan", "bayangan", atau "lighting" mengaktifkan 7.9.
- Kata di sekitarnya bebas. "Pakai subtitle", "dengan subtitle", dan "tolong gunakan subtitle" semuanya cukup karena memuat kata "subtitle". Tidak perlu kalimat tertentu.
- Selain nama fitur, tetap kenali variasi lain yang jelas bermaksud sama (mis. "bagaimana jika ..." untuk Timer, "tampilkan teks ucapannya di bawah" untuk Subtitle). Contoh-contoh di dokumen ini bukan daftar tertutup, dan jangan menambah kata kunci baru sebagai syarat.
- Dua catatan kecil. Kata "hook" hanya berarti Hook Improvement bila maksudnya memperbaiki hook yang sudah ada; menyebut hook saat meminta script baru belum berarti minta perbaikan. Kata "video effect" tanpa nama efek: tanyakan dulu efek mana dari 20 daftar (tampilkan daftarnya).

**Ditegakkan di kode:** `fxlib.IZIN` menolak pemanggilan fitur opsional (timer, subtitle, transisi, watermark, chat bubble, pencahayaan, video effects, voice over) sebelum diminta; lihat aturan umum 13.

## 0.2 Dua gaya video (tentukan GAYA dulu, baru pilih Cara 1, 2, atau 3)

Gaya dan Cara adalah dua hal berbeda. **Cara** (1, 2, 3) menentukan alur kerja dan fallback. **Gaya** menentukan seperti apa videonya. Urutannya: pilih gaya, lalu tentukan cara. Di atas dua gaya utama ini ada pustaka 13 gaya visual (0.6) yang menentukan tampilan. Dua gaya itu bernama **Animasi Cerita Berkarakter** dan **Reel Tipografi Bergerak**; sebutan ini dipakai konsisten di seluruh skill.

**Animasi Cerita Berkarakter.**

- Satu kalimat: animasi flat bercerita, yaitu karakter dan adegan ilustrasi yang diceritakan voice over dengan subtitle.
- Contoh: video cerita atau edukasi berkarakter, seperti video Interstellar dan Dajjal-Yajuj-Majuj.
- Irama mengikuti kalimat narasi. SFX keluarga `muncul`, `sukses`, `kaget`, `benturan`.

**Reel Tipografi Bergerak.**

- Satu kalimat: motion design reel, tanpa karakter, tipografi dan bentuk abstrak bergerak mengikuti ketukan, dengan teks penjelas di layar sebagai narator.
- Contoh: video seperti Example_Vid_1 dan Example_Vid_2 (tipografi besar, latar berganti warna, bingkai kecil di sudut, pemotongan di ketukan).
- Irama mengikuti ketukan (BPM, `beat_grid`). SFX keluarga `ritme`, `digital`, `sapuan`, `tegang`, ditambah bunyi aksen.

**Kata kunci Reel Tipografi Bergerak**: "showreel" atau "reel", "kinetic typography", "typography animation", "motion design", "teks bergerak", "tanpa karakter", "mengikuti beat". Referensi video user yang tanpa karakter dan berisi tipografi besar juga termasuk. **Kata kunci Animasi Cerita Berkarakter**: "flat animation", "animasi flat", "motion graphic bercerita", "ceritakan", "karakter", "edukasi dengan voice over".

**Aturan memilih (anti-salah gaya):**

1. Sinyal satu gaya jelas dan tidak bertentangan: pakai gaya itu.
2. **Tidak jelas: jangan mengasumsikan salah satu gaya. Tanya dulu** dengan satu kartu (AskUserQuestion): "Mohon maaf, permintaanmu belum bisa saya pahami dengan jelas. Apakah maksudnya Animasi Cerita Berkarakter (karakter ilustrasi yang diceritakan voice over dan subtitle) atau Reel Tipografi Bergerak (tanpa karakter, teks dan bentuk bergerak mengikuti ketukan)?" Tombolnya dua nama itu. Setelah gaya dipilih dengan jelas, baru tentukan cara. Sesi tanpa pengawasan: berhenti di kartu ini.
3. **Reel Tipografi Bergerak tidak memanggil fungsi karakter, dan hanya itu:** 6.2 ekspresi, 6.3 pakaian, dan audit luwes, proporsi, wajah. Ini TIDAK berarti SFX ditiadakan, TIDAK berarti animasi hidup ditiadakan, dan TIDAK berarti verifikasi fakta ditiadakan.
4. **SFX WAJIB di kedua gaya** (6.1). Jangan pernah menghapus, menonaktifkan, atau mengabaikan SFX di gaya mana pun. Animasi hidup (6.4) dan verifikasi fakta (6.5) juga berlaku di kedua gaya.
5. Reel Tipografi Bergerak meniru warna, ritme, dan tata letak referensi, bukan nama merek atau logo di dalamnya (aturan umum 8).
6. **Bentuk 3D chrome dan partikel 3D WAJIB dicoba dulu.** Jangan langsung menyatakan tidak bisa. Batas kemampuan hanya boleh dinyatakan setelah upaya nyata dan hasilnya benar-benar belum memenuhi standar referensi, dan pernyataannya wajib menyebut apa yang sudah dicoba, apa hasilnya, dan di bagian mana yang masih belum sesuai. Setelah itu tawarkan padanan terdekat.
7. Aturan Reel Tipografi Bergerak ini sengaja ringkas: ia diturunkan dari dua video contoh, jadi dipegang sebagai ciri yang teramati, bukan doktrin. Bila user memberi referensi lain yang berbeda, ikuti referensi itu.

**Tiga cara untuk Reel Tipografi Bergerak** (setara dengan tiga cara di bagian 1; script tetap ada, yaitu teks yang tampil di layar):

- **Cara 1: teks layar, video, suara bila diminta.** User memberi topik atau brief; Claude menulis teks layar per ketukan (kalimat singkat, label, angka), membuat video dari teks itu dengan ritme dan SFX, dan suara hanya bila diminta (alur di 0.3). Hasil mp4.
- **Cara 2: audio dan teks dari user.** User membawa musik atau voice over beserta teksnya; pemotongan dan gerak dipasang mengikuti ketukan dan onset audio itu (BPM dideteksi dari audionya). Bukan fallback.
- **Cara 3: JS murni + perintah render.** Fallback Cara 1 (setelah minimal dua pendekatan render berbeda gagal), atau bila user meminta JS murni atau render di Termux.

## 0.3 Alur pertanyaan voice over (WAJIB, Cara 1 dan Cara 3, di kedua gaya)

Saat user memulai pembuatan video, Claude WAJIB menanyakan pilihan berikut lebih dulu, berurutan, dengan kartu (AskUserQuestion, satu pertanyaan per kartu). Kalimat kartu berbahasa Inggris yang profesional dan natural, persis seperti di bawah; jangan menulis "VO" atau "No VO" mentah. Urutan seluruhnya: kartu gaya bila tidak jelas (0.2), tentukan cara, kartu voice over ini, baru membangun apa pun. Teks balasan di chat tetap berbahasa Indonesia.

1. **Langkah 1.** Pertanyaan: "Do you want to include a voice over?" Tombol: **"Yes, add Voice Over"** dan **"No, without Voice Over"**. Bila "No": lanjut tanpa suara (SFX tetap ada).
2. **Langkah 2 (bila Yes).** Pertanyaan: "How would you like to create the voice over?" Tombol: **"Instant Voice Over"** dan **"Manual Voice Over"**. Pada deskripsi tombol "Instant Voice Over" tulis bahwa fitur ini masih berstatus sementara dan belum berfungsi sepenuhnya, dan hasil video saat ini masih tanpa suara. Bila "Instant" dipilih: katakan itu terus terang di kalimat pertama laporan (status 0.5), kerjakan video tanpa suara dengan SFX, tawarkan "Manual Voice Over" sebagai gantinya, dan jangan memakai suara robot.
3. **Langkah 3 (bila Manual Voice Over).** Pertanyaan: "Which platform will you use for the manual voice over?" Tombol: **"Google AI Studio"** dan **"ElevenLabs"**. Naskah bertag mengikuti 7.10: ElevenLabs memakai tag kurung siku `[]`, Google AI Studio memakai tag kurung sudut `<>` plus `speech_metadata.style`. Jangan tertukar.
4. **Wajib dijalankan.** Claude tidak boleh langsung membuat video tanpa menanyakan ini. Kesalahan nyata: pada video "Keindahan Indonesia" (2026-11-07) kartu ini tidak ditanyakan sama sekali. Satu-satunya pengecualian: user sudah menjawab tegas di pesannya (mis. "tanpa voice over" atau "Manual Voice Over dengan ElevenLabs"); langkah yang sudah terjawab dilewati dan jawaban itu disebut di kalimat pertama laporan.
5. Berlaku untuk Cara 1 dan Cara 3. **Cara 2 tidak ditanya**, karena user langsung mengirim voice over-nya.
6. Jawaban kartu diteruskan ke `F.izin_dari_teks(jawaban)`: "Instant Voice Over" mengaktifkan `voice_over_langsung`, "Manual Voice Over" mengaktifkan `voice_over_naskah`. Sesi tanpa pengawasan: berhenti di kartu.

## 0.4 Target kualitas voice over

Voice over harus benar-benar jalan dengan baik, bukan sekadar ada. Syarat wajibnya:

- Natural, enak didengar, tidak seperti robot.
- Nada tidak datar, tidak monoton, tidak terburu-buru, dan tidak menggantung di akhir kalimat (naskah: kalimat pendek sampai sedang, diakhiri tanda baca penutup, tanpa titik-titik menggantung).
- **Nada mengikuti isi naskah:** sedih berarti nada sedih, excited berarti excited, tegas berarti tegas, lembut berarti lembut. Nada tidak boleh bertentangan dengan suasana naskah. Pada naskah bertag, beri tag emosi per kalimat atau paragraf sesuai suasananya (tag dari daftar terverifikasi di `suara_naskah.py`).
- **Pilih jenis suara yang cocok dengan naskah:** misalnya pria berat untuk naskah tegas atau dramatis, wanita kalem untuk naskah lembut atau reflektif, pria muda untuk naskah santai. Pertimbangkan emosi, tempo, dan target pendengar.
- **Jangan memilih suara asal.** Pakai `pilih_suara(platform, kebutuhan, suasana, tempo, pendengar, nama)` di `suara_naskah.py`: nama harus ada di daftar terverifikasi dan hasilnya memuat alasan singkat yang ditulis di laporan agar bisa diperiksa.
- Hasil suara yang terdengar robot, datar, atau tidak cocok dengan naskah dianggap **GAGAL** dan harus diperbaiki, bukan dikirim.

## 0.5 Status voice over (sementara, jangan dihapus)

Voice over langsung belum bisa dijalankan dengan baik di lingkungan ini: tidak ada suara yang lolos target 0.4 (suara bawaan dan sintesis sendiri terdengar robot, jadi ditolak). Hasil video saat ini masih tanpa suara, tetapi **SFX tetap ada**. Ada klaim sebelumnya yang menyebut video tanpa SFX; klaim itu meragukan dan tidak berlaku, karena SFX wajib di setiap video (0.2 aturan 4). Bagian ini tetap ada sampai voice over langsung benar-benar bisa dijalankan sesuai target di 0.4. Sampai saat itu: katakan terus terang di kalimat pertama laporan, kirim video dengan SFX tanpa suara beserta naskah bersih (atau naskah bertag bila user memilih manual), dan jangan menyebut video "lengkap".

**Jawaban jujur untuk "Instant Voice Over" (diperiksa 2026-11-08): TIDAK BISA di lingkungan ini.** Tidak ada mesin suara neural (tidak ada espeak, flite, piper, TTS, torch, kokoro; hanya `onnxruntime` tanpa model suara), model suara tidak bisa diunduh (huggingface, pypi, dan situs lain ditolak proxy dengan kode 403), dan Claude sendiri tidak menghasilkan audio. Mesin robotik ditolak oleh 0.4. Karena itu fitur Instant tidak dibuat pura-pura jalan; yang berfungsi adalah naskah bertag (0.3 langkah 3, 7.10) dan Cara 2. Bila suatu sesi punya mesin neural: ikuti 7.10 butir 1 (contoh pendek ke user dulu) dan perbarui bagian ini.

## 0.6 Pustaka 13 gaya visual (tampilan, di atas dua gaya utama)

Gaya utama (0.2) menentukan STRUKTUR video; gaya visual menentukan TAMPILAN: palet, bahan, bentuk, gerak, huruf, aksen SFX, dan cara kata kunci disorot. Data lengkap ada di `scripts/gaya_visual.py` (`daftar()`, `gaya(nama)`, `pilih(teks)`, `pilih_gaya_utama(teks)`, `daftar_kata_kunci()`, `cek_gaya_utama`).

**Sumber dan kejujuran.** Referensinya adalah halaman "Motion Graphics" milik kreatorlab.id (13 gaya) yang diberikan user sebagai tangkapan layar. Deskripsi di bawah disusun dari FRAME DIAM tangkapan layar itu (warna disampling dari gambar, lalu disesuaikan dengan mata). Video aslinya BELUM ditonton: pada 2026-11-08 situs ditolak proxy workspace (403) dan teks halaman tidak memuat tautan video bagian Motion Graphics, jadi tidak ada video yang bisa dikirim ke user, dan gerak di sini adalah penafsiran, bukan hasil menonton. DILARANG mengaku sudah menonton atau mengirim video yang tidak benar-benar berasal dari sumbernya. Bila suatu sesi bisa membuka situsnya (browser tersedia) atau user melampirkan videonya: buka situs, klik tombol "Motion Graphics" (tampilan awalnya bagian 3D), gulir sampai sampel yang sama dengan gambar referensi, tonton, lalu koreksi `gaya_visual.py` dan bagian ini.

**Ciri bersama semua contoh:** keterangan (caption) di bagian bawah berupa kapsul dengan kata kunci disorot warna; chip label kecil di sudut (kategori, "SIMULASI", "FAKTA & ANGKA"); satu ide besar per adegan dengan banyak ruang kosong; angka atau objek utama sangat besar. Penyorotan kata kunci mengikuti 6.9.

**Kata kunci dua gaya utama:**

- Flat (Animasi Cerita Berkarakter): "flat animation"
- Reel (Reel Tipografi Bergerak): "showreel" atau "reel"

**Kata kunci 13 gaya visual** (bahasa Inggris di depan dari daftar user, padanan Indonesia ditambahkan; tidak ada kata kunci user yang diganti pada versi ini):

- **ARSIP** (kata kunci: "archive", "arsip", "kalender", "dokumen", "tanggal", "sejarah", "stempel", "kertas usang"; penekanan bawaan: stabilo): kalender dan dokumen cetak usang: halaman kalender krem miring dengan kepala merah dan lingkaran merah gambar tangan di satu angka, stempel merah di sudut, keterangan di strip kertas dengan huruf mesin tik. Cocok dengan Reel Tipografi Bergerak.
- **BLUEPRINT** (kata kunci: "blueprint", "cetak biru", "teknik", "mesin", "arsitektur", "cara kerja", "lift", "rancangan"; penekanan bawaan: garis): cetak biru teknik: latar biru tua berkisi tipis, gambar garis putih-biru muda (lingkaran, garis dimensi, panah, label kecil monospace seperti penanda lantai atau kabel), keterangan di kotak gelap bersudut membulat. Cocok dengan Reel Tipografi Bergerak.
- **SKETSA** (kata kunci: "sketch", "sketsa", "gambar tangan", "coretan", "buku catatan", "psikologi", "doodle"; penekanan bawaan: stabilo): buku catatan bergaris dengan gambar tangan: tokoh stik dan lampu dengan kerucut cahaya kuning, judul tulisan tangan dengan stabilo kuning, tag kecil hijau (mis. nama topik), keterangan tulisan tangan. Cocok dengan Animasi Cerita Berkarakter.
- **GEOMETRIK** (kata kunci: "geometric", "geometrik", "angka", "statistik", "fakta dan angka", "persen", "bentuk dasar"; penekanan bawaan: warna): angka atau bentuk geometris raksasa: latar abu terang, angka hitam sangat tebal di atas lingkaran kuning mustard, chip label kecil di bawah dan teks kecil di sudut (mis. kategori fakta), elemen sangat sedikit. Cocok dengan Reel Tipografi Bergerak.
- **HIKAYAT** (kata kunci: "silhouette", "history", "hikayat", "legenda", "dongeng", "cerita rakyat", "wayang", "siluet", "sejarah", "mitos"; penekanan bawaan: garis): siluet cerita rakyat atau sejarah: gradien oranye sampai cokelat tua seperti sepia, siluet gaya wayang kulit dan gunung berlapis berlubang, label kecil bertema (mis. LEGENDA), keterangan di kapsul emas. Cocok dengan Animasi Cerita Berkarakter.
- **TERMINAL** (kata kunci: "terminal", "hacker", "peretas", "command line", "kode", "password", "keamanan", "login", "cyber"; penekanan bawaan: warna): antarmuka baris perintah ala peretas: latar hampir hitam, teks hijau terminal monospace, jendela berbingkai (merah atau hijau), kotak kode OTP, banner hijau seperti ACCESS GRANTED, baris prompt dengan kursor, hujan kode samar. Cocok dengan Reel Tipografi Bergerak.
- **CAIR** (kata kunci: "liquid", "cair", "air", "darah", "cairan", "fluida", "liter", "tubuh", "biologi"; penekanan bawaan: stabilo): fluida dan cairan di latar gelap: gradien ungu-biru tua, gumpalan atau gelembung berkilau berisi angka besar dan keterangan kecil, tetesan merah muda, kapsul keterangan semi-transparan dengan kata kunci berlatar ungu. Cocok dengan Reel Tipografi Bergerak.
- **FLATLIFE** (kata kunci: "flat life illustration", "everyday life", "flatlife", "sehari-hari", "ilustrasi", "harga", "ekonomi", "kehidupan", "orang"; penekanan bawaan: stabilo): ilustrasi flat tokoh sehari-hari: latar pastel (krem, hijau muda), tokoh sederhana membawa kotak, grafik batang berblok dengan label harga, kapsul putih dengan kata kunci berlatar merah muda. Cocok dengan Animasi Cerita Berkarakter.
- **KLIPING** (kata kunci: "clipping", "collage", "kliping", "koran", "majalah", "kolase", "hoaks", "bohong", "berita", "fakta atau hoaks"; penekanan bawaan: stabilo): kolase guntingan koran atau majalah: latar merah muda berpola halftone, potongan kertas bertepi sobek, huruf tempel campur-campur seperti surat kaleng, foto dengan lingkaran penanda, stempel merah (mis. BOHONG), bar hitam sensor, stiker keterangan. Cocok dengan Reel Tipografi Bergerak.
- **LANTANG** (kata kunci: "bold typography", "lantang", "tipografi", "kinetic typography", "teks besar", "tahun", "judul", "tegas"; penekanan bawaan: warna): tipografi raksasa: latar hampir hitam, kata putih atau abu sangat tebal dan rapat, angka merah menyala sebesar layar, tanpa dekorasi lain. Cocok dengan Reel Tipografi Bergerak.
- **PETA** (kata kunci: "map", "peta", "lokasi", "wilayah", "negara", "pulau", "jarak", "geografi"; penekanan bawaan: garis): visualisasi peta dan lokasi: latar abu-biru pucat, peta wilayah berwarna kuning mustard dengan label wilayah kecil, judul serif dengan kata ditekan (miring, bergaris bawah), skala di sudut kanan atas, pin lokasi, keterangan di kapsul gelap. Cocok dengan keduanya.
- **MIDNIGHT** (kata kunci: "midnight", "dark mode", "simulasi", "kalau besok", "aplikasi", "ponsel", "notifikasi", "peluang", "keputusan", "malam"; penekanan bawaan: warna): latar navy sangat gelap dengan antarmuka dan diagram: chip kecil seperti SIMULASI atau KALAU BESOK, mockup ponsel dengan daftar notifikasi, judul putih tebal dengan kata kunci kuning dan garis bawah; varian lain berupa pintu-pintu dengan persentase. Cocok dengan Reel Tipografi Bergerak.
- **MINIATUR** (kata kunci: "miniature", "isometric", "miniatur", "diorama", "isometrik", "kota", "3d", "rating", "dunia mini"; penekanan bawaan: stabilo): diorama isometrik seperti miniatur: latar langit pucat, kota atau ruang kecil tiga dimensi semu dengan bangunan, jalan, dan orang kecil, bintang rating atau lencana, keterangan di kapsul gelap dengan kata kunci kuning. Cocok dengan Animasi Cerita Berkarakter. Catatan: isometrik tiga dimensi semu: aturan 0.2 nomor 6 berlaku (coba dulu, nyatakan batas hanya setelah upaya nyata).

**Kebebasan kata kunci.** Claude boleh mengganti kata kunci mana pun di atas bila menurut Claude kurang pas, dengan syarat WAJIB memberikan salinan daftar kata kunci terbaru (`daftar_kata_kunci()`) kepada user di laporan agar bisa diperiksa. "Flatlife" dan "Flat animation" boleh sama karena hasilnya sama; pencocokan memakai frasa utuh, jadi "flat life illustration" menuju FLATLIFE dan "flat animation" menuju gaya utama, bukan sebaliknya.

**Cara memilih dan memakai:**

1. User menyebut nama atau kata kunci gaya visual: pakai gaya itu.
2. Tidak disebut: Claude memilih sendiri yang paling cocok dengan topik, dan menyebutnya di kalimat pertama laporan beserta alasannya (tanpa kartu tambahan; kartu hanya untuk gaya utama yang tidak jelas, 0.2).
3. Gaya visual harus bisa dikerjakan di gaya utama yang aktif (`cek_gaya_utama`); bila tidak, ambil palet, bahan, dan gerak, tetapi struktur mengikuti gaya utama.
4. Ambil `palet`, `elemen`, `gerak`, `sfx` (keluarga SFX untuk aksen; SFX tetap wajib), dan `tekan` dari `gaya(nama)`. Huruf yang disebut gaya (mesin tik, tulisan tangan, condensed) dicari di `font_tersedia()`; tidak ada berarti dilaporkan dan dipilih padanan yang benar-benar ada, tidak diganti diam-diam (aturan font di 7.7).
5. Konten tetap tunduk pada aturan lain: fakta diverifikasi (6.5; PETA wajib data peta asli), kata luas divisualkan konkret (6.8), komposisi aman (6.10), tidak menggambar wajah nabi atau tokoh agama (HIKAYAT hanya siluet generik), dan MINIATUR (isometrik) mengikuti aturan "coba dulu" di 0.2 nomor 6.

## 1. Tiga cara kerja

**Cara 1: script, video, voice over.** Dipakai saat user minta script lalu lanjut minta videonya, atau minta video tanpa membawa voice over sendiri. Alur: script, lalu video dari script, lalu voice over (dibuat di mana saja yang bisa), lalu gabung. Hasil: mp4.

**Cara 2: voice over dan script dari user.** Dipakai saat user mengirim voice over + script sendiri (ElevenLabs atau TTS gratis). Alur: motion dibuat mengikuti script dan suara yang sudah ada. Hasil: mp4.

**Cara 3: JS murni + perintah render.** Dipakai sebagai fallback Cara 1 bila gagal, atau saat user eksplisit minta "JS murni / render di Termux". Alur sama dengan Cara 1, tetapi hasilnya file JS + perintah render.

**Routing:**

1. Minta script lalu lanjut minta video dari script itu: Cara 1.
2. Minta script di awal, lalu mengirim voice over + script untuk dijadikan video: Cara 2.
3. Cara 1 gagal: Cara 3, wajib menyertakan perintah render.
4. User sendiri minta JS murni / render di Termux: langsung Cara 3.

**Cara 2 bukan fallback.** Cara 1 dan 3 satu keluarga (input sama, bentuk hasil beda), sedangkan Cara 2 beda input karena suaranya sudah dibuat user. Cara 2 tidak dipakai sebagai cadangan Cara 1 atau 3, dan sebaliknya. Bila Cara 2 gagal: laporkan apa yang gagal dengan jujur, lalu tanya user mau diulang dengan pendekatan lain atau tidak. Jangan pindah cara diam-diam.

**Cara 1 dianggap gagal** bila, setelah minimal dua pendekatan render berbeda, belum ada mp4 yang bisa diputar dan lolos pengecekan. Jangan mengulang perintah yang sama terus-menerus. Saat pindah ke Cara 3, bilang singkat bahwa Cara 1 gagal dan kenapa.

## 2. Parameter yang bisa diubah user

Baca dari kalimat user, jangan dipaku:

- jenis konten (iklan produk, cerita, edukasi), nama produk atau topik
- durasi
- rasio dan resolusi: 9:16 = 1080x1920, 16:9 = 1920x1080, 1:1 = 1080x1080, 4:5 = 1080x1350. "Full HD" berarti sisi 1080p
- fps (default 30; 60 bila diminta)
- gaya, posisi timer, gaya subtitle

Bila tidak disebut: 9:16, 1080x1920, 30 fps, flat animation. Jangan menahan pekerjaan hanya untuk menanyakan hal-hal ini.

## 3. Aturan umum

1. **Folder project terpisah** per video (`projects/<nama>/` berisi script, audio, scenes, out). Jangan menyentuh folder website atau project lain milik user. Sebutkan lokasinya di laporan.
2. **Cek dulu, baru kirim.** Sebelum video apa pun dikirim (preview maupun penuh), jalankan pengecekan dan jangan klaim pengecekan yang tidak dijalankan: `ffprobe` (durasi, resolusi, fps, ada audio), `blackdetect`, `freezedetect`, jeda narasi pas dengan pergantian adegan, `mean_volume` voice over sama dengan file aslinya, `Sfx.audit()` (variasi SFX, bagian 6.1), `motion_report` (tidak ada gerak mati, bagian 6.4), bila ada voice over `probe_dur` video sama dengan audio (selisih paling banyak 0,05 detik) + `sync_audit` + `mouth_check` (bagian 6.6), `Fakta.laporan()` (bagian 6.5), dan lihat langsung beberapa frame, termasuk satu frame karakter diperbesar (outfit, bagian 6.3) dan satu frame dengan watermark bila diminta.
3. **Isi layar.** Jangan menaruh seluruh naskah sebagai teks di layar. Pakai ikon, bentuk, dan animasi yang mewakili isi naskah. Teks di layar hanya kata kunci pendek (nama produk, harga, CTA, label ikon). Pengecualian: subtitle, timer, dan chat bubble (frasa kunci saja) yang diminta user.
4. **Flat animation:** bentuk datar tegas, 3-5 warna, easing, gerak bergantian (stagger), satu ide visual per adegan. Elemen masuk dan keluar dengan mulus, dengan gaya masuk yang bervariasi (lihat 6.4). Datar bukan berarti polos: tetap beri lapisan, lipatan, dan sisi teduh (lihat 6.3).
5. **Pergantian adegan default:** potong bersih atau crossfade pendek (0,3 detik atau kurang), jatuh di jeda narasi. Bukan transisi bergaya (lihat 7.3).
6. **Environment:** cek tool yang tersedia dan pasang bila kurang. Akses jaringan dari shell bisa dibatasi; bila ada request yang ditolak, jangan coba cara lain untuk menembusnya, bilang apa adanya.
7. **Cerita nabi atau tokoh agama:** jangan menggambar wajah atau sosok nabi; pakai siluet dari jauh, simbol, cahaya, dan narasi. Ini default; user boleh mengubahnya.
8. **Karakter atau merek pihak lain:** jangan menggambar karakter berhak cipta atau meniru logo/maskot nyata, termasuk dari video referensi. Ambil identitasnya yang faktual (palet warna resmi, gaya tata letak, ritme), bukan logo atau karakternya; nama merek cukup ditulis sebagai teks. Warna merek WAJIB sesuai aslinya (lihat 6.5).
9. **Topik kesehatan atau keselamatan** (hewan, obat, makanan): jangan menyebut takaran atau dosis; tekankan menghubungi dokter, dokter hewan, atau profesional.
10. **Jujur soal suara.** Bila voice over belum ada (tidak ada TTS yang bisa jalan), katakan di kalimat pertama laporan, kirim video dengan SFX tanpa suara + `narasi-voice-over.txt`, dan tawarkan lanjut ke Cara 2 begitu user mengirim audionya. Jangan menyebut video "lengkap" bila tidak ada suara.
11. **Jangan minta user mengirim ini dan itu.** Hal yang bisa dihitung, dicari, atau dicoba sendiri (timestamp suara, transkrip, warna merek, bentuk negara) dikerjakan sendiri. Tanya user hanya untuk keputusan yang benar-benar miliknya.
12. **Penamaan file wajib deskriptif dan tetap.** DILARANG nama berembel-embel versi: v2, v3, v4, final, final2, baru, copy, revisi, edit, backup, atau (1). Nama mengikuti isi (mis. `kucing-cokelat.mp4`, `narasi-voice-over.txt`); revisi MENIMPA nama yang sama dan versi lama dipindah otomatis ke folder `arsip/` (tidak dikirim ke user). Ditegakkan di kode: `fxlib.nama_file_ok(path)` menolak nama berversi dan `fxlib.tulis_aman(path)` dipanggil sebelum menulis setiap keluaran.
13. **Fitur "hanya bila diminta" ditegakkan di kode, bukan hanya di niat.** Langkah pertama tiap project: `F.izin_dari_teks(<kalimat permintaan user>)`. Timer, subtitle, transisi, watermark, chat bubble, pencahayaan, video effects, dan voice over (langsung dan naskah) melempar `FiturTidakDiminta` bila belum diminta. Hanya Timer yang boleh diaktifkan AI sendiri lewat `F.IZIN.aktifkan_sendiri("timer", alasan)`, dan alasannya masuk laporan akhir.

## 4. Kartu pilihan

Kartu dibuat dengan tool `AskUserQuestion` (satu pertanyaan, bukan multi-select). Ada tiga kartu berbeda yang muncul di waktu berbeda. Jangan mengganti kartu dengan pertanyaan teks biasa seperti "Mau lanjut jadi videonya?".

### Kartu 1: setelah SCRIPT (WAJIB)

- **Kapan:** setiap kali user meminta script atau naskah (belum minta video), di gaya mana pun dan cara mana pun (di Reel Tipografi Bergerak, script = teks layar per ketukan). Tampil setelah tabel script, narasi bersih, dan catatan asumsi. Kartu ini WAJIB ada: tidak boleh dilewati, dan tidak boleh diganti pertanyaan teks biasa.
- **Pertanyaan:** "Script sudah jadi. Lanjut buat full film?"
- **Tombol:** "Lanjut buat full film" (buat video dari script ini) dan "Revisi" (ubah script dulu: isi, durasi, atau gaya bahasa).
- **Lanjut buat full film:** mulai Cara 1 dengan script itu (kartu voice over di 0.3 tetap ditanyakan sebelum membangun).
- **Revisi:** bila user belum menulis apa yang diubah, tanya multi-select ("Isi/fakta", "Durasi", "Gaya bahasa", "Jumlah adegan", "Visual", plus input bebas). Ubah script, tampilkan lagi script + narasi bersih, lalu Kartu 1 lagi. Ulangi sampai "Lanjut buat full film".
- **Tidak tampil** bila user sudah meminta script + video dalam satu pesan, atau mengirim script sendiri (Cara 2).

### Kartu 2: setelah PREVIEW, hanya untuk palet NEON

- **Pemicu:** palet atau hasil berupa gradien neon (ungu neon, biru neon, hijau neon, atau kombinasinya, termasuk gaya glow neon). Putuskan saat merencanakan palet, sebelum membangun apa pun. Bila ragu, anggap neon.
- **Alur:** bangun preview adegan pembuka saja (sekitar 6-10 detik, rasio dan resolusi sama dengan video akhir, lengkap dengan suara dan SFX bila ada), jalankan pengecekan, kirim dengan `SendUserFile` (`display: "render"`), tulis ringkasan jujur (hanya yang benar-benar dicek), lalu tampilkan kartu.
- **Contoh ringkasan:** "Preview adegan pembuka (7,75 detik, vertikal) sudah jadi dan sudah aku cek: gambar tidak ada yang hitam, jeda narasi pas, suara voice over sama kerasnya dengan file asli. Project-nya ada di folder terpisah. Sisa film (sekitar 61 detik) belum dibuat."
- **Pertanyaan:** "Lanjut ke film penuh {durasi total} detik dengan tampilan seperti ini?"
- **Tombol:** "Lanjut film penuh" (lanjutkan sampai video selesai) dan "Revisi dulu" (buat ulang preview: efek, warna, atau script).
- **Lanjut film penuh:** buat sisa video dengan tampilan yang sama, cek lagi, kirim.
- **Revisi dulu:** bila belum jelas apa yang kurang, tanya multi-select ("Efek/animasi kurang bagus", "Warna kurang enak", "Script belum sesuai", plus input bebas). Buat ulang preview, cek, kirim, tampilkan kartu lagi. Ulangi sampai "Lanjut film penuh". Di Cara 2 suara milik user: bila isi kalimat berubah, minta suara baru; yang bisa diubah sendiri hanya visual.
- **Cara 3:** preview berupa file JS yang baru berisi adegan pembuka + perintah render preview (`--preview`); kartu di balasan yang sama; setelah "Lanjut film penuh", kirim JS lengkap + perintah render penuh.
- **Palet non-neon:** tidak ada Kartu 2; video penuh boleh langsung dibuat dan dikirim. WAJIB tulis satu kalimat di laporan, mis.: "Palet video ini bukan neon, jadi tidak ada preview dan kartu; video penuh langsung kukirim. Kalau mau lihat preview dulu, bilang saja." Preview + kartu tetap boleh bila user memintanya.

### Kartu 3: setelah PREVIEW TRANSISI, hanya bila user meminta transisi

- **Kapan:** user meminta transisi (lihat 7.3). Kirim klip pendek 3-5 detik (akhir adegan A, transisi, awal adegan B), lengkap dengan SFX transisinya.
- **Pertanyaan:** "Transisinya seperti ini. Dipakai di seluruh video?"
- **Tombol:** "Pakai transisi ini" dan "Revisi transisi" (ganti jenis, lebih halus, atau tanpa transisi).
- **Pakai transisi ini:** terapkan ke seluruh video. **Revisi transisi:** buat ulang klip dengan jenis lain, tampilkan kartu lagi.

### Ringkasan kapan kartu muncul

- User meminta script atau naskah (belum minta video), di gaya dan cara mana pun: Kartu 1 ("Lanjut buat full film" atau "Revisi"), WAJIB.
- User minta script + video sekaligus: tidak ada Kartu 1.
- Palet neon, setelah preview: Kartu 2. Palet non-neon: tidak ada Kartu 2.
- Cara 2 (user kirim voice over + script): tidak ada Kartu 1; Kartu 2 hanya bila neon.
- Transisi diminta: Kartu 3 sebelum video penuh.
- Gaya tidak jelas: kartu gaya (0.2) sebelum apa pun dibangun.
- User memulai pembuatan video (Cara 1 atau 3): tiga kartu voice over berbahasa Inggris berurutan, "Do you want to include a voice over?", lalu "How would you like to create the voice over?", lalu "Which platform will you use for the manual voice over?" (0.3). Cara 2 tidak ditanya.
- Sesi tanpa pengawasan (tidak ada yang bisa menjawab): berhenti di titik kartu; jangan kirim video penuh.

## 5. Narasi voice over harus BERSIH

Kesalahan yang dulu terjadi: file narasi berisi judul, durasi video, petunjuk baca, rentang detik, label "Adegan N", dan catatan penutup, sehingga ikut dibacakan saat ditempel ke ElevenLabs atau TTS lain. Aturan:

1. Setiap script disertai narasi bersih: file `narasi-voice-over.txt` DAN satu blok kode di chat yang bisa disalin, ditulis setelah tabel script.
2. Isinya HANYA kalimat yang dibacakan, urut sesuai adegan, satu adegan satu paragraf, dipisah satu baris kosong.
3. DILARANG di dalamnya: judul, nama video, durasi/rasio/fps, rentang waktu, label "Adegan N", nomor, petunjuk tempo atau jeda, catatan, instruksi, nama file, emoji, tanda kurung berisi arahan, dan tanda kutip di sekitar kalimat.
4. Teks harus sama persis, kata per kata, dengan kolom Narasi di script; cocokkan setelah menulis.
5. Waktu per adegan dan petunjuk baca TIDAK dicampur ke file narasi; taruh di chat atau `jadwal-adegan.txt`.
6. Di chat jelaskan singkat: "Salin hanya blok narasi ini ke ElevenLabs. Tiap paragraf = satu adegan, jadi kamu juga bisa membuat suaranya per adegan." Jangan mengklaim fitur spesifik tool pihak ketiga yang tidak pasti.

Contoh BENAR:

```
Kucingmu mengendus cokelat di atas meja. Lucu? Justru ini bisa berbahaya buat dia.

Cokelat mengandung teobromin dan kafein, dua zat yang tidak cocok untuk tubuh kucing.
```

Contoh SALAH (jangan ditiru): baris `NARASI VOICE OVER - "Judul"`, baris `[00:00 - 00:06] Adegan 1`, kalimat dalam tanda kutip, dan baris `Catatan: kirim file audionya ke sini`.

## 6. Fitur WAJIB

### 6.1 SFX (sound effect)

**Wajib di setiap video**, termasuk bila user tidak menyebut SFX.

- **Pembuatan:** sintesis lokal dengan kode di bagian 13 (tanpa internet, tanpa unduhan). Bank-nya besar: 77 bunyi dalam 10 keluarga (`KATALOG` di fxlib; `daftar_sfx()` mencetak nama dan kapan dipakainya). Keluarga: `muncul` (pop, bubble, blip, click, plop, wood, pluck, marimba, snap, zip_up, toggle_on, key); `benturan` (stamp, impact, thud, boom, slam, stomp, punch, glass); `sukses` (ding, chime, sparkle, coin, levelup, fmbell, harp, notify, cash); `ritme` (kick, snare, hat, hat_open, clap, rim, tom, sub, clock); `kaget` (boing, alert, stinger, hornsting, scratch, gasp); `gagal` (buzz, fail, slide_down, powerdown, tapestop, toggle_off); `lucu` (bonk, squeak, cork, wobble); `sapuan` (whoosh, swish, whoosh_down, air, rewind, pitchsweep, flutter, slide_up); `tegang` (riser, noise_riser, revcym, heartbeat, sonar, pad, rumble, wind); `digital` (glitch, zap, laser, static, powerup, teleport, shutter). Ditambah `tick` dan `beep` untuk timer. Jangan menjanjikan yang tidak bisa dibuat (teriakan suara manusia, musik latar); katakan apa adanya dan tawarkan SFX sintesis terdekat atau minta user mengirim file audionya.

**Variasi (anti berulang). Masalah yang harus dihindari: bunyi yang sama persis diputar berulang dengan pola yang sama terdengar murahan dan membosankan.**

1. **Jangan memutar bunyi yang itu-itu saja.** Pakai `Sfx(track, seed)` (bagian 13) dan panggil `add(keluarga, t)`: bank memilih jenis yang berbeda dari DUA pemakaian terakhir di keluarga itu (keluarga `muncul` punya 12 jenis, jadi 60 kemunculan beruntun tidak berulang dalam 3 berturut-turut). Untuk kejadian yang butuh bunyi tertentu (kaca pecah, kick, snare, ping sonar), pakai `add_nama("glass", t)`. Pilih keluarga dan nama yang cocok dengan gaya video, lalu biarkan bank memvariasikannya. Pengecualian: ketukan di Reel Tipografi Bergerak (keluarga `ritme`: kick, snare, clap, hat) sengaja berulang karena itulah iramanya, jadi `Sfx.audit()` tidak menghitungnya sebagai pengulangan dan melaporkannya terpisah sebagai `ketukan`; variasikan lewat pergantian snare dan clap, hat dan hat_open, serta bunyi aksen (stamp, punch, stomp, thud, slam) yang berganti tiap kejadian.
2. **Acak terkendali di tiap pemutaran:** nada bergeser sekitar 1,5 semiton, gain sekitar 1,5 dB, waktu sekitar 12 milidetik (`Sfx.add`). Waktu tidak diacak untuk timer.
3. **Rangkaian elemen** yang muncul beruntun (daftar, ikon, checklist) memakai `rise`: nada naik sedikit demi sedikit (mis. 0,8 semiton per elemen), jadi terdengar menaiki tangga nada, bukan pola yang sama.
4. **Timer:** tik dan tok bergantian dua nada lewat `Sfx.tick(t, i)`, ada aksen tiap 5 detik, waktu tetap tepat. Jangan memakai satu tik yang sama untuk semua detik.
5. **Kejadian besar** dibuat berlapis dengan `layer([...])` (mis. impact + thud + alert yang tertunda 0,12 detik), lalu `room(...)` untuk gema tipis. Bukan satu bunyi tunggal.
6. **Irama tidak seragam:** jarak antar SFX tidak sama rata, SFX mengikuti kejadian di layar (bukan jam). Adegan yang tenang boleh nyaris hening; hening juga bagian dari variasi. Satu jenis bunyi maksimal dipakai dua kali dalam 5 detik.
7. **Jangan mengubah gaya per video secara acak.** Variasi terjadi di dalam satu keluarga bunyi yang cocok dengan gaya video (lihat Prinsip), bukan campuran semua bunyi.

**Peta kejadian ke SFX (gain relatif, dB; tiap baris adalah keluarga bunyi, bukan satu bunyi tetap):**

- Ikon atau elemen muncul: keluarga `muncul` (-14), dengan `rise` bila beruntun.
- Tanda tanya muncul: `pop` atau `bubble` bernada tinggi (-15).
- Timer berdetik tiap detik: `Sfx.tick` tik-tok (-12). Tiga detik terakhir: `beep` bernada naik 1200 ke 1800 Hz (-12).
- Timer nol atau kejadian besar: `layer` impact (-6) + thud + alert (-14).
- Tanda seru atau kaget: keluarga `kaget` (-12).
- Sukses atau info: keluarga `sukses` (-16).
- Ketegangan menuju kejadian: `riser` 1-2 detik (-14).
- Benda jatuh atau menutup: keluarga `benturan` pendek (-14).
- Transisi: hanya bila transisi diminta (7.3), keluarga `sapuan` (-12).
- Gagal, salah, padam: keluarga `gagal` (`buzz`, `fail`, `powerdown`, `tapestop`) (-12).
- Kejadian lucu atau karakter kena benda: keluarga `lucu` (`bonk`, `squeak`, `cork`, `wobble`) (-12).
- Gangguan, sains, perangkat: keluarga `digital` (`glitch`, `zap`, `laser`, `static`, `powerup`, `teleport`, `shutter`) (-14).
- Suasana atau ketegangan panjang: keluarga `tegang` (`noise_riser`, `revcym`, `heartbeat`, `sonar`, `pad`, `rumble`, `wind`) (-16, lebih pelan dari SFX kejadian).
- Video bergaya beat (tanpa voice over, teks atau tipografi bergerak mengikuti ketukan): keluarga `ritme` (`kick`, `snare`, `hat`, `hat_open`, `clap`, `rim`, `tom`, `sub`, `clock`). Hitung waktu ketukan dengan `beat_grid(bpm, durasi)`, pasang pemotongan dan SFX tepat di ketukan (tanpa `jit`, `jit=0`), dan pakai `revcym` atau `noise_riser` 1 bar sebelum drop.

**Prinsip:**

- Padat tapi tidak ramai: paling banyak satu SFX tiap 0,4 detik, satu bunyi per kejadian.
- SFX penting (impact, alert, ding) sebaiknya jatuh di jeda narasi agar terdengar jelas.
- Karakter SFX mengikuti gaya video (flat ceria: pop dan ding; sains atau dramatis: impact dan riser).

**Campur ke audio:** pakai `Track.write(path, vo_path=..., duck_db=-12)` (bagian 13). Voice over TIDAK diubah. RMS SFX otomatis dibatasi maksimal 12 dB di bawah RMS ucapan (ducking dinamis jendela 250 ms), hanya SFX yang diturunkan bila hampir clipping. Hasil satu file wav, lalu `ffmpeg -c:a aac -b:a 256k`. Tanpa voice over: SFX dipakai dengan gain apa adanya.

**Cek:**

- `mean_volume` dan `max_volume` video sama dengan voice over asli (SFX tipis di antara ucapan), puncak campuran di bawah -1 dBFS.
- Bandingkan campuran dengan voice over asli per jendela 0,25 detik: di jendela ucapan, SFX minimal sekitar 8 dB di bawah ucapan.
- SFX berbunyi tepat pada detik yang dijadwalkan (SFX di jeda terdengar jelas, mis. puncak lebih dari 0,05).
- **Audit variasi:** jalankan `Sfx.audit()`. `runtun_sama_terpanjang` harus 1 (tidak ada jenis sama berturut-turut) dan `jenis_berbeda` minimal 3 bila ada 6 bunyi non-timer atau lebih. Jangan klaim "sudah diaudit" bila tidak dijalankan, dan jangan klaim sudah "mendengarkan" bila hanya mengecek angka. Bunyi bank sendiri sudah dites angka (tanpa NaN, puncak 0,5 sampai 1, tanpa klik di tepi, tanpa pasangan kembar), tetapi kualitas telinga belum dinilai: dengarkan `sfx-demo.wav` dan buang bunyi yang tidak enak.

### 6.2 Ekspresi dan efek karakter

**Wajib.** Setiap karakter punya ekspresi yang berubah mengikuti narasi, plus efek visual di momen penting. Ekspresi muncul tepat di kata yang relevan, efek berlangsung 0,6-1,2 detik lalu mereda, maksimal dua efek bersamaan, dan tidak menutupi wajah (taruh di atas atau samping kepala). Berlaku untuk karakter apa pun, bukan hanya kucing.

**Daftar ekspresi (wajah, efek, SFX):**

- **Teriak atau kaget besar:** mata `wide`, mulut `scream`; `fx_exclaim(n=2)` + `fx_waves` + `shake` + `flash`; SFX impact + alert.
- **Kaget:** mata `wide`, mulut `frown`; `fx_exclaim(n=1)`; SFX boing.
- **Takut atau gemetar:** mata `wide`, mulut `frown`; `fx_waves` kecil + `shake` kecil + `fx_sweat`.
- **Sedih:** mulut `frown`; `fx_sweat` berwarna biru sebagai air mata.
- **Bingung:** mata `open`, kepala miring; teks `?` yang pop-in; SFX pop.
- **Senang:** mata `happy`, mulut `smile`; bintang kecil atau pantulan; SFX ding.
- **Marah:** mata `open`, mulut `frown`; tint merah pelan + `shake`; SFX alert.

**Varian wajah** yang perlu ditambahkan ke fungsi wajah karakter:

```python
elif eyes == 'wide':      # kaget: putih lebar + pupil kecil
    c.ell(ex, ey, 44, 55, INK); c.ell(ex, ey, 37, 48, WHITE); c.circ(ex, ey + 4, 10, INK)
elif mouth == 'scream':   # teriak
    c.ell(0, 98, 42, 56, INK); c.ell(0, 128, 26, 20, PINK)
```

Tanda seru dan gelombang digambar dari bentuk (tanpa font), jadi aman juga di Cara 3. Tanda seru diberi outline putih agar terbaca di latar apa pun. Untuk kamera: `Cv(cam=(540 + dx, 960 + dy, zoom))` dengan `shake` dan sedikit zoom-punch (1 + 0,05 x pulsa) saat kejadian.

### 6.3 Karakter berpakaian dan bertenaga (jangan kaku, jangan letoy)

**Wajib.** Berlaku untuk karakter apa pun (orang, hewan, robot, maskot orisinal). Pegang dua hal yang BERBEDA dan jangan dicampur:

**A. "Jangan kaku" = BENTUK elemen pakaian dan aksesoris.** Yang dimaksud BUKAN animasi gerak dan BUKAN anatomi tubuh. Bentuk badan, kepala, dan proporsi sudah benar; yang kaku hanyalah bentuk elemen pakaian atau aksesoris yang terlalu geometris.

- Berlaku untuk SEMUA elemen pakaian dan aksesoris, apa pun jenisnya (jaket, kaus, rok, celana, syal, kerudung, topi, tas, sabuk, sepatu, kacamata, dan lainnya) dan apa pun bentuk bangun datar dasarnya (persegi, segitiga, trapesium, lingkaran, dan sebagainya). Ini BUKAN kasus khusus kerudung, BUKAN hanya kain, dan BUKAN hanya segitiga atau trapesium. Bisa terjadi kapan saja, pada elemen mana saja, dengan bentuk mana saja.
- Bentuk yang terlalu lurus, terlalu simetris, bersudut tajam, atau terlihat seperti bangun datar adalah masalah yang HARUS dihilangkan, bukan dipertahankan. Beri lekukan, lipatan, atau variasi bentuk agar luwes dan natural: kurva (`F.smooth`) dengan jari-jari sudut sekitar 6 px atau lebih, asimetri kecil (sisi kiri dan kanan tidak identik), dan lipatan atau jatuhnya kain.
- Keluwesan HANYA untuk elemen pakaian dan aksesoris. Anatomi tidak ikut diluweskan.

**B. "Jangan letoy" = BADAN tetap kokoh.** Versi "tidak kaku" yang salah arah membuat hasil letoy; itu dilarang.

- Badan, kepala, dan anggota badan kembali ke proporsi yang stabil, rapi, tegas, dan jelas, sesuai gaya motion graphic flat vector yang sedang tren di media sosial (bukan realistis).
- DILARANG: badan oval atau telur, badan gepeng, badan melengkung aneh, bahu menyempit seperti telur, tangan atau kaki letoy (seperti mi, melengkung tanpa tenaga, tipis, atau tidak proporsional), postur terkulai.
- Torso: bahu lebar, dada terisi, pinggang sedikit mengecil, ujung pakaian melebar; lebar terhadap tinggi sekitar 0,5 sampai 0,95. Lengan dan kaki tebal (sekitar 40-70 px pada lebar 1080) dan meruncing wajar lewat `limb(...)`; sendi menekuk lewat `ik2(...)` dengan tekukan wajar (tidak kurang dari 45 derajat).
- Amplitudo organik kecil: `blob_pts` amp tidak lebih dari 0,02, napas tidak lebih dari sekitar 2,5 persen. Gerak punya tenaga: aksi cepat lalu berhenti tegas (lihat 6.4).

**C. Wajah tetap utuh saat animasi.** Mata, alis, mulut, dan tanda di wajah (pipi, air mata, urat) tidak melenceng dan tidak berubah bentuk ketika badan atau kepala squash-stretch: bentuk wajah digambar dengan ukuran tetap relatif ke pusat kepala, dan tetap berada di dalam kepala. Hanya kedip dan bukaan mulut saat bicara yang boleh berubah.

**Outfit berlapis, minimal empat lapisan terlihat:** pakaian luar, lapisan dalam, bawahan, alas kaki, ditambah satu aksesori. Detail yang wajib: kerah atau garis leher, manset, sabuk atau garis pinggang, jahitan atau resleting, lipatan pendek lebih gelap di siku, lutut, dan pinggang, sisi teduh untuk volume, sepatu bersol berbeda warna, dan bayangan tanah yang mengecil saat melompat. Bagian lepas (ekor syal, ujung jaket, tali tas, rambut) memakai `lag(...)` tertinggal 0,1-0,2 detik lalu tenang.

**Hidup tanpa kaku:** asimetri kecil (bahu, tangan, arah kaki), pose berbeda tiap adegan, tangan tidak selalu lurus ke bawah. **Identitas:** siluet dan warna dominan tiap karakter berbeda, outfit cocok dengan peran, warna dari palet video (3-5 warna), orisinal (aturan umum nomor 8). **Cara 3 (tanpa font):** semua bentuk dari poligon, elips, dan kurva; kode di bagian 13 (`karakter.py`, `ekspresi.py`).

**Tiga audit terpisah (`audit.py`), wajib lolos sebelum render final (lihat 6.7):**

1. `luwes_audit` (KELUWESAN pakaian/aksesoris): untuk tiap poligon pakaian, tidak ada sudut tajam (belokan lebih dari 55 derajat pada skala 6 px), bukan bangun datar bertitik sedikit (5 titik atau kurang), dan tidak terlalu simetris (IoU dengan cerminannya 0,975 atau kurang untuk bentuk selebar 60 px ke atas). Garis lurus panjang (resleting, sabuk) hanya dicatat.
2. `proporsi_audit` (PROPORSI tubuh): badan tidak gepeng, TIDAK oval (isi terhadap elips dalam bbox minimal 1,06, bahu minimal 85 persen lebar maksimum, ujung bawah minimal 80 persen), anggota badan tidak tipis (minimal 38 px), tidak seperti mi (panjang per tebal paling banyak 6), sendi tidak tertekuk berlebihan.
3. `wajah_audit` (WAJAH stabil): lewat berbagai pose squash-stretch, posisi dan lebar mata relatif ke pusat kepala tetap, dan semua fitur wajah berada di dalam kepala.

Jalankan sekaligus: `audit.audit_karakter(warga, warna_pakaian, warna_badan, warna_kepala)` pada pose diam, lompat (antisipasi, puncak, mendarat), dan kaget. Audit mengukur bentuk yang benar-benar digambar (kanvas dibungkus `Rekam`), bukan niat. Hasil gagal berarti bentuknya diperbaiki, bukan ambangnya dilonggarkan.

**Cek manual:** perbesar satu frame karakter di tiap adegan, hitung lapisan outfit (minimal empat), bandingkan dua pose dari adegan berbeda (tidak boleh sama), dan lihat satu frame saat bergerak untuk memastikan badan tidak terkulai atau oval.

### 6.4 Animasi hidup (tidak kaku)

**Wajib.** Animasi yang kaku biasanya berupa: semua elemen muncul dengan pola sama, gerak linear, benda berhenti mendadak, karakter membeku saat diam, kamera tidak pernah bergerak. Aturan:

1. **Tidak ada easing linear** (kecuali angka timer). Pakai `e_io`, `e_out`, `spring`, atau `anticipate`, dan ganti jenisnya antar elemen.
2. **Antisipasi, aksi, overshoot, tenang.** Sebelum melompat atau muncul: tarik sedikit ke arah berlawanan (`anticipate`); di ujung gerak: lewati target lalu tenang (`spring`).
3. **Squash dan stretch** dengan volume tetap (`squash(v)`) saat meluncur, mendarat, kaget, dan benda memantul; getar meredam setelah kejadian dengan `jelly(...)`.
4. **Gerak melengkung (arc):** lompat berupa busur, menoleh sedikit berputar, tangan mengayun melengkung. Hindari garis lurus mekanis.
5. **Gerak susulan (overlap):** bagian sekunder mengikuti dengan tertinggal (`lag`), bukan berhenti bersamaan dengan badan.
6. **Tidak ada diam total.** Karakter yang diam memakai `idle(t, seed)` (napas, miring pelan, kedip acak `blink`, pandangan melayang `look`). Latar punya gerak pelan (kelap-kelip, awan, debu). Kamera melayang pelan lewat `cam_drift`. Pose boleh ditahan paling lama sekitar 0,5 detik tanpa gerak sekunder.
7. **Gaya masuk dan keluar bervariasi:** slide, jatuh memantul, membesar, berayun, wipe, pop. Dalam satu adegan, tidak lebih dari sekitar 40 persen elemen memakai gaya masuk yang sama. Jeda antar elemen (stagger) 0,06-0,15 detik dan tidak seragam.
8. **Paralaks:** minimal tiga lapisan latar yang bergerak dengan kecepatan berbeda di tiap adegan.
9. **Ritme bervariasi:** gerak kejadian cepat (0,2-0,3 detik), gerak suasana lambat (0,6-1,0 detik); jangan semua gerak berdurasi sama.
10. **Pergantian adegan:** elemen penting keluar sebelum pindah; jangan semua elemen berhenti serentak.

**Cek:**

- Ambil frame tiap 0,25 detik, jalankan `motion_report(frames, 0.25)`. `jendela_mati` harus kosong. Nilainya diukur dari selisih antar frame: gerak nol berarti beku, karakter yang hanya idle sekitar 0,1-0,3 sehingga tetap lolos (ambang 0,05).
- Buat contact sheet tiga frame berurutan (mis. 0,1 detik) di momen penting dan pastikan pose berubah nyata (antisipasi, puncak, mendarat).
- Bandingkan gaya masuk elemen dalam satu adegan; pastikan tidak seragam.

### 6.5 Verifikasi fakta dan informasi (cari dulu, baru gambar)

**Aktif otomatis** bila permintaan memuat sesuatu yang punya acuan di dunia nyata: bumi, negara, pulau, hewan, makanan, warna benda, merek, aplikasi atau situs, tokoh, tempat, angka. Aktif juga bila user meminta verifikasi fakta, peta, atau pulau. Berlaku untuk SEMUA hal, bukan hanya negara atau wilayah, termasuk fakta yang berurutan, berpola, berkronologi, berklasifikasi, dan berhubungan beraturan (aturan 9). Contoh kesalahan fatal yang dicegah: video tutorial di "CLAUDE" yang warnanya tidak sesuai warna aplikasi asli, atau bumi yang warnanya dan bentuk pulaunya tidak sesuai.

**Aturan:**

1. **Sumber = hasil pencarian web** (`WebSearch`, lalu `WebFetch` halaman sumbernya). BUKAN GitHub, repositori kode, atau paket npm dan pip. Cari minimal satu sumber, dua bila angka atau klaimnya penting, dan catat alamatnya.
2. **Lembar fakta sebelum menggambar.** Tulis tiap elemen yang punya acuan ke `fakta.py` (`Fakta.add(kunci, klaim, nilai, sumber)`) dan saat menggambar ambil nilainya lewat `Fakta.pakai(kunci)`. Elemen yang tidak ada di lembar atau berstatus belum terverifikasi ditolak.
3. **Fakta yang beragam tetap beragam.** Rumput umumnya hijau, bukan kuning, kecuali memang ada kondisi faktual lain (mis. kemarau): catat rentangnya. Warna baju boleh bermacam-macam (kuning, hijau, dan seterusnya) sesuai fakta atau script. Yang dilarang adalah mengarang.
4. **Bumi, negara, pulau.** Cari ciri visual Bumi (contoh hasil pencarian: laut menutupi sekitar 71 persen permukaan, daratan sekitar 29 persen, awan, es putih di kutub, tepi atmosfer biru tipis, hutan hujan hijau tua, gurun cokelat muda). Untuk setiap negara atau pulau yang disebut, cari letaknya (benua, koordinat kota acuan, tetangga) lalu cocokkan bentuknya dengan nama yang benar. Bentuk di gambar HANYA boleh berasal dari data peta asli (GeoJSON atau TopoJSON milik user atau yang sudah ada di sesi, `find_geo`) yang lolos `geo_selfcheck` (porsi daratan 24-34 persen, kota acuan jatuh di dalam negaranya, tidak ada cincin lintas garis 180). Gambar lewat `universe_kit.draw_globe`. Bila data peta tidak ada: JANGAN menggambar bentuk dari ingatan. Pakai `country_points` + `pin` (koordinat nyata dari database zona waktu), beri label, dan katakan di laporan bahwa bentuk negara belum bisa digambar.
5. **Merek, aplikasi, situs.** Cari palet resmi, font, dan gaya tampilannya (halaman panduan merek atau desain resmi), lalu pakai warna ASLI. Contoh terverifikasi untuk Claude: Clay #D97757, Slate #141413, Ivory #FAF9F5, Biru #6A9BCC, Hijau #788C5D, Abu #B0AEA5; sumber lain menyebut Poppins untuk judul dan Lora untuk isi (panduan merek), sedangkan type.today menyebut Styrene dan Tiempos di situs Anthropic: bila sumber berbeda, catat keduanya di lembar fakta dan sebutkan di laporan. Jangan menggambar logo atau maskot persis (aturan umum nomor 8).
6. **Ketidaksesuaian.** Bila permintaan atau script bertentangan dengan fakta (mis. "kucing boleh makan cokelat"), jangan diam-diam mengikuti atau mengubahnya. Tampilkan temuan beserta sumbernya (`Fakta.beda`) di laporan, buat sesuai fakta, kecuali user jelas memilih fiksi.
7. **Tidak yakin atau tidak ketemu:** cari lagi dengan kata kunci lain; bila tetap tidak ada, tulis "belum terverifikasi" di laporan dan jangan menyajikannya sebagai fakta.
8. **Laporan:** daftar "Sumber:" berupa tautan dan butir yang belum terverifikasi (`Fakta.laporan()`).
9. **Fakta berurutan, pola, kronologi, klasifikasi, dan hubungan.** Urutan atau kronologi (mis. planet dari Matahari: Merkurius, Venus, Bumi, Mars, Jupiter, Saturnus, Uranus, Neptunus; peristiwa menurut tahun) dicari lewat web lalu dicatat dengan `Fakta.add_urut`, dan SEBELUM digambar atau ditulis, urutan yang dipakai dicocokkan dengan `Fakta.cek_urut(kunci, dipakai)` (hasilnya posisi yang salah, yang hilang, dan sumbernya). Klasifikasi: `add_kelas` + `cek_kelas` (mis. Mars termasuk planet dalam). Hubungan beraturan (mengorbit, bagian dari, sebab-akibat): `add_relasi` + `cek_relasi`. Pola deret angka yang disebut di script diperiksa dengan `Fakta.cek_pola` (aritmetika, geometri, bergantian, dan suku berikutnya). Urutan atau pola yang salah diperlakukan sama dengan ketidaksesuaian fakta (aturan 6).
10. **Planet dan tata surya (`universe_kit.py`).** Bentuk, warna, ukuran, dan posisi planet tidak digambar dari ingatan: ukuran, rotasi, kemiringan sumbu, jumlah bulan diambil dari lembar fakta NASA, posisi dari unsur orbit JPL (`posisi(nama, (tahun, bulan, hari))`, valid 1800-2050), warna dari sumber yang menjelaskannya (`WARNA_U`, dua gaya: `asli` = tampak mata manusia, `populer` = gaya gambar umum, mis. Neptunus biru tua). Gambar lewat `draw_planet` (merkurius, venus, bumi, mars, jupiter, saturnus, uranus, neptunus, bulan, matahari), tampilan sistem lewat `draw_sistem` (WAJIB menyebut "skala jarak tidak sebenarnya" bila `mode="seni"`), ukuran sebanding lewat `banding_ukuran`, fakta narasi lewat `info`, dan muat semua fakta beserta sumber ke lembar fakta dengan `fakta_universe(fk)`. Corak halus (kawah, awan, pita) adalah tekstur prosedural yang mengikuti deskripsi sumber, BUKAN foto atau peta asli; jangan menyebutnya peta. Yang berasal dari ingatan dan belum dicari (jari-jari cincin Uranus, pemipihan kutub, posisi lautan Bulan, warna asli Matahari) berstatus belum-terverifikasi di lembar fakta, jadi `Fakta.pakai` menolaknya sampai dicari dulu. `universe_selfcheck()` membuktikan kodenya: hukum Kepler ketiga, urutan jarak, lima oposisi nyata (Mars 2025-01-16, Saturnus 2025-09-21, Jupiter 2024-12-07, Uranus 2025-11-21, Neptunus 2025-09-23), dan rasio Jupiter/Bumi sekitar 11. **Status verifikasi data luar angkasa (dicatat jujur):** unsur orbit JPL (96 angka) sudah dibandingkan ulang dengan halaman resmi pada 2026-11-07 (tabel 1, valid 1800-2050) dan semuanya sama; lembar fakta NASA (ukuran, rotasi, kemiringan, bulan) sudah dibaca ulang pada hari yang sama. Bila pencarian atau halaman NASA/JPL terkena pembatasan laju (rate limit) atau gagal dibuka, statusnya "menunggu verifikasi ulang sampai waktu yang dicatat" dan TIDAK BOLEH mengklaim data luar angkasa sudah terverifikasi penuh sebelum verifikasi ulang berhasil; tulis status itu di lembar fakta dan di laporan akhir, jangan mengisi dari ingatan.

**Batas jujur:** kode `universe_kit` (bagian Bumi) diuji dengan data peta sintetis (proyeksi, decode TopoJSON, luas, render); data Natural Earth asli tidak bisa diunduh dari sandbox yang dipakai menguji, jadi jalankan `geo_selfcheck` pada data yang benar-benar dipakai.

### 6.6 Sinkronisasi voice over otomatis

**Aktif otomatis** di Cara 1, 2, dan 3 bila ada voice over. Semua dihitung sendiri. DILARANG meminta user mengirim timestamp, transkrip, atau suara ulang; laporkan hanya bila suaranya benar-benar tidak bisa dipakai (kosong, rusak).

**Langkah:**

1. **Ukur:** `load_audio`, `speech_segments` (celah napas dari RMS 20 ms), `probe_dur`.
2. **Petakan kalimat:** `align_sentences(kalimat_script, segs)` memberi waktu nyata tiap kalimat, berapa pun jumlah segmen suara (suku kata + menempel ke celah napas).
3. **Durasi suara lebih panjang atau pendek dari video:**
   - Durasi tidak dikunci user (umumnya Cara 2): video mengikuti suara. `video_len_for(vo)` memberi panjang video, `scene_cuts(aligned, groups, total)` memotong adegan di TENGAH celah antar kalimat.
   - Durasi dikunci (mis. "40 detik") atau video sudah ada: `fit_voice(src, dst, target)`. Urutannya: celah antar frasa diskalakan (0,2 sampai 0,9 detik), lalu tempo diubah paling banyak 8 persen (`atempo`, nada tetap), dan sisanya DILAPORKAN (`sisa`). Bila `sisa` masih lebih dari 0,5 detik, videonya yang menyesuaikan (tahan adegan penutup atau pendekkan). Jangan mempercepat lebih dari 8 persen, jangan memotong ucapan, jangan mengubah gain.
   - Cara 1 dengan suara buatan AI: tulis narasi sesuai durasi (2,3 sampai 2,8 kata per detik), buat suaranya, lalu `fit_voice`.
4. **Durasi pas tapi suara tidak pas dengan yang berbicara:**
   - Dialog: `assign_speakers([(pembicara, teks), ...], segs)` lalu `speaker_at(lines, t)`: hanya pembicara aktif yang membuka mulut; karakter lain diam atau mendengarkan.
   - Mulut: `mouth_env(y, fps, nframes)` jadi bukaan mulut tiap frame.
   - Subtitle: `make_cues` dari `align_sentences` (waktu suara nyata, bukan perkiraan script).
   - Ikon, efek, dan SFX terikat ke kata lewat `word_times`.
5. **Cara 3:** hitung di workspace dengan Python, simpan ke `sync.json`, JS membaca angkanya; audio akhir dicampur di workspace.
6. **Cek wajib:** `probe_dur(video)` sama dengan audio (selisih paling banyak 0,05 detik); `sync_audit(cues, segs)["lolos"]`; `mouth_check` dengan korelasi minimal 0,6 dan `diam_saat_suara` paling banyak 0,05; `mean_volume` suara sama dengan file asli; lihat frame saat ucapan dimulai.
7. **Batas jujur:** tanpa ASR (cek `import whisper` atau `faster_whisper`), kecocokan ada di tingkat kalimat, bukan kata per kata; salah ucap hanya bisa dikoreksi bila ada ASR. Katakan itu di laporan.

**Kode contoh:**

```python
y = F.load_audio(VO); segs = F.speech_segments(y)
al = F.align_sentences(KALIMAT, segs)                       # waktu nyata tiap kalimat
r = F.fit_voice(VO, "vo-pas.wav", target=DUR)               # hanya bila durasi video dikunci
if abs(r["sisa"]) > 0.5: DUR = r["hasil"]                   # video yang menyesuaikan
segs = r["segs_baru"]; al = F.align_sentences(KALIMAT, segs)
dur_adegan = F.scene_cuts(al, [2, 1, 2], DUR)
CUES = F.make_cues(al); env = F.mouth_env(F.load_audio("vo-pas.wav"), FPS, int(DUR * FPS))
print(F.sync_audit(CUES, segs))
```

### 6.7 Gerbang audit wajib sebelum render final (satu tempat)

Semua audit dikumpulkan di `audit.Gerbang`; render final (ffmpeg terakhir, kirim video penuh) DITOLAK bila ada audit wajib yang belum dijalankan atau gagal. Daftar wajib mengikuti fitur yang dipakai:

- **Selalu:** `motion_report` (tidak ada jendela mati), `Sfx.audit()` (variasi SFX), `komposisi_audit` (objek menapak, landmark utuh dan tidak tertimpa, 6.10), dan `tekan_audit` (penekanan kata, 6.9). Video tanpa objek berdiri dan tanpa kata kunci tetap mencatatnya dengan daftar kosong (lolos).
- **Karakter:** `luwes_audit`, `proporsi_audit`, `wajah_audit` (6.3).
- **Voice over:** `sync_audit` (subtitle terhadap suara) dan, bila karakter berbicara, `mouth_check`.
- **Pencahayaan diminta:** `light_check`. **Bumi atau negara:** `geo_selfcheck`. **Planet:** `universe_selfcheck`.

```python
g = audit.Gerbang(karakter=True, suara=True, geo=False, universe=False, komposisi=True, tekan=True)
g.jalankan("luwes_audit", ...)   # atau g.catat("sync_audit", lolos, ringkas)
g.periksa()                      # raise GerbangGagal bila ada yang BELUM DIJALANKAN atau GAGAL; panggil sebelum ffmpeg final
```

`g.laporan()` memberi LOLOS, GAGAL, atau BELUM DIJALANKAN per audit; salin ke laporan akhir. Jangan mengklaim audit yang tidak dijalankan.

### 6.8 Kata dan frasa bermakna luas wajib punya visual konkret

Frasa seperti "keanekaragaman Indonesia", "keberagaman Indonesia", "kebudayaan Indonesia" mencakup banyak arti, visual, warna, dan bentuk. Frasa itu BUKAN hanya teks. Setiap kali naskah atau teks layar memuat kata atau frasa bercakupan luas, tampilkan elemen konkret yang mewakilinya, di kedua gaya.

- "Keanekaragaman" atau "keberagaman Indonesia": suku, ragam budaya, pakaian adat, rumah tradisional, bahasa daerah, dan sejenisnya, dalam beberapa elemen berbeda yang bergantian.
- "Kebudayaan Indonesia": batik, tenun, rumah adat, tari tradisional, alat musik, makanan khas, upacara adat, dan sejenisnya.
- Berlaku untuk SEMUA frasa luas, bukan hanya tiga contoh itu. Contoh lain: "teknologi", "alam", "sejarah", "olahraga", "musik".
- Teks boleh ada, tetapi harus disertai elemen visual konkret; jangan hanya menampilkan teks.
- Elemen yang dipilih relevan dengan konteks, akurat secara fakta, dan mengikuti verifikasi fakta 6.5 (nama dan asal daerah tiap elemen dicek lewat pencarian web dan dicatat di `fakta.py`). Orang dan budaya digambar dengan hormat sebagai siluet atau ilustrasi flat umum, bukan karikatur.
- Bila elemen konkret tidak bisa ditampilkan (data atau referensi tidak ada), tulis alasannya di laporan; jangan menggantinya diam-diam dengan teks saja.

### 6.9 Penekanan kata (WAJIB, kata kunci jangan tampil seperti teks biasa)

Bila ada kata atau frasa kunci yang menjelaskan atau menuntut penekanan dalam sebuah kalimat, alihkan perhatian penonton ke kata itu. Contoh: pada "Jangan merokok", kata "Jangan" harus diberi penekanan khusus. Berlaku untuk subtitle dan teks layar, di kedua gaya utama dan di semua gaya visual.

- **Metode:** `stabilo` (latar warna aksen seperti penanda), `garis` (garis bawah), `warna` (huruf berwarna aksen), `tebal` (huruf ditebalkan plus garis bawah), atau efek visual lain yang jelas membedakan kata itu dari teks di sekitarnya (ganti jenis font hanya lewat aturan font 7.7, dengan alasan). Pilih satu metode utama per video yang cocok dengan gaya visual (`gaya(nama)["tekan"]`) dan pakai konsisten.
- **Cara menandai:** bungkus kata dengan tanda bintang di teks cue atau teks layar: `*Jangan* merokok`, atau frasa `*sangat berbahaya*`. Penanda dibuang sebelum dibacakan: `naskah_bersih` dan file narasi bersih tidak boleh berisi tanda bintang. `make_cues` menjaga penanda yang melintasi dua cue.
- **Berapa banyak:** paling banyak 2 kelompok per kalimat, paling banyak 3 kata per kelompok, dan tidak lebih dari 60 persen kata dalam kalimat (semua ditekan berarti tidak ada yang menonjol). Kalimat yang berisi angka atau kata penting (jangan, tidak, bukan, hanya, wajib, bahaya, awas, dilarang, selalu, harus, gratis, terakhir, pernah) WAJIB punya minimal satu kata bertanda.
- **Di subtitle:** kata kunci ditekan sejak diucapkan sampai cue habis, sebelumnya tampil biasa. Warna kata yang sedang diucapkan (7.2) tetap berlaku untuk kata lain.
- **Alat:** `draw_subtitle(..., tekan="stabilo", ink=...)`, `draw_kalimat_tekan(img, "Kalau *tidak* dijaga ...", cx, cy, px, fg, aksen, metode)` untuk teks layar, `tandai_kata`, dan audit `cek_tekan(daftar_kalimat)` yang dicatat ke gerbang sebagai `tekan_audit` (6.7).

### 6.10 Komposisi aman: objek menapak, landmark utuh, tidak tertimpa

Kesalahan nyata pada video "Keindahan Indonesia" (2026-11-07), penyebabnya kode gambar, bukan renderer: (a) pohon palem pada adegan sawah terasering digambar di koordinat tetap, tidak menempel pada tepi teras dan sebagian tertimpa lapisan teks, jadi tampak melayang; (b) Borobudur tampak setengah: baris stupa ditaruh di tinggi yang tidak sama dengan atap tingkatnya sehingga sebagian melayang di luar siluet, teras bundar di bagian atas tidak digambar, dan dasarnya terpotong rata oleh lapisan tanah gelap dan scrim teks. Bug itu hanya dicatat sebagai pengingat; videonya tidak direvisi atas permintaan user. Aturan agar tidak terulang:

1. **Objek berdiri harus menapak.** Pangkal pohon, tiang, rumah, atau orang dihitung dari fungsi permukaan yang SAMA dengan yang digambar (garis tanah, tepi teras, atap tingkat), bukan angka tebakan, dan diberi bayangan kontak kecil. Cek dengan `audit.cek_menapak(pangkal, permukaan_y, toleransi)`.
2. **Bangun landmark dari bagian aslinya.** Daftar bagian (tingkat, teras, atap, menara) diambil dari sumber terverifikasi (6.5), digambar lengkap dari dasar sampai puncak; elemen kecil (stupa, jendela, tiang) mengikuti garis bagian induknya.
3. **Hitung kotak objek utama dari titik gambarnya** (min dan maks koordinat) dan daftar zona yang digambar di atasnya (scrim teks, kotak teks, bar equalizer, HUD, subtitle, tanah depan). `audit.cek_komposisi(kotak, zona_terlarang)` harus lolos: objek utuh di layar dan tidak tertimpa. Rancang zona seni aman sejak awal; teks dan scrim hanya di luar zona itu.
4. **Lihat frame ukuran penuh dan potong (crop) objek utamanya** untuk setiap adegan; lembar kontak kecil menyembunyikan bug seperti ini.
5. Catat hasilnya ke gerbang sebagai `komposisi_audit` (6.7).

## 7. Fitur HANYA bila diminta

### 7.1 Timer dan penjelasan kejadian

**Pemicu utama: nama fitur, yaitu kata "timer". Variasi lain yang jelas bermaksud sama juga dikenali, mis.:**

- "bagaimana jika ..." (juga "bagaimana kalau", "what if"), contoh: "bagaimana jika setiap 2 detik bumi makin membesar" dan "bagaimana jika bumi kehilangan listrik selama 1 menit".
- "setiap N detik terjadi ...", "selama N menit", "... dalam N detik".
- AI juga boleh memakainya sendiri di video yang jelas cocok (fakta sains, peringatan, kejadian yang akan datang). Jangan dipakai bila tidak relevan.

**Isi timer:** selalu teks murni lewat `draw_timer_teks` (bagian 7.7): penjelasan di atas, angka `m:ss.mmm` (lebar tetap, tidak bergoyang) di tengah, keterangan kecepatan (mis. "Dipercepat 5x", "Diperlambat 11x") di bawah, lalu dampak berupa kalimat akibat. Tanpa latar, blok, kotak, atau panel. Subtitle narasi di bawah-tengah terpisah dari timer.

**Posisi (6):** `kiri-atas`, `tengah-atas`, `kanan-atas`, `kiri-tengah`, `tengah`, `kanan-tengah`.

- Bila user menyebut posisi, ikuti persis. Bila tidak: `tengah-atas` (vertikal).
- Pilih posisi yang tidak menutupi wajah, objek utama, atau teks lain. Bagian bawah-tengah dipakai subtitle, jangan ditempati timer.
- Setelah render, lihat frame: bila timer menutupi subjek, geser posisi atau kecilkan `scale`.

**Mode:**

- **Hitung mundur** ke kejadian: `timer_value(t, start, end=T)`.
- **Hitung naik:** `timer_value(..., up=True)`.
- **Berulang "setiap N detik":** `timer_value(t, start, every=N)`; angka reset tiap kejadian, nomor kejadian `int((t - start) // N)`.
- **Multi-fase:** `timer_plan(t, plan)` dengan `plan = [(t0, t1, v0, v1, label, sub), ...]`; nilai bergerak linear dari v0 ke v1 selama t0..t1 (detik video), dan `{x}` di keterangan diganti kecepatan waktunya.

**Contoh 1: "bagaimana jika setiap 2 detik bumi makin membesar".**

- Mode `every=2`. Label `BUMI MEMBESAR DALAM`, keterangan `UKURAN BUMI +25% TIAP KEJADIAN`.
- Tiap kali angka mencapai nol terjadi kejadian nyata: bumi membesar (skala dikali 1,25 dengan easing overshoot), SFX `pop` + `boing`, sedikit getar kamera. Gunakan nomor kejadian sebagai pangkat skala.

**Contoh 2: "bagaimana jika bumi kehilangan listrik selama 1 menit".**

- **Fase 1 (timeout sebelum kejadian):** 5 detik hitung mundur ke padam (default 5 detik bila user tidak menyebut), mis. `(0, 5, 5, 0, "LISTRIK PADAM DALAM", "SELURUH LISTRIK DI BUMI MATI")`.
- **Kejadian di detik nol:** layar atau kota menjadi gelap, SFX `impact`, efek karakter (kaget).
- **Fase 2 (sesudah kejadian):** durasi persis sesuai permintaan, mis. 1 menit: `(5, 17, 60, 0, "LISTRIK KEMBALI DALAM", "WAKTU DIPERCEPAT {x}X")`. Video menampilkannya 12 detik, jadi waktu dipercepat 5x dan keterangan terisi otomatis. Bila durasi kejadian muat di video, pakai 1x.
- **Saat nol di fase 2:** kejadian pemulihan (lampu menyala kembali, `ding`).

**Aturan lain:**

- Angka memerah di 3 detik terakhir (`hot_below`). Sembunyikan atau ganti timer saat pergantian adegan.
- Dengan voice over (Cara 2): timer mengikuti timeline suara; jatuhkan kejadian pada kata yang relevan.
- Cara 3 (tanpa font): render huruf dan angka yang dipakai (A-Z, 0-9, `:` `.` spasi) di workspace dengan Pillow menjadi mask 1-channel, simpan sebagai base64 di dalam JS, dan gambar per karakter (angka lebar tetap). Uji dengan `--preview` sebelum dikirim.

### 7.2 Subtitle (wajib mengikuti voice over)

**Pemicu utama: nama fitur, yaitu kata "subtitle"** ("pakai subtitle", "dengan subtitle", "tolong gunakan subtitle" semuanya cukup). Variasi lain yang jelas bermaksud sama juga dikenali: permintaan menampilkan teks ucapan di layar, mis. teks narasi, caption, takarir, "kasih teks di bawah", atau ungkapan lain yang tidak terduga.

**Wajib mengikuti voice over:**

- Teks subtitle diambil dari script yang BENAR (bukan salah ucap), sama persis dengan narasi bersih.
- Waktu tiap frasa diambil dari audio (celah napas, bagian 8 Cara 2, atau transkripsi bila ada tool-nya). Waktu tiap kata ditaksir sebanding suku kata, jadi bilang jujur bahwa sinkron per frasa terukur dan per kata ditaksir.
- Bila voice over belum ada (Cara 1), subtitle mengikuti jadwal narasi di script; begitu suara diberikan, waktu dihitung ulang dari audio.

**Tampilan (keren, kece, aesthetic, sesuai gaya dan warna video):**

- Pilih gaya subtitle yang cocok dengan gaya video:
  - `pill`: kartu berwarna palet dengan kata yang sedang diucapkan beraksen. Untuk flat animation, kartun, edukasi, iklan (default).
  - `serif`: gradien gelap tipis di bawah, tampilan sinematik; kata yang sedang diucapkan berwarna aksen. Untuk sains, dokumenter, dan video bernuansa gelap (seperti gaya referensi user).
  - `pop`: kata muncul satu per satu, tebal dengan outline. Untuk konten energik dan iklan cepat.
- **Kata yang sedang diucapkan berwarna, kata lain putih (di pill, serif, dan pop):** pada "Kopi hangat", saat "Kopi" diucapkan hanya "Kopi" yang berwarna aksen dan "hangat" putih; saat "hangat" diucapkan hanya "hangat" yang berwarna dan "Kopi" kembali putih. Teruji untuk ketiga gaya (tes 40). Kata kunci bertanda `*kata*` mengikuti 6.9: ditekan sejak diucapkan sampai cue habis.
- Warna ikut palet video: `bg` = warna tergelap palet, `fg` = warna terterang, `accent` = warna aksen palet. Kontras teks terhadap latar minimal 4,5:1. Palet neon: aksen neon di atas latar gelap.
- Maksimal 4 kata per cue (`make_cues(segments, max_words=4)`), tanpa koma atau titik di ujung, fade masuk dan keluar singkat, teks mengecil otomatis bila terlalu lebar.
- **Area subtitle:** rancang layout adegan sejak awal dengan zona subtitle kosong. 9:16: `pos` sekitar 0,80-0,88 (di atas zona UI platform); 16:9: sekitar 0,86. Pastikan tidak menabrak karakter atau ikon, lalu lihat frame tiap adegan.

**Font subtitle:** font awal WAJIB AnthropicSerifWebText (`draw_subtitle` memakainya otomatis). Boleh dan disarankan diganti HANYA bila tidak cocok dengan visual atau warna video (kontras kurang, terlalu tipis atau tebal, mengganggu keterbacaan), lewat `font=` dan `font_alasan=` dengan berkas yang benar-benar ada (aturan lengkap di 7.7). Tidak ditemukan berarti ditolak, tidak diganti diam-diam. Gaya `serif`, `pill`, dan `pop` hanya mengatur tata letak dan warna, bukan jenis huruf.

**Cek sinkron:**

- Subtitle tidak tampil di tengah jeda panjang (0,5 detik atau lebih), dan setiap titik ucapan punya subtitle.
- Lihat frame di beberapa kata kunci dan pastikan teks yang tampil = yang sedang diucapkan.

### 7.3 Transisi (hanya bila diminta)

**Default: tanpa transisi bergaya.** Pergantian adegan memakai potong bersih atau crossfade pendek (aturan umum nomor 5).

**Bila user meminta transisi (pemicu utama: kata "transisi"):**

1. **Standar kualitas, bukan gaya "CapCut gratisan".** Hindari: putar atau spin, glitch murahan, flash putih berlebihan, zoom blur generik, wipe berbentuk bintang atau hati, mengganti jenis tiap adegan. Pilih transisi yang bermotif: berasal dari objek atau gerak di video (benda yang keluar layar menyapu adegan berikutnya, iris dari objek, push searah gerak), satu bahasa transisi yang konsisten, easing cosinus, 0,4-0,7 detik.
2. **Preview dulu.** Buat klip 3-5 detik dan tampilkan Kartu 3 (bagian 4). Hanya setelah "Pakai transisi ini", terapkan ke seluruh video.
3. **Jenis tersedia** lewat `transition(kind, a, b, p)`: `fade`, `slide`, `wipe`, `iris`. Jenis lain boleh dibuat bila lolos standar kualitas.
4. **SFX transisi:** `whoosh` halus (`fade` memakai `f_hi=2500`; `slide` dan `wipe` memakai `up=True`; `iris` memakai whoosh + `pop` saat lingkaran penuh), mulai sekitar 0,05 detik sebelum transisi, jatuh di jeda narasi.
5. **Cek:** lihat frame di p = 0,5 dan pastikan tidak ada flash hitam atau elemen terpotong.

### 7.4 Hook Improvement (hanya bila diminta)

**Aturan penggunaan:** hanya dipakai ketika user memintanya. Pemicu utama: kata "hook" dengan maksud memperbaiki, merapikan, atau meningkatkan hook yang sudah ada (menyebut hook saat meminta script baru belum berarti minta perbaikan). JANGAN mengubah hook secara otomatis, termasuk saat membuat script atau video biasa.

**Tujuan:** hook lebih menarik, efektif, natural, dan mampu mempertahankan perhatian penonton.

**Ketentuan:**

- Perbaiki hook yang terlalu berlebihan, terlalu agresif, memaksakan perhatian, atau clickbait yang menyesatkan dan tidak sesuai dengan isi video.
- JANGAN membuat hook makin clickbait, sensasional, berlebihan, atau menyesatkan.
- Bila hook sudah bagus (menarik, natural, dan menjelaskan isi video dengan baik), PERTAHANKAN tanpa perubahan yang tidak diperlukan, dan katakan terus terang bahwa hook sudah bagus.
- Utamakan kejelasan pesan, daya tarik, relevansi, dan kesesuaian dengan isi video.
- JANGAN mengubah maksud atau informasi utama dari hook asli.

**Cara kerja:**

1. Baca hook asli (kalimat pembuka narasi atau teks dan visual pembuka) bersama isi videonya.
2. Nilai: apakah sesuai isi video, apakah berlebihan atau memaksa, apakah pesannya jelas.
3. Hasil: bila perlu diubah, tampilkan hook asli, hook perbaikan, dan alasan singkat. Bila tidak perlu, tulis "dipertahankan" beserta alasannya.
4. Bila hook berubah: perbarui script, narasi bersih, dan jadwal adegan. Di Cara 2 (voice over milik user) minta suara baru untuk kalimat yang berubah; visual boleh disesuaikan sendiri. Jangan mengganti isi audio user diam-diam.

### 7.5 Video Effects (20 efek, hanya bila diminta)

**Aturan penggunaan:** hanya dipakai ketika user memintanya. Pemicu utama: kata "video effect" (atau "video effects") dan/atau nama efek dari daftar di bawah, mis. "gunakan video effects Orbit". Bila hanya menyebut "video effect" tanpa nama efek, tanyakan efek mana dari 20 daftar. Ungkapan lain yang jelas bermaksud sama juga dikenali. JANGAN menerapkan Video Effects secara otomatis.

**Sumber kebenaran: video referensi.** Video referensi adalah acuan utama untuk memahami tampilan dan cara kerja tiap efek. Implementasi harus meniru efek di video referensi, bukan sekadar memakai namanya atau membuat animasi sederhana yang mirip konsepnya.

**Daftar 20 efek (deskripsi dari user, tetap dan tidak boleh diubah):**

1. **Orbit:** efek pergerakan elemen mengelilingi subjek dengan komposisi visual yang dinamis.
2. **Chat Takeover:** tampilan antarmuka percakapan mengambil alih layar dan menjadi elemen utama dalam video.
3. **Frame Escape:** efek subjek yang terlihat keluar atau menembus batas frame.
4. **Snap Zoom:** perbesaran kamera secara cepat dan tegas untuk memberikan penekanan pada subjek.
5. **Checklist Pop:** elemen checklist muncul secara bertahap dengan animasi pop.
6. **Headline Storm:** kumpulan headline atau teks bergerak dan bertumpuk secara dinamis memenuhi komposisi video.
7. **Zoom Portal:** efek portal visual yang menghubungkan subjek dengan tampilan atau lapisan visual lainnya.
8. **Growth Curve:** animasi grafik pertumbuhan dengan garis kurva yang bergerak dan berkembang.
9. **Studio Reveal:** efek pengungkapan suasana studio dengan elemen pencahayaan dan tampilan siaran.
10. **B-Roll Overlay:** menggabungkan footage tambahan sebagai lapisan visual di atas video utama.
11. **Paper Cutout:** efek subjek yang dipisahkan dari latar belakang dan dikomposisikan seperti potongan kertas.
12. **Dolly Zoom:** efek perubahan perspektif dengan pergerakan zoom dan penyesuaian skala latar belakang.
13. **Magazine Cover:** mengubah komposisi video menjadi tampilan sampul majalah dengan tipografi dan elemen editorial.
14. **Liquid Glass:** efek material kaca transparan dengan distorsi dan tampilan reflektif.
15. **Zoom Through Cut:** transisi zoom yang bergerak menembus satu adegan menuju adegan berikutnya.
16. **Green Screen:** menggunakan latar hijau untuk memisahkan subjek dan menggantinya dengan latar visual lain.
17. **Frame Break:** efek visual seolah-olah frame pecah atau terbelah dengan elemen yang keluar dari batas komposisi.
18. **Digital Zoom:** perbesaran digital yang memberikan penekanan pada bagian tertentu dari video.
19. **Phone Mockup:** menampilkan konten di dalam mockup perangkat smartphone.
20. **Checklist:** menampilkan daftar checklist dengan susunan elemen dan animasi yang terorganisasi.

**Bila video referensi TIDAK tersedia atau tidak bisa dibuka:**

1. JANGAN mengarang detail visual (bentuk, timing, easing, layering) dari nama efek saja.
2. Minta user mengunggah video referensi efek itu, atau memberikan deskripsi acuan, SEBELUM membuat efeknya.
3. Bagian video lain yang tidak memakai efek itu boleh dikerjakan lebih dulu; sebutkan jelas efek mana yang menunggu referensi.
4. Cek dulu di percakapan dan di folder project apakah referensi sudah pernah dilampirkan; bila ada, pakai itu tanpa bertanya lagi.

**Bila video referensi tersedia:**

1. Ambil frame dengan `ffmpeg` (rapat di sekitar momen efek) dan baca durasi, ritme, dan urutan kejadiannya.
2. Catat dari referensi: timing, easing, transisi, layering (urutan tumpukan), masking, komposisi, dan pergerakan elemen. Simpan ringkasannya di `efek/<nama-efek>.md` di folder project supaya efek bisa direproduksi konsisten.
3. Bangun efeknya mengikuti catatan itu, bandingkan frame hasil dengan frame referensi, dan perbaiki yang meleset.
4. Bila ada bagian yang tidak bisa direplikasi persis (mis. footage asli di referensi), katakan di laporan, jangan diganti diam-diam.

**Ketentuan implementasi:**

- Pertahankan karakteristik visual tiap efek sesuai video referensi.
- Perhatikan detail animasi, timing, easing, transisi, layering, masking, komposisi, dan pergerakan elemen.
- Setiap efek punya karakter sendiri, bukan variasi dari satu animasi yang sama.
- Kualitas tinggi, halus, profesional, dan konsisten dengan palet dan gaya video.
- Efek harus bisa diterapkan pada video sesuai kebutuhan dan konteksnya, dan tidak menabrak area subtitle atau timer bila dua fitur itu juga dipakai.
- Jangan menghilangkan, menggabungkan, atau mengganti salah satu dari 20 efek.
- Jangan mengarang efek tambahan sebagai pengganti efek dari referensi.
- Jangan menambah efek di luar 20 efek ini kecuali user memintanya dengan jelas.
- Efek tidak menggantikan fitur wajib: SFX dan ekspresi karakter tetap ada. Efek yang berupa transisi (mis. Zoom Through Cut) dianggap permintaan eksplisit karena user menyebut namanya; transisi bergaya lain tetap mati kecuali diminta.

**Status kode (`efek_video.py`):** `daftar()` memuat manifest 20 efek (nama, deskripsi tetap, primitif, status). Tersedia perangkat dasar: `kamera` (zoom digital), `kurva_snap`, `dolly`, `zoom_tembus`, `kunci_hijau` (Green Screen), `maske_subjek` (segmentasi subjek dari latar datar), `potong_kertas`, `kaca_cair` (kaca/cair dengan pembiasan, kilau, aberasi), `pecah_frame`, `ponsel`, `garis_tumbuh`, `centang`, `orbit_pos`, serta `Layer` dan `komposit` (mode normal, multiply, screen, add). 13 efek sudah punya perender dan 7 (Chat Takeover, Frame Escape, Headline Storm, Zoom Portal, Studio Reveal, B-Roll Overlay, Magazine Cover) baru berupa primitif; susunannya wajib mengikuti referensi. `terapkan(slug, ...)` menolak bila user belum memintanya (`IZIN`) atau catatan `efek/<slug>.md` belum lengkap (timing, easing, layering, masking, komposisi, gerak, plus blok ```json parameter); parameter perender dibaca dari catatan itu, bukan ditebak. Perangkat dasar boleh dipakai bebas karena hanya alat, bukan keputusan visual.

**Format hasil** mengikuti kebutuhan user: deskripsi visual, instruksi editing, prompt untuk video generator, langkah implementasi, atau video jadi bila memang diminta membuat video. Jangan menganggap "implementasi" sebagai eksekusi teknis bila konteksnya tidak meminta demikian.

### 7.6 Watermark pintar (hanya bila diminta)

**Pemicu: kata "watermark".** Isi watermark = teks atau gambar yang disebut user. Bila user tidak menyebut isinya, pakai dugaan terbaik dari konteks (nama channel atau produk), katakan itu di laporan, dan jangan menahan pekerjaan.

Tujuan: penonton tidak terhalang dan tidak teralihkan dari video. Aturan:

- **Kecil dan tenang:** tinggi paling banyak 4 persen tinggi layar (vertikal), opacity 0,55 (otomatis 0,35 bila tempat terbaik pun masih ramai), statis (tidak bergerak, berkedip, atau berdenyut), muncul pelan 0,5 detik.
- **Letak:** satu posisi tetap di sudut area aman, bukan di tengah gambar. Zona antarmuka aplikasi dihindari (perkiraan konservatif: atas 12 persen, bawah 22 persen, sisi kanan bagian tengah-bawah untuk video vertikal; strip bawah 10 persen untuk landscape; ini bukan angka resmi platform).
- **Jangan di atas** subtitle, timer, chat bubble, wajah atau objek utama, dan area yang geraknya banyak.
- **Cara memilih:** render dulu adegan TANPA watermark, cuplik frame tiap 0,5 detik, lalu `place_watermark(frames, mark.size, ui="vertikal", reserved=[...])`. Tiap sudut dinilai dari gerak (persentil 95), keramaian tepi, dan kedekatan ke tengah; kotak terlarang dan zona antarmuka dilarang. Hasilnya posisi, warna (`tone` terang atau gelap menurut latar), dan opacity.
- **Gambar:** `draw_watermark(img, mark, (x, y), t, opacity)` di akhir `frame(t)`, sesudah semua overlay. Lihat satu frame hasilnya sebelum kirim.
- Tanpa permintaan, tidak ada watermark.

### 7.7 Timer teks murni (hanya bila diminta)

**Pemicu: kata "timer" (juga "bagaimana jika ...", lihat 7.1).** Timer SELALU berupa teks saja: tanpa latar, blok, kotak, atau panel (fungsi lama `draw_timer` dengan panel sudah dihapus dari kode). Jangan dipakai otomatis; pemicunya ditegakkan di kode (`IZIN`). Susunan dari atas ke bawah:

1. **Atas:** penjelasan singkat tentang apa yang akan terjadi.
2. **Tengah:** timer `m:ss.mmm` (angka lebar tetap).
3. **Bawah:** keterangan kecepatan waktu, mis. "Diperlambat 11x" atau "Dipercepat 10x" (`speed_label`); kosong bila waktu nyata (1x).
4. **Dampak:** di BAWAH keterangan kecepatan; bila kecepatan kosong, dampak naik jadi baris bawah.

**Penulisan dampak.** Dampak BUKAN label, BUKAN kata "dampak:", dan BUKAN frasa pendek yang menggantung. Dampak adalah KALIMAT AKIBAT yang menyambung dari kejadian dan menjelaskan konsekuensi lanjutannya secara utuh, dengan kata sambung seperti "sehingga", "karena", "akibatnya", "yang membuat", atau "lalu".

- SALAH: "dampak: menjadi panas", "dampak: Bumi meledak", "panas".
- BENAR: "merasakan panas karena El Nino", "Bumi meledak sehingga peradaban manusia punah".
- Bila kejadian hanya berdampak tunggal tanpa akibat lanjutan, tulis kalimat lengkap yang menjelaskan akibat itu, bukan kata sifat atau kata benda saja.
- `cek_dampak(teks)` menolak label "dampak:", akhiran menggantung, kurang dari 4 kata, dan kalimat tanpa kata sambung akibat; `draw_timer_teks` melempar galat bila dampak salah.

**Hierarki ukuran (`UKURAN_TIMER`, `cek_hierarki`):** Timer >= Penjelasan >= Kecepatan > Dampak. Angka timer paling besar; penjelasan boleh sama besar dengan timer tetapi tidak boleh lebih kecil dari kecepatan; kecepatan lebih kecil dari timer dan tidak lebih besar dari penjelasan; dampak lebih kecil dari kecepatan. Bila kecepatan kosong, dampak tetap paling kecil di antara baris yang ada. Teks panjang dibungkus ke baris berikutnya, bukan dikecilkan di bawah tingkatnya. Susunan rapi, mudah dibaca, konsisten.

- **Kecepatan harus benar:** pakai `timer_plan`; kecepatan = |v0 - v1| / (t1 - t0); `timer_speed(t, plan)` mengisi keterangan, jadi angka yang tampil dan kecepatan yang tertulis selalu sama. Timer berjalan sesuai kecepatan yang ditampilkan.
- **Warna teks** otomatis dari kecerahan latar. Bila sulit terbaca, pindahkan posisi atau ganti warna, bukan menambah kotak.
- Fungsi: `draw_timer_teks(img, "tengah-atas", penjelasan, nilai, speed, dampak)`.

**Font untuk timer dan subtitle (aturan baru):**

- **Font awal = AnthropicSerifWebText** (berkas `fonts/AnthropicSerifWebText.ttf`, dipasang user), untuk semua baris timer (angka, penjelasan, kecepatan, dampak) dan untuk subtitle. `anthropic_font(px)` mencarinya berdasarkan nama berkas, lalu env `ANTHROPIC_SERIF`, lalu font sistem "Anthropic ...".
- **Boleh dan disarankan diganti HANYA bila tidak cocok** dengan visual atau warna video: kontras kurang (di bawah 4,5:1), goresan terlalu tipis atau tebal, atau mengganggu keterbacaan. `font_cocok(font, fg, bg)` mengukurnya, dan `teks_font` mencatat saran di `fxlib.LAPORAN`.
- **Penggantian harus eksplisit dan jujur:** `font="<berkas atau nama>"` dengan `font_alasan="..."`. Penggantinya harus berkas yang benar-benar ada di `fonts/` atau font sistem terpasang (`font_tersedia()` mendaftarnya); JANGAN mengarang nama berkas (nama yang tidak ada ditolak). Pengganti tetap terbaca jelas dan konsisten dengan gaya video. Alasan penggantian wajib disebut di laporan akhir.
- **Bila AnthropicSerifWebText tidak ditemukan:** fungsi menolak (`FontAnthropicTidakAda`); JANGAN diam-diam memakai font lain. Katakan di kalimat pertama laporan, tahan bagian timer atau subtitle, dan tanyakan lewat kartu pilihan (satu kali): user menaruh berkasnya di `fonts/`, atau memakai font pengganti yang DITANDAI jelas, atau tanpa timer atau subtitle. Tanpa pengawasan: kirim tanpa elemen itu plus penjelasannya.
- Elemen lain (chat bubble, label, judul) memakai font sesuai gaya video; Anthropic Sans hanya bila berkasnya ada dan user memintanya (`anthropic=True` pada chat bubble; bila Sans tidak ada, bubble memakai AnthropicSerifWebText dan hal itu dicatat di `LAPORAN`).

### 7.8 Chat bubble non-full text (hanya bila diminta)

**Pemicu: "chat bubble".** Jangan dipakai otomatis. Bubble menyesuaikan isi dan TIDAK menutupi seluruh teks di layar.

- Isi hanya frasa kunci (paling banyak 9 kata; fungsi menolak lebih), lebar paling banyak 60 persen layar, ukuran mengikuti teks.
- Posisi dekat pembicara dan tidak menutupi teks utama atau elemen penting: `place_box(size, anchor, W, H, reserved, ui)`. Bila hasilnya `None`, persingkat teks atau kecilkan `scale`; jangan memaksa menutupi.
- **Saat narator menyebut "mengulang"** (juga "ulang", "diulang", "berulang"): tampilkan ikon loading (titik berputar) DI DALAM bubble. Waktunya dicari dari suara nyata: `find_words(aligned)` memberi (mulai, selesai, kata), lalu `draw_chat_bubble(..., loading=(mulai, selesai + 0.9))`.
- Muncul pop-in lalu keluar halus; `side="kiri"` atau `"kanan"` menentukan sisi ekor.

### 7.9 Pencahayaan dan bayangan (hanya bila diminta)

**Pemicu: "pencahayaan", "bayangan", "lighting", atau permintaan suasana visual tertentu (mis. senja, ruangan gelap dengan satu lampu).** Jangan diterapkan otomatis.

Prinsip: satu sumber cahaya untuk seluruh adegan (`Light(angle, intensity, ambient, spot)`), dipakai oleh semua subjek, objek, latar, dan elemen visual sesuai konteks.

- **Area terkena cahaya tetap terang.** Permukaan yang menghadap cahaya memakai warna aslinya (faktor 1,0); jangan digelapkan.
- **Area tidak terkena cahaya lebih gelap**, turun halus ke `ambient` (bukan hitam pekat, sedikit condong biru), dengan gradasi yang sama di semua objek.
- **Arah, intensitas, dan gradasi konsisten.** Jangan membuat bayangan yang bertentangan dengan sumber cahaya: `cast_shadow` selalu jatuh berlawanan arah dengan sumber cahaya, panjangnya mengikuti tinggi objek, warnanya tanah yang digelapkan.
- **Alat:** `lit_ball` (bola, planet, kepala), `lit_rect` (dinding, kotak, gedung), `light_col` (warna per permukaan), `cast_shadow` (bayangan jatuh), dan `light_pass` (lapisan cahaya untuk seluruh frame; arah, atau lampu titik dengan `spot=(x, y, radius)` untuk adegan gelap dengan satu lampu).
- **Cek:** `light_check(sebelum, sesudah, L)` harus lolos: sisi terang rugi paling banyak 3 persen, sisi jauh lebih gelap minimal 8 persen, gradasi searah (korelasi negatif). Lihat satu frame: tidak ada objek yang terang di sisi yang seharusnya gelap, dan semua bayangan searah.
- Efek lain tetap jalan: pencahayaan tidak boleh menutupi subtitle, timer, atau menurunkan keterbacaan teks.

### 7.10 Voice Over: langsung dan naskah bertag (hanya bila diminta)

**Aturan penggunaan:** voice over langsung MAUPUN naskah bertag hanya diaktifkan ketika user memintanya, termasuk lewat jawaban kartu 0.3 ("Instant Voice Over" atau "Manual Voice Over"; `IZIN`: `voice_over_langsung`, `voice_over_naskah`). Jangan diterapkan otomatis. Bagian ini berdiri sendiri dan tidak mengubah narasi bersih (bagian 5) yang selalu ada.

**1. Voice over langsung.** Suaranya harus natural, enak didengar, dan cocok sebagai narator. DILARANG suara yang terdengar seperti robot. Kenyataan yang dicek kode: `vo_langsung_tersedia()` mencari mesin suara neural; mesin robotik (flite, espeak, festival, sintesis formant sendiri) tidak dihitung dan DITOLAK. Di sesi ini tidak ada mesin neural dan layanan suara luar diblokir, jadi `vo_langsung` melempar `SuaraAlamiTidakAda`. Saat itu terjadi: katakan di kalimat pertama laporan bahwa voice over langsung yang natural tidak bisa dibuat di sini (jujur, tanpa menjanjikan), jangan memakai suara robot, lalu tawarkan naskah bertag (bagian 2) atau Cara 2 (user mengirim audionya). Bila suatu sesi punya mesin neural: buat contoh pendek, kirim ke user, dan baru terapkan ke seluruh video setelah user setuju; hasil wajib lolos `sync_audit`.

**2. Naskah voice over bertag dan saran suara.** Tulis file terpisah dari narasi bersih. Data platform di bawah dari dokumentasi resmi (dibaca 2026-11-07), jangan menambah nama suara atau tag dari ingatan.

- **ElevenLabs (kurung siku `[]`):** tag dibaca sebagai arahan performa (emosi, penyampaian, reaksi, tempo, aksen), BUKAN kata yang diucapkan. Contoh dari halaman resmi: `[whispers]`, `[shouts]`, `[softly]`, `[excited]`, `[sad]`, `[sighs]`, `[laughs]`, `[gasps]`, `[clears throat]`, `[pause]`, `[rushed]`, `[drawn out]`, `[panicking]`, `[surprised]`, `[British accent]`; halaman itu memberi contoh, bukan daftar tertutup (tag lain seperti `[curious]`, `[sarcastic]`, `[dramatic tone]` boleh dicoba tetapi berstatus belum terverifikasi di halaman resmi dan `cek_tag_eleven` menandainya). Indonesian didukung Eleven v3, Multilingual v2, dan Flash v2.5. Saran suara hanya dari 17 suara bawaan: untuk narasi Bill, Brian, George, Liam, Lily, Matilda; berita Alice, Daniel, Sarah; percakapan Charlie, Chris, Eric, Jessica; media sosial Laura, Will; karakter Callum, Charlotte. Semuanya beraksen asing; untuk logat Indonesia, sarankan mencari di Voice Library dengan filter bahasa Indonesia dan pratinjau dulu, jangan menyebut nama suara Indonesia yang tidak terverifikasi.
- **Google AI Studio (Gemini TTS), dua lapis kontrol:** (a) `speech_metadata.style` untuk gaya sepanjang satu giliran bicara, mis. "whispered urgently" atau "warm and enthusiastic"; WAJIB mendeskripsikan gaya narator yang cocok, mis. "A warm, professional narrator with clear articulation and a measured pace" (`gaya_google`); (b) tag dalam kurung sudut `<>` untuk kejadian sesaat: `<short pause>`, `<long pause>`, `<laugh>`, `<gasp>`, `<sigh>`, `<cough>`, `<breath>`, `<throat-clearing>`; dokumentasi menyarankan tidak memakai efek bunyi non-vokal. Jeda juga bisa lewat tanda baca (elipsis). Indonesian tercantum didukung (Gemini 3.8 Flash TTS dan Flash-Lite TTS). Saran suara hanya dari 30 suara bawaan beserta sifatnya, mis. Sulafat (Warm), Charon (Informative), Kore (Firm), Iapetus (Clear), Achird (Friendly), Zephyr (Bright), Puck (Upbeat).
- **Jangan tertukar:** ElevenLabs `[]`, Google `<>`. `cek_tag_eleven` dan `cek_tag_google` menolak kurung yang salah platform; `naskah_bersih(teks_bertag)` membuang semua tag untuk membuat narasi bersih yang sama persis kata per katanya.
- **Hasil:** `narasi-voice-over.txt` (bersih, tetap ada), `narasi-elevenlabs.txt` atau `narasi-google-ai-studio.txt` (bertag, plus gaya dan saran suara), dan satu blok kode per versi di chat. Tag diletakkan hemat dan tepat di kalimat yang butuh arahan.

## 8. Detail per cara

### Format script

Tabel per adegan di chat dengan kolom: nomor, waktu, visual, narasi (VO), dan pergantian adegan. Tambah kolom "Efek / SFX / Timer / Subtitle" hanya bila fitur itu dipakai.

- Kata narasi kira-kira durasi x 2,3 sampai 2,8 per detik (Bahasa Indonesia tempo normal), jeda 0,3-0,5 detik di pergantian adegan. Total waktu adegan pas dengan durasi yang diminta.
- Urutan di chat: tabel script, blok narasi bersih, catatan asumsi singkat (durasi, rasio, palet, apakah neon, supaya user tahu kartu mana yang menyusul), lalu Kartu 1.

### Cara 1: script, video, voice over

1. Tulis script sesuai jenis konten, nama produk atau topik, dan durasi.
2. Bangun video dari script itu. Implementasi yang terbukti: Pillow dengan supersampling 2x (gambar 2160x3840 lalu `reduce(2)`), tiap adegan sebuah fungsi `scene_n(t_lokal)`, `frame(t)` memilih adegan dan menumpuk overlay (timer, subtitle), `multiprocessing.Pool` dan pipe `rgb24` ke `ffmpeg -c:v libx264 -crf 18 -preset medium -pix_fmt yuv420p`. Buat contact sheet 12-24 frame dan lihat dulu sebelum render penuh (periksa outfit karakter, bagian 6.3, dan jalankan `motion_report`, bagian 6.4).
3. Buat voice over dengan tool apa pun yang tersedia dan bisa jalan, sinkronkan otomatis (6.6: pas-kan durasi, kalimat, subtitle, mulut), lalu campur SFX (6.1) dan gabungkan. Bila tidak ada TTS yang bisa jalan: ikuti aturan umum nomor 10.
4. Cek (aturan umum nomor 2). Bila neon, ikuti Kartu 2. Kirim.
5. Gagal: Cara 3.

### Cara 2: voice over dan script dari user

1. Baca script dan audio (`ffprobe`). Durasi adegan mengikuti audio; tambahkan 1-1,5 detik kartu penutup setelah suara selesai.
2. Cari waktu kalimat dan kata dengan kode bagian 6.6 (`load_audio`, `speech_segments`, `align_sentences`). Transkripsi dengan timestamp dipakai bila ada tool-nya; bila tidak ada, celah napas + suku kata sudah cukup untuk waktu tiap kalimat. Jangan meminta user mengirim timestamp atau transkrip.
   Rumus celah: celah 0,5 detik atau lebih biasanya batas adegan atau kalimat; 0,2-0,45 koma; di bawah itu antar kata.
3. Cocokkan pola celah dengan jumlah kalimat di script (`align_sentences` menangani jumlah yang berbeda) dan potong adegan di tengah celah (`scene_cuts`). Segmen ucapan = ruang di antara celah.
4. **Koreksi salah ucap:** bandingkan transkripsi dengan script; bila ada kata salah, hilang, atau berulang, buat daftar (waktu, yang terdengar, yang seharusnya). Visual dan teks mengikuti script yang benar. Jangan mengubah isi audio asli diam-diam; untuk kalimat salah, sarankan user membuat ulang kalimat itu. Bila tidak ada tool transkripsi, katakan di laporan bahwa pengecekan salah ucap otomatis tidak bisa dilakukan (sinkron tetap di tingkat kalimat); jangan mengaku sudah mengecek dan jangan menahan pekerjaan.
5. Ikat ikon, efek, SFX, timer, subtitle, dan mulut karakter ke kata yang diucapkan (6.6); fps sesuai permintaan (mis. 60).
6. Gabungkan audio asli apa adanya (mp3 ke `aac -b:a 256k`) bersama SFX via `Track.write`, pastikan `mean_volume` sama dengan aslinya, cek, kirim. Kartu 2 hanya bila neon.

### Cara 3: JS murni + perintah render

- Satu file `.js` (Node.js), tanpa Chromium, Puppeteer, atau Playwright. Utamakan tanpa dependensi native: gambar frame sendiri (rasterizer perangkat lunak sederhana) dan tulis frame mentah `rgba` ke stdout yang di-pipe ke FFmpeg. Bila butuh paket, tulis perintah pasangnya dan alasannya.
- Resolusi, fps, dan durasi jadi konstanta di atas file (bisa di-override argumen CLI). Ada opsi `--preview` yang hanya merender adegan pembuka. Tanpa ketergantungan font atau `drawtext`; teks (timer, subtitle) memakai mask huruf yang disematkan (lihat 7.1).
- SFX wajib: buat di workspace dengan kode bagian 13, campur dengan voice over (bila ada) menjadi `audio-final.wav`, kirim file itu bersama JS; perintah render tinggal menambah `-i audio-final.wav`.
- Sinkron suara (6.6) dihitung dengan Python di workspace dan disimpan ke `sync.json` (waktu ucapan, cue subtitle, durasi adegan, amplop mulut per frame); JS hanya membaca angka itu.
- Uji dulu di workspace (beberapa frame atau `--preview` singkat): tidak ada error dan frame tidak hitam.
- Kirim JS dengan `SendUserFile`, lalu perintah render sesuai nama file di blok kode (wajib):

```bash
# siapkan sekali (Termux): pkg install nodejs ffmpeg -y
# render penuh, tanpa suara
node nama-video.js | ffmpeg -y -f rawvideo -pixel_format rgba -video_size 1080x1920 -framerate 30 -i - -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -movflags +faststart nama-video.mp4

# render penuh, dengan audio (voice over + SFX yang sudah dicampur)
node nama-video.js | ffmpeg -y -f rawvideo -pixel_format rgba -video_size 1080x1920 -framerate 30 -i - -i audio-final.wav -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -shortest -movflags +faststart nama-video.mp4

# render preview adegan pembuka saja
node nama-video.js --preview | ffmpeg -y -f rawvideo -pixel_format rgba -video_size 1080x1920 -framerate 30 -i - -c:v libx264 -preset veryfast -crf 20 -pix_fmt yuv420p nama-video-preview.mp4
```

- Catat: file harus ada di folder tempat perintah dijalankan (Termux: `cd` ke folder itu; bila di penyimpanan HP, jalankan `termux-setup-storage` dulu).

## 9. Storyboard dan referensi

**Storyboard** adalah rancangan adegan demi adegan sebelum animasi dibuat: tiap panel berisi gambaran visual, gerakan tiap elemen, kamera atau transisi, durasi, dan narasi atau teks pendek.

- User boleh mengirim storyboard (teks, tabel, gambar), foto, atau video referensi. Bila ada, ikuti urutan adegan, komposisi, palet, ritme gerak, dan tata letak timer atau teks. Bila perlu menyimpang, bilang di laporan.
- Video referensi: ambil beberapa frame dengan `ffmpeg` untuk membaca palet, transisi, dan tempo.
- Prompt yang terlalu sederhana berisiko meleset; tetap kerjakan, cukup satu kalimat di akhir bahwa storyboard atau referensi bisa dikirim.

## 10. Contoh prompt user yang harus dikenali (bagian yang bisa diubah)

- **Cara 1:** "Bikinin script buat video flat animation motion graphic iklan produk pizzaku durasinya 40 detik aja" (ubah: jenis, nama produk, durasi, rasio). Lanjut: "Buatin video motion graphic flat animation untuk produk pizzaku ini. 9:16, full hd."
- **Cara 2:** "bantu buatkan script cerita untuk motion grafik tentang Nabi Musa membelah laut durasi 30 detik aja" (ubah: topik, durasi). Lanjut: "ini voice over dan scriptnya selanjutnya buatkan motion design 60 fps menggunakan voice over itu dan kalau ada suara yang salah ngomong tolong koreksi".
- **Cara 3:** "Tolong buatkan video animasi motion graphics berdasarkan naskah yang sudah saya berikan. Jangan masukkan semua teks ke layar ... file JS murni ... Termux ... perintah render sesuai nama file".
- **Timer:** "bagaimana jika setiap 2 detik bumi makin membesar", "bagaimana jika bumi kehilangan listrik selama 1 menit", "setiap 5 detik terjadi gempa, timer di kanan atas".
- **Subtitle:** "tolong gunakan subtitle", "dengan subtitle", "pakai subtitle".
- **Transisi:** "pakai transisi yang halus antar adegan".
- **Gaya utama dan gaya visual (0.2, 0.6):** "make a flat animation about coffee", "buat showreel kopi", "bold typography tentang tahun 1955", "blueprint explainer tentang lift", "terminal style tentang password", "isometric miniature kota". Kata kunci lengkap di 0.6.

## 11. Laporan akhir (singkat)

Satu atau dua kalimat hasil (apa yang jadi, gaya utama dan gaya visual yang dipakai beserta alasannya bila Claude yang memilih, durasi, rasio, fps), file dikirim dengan `SendUserFile` (video + `narasi-voice-over.txt` bersih bila relevan), lokasi folder project, hal yang tidak bisa dilakukan (belum ada suara, salah ucap tidak bisa dicek, sinkron kata ditaksir), satu kalimat soal ada atau tidaknya preview dan kartu, dan satu langkah lanjut bila ada. Bila ada hal nyata yang diverifikasi (6.5): daftar "Sumber:" berupa tautan dan butir yang belum terverifikasi. Bila ada kata kunci gaya yang Claude ganti (0.6): salin daftar terbaru (`daftar_kata_kunci()`). Bila ada voice over (6.6): satu kalimat hasil sinkron (durasi sudah pas atau disesuaikan, batas sinkron kata). Jangan menceritakan ulang langkah kerja.

## 12. Uji sebelum selesai

1. "Buatkan script video motion graphic tentang X": tabel script, blok narasi bersih tanpa detik atau label, catatan asumsi, dan Kartu 1.
2. "Lanjut buat full film" dengan palet non-neon: video penuh tanpa Kartu 2, dengan satu kalimat penjelasan di laporan, SFX ada, karakter berekspresi.
3. Palet neon: preview + Kartu 2 ("Lanjut film penuh" / "Revisi dulu"); sisa video belum dibuat.
4. Tidak ada TTS: video bersuara SFX tanpa voice over, `narasi-voice-over.txt` bersih, tawaran lanjut ke Cara 2.
5. Voice over dari user + SFX: voice over tidak berubah, SFX tidak menutupi ucapan, puncak di bawah -1 dBFS.
6. "Bagaimana jika bumi kehilangan listrik selama 1 menit": timer dua fase (5 detik, lalu 1:00 dengan "WAKTU DIPERCEPAT"), kejadian tepat di nol.
7. "Bagaimana jika setiap 2 detik bumi makin membesar": timer mode `every=2`, bumi membesar tiap kejadian.
8. "Pakai subtitle": subtitle mengikuti voice over, gaya dan warna sesuai palet, tidak menabrak objek.
9. "Pakai transisi": klip preview + Kartu 3 sebelum video penuh.
10. Karakter teriak: mata `wide`, mulut `scream`, tanda seru, gelombang, getar, kilat, tepat di kata yang diucapkan.
11. Hook diminta diperbaiki: hook asli, hook perbaikan, alasan; hook yang sudah bagus dipertahankan; tidak lebih clickbait; maksud dan informasi utama tidak berubah. Tanpa permintaan, hook tidak disentuh.
12. "Gunakan video effects Orbit" tanpa video referensi: tidak ada detail visual karangan; minta user mengunggah referensi atau deskripsi acuan. Dengan referensi: catatan `efek/orbit.md`, frame hasil dibandingkan dengan frame referensi.
13. Permintaan dengan kata-kata di luar contoh (mis. "tampilkan teks ucapannya di bawah"): tetap dikenali dari maksudnya.
14. Video dengan 6 ikon atau lebih muncul beruntun: `Sfx.audit()` menunjukkan `runtun_sama_terpanjang` = 1 dan `jenis_berbeda` minimal 3; nada naik bertahap (`rise`); timer memakai tik-tok bergantian; kejadian besar berlapis.
15. Karakter di tiap adegan: outfit minimal empat lapisan dengan kerah, manset, sabuk, lipatan, sol sepatu, dan bagian lepas yang tertinggal saat bergerak; lengan dan kaki tegas (tidak seperti mi), tidak berupa blok polos.
16. Animasi: `motion_report` tanpa `jendela_mati`; lompat atau kaget memperlihatkan antisipasi, overshoot, dan squash-stretch; gaya masuk elemen bervariasi; ada paralaks dan kamera melayang pelan.
17. Fitur akhir: bagian 0 menyebut 7 fitur wajib dan 10 fitur bila diminta, dan jawaban "fiturnya apa saja" mengikuti daftar itu.
18. "Buat video tentang bumi dan negara X": lembar fakta berisi ciri Bumi dan letak X dengan sumber; bentuk X hanya dari data peta yang lolos `geo_selfcheck`, atau pin koordinat nyata + label bila data tidak ada; tidak ada bentuk karangan; laporan memuat "Sumber:".
19. "Tutorial video motion graphic di CLAUDE": warna video sama dengan palet Claude asli hasil pencarian (mis. Clay #D97757), tanpa logo atau maskot yang ditiru, sumber di laporan.
20. Voice over lebih panjang atau pendek dari durasi video: tanpa meminta apa pun dari user, durasi dipas (video mengikuti suara, atau `fit_voice` dengan tempo paling banyak 8 persen), selisih video dan audio paling banyak 0,05 detik, `sync_audit` lolos, mulut karakter hanya terbuka saat ada suara dan hanya pada pembicara aktif.
21. "Pakai watermark": satu posisi tetap di sudut area aman, tidak menutupi subtitle, timer, wajah, atau objek bergerak; statis, opacity 0,55 atau 0,35; satu frame hasil dilihat. Tanpa permintaan, tidak ada watermark.
22. "Timer teks": teks saja tanpa kotak (diuji dengan membandingkan piksel latar), susunan penjelasan, timer, kecepatan, lalu dampak (dampak naik ke bawah timer bila kecepatan kosong), kecepatan yang tertulis sama dengan laju timer sebenarnya. Tanpa berkas Anthropic Font, fungsi menolak dan laporan menyebutnya di kalimat pertama; tidak ada font pengganti diam-diam. Tanpa permintaan, tidak dipakai.
23. "Chat bubble": bubble hanya frasa kunci (teks lebih dari 9 kata ditolak), tidak menutupi teks utama; saat narator menyebut "mengulang", ikon loading muncul di dalam bubble tepat di kata itu. Tanpa permintaan, tidak dipakai.
24. "Pakai pencahayaan" atau "bayangan": satu arah cahaya untuk semua objek; sisi terang tidak digelapkan; sisi jauh lebih gelap; bayangan berlawanan dengan sumber cahaya; `light_check` lolos dan satu frame dilihat. Tanpa permintaan, tidak ada.
25. Fakta berurutan: "urutan planet" dicatat dari sumber web (Merkurius, Venus, Bumi, Mars, Jupiter, Saturnus, Uranus, Neptunus); gambar dengan urutan tertukar ditangkap `cek_urut` dengan posisi yang salah dan sumbernya; kronologi, klasifikasi, hubungan, dan pola deret diperiksa dengan cara yang sama.
26. Tata surya: `universe_selfcheck()` lolos; tampilkan lembar kontak semua planet dan lihat langsung (Saturnus bercincin dengan bayangan, Jupiter pipih dengan pita dan Bintik Merah, Uranus miring); `draw_sistem` pada tanggal video menaruh Bumi di bujur heliosentris sesuai tanggal (sekitar 43 derajat pada awal November); skala jarak yang dimampatkan disebut di video atau laporan.
27. Font: `anthropic_font` menemukan `fonts/AnthropicSerifWebText.ttf`; subtitle dan timer memakainya; tanpa berkas fungsi menolak (tidak ada font diam-diam); `font="nama-ngarang"` ditolak; penggantian nyata tanpa `font_alasan` ditolak dan yang diterima masuk `LAPORAN`.
28. Timer teks: dampak "dampak: panas" dan "Bumi meledak." ditolak, "Bumi meledak sehingga peradaban manusia punah" diterima; `ukuran=dict(dampak=40)` ditolak oleh `cek_hierarki`; satu frame dilihat (penjelasan, timer, kecepatan, dampak berurutan, tanpa kotak); `draw_timer` lama tidak ada lagi.
29. Audit bentuk: `audit.audit_karakter(...)` lolos untuk tiga audit; kontrol negatif (persegi, segitiga, trapesium, elips simetris, badan telur, anggota badan seperti mi) GAGAL; satu frame karakter diam, lompat, dan kaget dilihat.
30. Gerbang: `Gerbang(...).periksa()` menolak bila ada audit BELUM DIJALANKAN atau GAGAL dan lolos hanya bila semua LOLOS.
31. Izin fitur: tanpa `izin_dari_teks`, `draw_subtitle`, `draw_timer_teks`, `draw_watermark`, `draw_chat_bubble`, `light_pass`, `transition`, dan `efek_video.terapkan` melempar `FiturTidakDiminta`; kalimat "pakai subtitle dan watermark" hanya mengaktifkan keduanya.
32. Penamaan: `nama_file_ok` menolak kucing_v2.mp4, final2.mp4, hasil (1).mp4 dan menerima kucing-cokelat.mp4; `tulis_aman` memindahkan versi lama ke `arsip/`.
33. Voice over: tanpa permintaan, `saran_suara` dan `vo_langsung` ditolak; `vo_langsung` tanpa mesin neural melempar `SuaraAlamiTidakAda` dan laporan menyebutnya di kalimat pertama; `cek_tag_eleven` menolak `<>` dan `cek_tag_google` menolak `[]`; saran suara hanya dari daftar terverifikasi.
34. Video effects: `daftar()` berisi tepat 20 efek; `terapkan("snap-zoom")` tanpa `efek/snap-zoom.md` lengkap melempar `ReferensiDiperlukan`; dengan catatan lengkap perender berjalan memakai parameter dari catatan.
35. Bank SFX: `KATALOG` berisi 77 bunyi dalam 10 keluarga; semua bunyi lolos tes angka (tanpa NaN, puncak 0,5 sampai 1, tanpa klik di tepi, tanpa pasangan kembar); 60 panggilan `Sfx.add("muncul", ...)` memakai 12 jenis tanpa pengulangan dalam 3 berturut-turut; `add_nama("glass", t)` dan `beat_grid(120, 2.0)` jalan.
36. Gaya: tipografi bergerak tanpa karakter dipetakan ke Reel Tipografi Bergerak, cerita berkarakter ke Animasi Cerita Berkarakter, yang tidak jelas memunculkan kartu gaya (tanpa asumsi); Reel Tipografi Bergerak tidak memanggil fungsi karakter tetapi tetap memakai SFX, animasi hidup, dan verifikasi fakta.
37. Voice over: tiga kartu berbahasa Inggris muncul berurutan di Cara 1 dan 3 (bukan Cara 2) sebelum membangun apa pun: "Do you want to include a voice over?" ("Yes, add Voice Over" / "No, without Voice Over"), lalu "How would you like to create the voice over?" ("Instant Voice Over" dengan keterangan status sementara / "Manual Voice Over"), lalu "Which platform will you use for the manual voice over?" ("Google AI Studio" / "ElevenLabs"); video tidak dibuat sebelum kartu dijawab kecuali user sudah menjawab tegas di pesannya; "Instant" memunculkan pemberitahuan jujur dan video tanpa suara dengan SFX; naskah ElevenLabs bertag `[]` dan Google bertag `<>`; `pilih_suara` menolak nama di luar daftar dan menolak tanpa suasana, tempo, atau pendengar; status 0.5 tercantum dan tidak menyebut video lengkap.
38. Frasa luas: naskah "kebudayaan Indonesia" menghasilkan elemen visual konkret (batik, rumah adat, tari, dan sejenisnya) yang terverifikasi, bukan hanya teks.

39. Penekanan kata: "Jangan merokok" tanpa tanda ditangkap `cek_tekan`, `*Jangan* merokok` lolos; lebih dari 2 kelompok, lebih dari 3 kata per kelompok, atau lebih dari 60 persen kata ditolak; penanda tidak tertutup ditolak; `make_cues` menjaga penanda lintas cue; empat metode (stabilo, garis, warna, tebal) menghasilkan gambar berbeda dari teks biasa dan metode ngawur ditolak; `naskah_bersih` tanpa tanda bintang; satu frame teks layar dilihat.
40. Subtitle warna kata: untuk pill, serif, dan pop, pada "Kopi hangat" saat "Kopi" diucapkan hanya Kopi berwarna aksen dan hangat putih, saat "hangat" diucapkan hanya hangat berwarna dan Kopi putih; kata kunci bertanda baru ditekan sejak diucapkan.
41. 13 gaya visual: `daftar()` berisi tepat 13 gaya, tiap gaya punya ciri, palet, huruf, elemen, gerak, sfx, cocok, sinyal, dan metode penekanan; semua kata kunci dari user ada ("archive", "blueprint", "sketch", "geometric", "silhouette" dan "history", "terminal", "liquid", "flat life illustration" dan "everyday life", "clipping" dan "collage", "bold typography", "map", "midnight" dan "dark mode", "miniature" dan "isometric"); `pilih_gaya_utama` memetakan "flat animation" ke Animasi Cerita Berkarakter dan "showreel" atau "reel" ke Reel Tipografi Bergerak, dan ambigu atau tanpa kata kunci memberi None (kartu gaya, tanpa asumsi); "flat life illustration" menuju FLATLIFE bukan gaya utama; kata kunci yang diganti Claude muncul di daftar terbaru pada laporan; deskripsi tidak mengaku sudah menonton video referensi.
42. Komposisi: `cek_menapak` menangkap baris stupa yang melayang dari tingkatnya (selisih 45 px pada kode lama) dan palem yang tidak menempel tepi teras; `cek_komposisi` menangkap dasar monumen yang tertimpa scrim dan objek yang keluar layar, dan lolos bila monumen berada di zona aman; `Gerbang` menolak tanpa `komposisi_audit` dan `tekan_audit`; satu frame penuh per adegan dilihat dan objek utama di-crop.
43. Kartu script: permintaan script saja memunculkan Kartu 1 dengan tombol "Lanjut buat full film" dan "Revisi" (juga di Reel Tipografi Bergerak dan Cara 3); tidak diganti pertanyaan teks.
44. Kejujuran referensi: bila situs atau video referensi tidak bisa dibuka, laporan menyebutnya terus terang dan tidak mengirim berkas yang diaku sebagai video referensi; deskripsi gaya dari tangkapan layar diberi catatan "frame diam, video belum ditonton".

## 13. Kode referensi (teruji)

Kode referensi yang teruji ada di folder `scripts/` pada skill ini (di samping SKILL.md). Salin ke folder project sebelum dipakai: `cp <folder-skill>/scripts/*.py projects/<nama>/` lalu `import` dari sana. Jangan menyalin kodenya ke dalam SKILL.md atau menulis ulang dari ingatan.

- `canvas.py`: kanvas `Cv` (Pillow, supersampling 2x: `poly`, `ell`, `circ`, `rr`, `line`, `xf`, `out`), easing, bentuk geometri. Ubah `W`, `H`, `FPS` di dalamnya sesuai rasio video.
- `fxlib.py`: SFX sintesis + `Track` (pencampur dengan ducking), variasi SFX (`vary`, `layer`, `room`, `Sfx`), gerak hidup (`spring`, `anticipate`, `jelly`, `squash`, `idle`, `blink`, `look`, `lag`, `cam_drift`, `motion_report`), bentuk karakter (`smooth`, `blob_pts`, `ik2`, `limb`), efek karakter, `transition`, timer (`timer_value`, `timer_plan`, `draw_timer_teks`, `timer_speed`, `speed_label`, `cek_dampak`, `cek_hierarki`, `anthropic_font`, `teks_font`, `font_cocok`, `font_tersedia`), izin fitur (`IZIN`, `izin_dari_teks`, `butuh`), penamaan file (`nama_file_ok`, `arsipkan`, `tulis_aman`), subtitle (`make_cues`, `draw_subtitle`), penekanan kata (`tandai_kata`, `draw_kalimat_tekan`, `cek_tekan`), sinkron voice over (`load_audio`, `speech_segments`, `align_sentences`, `fit_voice`, `video_len_for`, `scene_cuts`, `mouth_env`, `assign_speakers`, `speaker_at`, `sync_audit`, `mouth_check`, `probe_dur`), watermark (`text_mark`, `place_watermark`, `draw_watermark`), chat bubble (`find_words`, `place_box`, `draw_chat_bubble`), pencahayaan (`Light`, `light_col`, `lit_ball`, `lit_rect`, `cast_shadow`, `light_pass`, `light_check`).
- `karakter.py`: karakter berpakaian berlapis `warga(c, t, x, y, act, t0, seed, mulut)` (satu contoh tokoh; `mulut` = bukaan 0..1 dari `mouth_env`, hanya untuk pembicara aktif); ganti warna dan bentuk pakaian sesuai peran dan palet, jangan menyalin persis ke setiap karakter.
- `universe_kit.py`: Bumi, negara, pulau dari data peta asli (`find_geo`, `load_geo`, `geo_selfcheck`, `draw_globe`, `pin`, `country_points`) dan tata surya (`posisi`, `draw_planet`, `draw_sistem`, `banding_ukuran`, `info`, `lon_putar`, `fakta_universe`, `universe_selfcheck`; data NASA/JPL berikut sumbernya).
- `fakta.py`: lembar fakta `Fakta` (`add`, `pakai`, `beda`, `laporan`; fakta berurutan, klasifikasi, hubungan: `add_urut`, `cek_urut`, `add_kelas`, `cek_kelas`, `add_relasi`, `cek_relasi`; `cek_pola`).
- `ekspresi.py`: 20 ekspresi wajah (`NAMA`, `wajah`) dengan mata, alis, mulut, pipi, air mata, urat, dan ikon efek di atas kepala; dipakai `karakter.warga(..., ekspresi="senang")`.
- `audit.py`: audit bentuk (`luwes_audit`, `proporsi_audit`, `audit_karakter` dengan `Rekam`) dan `Gerbang` audit wajib sebelum render final (bagian 6.7), dan audit komposisi `cek_menapak` dan `cek_komposisi` (bagian 6.10).
- `efek_video.py`: manifest 20 video effects, perangkat dasar (zoom, kunci hijau, mask subjek, kertas, kaca cair, pecah frame, mockup ponsel, layer dan komposit) dan perender berbasis catatan referensi (bagian 7.5).
- `suara_naskah.py`: voice over naskah bertag ElevenLabs dan Google AI Studio, saran suara terverifikasi, dan `vo_langsung` yang menolak suara robot (bagian 7.10).
- `gaya_visual.py`: pustaka 13 gaya visual (ARSIP, BLUEPRINT, SKETSA, GEOMETRIK, HIKAYAT, TERMINAL, CAIR, FLATLIFE, KLIPING, LANTANG, PETA, MIDNIGHT, MINIATUR) dengan palet, elemen, gerak, aksen SFX, metode penekanan, dan kata kunci; `pilih`, `pilih_gaya_utama`, `daftar_kata_kunci` (bagian 0.6).
- `fonts/` (root skill): berisi `AnthropicSerifWebText.ttf` (font awal subtitle dan timer; lihat 7.7). Salin ke project: `cp -r <folder-skill>/fonts projects/<nama>/`.

Uji dulu setelah disalin: `python3 -c "import fxlib, canvas, universe_kit, fakta, karakter, ekspresi, audit, efek_video, suara_naskah, gaya_visual"`. Kode ini teruji dengan Pillow, numpy, dan ffmpeg.

Contoh pemakaian di `frame(t)` dan audio:

```python
import fxlib as F
img = scene(t)                                                    # PIL RGB
img = F.flash(img, t, T_EVENT)                                    # kilat saat kejadian
img = F.draw_timer_teks(img, "tengah-atas", "Kucing makan cokelat dalam", F.timer_value(t, 0.0, end=T_EVENT),
                        dampak="Teobromin mulai masuk tubuh sehingga jantung kucing berdetak lebih cepat")      # hanya bila timer diminta
img = F.draw_subtitle(img, CUES, t, style="pill", fg=TERANG, bg=GELAP, accent=AKSEN, pos=0.86)
# CUES = F.make_cues([(teks_script, mulai, selesai), ...], max_words=4)
# transisi (bila diminta): img = F.transition("iris", scene_a(t), scene_b(t), (t - TR0) / (TR1 - TR0))

tr = F.Track(DUR); sfx = F.Sfx(tr, seed=7)
for i, ti in enumerate(T_IKON): sfx.add("muncul", ti, -14, rise=0.8 * i)           # ikon beruntun: jenis berganti, nada naik
for i, ts in enumerate(T_DETIK): sfx.tick(ts, i)                                   # timer: tik-tok bergantian, waktu tepat
tr.add(F.layer([(F.sfx_impact(), 0, 0), (F.sfx_thud(), 0, -3), (F.sfx_alert(0.4), 0.12, -10)]), T_EVENT, -6)   # kejadian besar berlapis
tr.write("audio-final.wav", vo_path=VO, duck_db=-12)             # voice over utuh; SFX dibatasi di bawah ucapan
print(sfx.audit())                                               # laporan variasi SFX; wajib dijalankan sebelum kirim
```

Contoh fitur baru:

```python
# LANGKAH PERTAMA project: aktifkan hanya fitur yang user minta (fitur lain melempar FiturTidakDiminta)
F.izin_dari_teks(PERMINTAAN_USER)                                  # mis. "pakai subtitle dan timer"
F.tulis_aman("out/kucing-cokelat.mp4")                             # nama berversi (v2, final2) ditolak; versi lama ke arsip/
# verifikasi fakta (6.5): cari lewat WebSearch/WebFetch dulu, catat, baru gambar
from fakta import Fakta
fk = Fakta("riset/fakta-visual.json")
fk.add("claude.clay", "warna aksen Claude", "#D97757", ["https://..."]); clay = fk.pakai("claude.clay")
# bumi dan negara: hanya dari data peta asli yang lolos selfcheck; tanpa data -> pin koordinat nyata
import universe_kit as G, canvas
path = G.find_geo(); geo = G.load_geo(path) if path else None
if geo and G.geo_selfcheck(geo)["lolos"]:
    c = canvas.Cv((20, 28, 60)); rep = G.draw_globe(c, 540, 900, 380, geo, lon0=115, lat0=-5, hi=("Indonesia",), clouds=0.5, t=t)   # rep["hilang"] = nama yang tidak ketemu
else:
    for la, lo, zona in G.country_points("Indonesia")[:1]: G.pin(c, lo, la, 115, -5, 540, 900, 380)   # lalu katakan di laporan: bentuk belum bisa digambar

# watermark pintar (7.6): pilih posisi dari cuplikan frame TANPA watermark, lalu gambar di akhir frame(t)
mark = F.text_mark("@namakamu", 46, "terang")
pos = F.place_watermark(CUPLIKAN, mark.size, ui="vertikal", reserved=[KOTAK_SUBTITLE, KOTAK_TIMER])
mark = F.text_mark("@namakamu", 46, pos["tone"]); img = F.draw_watermark(img, mark, (pos["x"], pos["y"]), t, pos["opacity"])

# fakta berurutan (6.5): catat dari sumber web, cocokkan sebelum menggambar
fk.add_urut("tata_surya.urutan", "Urutan planet dari Matahari", ["Merkurius", "Venus", "Bumi", "Mars", "Jupiter", "Saturnus", "Uranus", "Neptunus"], ["https://..."])
cek = fk.cek_urut("tata_surya.urutan", URUTAN_YANG_DIGAMBAR); assert cek["sesuai"], cek      # kalau salah: tampilkan posisi dan sumbernya

# pencahayaan (7.9): satu sumber cahaya untuk semua objek
L = F.Light(angle=225, ambient=0.5)                                   # cahaya dari kiri-atas
F.cast_shadow(c, titik_objek, L, y_tanah, warna_tanah); F.lit_ball(c, x, y, r, warna, L); F.lit_rect(c, x0, y0, x1, y1, warna, L)
img = F.light_pass(c.out(), L, 0.4)                                   # lapisan cahaya seluruh frame; lampu titik: F.Light(spot=(x, y, radius))
# print(F.light_check(sebelum, sesudah, L))                           # wajib lolos

# timer teks murni (7.7) dan chat bubble (7.8)
img = F.draw_timer_teks(img, "tengah-atas", "LISTRIK KEMBALI DALAM", F.timer_plan(t, PLAN)[1], F.timer_speed(t, PLAN), dampak="Kota menjadi gelap sehingga lampu kota padam")   # font awal AnthropicSerifWebText di fonts/; dampak = kalimat akibat; ukuran timer >= penjelasan >= kecepatan > dampak
# gerbang audit wajib sebelum render final (6.7)
import audit
r = audit.audit_karakter(karakter.warga, WARNA_PAKAIAN, karakter.JACKET, karakter.SKIN)      # luwes, proporsi, wajah
g = audit.Gerbang(karakter=True, suara=True); g.catat("luwes_audit", r["luwes"]["lolos"]); g.catat("proporsi_audit", r["proporsi"]["lolos"]); g.catat("wajah_audit", r["wajah"]["lolos"])
# ... catat motion_report, sfx_audit, sync_audit, mouth_check; lalu g.periksa() sebelum ffmpeg final
# voice over naskah bertag (7.10, hanya bila diminta): import suara_naskah as V; V.saran_suara("elevenlabs", "narasi"); V.cek_tag_eleven(naskah)
# ekspresi karakter: karakter.warga(c, t, x, y, "diam", ekspresi="jatuh_cinta") (lihat ekspresi.NAMA)
kata = F.find_words(al)                                           # waktu kata "mengulang" dari suara nyata
img = F.draw_chat_bubble(img, "Mengulang dari awal", F.place_box((560, 130), (x_kepala, y_kepala), 1080, 1920, reserved=[KOTAK_TEKS]), t, 2.0, 5.0,
                         loading=(kata[0][0], kata[0][1] + 0.9) if kata else None)
```

Pemakaian karakter di tiap frame: `karakter.warga(c, t, x, y, act="diam" | "lompat" | "kaget", t0=waktu_mulai_lompat, seed=nomor_karakter)`. Gambar `Cv(cam=...)` dengan `F.cam_drift(t)` bila kamera ikut melayang.

