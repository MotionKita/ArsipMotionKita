---
name: "motion-graphic-vednnayr"
description: "Bikin video motion graphic/flat animation: script, video, voice over, SFX & ekspresi wajib; timer, subtitle, hook, 20 video effects bila diminta. 3 cara termasuk fallback JS Termux."
---

# Motion Graphic (vednnayr)

Skill ini mengatur pembuatan video motion graphic dari permintaan user: 3 cara kerja, 3 kartu pilihan, narasi voice over yang bersih, 2 fitur wajib (SFX, ekspresi/efek karakter) dan 5 fitur bila diminta (timer, subtitle, transisi, hook improvement, 20 video effects). Baca semuanya sebelum mulai. Kode referensi yang sudah teruji ada di bagian 13.

## 0. Status fitur (baca dulu)

**WAJIB ada di setiap video:**

- **SFX (sound effect)**, bagian 6.1.
- **Ekspresi dan efek karakter**, bagian 6.2. Bila video tidak punya karakter, terapkan efek setara pada objek utama (goyang, kilau, tanda seru).

**HANYA bila user benar-benar meminta:**

- **Timer + penjelasan kejadian**, bagian 7.1. Contoh pemicu: "bagaimana jika ...", "setiap N detik ..." (lihat 7.1). AI juga boleh memakainya sendiri di video yang jelas cocok.
- **Subtitle**, bagian 7.2. Contoh pemicu: "pakai subtitle", "dengan subtitle" (lihat 7.2). Wajib mengikuti voice over.
- **Transisi bergaya**, bagian 7.3. Hanya bila diminta, dan harus lolos preview dulu (Kartu 3). Tanpa permintaan, tidak ada transisi bergaya.
- **Hook Improvement**, bagian 7.4. Hanya bila user memintanya. Jangan mengubah hook secara otomatis.
- **Video Effects (20 efek)**, bagian 7.5. Hanya bila user memintanya dengan menyebut nama efek dari daftar. Acuan utamanya video referensi; tanpa referensi, jangan mengarang.

**Soal kata kunci:** pemicu utama sebuah fitur adalah NAMA FITURNYA sendiri.

- Kata "subtitle" mengaktifkan Subtitle (7.2). Kata "timer" mengaktifkan Timer (7.1). Kata "transisi" mengaktifkan Transisi (7.3). Kata "hook" mengaktifkan Hook Improvement (7.4). Kata "video effect" atau "video effects" mengaktifkan Video Effects (7.5).
- Kata di sekitarnya bebas. "Pakai subtitle", "dengan subtitle", dan "tolong gunakan subtitle" semuanya cukup karena memuat kata "subtitle". Tidak perlu kalimat tertentu.
- Selain nama fitur, tetap kenali variasi lain yang jelas bermaksud sama (mis. "bagaimana jika ..." untuk Timer, "tampilkan teks ucapannya di bawah" untuk Subtitle). Contoh-contoh di dokumen ini bukan daftar tertutup, dan jangan menambah kata kunci baru sebagai syarat.
- Dua catatan kecil. Kata "hook" hanya berarti Hook Improvement bila maksudnya memperbaiki hook yang sudah ada; menyebut hook saat meminta script baru belum berarti minta perbaikan. Kata "video effect" tanpa nama efek: tanyakan dulu efek mana dari 20 daftar (tampilkan daftarnya).

## 1. Tiga cara kerja

**Cara 1: script, video, voice over.** Dipakai saat user minta script lalu lanjut minta videonya, atau minta video tanpa membawa voice over sendiri. Alur: script, lalu video dari script, lalu voice over (dibuat di mana saja yang bisa), lalu gabung. Hasil: mp4.

**Cara 2: voice over dan script dari user.** Dipakai saat user mengirim voice over + script sendiri (ElevenLabs atau TTS gratis). Alur: motion dibuat mengikuti script dan suara yang sudah ada. Hasil: mp4.

**Cara 3: JS murni + perintah render.** Dipakai sebagai fallback Cara 1 bila gagal, atau saat user eksplisit minta "JS murni / render di Termux". Alur sama dengan Cara 1, tetapi hasilnya file JS + perintah render.

**Routing:**

1. Minta script lalu lanjut minta video dari script itu: Cara 1.
2. Minta script di awal, lalu mengirim voice over + script untuk dijadikan video: Cara 2.
3. Cara 1 gagal: Cara 3, wajib menyertakan perintah render.
4. User sendiri minta JS murni / render di Termux: langsung Cara 3.

**Cara 2 bukan fallback.** Cara 1 dan 3 satu keluarga (input sama, bentuk hasil beda), sedangkan Cara 2 beda input karena suaranya sudah dibuat user. Cara 2 tidak dipakai sebagai cadangan Cara 1 atau 3, dan sebaliknya. Bila Cara 2 gagal: laporkan apa yang gagal dengan jujur, lalu tanya user mau diulang dengan pendekatan lain atau tidak. Jangan pindah cara diam-diam.

**Cara 1 dianggap gagal** bila, setelah minimal dua pendekatan render berbeda, belum ada mp4 yang bisa diputar dan lolos pengecekan. Jangan mengulang perintah yang sama terus-menerus. Saat pindah ke Cara 3, bilang singkat bahwa Cara 1 gagal dan kenapa.

## 2. Parameter yang bisa diubah user

Baca dari kalimat user, jangan dipaku:

- jenis konten (iklan produk, cerita, edukasi), nama produk atau topik
- durasi
- rasio dan resolusi: 9:16 = 1080x1920, 16:9 = 1920x1080, 1:1 = 1080x1080, 4:5 = 1080x1350. "Full HD" berarti sisi 1080p
- fps (default 30; 60 bila diminta)
- gaya, posisi timer, gaya subtitle

Bila tidak disebut: 9:16, 1080x1920, 30 fps, flat animation. Jangan menahan pekerjaan hanya untuk menanyakan hal-hal ini.

## 3. Aturan umum

1. **Folder project terpisah** per video (`projects/<nama>/` berisi script, audio, scenes, out). Jangan menyentuh folder website atau project lain milik user. Sebutkan lokasinya di laporan.
2. **Cek dulu, baru kirim.** Sebelum video apa pun dikirim (preview maupun penuh), jalankan pengecekan dan jangan klaim pengecekan yang tidak dijalankan: `ffprobe` (durasi, resolusi, fps, ada audio), `blackdetect`, `freezedetect`, jeda narasi pas dengan pergantian adegan, `mean_volume` voice over sama dengan file aslinya, dan lihat langsung beberapa frame.
3. **Isi layar.** Jangan menaruh seluruh naskah sebagai teks di layar. Pakai ikon, bentuk, dan animasi yang mewakili isi naskah. Teks di layar hanya kata kunci pendek (nama produk, harga, CTA, label ikon). Pengecualian: subtitle dan timer yang diminta user.
4. **Flat animation:** bentuk datar tegas, 3-5 warna, easing, gerak bergantian (stagger), satu ide visual per adegan. Elemen masuk dan keluar dengan mulus (pop-in overshoot atau fade/slide, 0,3-0,5 detik).
5. **Pergantian adegan default:** potong bersih atau crossfade pendek (0,3 detik atau kurang), jatuh di jeda narasi. Bukan transisi bergaya (lihat 7.3).
6. **Environment:** cek tool yang tersedia dan pasang bila kurang. Akses jaringan dari shell bisa dibatasi; bila ada request yang ditolak, jangan coba cara lain untuk menembusnya, bilang apa adanya.
7. **Cerita nabi atau tokoh agama:** jangan menggambar wajah atau sosok nabi; pakai siluet dari jauh, simbol, cahaya, dan narasi. Ini default; user boleh mengubahnya.
8. **Karakter atau merek pihak lain:** jangan menggambar karakter berhak cipta atau meniru logo/merek nyata, termasuk dari video referensi. Ambil gayanya (warna, ritme, tata letak), bukan karakternya.
9. **Topik kesehatan atau keselamatan** (hewan, obat, makanan): jangan menyebut takaran atau dosis; tekankan menghubungi dokter, dokter hewan, atau profesional.
10. **Jujur soal suara.** Bila voice over belum ada (tidak ada TTS yang bisa jalan), katakan di kalimat pertama laporan, kirim video dengan SFX tanpa suara + `narasi-voice-over.txt`, dan tawarkan lanjut ke Cara 2 begitu user mengirim audionya. Jangan menyebut video "lengkap" bila tidak ada suara.

## 4. Kartu pilihan

Kartu dibuat dengan tool `AskUserQuestion` (satu pertanyaan, bukan multi-select). Ada tiga kartu berbeda yang muncul di waktu berbeda. Jangan mengganti kartu dengan pertanyaan teks biasa seperti "Mau lanjut jadi videonya?".

### Kartu 1: setelah SCRIPT

- **Kapan:** setiap kali user hanya meminta script (belum minta video). Tampil setelah tabel script, narasi bersih, dan catatan asumsi.
- **Pertanyaan:** "Script sudah jadi. Lanjut buat videonya?"
- **Tombol:** "Lanjut buat video" (buat video dari script ini) dan "Revisi" (ubah script dulu: isi, durasi, atau gaya bahasa).
- **Lanjut buat video:** mulai Cara 1 dengan script itu.
- **Revisi:** bila user belum menulis apa yang diubah, tanya multi-select ("Isi/fakta", "Durasi", "Gaya bahasa", "Jumlah adegan", "Visual", plus input bebas). Ubah script, tampilkan lagi script + narasi bersih, lalu Kartu 1 lagi. Ulangi sampai "Lanjut buat video".
- **Tidak tampil** bila user sudah meminta script + video dalam satu pesan, atau mengirim script sendiri (Cara 2).

### Kartu 2: setelah PREVIEW, hanya untuk palet NEON

- **Pemicu:** palet atau hasil berupa gradien neon (ungu neon, biru neon, hijau neon, atau kombinasinya, termasuk gaya glow neon). Putuskan saat merencanakan palet, sebelum membangun apa pun. Bila ragu, anggap neon.
- **Alur:** bangun preview adegan pembuka saja (sekitar 6-10 detik, rasio dan resolusi sama dengan video akhir, lengkap dengan suara dan SFX bila ada), jalankan pengecekan, kirim dengan `SendUserFile` (`display: "render"`), tulis ringkasan jujur (hanya yang benar-benar dicek), lalu tampilkan kartu.
- **Contoh ringkasan:** "Preview adegan pembuka (7,75 detik, vertikal) sudah jadi dan sudah aku cek: gambar tidak ada yang hitam, jeda narasi pas, suara voice over sama kerasnya dengan file asli. Project-nya ada di folder terpisah. Sisa film (sekitar 61 detik) belum dibuat."
- **Pertanyaan:** "Lanjut ke film penuh {durasi total} detik dengan tampilan seperti ini?"
- **Tombol:** "Lanjut film penuh" (lanjutkan sampai video selesai) dan "Revisi dulu" (buat ulang preview: efek, warna, atau script).
- **Lanjut film penuh:** buat sisa video dengan tampilan yang sama, cek lagi, kirim.
- **Revisi dulu:** bila belum jelas apa yang kurang, tanya multi-select ("Efek/animasi kurang bagus", "Warna kurang enak", "Script belum sesuai", plus input bebas). Buat ulang preview, cek, kirim, tampilkan kartu lagi. Ulangi sampai "Lanjut film penuh". Di Cara 2 suara milik user: bila isi kalimat berubah, minta suara baru; yang bisa diubah sendiri hanya visual.
- **Cara 3:** preview berupa file JS yang baru berisi adegan pembuka + perintah render preview (`--preview`); kartu di balasan yang sama; setelah "Lanjut film penuh", kirim JS lengkap + perintah render penuh.
- **Palet non-neon:** tidak ada Kartu 2; video penuh boleh langsung dibuat dan dikirim. WAJIB tulis satu kalimat di laporan, mis.: "Palet video ini bukan neon, jadi tidak ada preview dan kartu; video penuh langsung kukirim. Kalau mau lihat preview dulu, bilang saja." Preview + kartu tetap boleh bila user memintanya.

### Kartu 3: setelah PREVIEW TRANSISI, hanya bila user meminta transisi

- **Kapan:** user meminta transisi (lihat 7.3). Kirim klip pendek 3-5 detik (akhir adegan A, transisi, awal adegan B), lengkap dengan SFX transisinya.
- **Pertanyaan:** "Transisinya seperti ini. Dipakai di seluruh video?"
- **Tombol:** "Pakai transisi ini" dan "Revisi transisi" (ganti jenis, lebih halus, atau tanpa transisi).
- **Pakai transisi ini:** terapkan ke seluruh video. **Revisi transisi:** buat ulang klip dengan jenis lain, tampilkan kartu lagi.

### Ringkasan kapan kartu muncul

- User hanya minta script: Kartu 1.
- User minta script + video sekaligus: tidak ada Kartu 1.
- Palet neon, setelah preview: Kartu 2. Palet non-neon: tidak ada Kartu 2.
- Cara 2 (user kirim voice over + script): tidak ada Kartu 1; Kartu 2 hanya bila neon.
- Transisi diminta: Kartu 3 sebelum video penuh.
- Sesi tanpa pengawasan (tidak ada yang bisa menjawab): berhenti di titik kartu; jangan kirim video penuh.

## 5. Narasi voice over harus BERSIH

Kesalahan yang dulu terjadi: file narasi berisi judul, durasi video, petunjuk baca, rentang detik, label "Adegan N", dan catatan penutup, sehingga ikut dibacakan saat ditempel ke ElevenLabs atau TTS lain. Aturan:

1. Setiap script disertai narasi bersih: file `narasi-voice-over.txt` DAN satu blok kode di chat yang bisa disalin, ditulis setelah tabel script.
2. Isinya HANYA kalimat yang dibacakan, urut sesuai adegan, satu adegan satu paragraf, dipisah satu baris kosong.
3. DILARANG di dalamnya: judul, nama video, durasi/rasio/fps, rentang waktu, label "Adegan N", nomor, petunjuk tempo atau jeda, catatan, instruksi, nama file, emoji, tanda kurung berisi arahan, dan tanda kutip di sekitar kalimat.
4. Teks harus sama persis, kata per kata, dengan kolom Narasi di script; cocokkan setelah menulis.
5. Waktu per adegan dan petunjuk baca TIDAK dicampur ke file narasi; taruh di chat atau `jadwal-adegan.txt`.
6. Di chat jelaskan singkat: "Salin hanya blok narasi ini ke ElevenLabs. Tiap paragraf = satu adegan, jadi kamu juga bisa membuat suaranya per adegan." Jangan mengklaim fitur spesifik tool pihak ketiga yang tidak pasti.

Contoh BENAR:

```
Kucingmu mengendus cokelat di atas meja. Lucu? Justru ini bisa berbahaya buat dia.

Cokelat mengandung teobromin dan kafein, dua zat yang tidak cocok untuk tubuh kucing.
```

Contoh SALAH (jangan ditiru): baris `NARASI VOICE OVER - "Judul"`, baris `[00:00 - 00:06] Adegan 1`, kalimat dalam tanda kutip, dan baris `Catatan: kirim file audionya ke sini`.

## 6. Fitur WAJIB

### 6.1 SFX (sound effect)

**Wajib di setiap video**, termasuk bila user tidak menyebut SFX.

- **Pembuatan:** sintesis lokal dengan kode di bagian 13 (tanpa internet, tanpa unduhan). Tersedia: `pop`, `whoosh`, `ding`, `tick`, `beep`, `impact`, `alert`, `boing`, `riser`. Jangan menjanjikan yang tidak bisa dibuat (teriakan suara manusia, musik latar); katakan apa adanya dan tawarkan SFX sintesis terdekat atau minta user mengirim file audionya.

**Peta kejadian ke SFX (gain relatif, dB):**

- Ikon atau elemen muncul: `pop` (-14).
- Tanda tanya muncul: `pop` bernada tinggi (-15).
- Timer berdetik tiap detik: `tick` (-12). Tiga detik terakhir: `beep` bernada naik 1200 ke 1800 Hz (-12).
- Timer nol atau kejadian besar: `impact` (-6) + `alert` (-14).
- Tanda seru atau kaget: `boing` atau `alert` (-12).
- Sukses atau info: `ding` (-16).
- Ketegangan menuju kejadian: `riser` 1-2 detik (-14).
- Benda jatuh atau menutup: `impact` pendek (-14).
- Transisi: hanya bila transisi diminta (7.3), `whoosh` (-12).

**Prinsip:**

- Padat tapi tidak ramai: paling banyak satu SFX tiap 0,4 detik, satu bunyi per kejadian.
- SFX penting (impact, alert, ding) sebaiknya jatuh di jeda narasi agar terdengar jelas.
- Karakter SFX mengikuti gaya video (flat ceria: pop dan ding; sains atau dramatis: impact dan riser).

**Campur ke audio:** pakai `Track.write(path, vo_path=..., duck_db=-12)` (bagian 13). Voice over TIDAK diubah. RMS SFX otomatis dibatasi maksimal 12 dB di bawah RMS ucapan (ducking dinamis jendela 250 ms), hanya SFX yang diturunkan bila hampir clipping. Hasil satu file wav, lalu `ffmpeg -c:a aac -b:a 256k`. Tanpa voice over: SFX dipakai dengan gain apa adanya.

**Cek:**

- `mean_volume` dan `max_volume` video sama dengan voice over asli (SFX tipis di antara ucapan), puncak campuran di bawah -1 dBFS.
- Bandingkan campuran dengan voice over asli per jendela 0,25 detik: di jendela ucapan, SFX minimal sekitar 8 dB di bawah ucapan.
- SFX berbunyi tepat pada detik yang dijadwalkan (SFX di jeda terdengar jelas, mis. puncak lebih dari 0,05).

### 6.2 Ekspresi dan efek karakter

**Wajib.** Setiap karakter punya ekspresi yang berubah mengikuti narasi, plus efek visual di momen penting. Ekspresi muncul tepat di kata yang relevan, efek berlangsung 0,6-1,2 detik lalu mereda, maksimal dua efek bersamaan, dan tidak menutupi wajah (taruh di atas atau samping kepala). Berlaku untuk karakter apa pun, bukan hanya kucing.

**Daftar ekspresi (wajah, efek, SFX):**

- **Teriak atau kaget besar:** mata `wide`, mulut `scream`; `fx_exclaim(n=2)` + `fx_waves` + `shake` + `flash`; SFX impact + alert.
- **Kaget:** mata `wide`, mulut `frown`; `fx_exclaim(n=1)`; SFX boing.
- **Takut atau gemetar:** mata `wide`, mulut `frown`; `fx_waves` kecil + `shake` kecil + `fx_sweat`.
- **Sedih:** mulut `frown`; `fx_sweat` berwarna biru sebagai air mata.
- **Bingung:** mata `open`, kepala miring; teks `?` yang pop-in; SFX pop.
- **Senang:** mata `happy`, mulut `smile`; bintang kecil atau pantulan; SFX ding.
- **Marah:** mata `open`, mulut `frown`; tint merah pelan + `shake`; SFX alert.

**Varian wajah** yang perlu ditambahkan ke fungsi wajah karakter:

```python
elif eyes == 'wide':      # kaget: putih lebar + pupil kecil
    c.ell(ex, ey, 44, 55, INK); c.ell(ex, ey, 37, 48, WHITE); c.circ(ex, ey + 4, 10, INK)
elif mouth == 'scream':   # teriak
    c.ell(0, 98, 42, 56, INK); c.ell(0, 128, 26, 20, PINK)
```

Tanda seru dan gelombang digambar dari bentuk (tanpa font), jadi aman juga di Cara 3. Tanda seru diberi outline putih agar terbaca di latar apa pun. Untuk kamera: `Cv(cam=(540 + dx, 960 + dy, zoom))` dengan `shake` dan sedikit zoom-punch (1 + 0,05 x pulsa) saat kejadian.

## 7. Fitur HANYA bila diminta

### 7.1 Timer dan penjelasan kejadian

**Pemicu utama: nama fitur, yaitu kata "timer". Variasi lain yang jelas bermaksud sama juga dikenali, mis.:**

- "bagaimana jika ..." (juga "bagaimana kalau", "what if"), contoh: "bagaimana jika setiap 2 detik bumi makin membesar" dan "bagaimana jika bumi kehilangan listrik selama 1 menit".
- "setiap N detik terjadi ...", "selama N menit", "... dalam N detik".
- AI juga boleh memakainya sendiri di video yang jelas cocok (fakta sains, peringatan, kejadian yang akan datang). Jangan dipakai bila tidak relevan.

**Isi timer (tiga baris):**

- Label kecil huruf kapital berjarak: apa yang akan terjadi (mis. `KUCING MAKAN COKELAT DALAM`).
- Angka besar `m:ss.mmm` (lebar tetap, tidak bergoyang).
- Keterangan kecil: penjelasan (mis. `TEOBROMIN MULAI MASUK TUBUH`, `WAKTU DIPERCEPAT 5X`, `WAKTU DIPERLAMBAT 11X`).

Meniru gaya referensi user: label kecil, angka besar, keterangan, dengan subtitle narasi di bawah-tengah yang terpisah dari timer.

**Posisi (6):** `kiri-atas`, `tengah-atas`, `kanan-atas`, `kiri-tengah`, `tengah`, `kanan-tengah`.

- Bila user menyebut posisi, ikuti persis. Bila tidak: `tengah-atas` (vertikal).
- Pilih posisi yang tidak menutupi wajah, objek utama, atau teks lain. Bagian bawah-tengah dipakai subtitle, jangan ditempati timer.
- Setelah render, lihat frame: bila timer menutupi subjek, geser posisi atau kecilkan `scale`.

**Mode:**

- **Hitung mundur** ke kejadian: `timer_value(t, start, end=T)`.
- **Hitung naik:** `timer_value(..., up=True)`.
- **Berulang "setiap N detik":** `timer_value(t, start, every=N)`; angka reset tiap kejadian, nomor kejadian `int((t - start) // N)`.
- **Multi-fase:** `timer_plan(t, plan)` dengan `plan = [(t0, t1, v0, v1, label, sub), ...]`; nilai bergerak linear dari v0 ke v1 selama t0..t1 (detik video), dan `{x}` di keterangan diganti kecepatan waktunya.

**Contoh 1: "bagaimana jika setiap 2 detik bumi makin membesar".**

- Mode `every=2`. Label `BUMI MEMBESAR DALAM`, keterangan `UKURAN BUMI +25% TIAP KEJADIAN`.
- Tiap kali angka mencapai nol terjadi kejadian nyata: bumi membesar (skala dikali 1,25 dengan easing overshoot), SFX `pop` + `boing`, sedikit getar kamera. Gunakan nomor kejadian sebagai pangkat skala.

**Contoh 2: "bagaimana jika bumi kehilangan listrik selama 1 menit".**

- **Fase 1 (timeout sebelum kejadian):** 5 detik hitung mundur ke padam (default 5 detik bila user tidak menyebut), mis. `(0, 5, 5, 0, "LISTRIK PADAM DALAM", "SELURUH LISTRIK DI BUMI MATI")`.
- **Kejadian di detik nol:** layar atau kota menjadi gelap, SFX `impact`, efek karakter (kaget).
- **Fase 2 (sesudah kejadian):** durasi persis sesuai permintaan, mis. 1 menit: `(5, 17, 60, 0, "LISTRIK KEMBALI DALAM", "WAKTU DIPERCEPAT {x}X")`. Video menampilkannya 12 detik, jadi waktu dipercepat 5x dan keterangan terisi otomatis. Bila durasi kejadian muat di video, pakai 1x.
- **Saat nol di fase 2:** kejadian pemulihan (lampu menyala kembali, `ding`).

**Aturan lain:**

- Angka memerah di 3 detik terakhir (`hot_below`). Sembunyikan atau ganti timer saat pergantian adegan.
- Dengan voice over (Cara 2): timer mengikuti timeline suara; jatuhkan kejadian pada kata yang relevan.
- Cara 3 (tanpa font): render huruf dan angka yang dipakai (A-Z, 0-9, `:` `.` spasi) di workspace dengan Pillow menjadi mask 1-channel, simpan sebagai base64 di dalam JS, dan gambar per karakter (angka lebar tetap). Uji dengan `--preview` sebelum dikirim.

### 7.2 Subtitle (wajib mengikuti voice over)

**Pemicu utama: nama fitur, yaitu kata "subtitle"** ("pakai subtitle", "dengan subtitle", "tolong gunakan subtitle" semuanya cukup). Variasi lain yang jelas bermaksud sama juga dikenali: permintaan menampilkan teks ucapan di layar, mis. teks narasi, caption, takarir, "kasih teks di bawah", atau ungkapan lain yang tidak terduga.

**Wajib mengikuti voice over:**

- Teks subtitle diambil dari script yang BENAR (bukan salah ucap), sama persis dengan narasi bersih.
- Waktu tiap frasa diambil dari audio (celah napas, bagian 8 Cara 2, atau transkripsi bila ada tool-nya). Waktu tiap kata ditaksir sebanding suku kata, jadi bilang jujur bahwa sinkron per frasa terukur dan per kata ditaksir.
- Bila voice over belum ada (Cara 1), subtitle mengikuti jadwal narasi di script; begitu suara diberikan, waktu dihitung ulang dari audio.

**Tampilan (keren, kece, aesthetic, sesuai gaya dan warna video):**

- Pilih gaya subtitle yang cocok dengan gaya video:
  - `pill`: kartu berwarna palet dengan kata yang sedang diucapkan beraksen. Untuk flat animation, kartun, edukasi, iklan (default).
  - `serif`: italic sinematik dengan gradien gelap tipis di bawah. Untuk sains, dokumenter, dan video bernuansa gelap (seperti gaya referensi user).
  - `pop`: kata muncul satu per satu, tebal dengan outline. Untuk konten energik dan iklan cepat.
- Warna ikut palet video: `bg` = warna tergelap palet, `fg` = warna terterang, `accent` = warna aksen palet. Kontras teks terhadap latar minimal 4,5:1. Palet neon: aksen neon di atas latar gelap.
- Maksimal 4 kata per cue (`make_cues(segments, max_words=4)`), tanpa koma atau titik di ujung, fade masuk dan keluar singkat, teks mengecil otomatis bila terlalu lebar.
- **Area subtitle:** rancang layout adegan sejak awal dengan zona subtitle kosong. 9:16: `pos` sekitar 0,80-0,88 (di atas zona UI platform); 16:9: sekitar 0,86. Pastikan tidak menabrak karakter atau ikon, lalu lihat frame tiap adegan.

**Cek sinkron:**

- Subtitle tidak tampil di tengah jeda panjang (0,5 detik atau lebih), dan setiap titik ucapan punya subtitle.
- Lihat frame di beberapa kata kunci dan pastikan teks yang tampil = yang sedang diucapkan.

### 7.3 Transisi (hanya bila diminta)

**Default: tanpa transisi bergaya.** Pergantian adegan memakai potong bersih atau crossfade pendek (aturan umum nomor 5).

**Bila user meminta transisi (pemicu utama: kata "transisi"):**

1. **Standar kualitas, bukan gaya "CapCut gratisan".** Hindari: putar atau spin, glitch murahan, flash putih berlebihan, zoom blur generik, wipe berbentuk bintang atau hati, mengganti jenis tiap adegan. Pilih transisi yang bermotif: berasal dari objek atau gerak di video (benda yang keluar layar menyapu adegan berikutnya, iris dari objek, push searah gerak), satu bahasa transisi yang konsisten, easing cosinus, 0,4-0,7 detik.
2. **Preview dulu.** Buat klip 3-5 detik dan tampilkan Kartu 3 (bagian 4). Hanya setelah "Pakai transisi ini", terapkan ke seluruh video.
3. **Jenis tersedia** lewat `transition(kind, a, b, p)`: `fade`, `slide`, `wipe`, `iris`. Jenis lain boleh dibuat bila lolos standar kualitas.
4. **SFX transisi:** `whoosh` halus (`fade` memakai `f_hi=2500`; `slide` dan `wipe` memakai `up=True`; `iris` memakai whoosh + `pop` saat lingkaran penuh), mulai sekitar 0,05 detik sebelum transisi, jatuh di jeda narasi.
5. **Cek:** lihat frame di p = 0,5 dan pastikan tidak ada flash hitam atau elemen terpotong.

### 7.4 Hook Improvement (hanya bila diminta)

**Aturan penggunaan:** hanya dipakai ketika user memintanya. Pemicu utama: kata "hook" dengan maksud memperbaiki, merapikan, atau meningkatkan hook yang sudah ada (menyebut hook saat meminta script baru belum berarti minta perbaikan). JANGAN mengubah hook secara otomatis, termasuk saat membuat script atau video biasa.

**Tujuan:** hook lebih menarik, efektif, natural, dan mampu mempertahankan perhatian penonton.

**Ketentuan:**

- Perbaiki hook yang terlalu berlebihan, terlalu agresif, memaksakan perhatian, atau clickbait yang menyesatkan dan tidak sesuai dengan isi video.
- JANGAN membuat hook makin clickbait, sensasional, berlebihan, atau menyesatkan.
- Bila hook sudah bagus (menarik, natural, dan menjelaskan isi video dengan baik), PERTAHANKAN tanpa perubahan yang tidak diperlukan, dan katakan terus terang bahwa hook sudah bagus.
- Utamakan kejelasan pesan, daya tarik, relevansi, dan kesesuaian dengan isi video.
- JANGAN mengubah maksud atau informasi utama dari hook asli.

**Cara kerja:**

1. Baca hook asli (kalimat pembuka narasi atau teks dan visual pembuka) bersama isi videonya.
2. Nilai: apakah sesuai isi video, apakah berlebihan atau memaksa, apakah pesannya jelas.
3. Hasil: bila perlu diubah, tampilkan hook asli, hook perbaikan, dan alasan singkat. Bila tidak perlu, tulis "dipertahankan" beserta alasannya.
4. Bila hook berubah: perbarui script, narasi bersih, dan jadwal adegan. Di Cara 2 (voice over milik user) minta suara baru untuk kalimat yang berubah; visual boleh disesuaikan sendiri. Jangan mengganti isi audio user diam-diam.

### 7.5 Video Effects (20 efek, hanya bila diminta)

**Aturan penggunaan:** hanya dipakai ketika user memintanya. Pemicu utama: kata "video effect" (atau "video effects") dan/atau nama efek dari daftar di bawah, mis. "gunakan video effects Orbit". Bila hanya menyebut "video effect" tanpa nama efek, tanyakan efek mana dari 20 daftar. Ungkapan lain yang jelas bermaksud sama juga dikenali. JANGAN menerapkan Video Effects secara otomatis.

**Sumber kebenaran: video referensi.** Video referensi adalah acuan utama untuk memahami tampilan dan cara kerja tiap efek. Implementasi harus meniru efek di video referensi, bukan sekadar memakai namanya atau membuat animasi sederhana yang mirip konsepnya.

**Daftar 20 efek (deskripsi dari user, tetap dan tidak boleh diubah):**

1. **Orbit:** efek pergerakan elemen mengelilingi subjek dengan komposisi visual yang dinamis.
2. **Chat Takeover:** tampilan antarmuka percakapan mengambil alih layar dan menjadi elemen utama dalam video.
3. **Frame Escape:** efek subjek yang terlihat keluar atau menembus batas frame.
4. **Snap Zoom:** perbesaran kamera secara cepat dan tegas untuk memberikan penekanan pada subjek.
5. **Checklist Pop:** elemen checklist muncul secara bertahap dengan animasi pop.
6. **Headline Storm:** kumpulan headline atau teks bergerak dan bertumpuk secara dinamis memenuhi komposisi video.
7. **Zoom Portal:** efek portal visual yang menghubungkan subjek dengan tampilan atau lapisan visual lainnya.
8. **Growth Curve:** animasi grafik pertumbuhan dengan garis kurva yang bergerak dan berkembang.
9. **Studio Reveal:** efek pengungkapan suasana studio dengan elemen pencahayaan dan tampilan siaran.
10. **B-Roll Overlay:** menggabungkan footage tambahan sebagai lapisan visual di atas video utama.
11. **Paper Cutout:** efek subjek yang dipisahkan dari latar belakang dan dikomposisikan seperti potongan kertas.
12. **Dolly Zoom:** efek perubahan perspektif dengan pergerakan zoom dan penyesuaian skala latar belakang.
13. **Magazine Cover:** mengubah komposisi video menjadi tampilan sampul majalah dengan tipografi dan elemen editorial.
14. **Liquid Glass:** efek material kaca transparan dengan distorsi dan tampilan reflektif.
15. **Zoom Through Cut:** transisi zoom yang bergerak menembus satu adegan menuju adegan berikutnya.
16. **Green Screen:** menggunakan latar hijau untuk memisahkan subjek dan menggantinya dengan latar visual lain.
17. **Frame Break:** efek visual seolah-olah frame pecah atau terbelah dengan elemen yang keluar dari batas komposisi.
18. **Digital Zoom:** perbesaran digital yang memberikan penekanan pada bagian tertentu dari video.
19. **Phone Mockup:** menampilkan konten di dalam mockup perangkat smartphone.
20. **Checklist:** menampilkan daftar checklist dengan susunan elemen dan animasi yang terorganisasi.

**Bila video referensi TIDAK tersedia atau tidak bisa dibuka:**

1. JANGAN mengarang detail visual (bentuk, timing, easing, layering) dari nama efek saja.
2. Minta user mengunggah video referensi efek itu, atau memberikan deskripsi acuan, SEBELUM membuat efeknya.
3. Bagian video lain yang tidak memakai efek itu boleh dikerjakan lebih dulu; sebutkan jelas efek mana yang menunggu referensi.
4. Cek dulu di percakapan dan di folder project apakah referensi sudah pernah dilampirkan; bila ada, pakai itu tanpa bertanya lagi.

**Bila video referensi tersedia:**

1. Ambil frame dengan `ffmpeg` (rapat di sekitar momen efek) dan baca durasi, ritme, dan urutan kejadiannya.
2. Catat dari referensi: timing, easing, transisi, layering (urutan tumpukan), masking, komposisi, dan pergerakan elemen. Simpan ringkasannya di `efek/<nama-efek>.md` di folder project supaya efek bisa direproduksi konsisten.
3. Bangun efeknya mengikuti catatan itu, bandingkan frame hasil dengan frame referensi, dan perbaiki yang meleset.
4. Bila ada bagian yang tidak bisa direplikasi persis (mis. footage asli di referensi), katakan di laporan, jangan diganti diam-diam.

**Ketentuan implementasi:**

- Pertahankan karakteristik visual tiap efek sesuai video referensi.
- Perhatikan detail animasi, timing, easing, transisi, layering, masking, komposisi, dan pergerakan elemen.
- Setiap efek punya karakter sendiri, bukan variasi dari satu animasi yang sama.
- Kualitas tinggi, halus, profesional, dan konsisten dengan palet dan gaya video.
- Efek harus bisa diterapkan pada video sesuai kebutuhan dan konteksnya, dan tidak menabrak area subtitle atau timer bila dua fitur itu juga dipakai.
- Jangan menghilangkan, menggabungkan, atau mengganti salah satu dari 20 efek.
- Jangan mengarang efek tambahan sebagai pengganti efek dari referensi.
- Jangan menambah efek di luar 20 efek ini kecuali user memintanya dengan jelas.
- Efek tidak menggantikan fitur wajib: SFX dan ekspresi karakter tetap ada. Efek yang berupa transisi (mis. Zoom Through Cut) dianggap permintaan eksplisit karena user menyebut namanya; transisi bergaya lain tetap mati kecuali diminta.

**Format hasil** mengikuti kebutuhan user: deskripsi visual, instruksi editing, prompt untuk video generator, langkah implementasi, atau video jadi bila memang diminta membuat video. Jangan menganggap "implementasi" sebagai eksekusi teknis bila konteksnya tidak meminta demikian.

## 8. Detail per cara

### Format script

Tabel per adegan di chat dengan kolom: nomor, waktu, visual, narasi (VO), dan pergantian adegan. Tambah kolom "Efek / SFX / Timer / Subtitle" hanya bila fitur itu dipakai.

- Kata narasi kira-kira durasi x 2,3 sampai 2,8 per detik (Bahasa Indonesia tempo normal), jeda 0,3-0,5 detik di pergantian adegan. Total waktu adegan pas dengan durasi yang diminta.
- Urutan di chat: tabel script, blok narasi bersih, catatan asumsi singkat (durasi, rasio, palet, apakah neon, supaya user tahu kartu mana yang menyusul), lalu Kartu 1.

### Cara 1: script, video, voice over

1. Tulis script sesuai jenis konten, nama produk atau topik, dan durasi.
2. Bangun video dari script itu. Implementasi yang terbukti: Pillow dengan supersampling 2x (gambar 2160x3840 lalu `reduce(2)`), tiap adegan sebuah fungsi `scene_n(t_lokal)`, `frame(t)` memilih adegan dan menumpuk overlay (timer, subtitle), `multiprocessing.Pool` dan pipe `rgb24` ke `ffmpeg -c:v libx264 -crf 18 -preset medium -pix_fmt yuv420p`. Buat contact sheet 12-24 frame dan lihat dulu sebelum render penuh.
3. Buat voice over dengan tool apa pun yang tersedia dan bisa jalan, sinkronkan, lalu campur SFX (6.1) dan gabungkan. Bila tidak ada TTS yang bisa jalan: ikuti aturan umum nomor 10.
4. Cek (aturan umum nomor 2). Bila neon, ikuti Kartu 2. Kirim.
5. Gagal: Cara 3.

### Cara 2: voice over dan script dari user

1. Baca script dan audio (`ffprobe`). Durasi adegan mengikuti audio; tambahkan 1-1,5 detik kartu penutup setelah suara selesai.
2. Cari waktu kalimat dan kata: pakai transkripsi dengan timestamp bila ada tool-nya; bila tidak, baca celah napas dari gelombang suara:

```python
import numpy as np, subprocess
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", VO, "-ac", "1", "-ar", "16000", "-f", "s16le", "-"],
                     capture_output=True, check=True).stdout
x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768; hop = 320; n = len(x) // hop
db = 20 * np.log10(np.sqrt((x[:n * hop].reshape(n, hop) ** 2).mean(1)) + 1e-6)
runs, s = [], None                                   # celah = frame di bawah -34 dB
for i, v in enumerate(db):
    if v < -34 and s is None: s = i
    if v >= -34 and s is not None:
        if (i - s) * hop / 16000 >= 0.06: runs.append((s * hop / 16000, i * hop / 16000))
        s = None
```

3. Baca celahnya: celah 0,5 detik atau lebih = batas adegan atau kalimat (adegan berikut mulai di ujung celah); 0,2-0,45 = koma; 0,06-0,15 = antar kata. Cocokkan pola celah dengan jumlah kalimat di script dan hitung suku kata untuk menaksir posisi kata. Segmen ucapan = ruang di antara celah.
4. **Koreksi salah ucap:** bandingkan transkripsi dengan script; bila ada kata salah, hilang, atau berulang, buat daftar (waktu, yang terdengar, yang seharusnya). Visual dan teks mengikuti script yang benar. Jangan mengubah isi audio asli diam-diam; untuk kalimat salah, sarankan user membuat ulang kalimat itu. Bila tidak ada tool transkripsi, katakan pengecekan salah ucap otomatis tidak bisa dilakukan dan minta user mendengarkan; jangan mengaku sudah mengecek.
5. Ikat ikon, efek, SFX, timer, dan subtitle ke kata yang diucapkan; fps sesuai permintaan (mis. 60).
6. Gabungkan audio asli apa adanya (mp3 ke `aac -b:a 256k`) bersama SFX via `Track.write`, pastikan `mean_volume` sama dengan aslinya, cek, kirim. Kartu 2 hanya bila neon.

### Cara 3: JS murni + perintah render

- Satu file `.js` (Node.js), tanpa Chromium, Puppeteer, atau Playwright. Utamakan tanpa dependensi native: gambar frame sendiri (rasterizer perangkat lunak sederhana) dan tulis frame mentah `rgba` ke stdout yang di-pipe ke FFmpeg. Bila butuh paket, tulis perintah pasangnya dan alasannya.
- Resolusi, fps, dan durasi jadi konstanta di atas file (bisa di-override argumen CLI). Ada opsi `--preview` yang hanya merender adegan pembuka. Tanpa ketergantungan font atau `drawtext`; teks (timer, subtitle) memakai mask huruf yang disematkan (lihat 7.1).
- SFX wajib: buat di workspace dengan kode bagian 13, campur dengan voice over (bila ada) menjadi `audio-final.wav`, kirim file itu bersama JS; perintah render tinggal menambah `-i audio-final.wav`.
- Uji dulu di workspace (beberapa frame atau `--preview` singkat): tidak ada error dan frame tidak hitam.
- Kirim JS dengan `SendUserFile`, lalu perintah render sesuai nama file di blok kode (wajib):

```bash
# siapkan sekali (Termux): pkg install nodejs ffmpeg -y
# render penuh, tanpa suara
node nama-video.js | ffmpeg -y -f rawvideo -pixel_format rgba -video_size 1080x1920 -framerate 30 -i - -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -movflags +faststart nama-video.mp4

# render penuh, dengan audio (voice over + SFX yang sudah dicampur)
node nama-video.js | ffmpeg -y -f rawvideo -pixel_format rgba -video_size 1080x1920 -framerate 30 -i - -i audio-final.wav -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -shortest -movflags +faststart nama-video.mp4

# render preview adegan pembuka saja
node nama-video.js --preview | ffmpeg -y -f rawvideo -pixel_format rgba -video_size 1080x1920 -framerate 30 -i - -c:v libx264 -preset veryfast -crf 20 -pix_fmt yuv420p nama-video-preview.mp4
```

- Catat: file harus ada di folder tempat perintah dijalankan (Termux: `cd` ke folder itu; bila di penyimpanan HP, jalankan `termux-setup-storage` dulu).

## 9. Storyboard dan referensi

**Storyboard** adalah rancangan adegan demi adegan sebelum animasi dibuat: tiap panel berisi gambaran visual, gerakan tiap elemen, kamera atau transisi, durasi, dan narasi atau teks pendek.

- User boleh mengirim storyboard (teks, tabel, gambar), foto, atau video referensi. Bila ada, ikuti urutan adegan, komposisi, palet, ritme gerak, dan tata letak timer atau teks. Bila perlu menyimpang, bilang di laporan.
- Video referensi: ambil beberapa frame dengan `ffmpeg` untuk membaca palet, transisi, dan tempo.
- Prompt yang terlalu sederhana berisiko meleset; tetap kerjakan, cukup satu kalimat di akhir bahwa storyboard atau referensi bisa dikirim.

## 10. Contoh prompt user yang harus dikenali (bagian yang bisa diubah)

- **Cara 1:** "Bikinin script buat video flat animation motion graphic iklan produk pizzaku durasinya 40 detik aja" (ubah: jenis, nama produk, durasi, rasio). Lanjut: "Buatin video motion graphic flat animation untuk produk pizzaku ini. 9:16, full hd."
- **Cara 2:** "bantu buatkan script cerita untuk motion grafik tentang Nabi Musa membelah laut durasi 30 detik aja" (ubah: topik, durasi). Lanjut: "ini voice over dan scriptnya selanjutnya buatkan motion design 60 fps menggunakan voice over itu dan kalau ada suara yang salah ngomong tolong koreksi".
- **Cara 3:** "Tolong buatkan video animasi motion graphics berdasarkan naskah yang sudah saya berikan. Jangan masukkan semua teks ke layar ... file JS murni ... Termux ... perintah render sesuai nama file".
- **Timer:** "bagaimana jika setiap 2 detik bumi makin membesar", "bagaimana jika bumi kehilangan listrik selama 1 menit", "setiap 5 detik terjadi gempa, timer di kanan atas".
- **Subtitle:** "tolong gunakan subtitle", "dengan subtitle", "pakai subtitle".
- **Transisi:** "pakai transisi yang halus antar adegan".

## 11. Laporan akhir (singkat)

Satu atau dua kalimat hasil (apa yang jadi, durasi, rasio, fps), file dikirim dengan `SendUserFile` (video + `narasi-voice-over.txt` bersih bila relevan), lokasi folder project, hal yang tidak bisa dilakukan (belum ada suara, salah ucap tidak bisa dicek, sinkron kata ditaksir), satu kalimat soal ada atau tidaknya preview dan kartu, dan satu langkah lanjut bila ada. Jangan menceritakan ulang langkah kerja.

## 12. Uji sebelum selesai

1. "Buatkan script video motion graphic tentang X": tabel script, blok narasi bersih tanpa detik atau label, catatan asumsi, dan Kartu 1.
2. "Lanjut buat video" dengan palet non-neon: video penuh tanpa Kartu 2, dengan satu kalimat penjelasan di laporan, SFX ada, karakter berekspresi.
3. Palet neon: preview + Kartu 2 ("Lanjut film penuh" / "Revisi dulu"); sisa video belum dibuat.
4. Tidak ada TTS: video bersuara SFX tanpa voice over, `narasi-voice-over.txt` bersih, tawaran lanjut ke Cara 2.
5. Voice over dari user + SFX: voice over tidak berubah, SFX tidak menutupi ucapan, puncak di bawah -1 dBFS.
6. "Bagaimana jika bumi kehilangan listrik selama 1 menit": timer dua fase (5 detik, lalu 1:00 dengan "WAKTU DIPERCEPAT"), kejadian tepat di nol.
7. "Bagaimana jika setiap 2 detik bumi makin membesar": timer mode `every=2`, bumi membesar tiap kejadian.
8. "Pakai subtitle": subtitle mengikuti voice over, gaya dan warna sesuai palet, tidak menabrak objek.
9. "Pakai transisi": klip preview + Kartu 3 sebelum video penuh.
10. Karakter teriak: mata `wide`, mulut `scream`, tanda seru, gelombang, getar, kilat, tepat di kata yang diucapkan.
11. Hook diminta diperbaiki: hook asli, hook perbaikan, alasan; hook yang sudah bagus dipertahankan; tidak lebih clickbait; maksud dan informasi utama tidak berubah. Tanpa permintaan, hook tidak disentuh.
12. "Gunakan video effects Orbit" tanpa video referensi: tidak ada detail visual karangan; minta user mengunggah referensi atau deskripsi acuan. Dengan referensi: catatan `efek/orbit.md`, frame hasil dibandingkan dengan frame referensi.
13. Permintaan dengan kata-kata di luar contoh (mis. "tampilkan teks ucapannya di bawah"): tetap dikenali dari maksudnya.

## 13. Kode referensi (teruji; Pillow + numpy + ffmpeg)

Simpan sebagai `fxlib.py` di folder project. Canvas `c` diasumsikan punya `poly(pts, fill)`, `line(pts, w, fill)`, `circ(x, y, r, fill)`, `ell`, `rr` (Pillow dengan supersampling 2x). Frame berupa gambar PIL RGB. Berisi: SFX sintesis + `Track` (pencampur dengan ducking), efek karakter, `transition`, `timer_value`, `timer_plan`, `draw_timer`, `make_cues`, `draw_subtitle`.

```python
# fxlib.py - SFX sintesis + mixer, efek karakter, timer overlay (hanya Pillow + numpy + ffmpeg)
import math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

# ---------------- util ----------------
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def prog(t, t0, d): return clamp((t - t0) / d)
def e_io(p): return 0.5 - 0.5 * math.cos(math.pi * p)
def e_out(p): return 1 - (1 - p) ** 3
def e_back(p, s=1.70158):
    p -= 1
    return p * p * ((s + 1) * p + s) + 1
def popin(t, t0, d=0.45):
    p = prog(t, t0, d)
    return e_back(p) if p > 0 else 0.0
def mixc(c1, c2, a): return tuple(int(c1[i] + (c2[i] - c1[i]) * a) for i in range(3))

# ---------------- SFX (sintesis, tanpa unduhan) ----------------
SR = 44100
def _t(d): return np.arange(int(SR * d)) / SR
def _norm(x, peak=0.9):
    m = float(np.max(np.abs(x))) or 1.0
    return (x / m * peak).astype(np.float32)
def _phase(f): return 2 * np.pi * np.cumsum(f) / SR

def sfx_pop(f0=700, f1=180, d=0.14):                    # elemen muncul
    t = _t(d); return _norm(np.sin(_phase(f1 + (f0 - f1) * np.exp(-t * 28))) * np.exp(-t * 22))
def sfx_whoosh(d=0.55, up=True, f_lo=300, f_hi=5000):   # transisi / sapuan
    n = int(SR * d); x = np.random.default_rng(7).standard_normal(n); p = np.linspace(0, 1, n)
    fc = f_lo * (f_hi / f_lo) ** (p if up else 1 - p)
    a = 1 - np.exp(-2 * np.pi * fc / SR); y = np.empty(n); s = 0.0
    for i in range(n):
        s += a[i] * (x[i] - s); y[i] = s
    y -= np.convolve(y, np.ones(220) / 220, 'same')
    return _norm(y * np.sin(np.pi * p) ** 2)
def sfx_ding(f=988, d=0.7):                             # sukses / info
    t = _t(d); y = np.sin(2*np.pi*f*t) + .5*np.sin(2*np.pi*f*2.01*t) + .25*np.sin(2*np.pi*f*3.02*t)
    return _norm(y * np.exp(-t * 6) * np.minimum(1, t / 0.003))
def sfx_tick(f=1800, d=0.05):                           # detik timer
    t = _t(d); return _norm(np.sin(2 * np.pi * f * t) * np.exp(-t * 90))
def sfx_beep(f=1200, d=0.12):                           # 3 detik terakhir timer
    t = _t(d); return _norm(np.sin(2*np.pi*f*t) * np.minimum(1, t/0.004) * np.minimum(1, (d-t)/0.01))
def sfx_impact(d=0.8):                                  # timer nol / kejadian besar
    t = _t(d); body = np.sin(_phase(40 + 110 * np.exp(-t * 18))) * np.exp(-t * 5)
    return _norm(body + np.random.default_rng(3).standard_normal(len(t)) * np.exp(-t * 30) * .5)
def sfx_alert(d=0.6):                                   # bahaya / teriak
    t = _t(d); f = np.where((t * 6).astype(int) % 2 == 0, 880, 660)
    return _norm(np.sign(np.sin(_phase(f))) * .6 * np.minimum(1, (d - t) / 0.03))
def sfx_boing(d=0.45):                                  # kaget kartun
    t = _t(d); f = 300 + 220 * np.sin(2*np.pi*7*t) * np.exp(-t*5) + 120 * np.exp(-t*8)
    return _norm(np.sin(_phase(f)) * np.exp(-t * 5))
def sfx_riser(d=1.0):                                   # ketegangan naik
    t = _t(d); q = t / d
    return _norm(np.sin(_phase(200 + 1800 * q ** 2)) * q * .7 + np.random.default_rng(5).standard_normal(len(t)) * q ** 2 * .3)

class Track:
    """Susun SFX di timeline lalu campur ke voice over TANPA mengubah voice over."""
    def __init__(self, dur): self.dur = dur; self.y = np.zeros(int(SR * dur), np.float32)
    def add(self, snd, t, db=-14):
        i = int(t * SR); g = 10 ** (db / 20)
        if 0 <= i < len(self.y):
            j = min(len(self.y), i + len(snd)); self.y[i:j] += snd[:j - i] * g
        return self
    def write(self, path, vo_path=None, duck_db=-12):
        n = len(self.y); vo = np.zeros(0, np.float32)
        if vo_path:
            raw = subprocess.run(["ffmpeg", "-v", "error", "-i", vo_path, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"],
                                 capture_output=True, check=True).stdout
            vo = np.frombuffer(raw, np.float32); n = max(n, len(vo))
        base = np.zeros(n, np.float32); base[:len(vo)] = vo
        sf = np.zeros(n, np.float32); sf[:len(self.y)] = self.y
        if len(vo) and duck_db:                       # RMS SFX tidak boleh melebihi RMS ucapan + duck_db (jendela 250 ms)
            w = int(0.25 * SR); ker = np.ones(w) / w
            ev = np.sqrt(np.convolve(base ** 2, ker, "same")); es = np.sqrt(np.convolve(sf ** 2, ker, "same")) + 1e-9
            lim = np.where(ev > 0.01, np.minimum(1.0, ev * 10 ** (duck_db / 20) / es), 1.0)
            k = int(0.1 * SR); sf *= np.convolve(lim, np.ones(k) / k, "same")     # perubahan gain halus 100 ms
        g = 1.0
        while g > 0.05 and np.max(np.abs(base + sf * g)) > 0.98: g *= 0.9   # hanya SFX yang diturunkan
        out = np.clip(base + sf * g, -1, 1)
        with wave.open(path, "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes((out * 32767).astype(np.int16).tobytes())
        return g

# ---------------- transisi antar adegan (a -> b, p = 0..1, easing cosinus) ----------------
def transition(kind, a, b, p, cx=540, cy=None, col=(107, 63, 38)):
    """kind: fade | slide | wipe | iris. a, b = gambar PIL ukuran sama."""
    W, H = a.size; e = e_io(clamp(p)); cy = H // 2 if cy is None else cy
    if kind == "fade": return Image.blend(a, b, e)
    if kind == "slide":
        off = int(W * e); out = Image.new("RGB", (W, H)); out.paste(a, (-off, 0)); out.paste(b, (W - off, 0)); return out
    if kind == "wipe":
        y0 = int(H * (1 - e)); out = a.copy()
        if y0 < H:
            out.paste(b.crop((0, y0, W, H)), (0, y0)); ImageDraw.Draw(out).rectangle([0, max(0, y0 - 10), W, y0 + 6], fill=col)
        return out
    R = e * math.hypot(W, H); m = Image.new("L", (W * 2, H * 2), 0)          # iris
    ImageDraw.Draw(m).ellipse([(cx - R) * 2, (cy - R) * 2, (cx + R) * 2, (cy + R) * 2], fill=255)
    out = a.copy(); out.paste(b, (0, 0), m.resize((W, H), Image.LANCZOS)); return out

# ---------------- efek karakter (c = canvas dengan poly/line/circ) ----------------
RED, ORANGE, WHITE = (229, 72, 77), (244, 144, 58), (255, 251, 243)

def shake(t, t0, dur=0.8, amp=12, hz=18):          # offset (dx, dy) untuk karakter atau kamera
    p = (t - t0) / dur
    if p < 0 or p > 1: return 0.0, 0.0
    a = amp * (1 - p); w = 2 * math.pi * (t - t0)
    return a * math.sin(w * hz), a * 0.6 * math.cos(w * hz * 1.3)

def fx_exclaim(c, x, y, h, t, t0, n=1, col=RED):    # tanda seru ! atau !! (tanpa font), pop + goyang
    s = popin(t, t0, 0.35)
    if s <= 0.01: return
    rot = 7 * math.sin(2 * math.pi * 6 * (t - t0)) * (1 - prog(t, t0, 1.0))
    for k in range(n):
        cx = x + (k - (n - 1) / 2) * h * 0.55
        for grow, cc in ((h * 0.05, WHITE), (0, col)):             # outline putih lalu isi
            w = h * 0.15 * s + grow; top = y - h * s - grow; neck = y - h * 0.30 * s
            ox = lambda yy: cx + (yy - y) * math.tan(math.radians(rot))
            c.poly([(ox(top) - w, top), (ox(top) + w, top), (ox(neck) + w * .55, neck), (ox(neck) - w * .55, neck)], cc)
            c.circ(ox(top), top, w, cc); c.circ(ox(neck), neck, w * .55, cc)
            c.circ(ox(y), y, w * .95, cc)

def fx_waves(c, x, y, t, t0, bg, n=3, r0=300, gap=48, span=32, col=ORANGE, w=10, sides=(-1, 1)):
    if t < t0: return                                # busur bergelombang memancar keluar (teriak / getar)
    for sx in sides:
        for k in range(n):
            f = ((t - t0) * 1.8 + k / n) % 1.0
            r = r0 + f * gap * n; cc = mixc(col, bg, f ** 1.5)
            pts = []
            for i in range(25):
                th = math.radians(-span + 2 * span * i / 24)
                rr = r + 9 * math.sin(math.degrees(th) * 0.55 + t * 16 + k * 2)
                pts.append((x + sx * rr * math.cos(th), y + rr * math.sin(th)))
            c.line(pts, w * (1 - 0.5 * f), cc)

def fx_sweat(c, x, y, t, t0, col=(143, 214, 190)):  # tetes keringat jatuh
    for k in range(2):
        f = ((t - t0) * 1.1 + k * 0.5) % 1.0
        if t < t0: return
        dx, dy = x + (k * 2 - 1) * 34 + f * 40 * (k * 2 - 1), y + f * 120
        c.poly([(dx, dy - 34), (dx - 15, dy - 6), (dx + 15, dy - 6)], col); c.circ(dx, dy, 15, col)

def flash(img, t, t0, dur=0.18, col=(255, 255, 255), peak=0.7):   # kilat layar saat kejadian
    p = prog(t, t0, dur)
    return img if p <= 0 or p >= 1 else Image.blend(img, Image.new("RGB", img.size, col), peak * (1 - p) ** 2)

# ---------------- timer / penjelasan (overlay di frame akhir) ----------------
FONT_B = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"
FONT_M = "/usr/share/fonts/truetype/google-fonts/Poppins-Medium.ttf"
POS = {"kiri-atas": (.07, .11, "l"), "tengah-atas": (.5, .11, "c"), "kanan-atas": (.93, .11, "r"),
       "kiri-tengah": (.07, .45, "l"), "tengah": (.5, .45, "c"), "kanan-tengah": (.93, .45, "r")}

def fmt_time(s):                                    # m:ss.mmm
    ms = int(max(0.0, s) * 1000 + 0.5)
    return f"{ms // 60000}:{(ms // 1000) % 60:02d}.{ms % 1000:03d}"

def timer_value(t, start, end=None, every=None, up=False):
    if every: return every - ((t - start) % every)  # "setiap N detik": reset ke N tiap kejadian
    return max(0.0, t - start) if up else max(0.0, end - t)

def timer_plan(t, plan):
    """plan = [(t0, t1, v0, v1, label, sub), ...]. Nilai timer bergerak linear v0 -> v1 selama t0..t1 (detik video).
    v0 > v1 = hitung mundur. Rasio (v0 - v1) / (t1 - t0) = kecepatan waktu; '{x}' di sub diganti kecepatannya.
    Hasil: (label, nilai, sub) atau None bila t di luar semua fase."""
    for t0, t1, v0, v1, label, sub in plan:
        if t0 <= t < t1:
            x = abs(v0 - v1) / (t1 - t0)
            return label, v0 + (v1 - v0) * (t - t0) / (t1 - t0), (sub or "").replace("{x}", f"{x:g}")
    return None

def draw_timer(img, pos, label, value, sub=None, scale=1.0, col=(255, 255, 255), hot=(255, 120, 110),
               hot_below=3.0, panel=True):
    W, H = img.size; k = W / 1080 * scale; fx, fy, al = POS[pos]
    fl, ft, fs = (ImageFont.truetype(FONT_B, int(30 * k)), ImageFont.truetype(FONT_M, int(84 * k)),
                  ImageFont.truetype(FONT_B, int(24 * k)))
    trl, trs = 5 * k, 4 * k
    tw = lambda s, f, tr: sum(f.getlength(ch) for ch in s) + tr * max(0, len(s) - 1)
    cell = max(ft.getlength(ch) for ch in "0123456789")                       # angka lebar tetap: tidak bergoyang
    ts = fmt_time(value); wt = sum(cell if ch.isdigit() else ft.getlength(ch) for ch in ts)
    bw = max(tw(label, fl, trl), wt, tw(sub or "", fs, trs)); pad = 26 * k
    bh = 30 * k + 14 * k + 84 * k * 1.25 + (14 * k + 24 * k if sub else 0)
    x0 = W * fx if al == "l" else W * fx - bw / 2 if al == "c" else W * fx - bw; y0 = H * fy
    ov = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
    if panel: d.rounded_rectangle([x0 - pad, y0 - pad, x0 + bw + pad, y0 + bh + pad], 22 * k, fill=(0, 0, 0, 150))
    cc = col if value > hot_below else mixc(col, hot, 0.55 + 0.45 * abs(math.sin(value * 6)) if value > 0 else 1.0)
    def line(s, f, tr, y, fill, fixed=False):
        w = wt if fixed else tw(s, f, tr)
        x = x0 if al == "l" else x0 + (bw - w) / 2 if al == "c" else x0 + bw - w
        for ch in s:
            adv = (cell if ch.isdigit() else f.getlength(ch)) if fixed else f.getlength(ch)
            ox = (cell - f.getlength(ch)) / 2 if fixed and ch.isdigit() else 0
            d.text((x + ox + 2 * k, y + 2 * k), ch, font=f, fill=(0, 0, 0, 150))
            d.text((x + ox, y), ch, font=f, fill=fill + (255,)); x += adv + (0 if fixed else tr)
    line(label, fl, trl, y0, col)
    line(ts, ft, 0, y0 + 30 * k + 6 * k, cc, fixed=True)
    if sub: line(sub, fs, trs, y0 + 30 * k + 14 * k + 84 * k * 1.25, col)
    return Image.alpha_composite(img.convert("RGBA"), ov).convert("RGB")

# ---------------- subtitle (wajib mengikuti voice over) ----------------
import re
FONT_SERIF_I = "/usr/share/fonts/truetype/google-fonts/Lora-Italic-Variable.ttf"

def _syl(w):                                          # taksiran suku kata Indonesia
    w = re.sub(r"[^a-z]", "", w.lower()); n = len(re.findall(r"[aiueo]", w)) - len(re.findall(r"(ai|au|oi)$", w))
    return max(1, n)

def word_times(words, t0, t1):                        # bagi waktu frasa ke tiap kata (sebanding suku kata)
    sy = [_syl(w) for w in words]; tot = sum(sy); out = []; a = t0
    for w, k in zip(words, sy):
        b = a + (t1 - t0) * k / tot; out.append((w, a, b)); a = b
    return out

def make_cues(segments, max_words=4):
    """segments = [(teks_script_yang_benar, mulai, selesai)] satu frasa per segmen ucapan (dari celah napas / transkripsi).
    Frasa panjang dipecah rata jadi cue <= max_words kata. Hasil: [(teks, t0, t1, [(kata, a, b), ...])]."""
    cues = []
    for text, a, b in segments:
        wt = word_times(text.split(), a, b); n = math.ceil(len(wt) / max_words); per = math.ceil(len(wt) / n)
        for i in range(0, len(wt), per):
            ch = wt[i:i + per]; ch[-1] = (ch[-1][0].rstrip(",.;:"), ch[-1][1], ch[-1][2])      # tanpa koma/titik di ujung
            cues.append((" ".join(w for w, _, _ in ch), ch[0][1], ch[-1][2], ch))
    return cues

def draw_subtitle(img, cues, t, style="pill", fg=(255, 241, 220), bg=(66, 38, 22), accent=(244, 144, 58), pos=0.90, size=52):
    """style: pill (kartu warna palet + kata aktif beraksen) | serif (italic sinematik) | pop (kata muncul satu-satu, tebal + outline)."""
    W, H = img.size; k = W / 1080
    if style == "serif":                                       # gradien gelap tipis agar teks selalu terbaca
        y0 = int(H * pos - 300 * k); h = H - y0; m = (np.linspace(0, 1, h) ** 1.3 * 215).astype(np.uint8)
        sc = Image.new("RGBA", (W, h), (0, 0, 0, 0)); sc.putalpha(Image.fromarray(np.tile(m[:, None], (1, W))))
        img = img.convert("RGBA"); img.alpha_composite(sc, (0, y0)); img = img.convert("RGB")
    cue = next((c for c in cues if c[1] - 0.04 <= t <= c[2] + 0.22), None)
    if not cue: return img
    text, t0, t1, wt = cue
    a = min(prog(t, t0 - 0.04, 0.14), 1 - prog(t, t1 + 0.06, 0.16))          # fade masuk/keluar
    if a <= 0: return img
    path = FONT_SERIF_I if style == "serif" else FONT_B; px = int(size * k * {"serif": 1.05, "pop": 0.92}.get(style, 1))
    words = [w.upper() if style == "pop" else w for w, _, _ in wt]
    for _ in range(2):                                         # kecilkan otomatis bila terlalu lebar untuk layar
        font = ImageFont.truetype(path, px); sp = font.getlength(" ") + (16 * k if style == "pop" else 0)
        wl = [font.getlength(w) for w in words]; tw = sum(wl) + sp * (len(words) - 1)
        if tw <= 0.88 * W: break
        px = int(px * 0.88 * W / tw)
    x0 = (W - tw) / 2; y = H * pos + (1 - e_out(prog(t, t0 - 0.04, 0.2))) * 14 * k
    ov = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(ov); al = int(255 * a)
    if style == "pill":
        px, py = 34 * k, 18 * k
        d.rounded_rectangle([x0 - px, y - py, x0 + tw + px, y + size * k * 1.25 + py], 30 * k, fill=bg + (int(225 * a),))
    x = x0
    for (w, ws, we), ww, wd in zip(wt, words, wl):
        if style == "pop" and t < ws - 0.03: x += wd + sp; continue          # kata muncul saat diucapkan
        on = ws <= t < we
        col = (accent if on else fg) if style in ("pill", "pop") else fg
        if style == "pop":
            d.text((x, y), ww, font=font, fill=col + (al,), stroke_width=int(6 * k), stroke_fill=bg + (al,))
        else:
            if style == "serif": d.text((x + 2 * k, y + 2 * k), ww, font=font, fill=(0, 0, 0, int(150 * a)))
            d.text((x, y), ww, font=font, fill=col + (al,))
        x += wd + sp
    return Image.alpha_composite(img.convert("RGBA"), ov).convert("RGB")
```

Contoh pemakaian di `frame(t)` dan audio:

```python
import fxlib as F
img = scene(t)                                                    # PIL RGB
img = F.flash(img, t, T_EVENT)                                    # kilat saat kejadian
img = F.draw_timer(img, "tengah-atas", "KUCING MAKAN COKELAT DALAM",
                   F.timer_value(t, 0.0, end=T_EVENT), sub="TEOBROMIN MULAI MASUK TUBUH")
img = F.draw_subtitle(img, CUES, t, style="pill", fg=TERANG, bg=GELAP, accent=AKSEN, pos=0.86)
# CUES = F.make_cues([(teks_script, mulai, selesai), ...], max_words=4)
# transisi (bila diminta): img = F.transition("iris", scene_a(t), scene_b(t), (t - TR0) / (TR1 - TR0))

tr = F.Track(DUR); tr.add(F.sfx_pop(), 1.35, -14); tr.add(F.sfx_impact(), T_EVENT, -6)
tr.write("audio-final.wav", vo_path=VO, duck_db=-12)             # voice over utuh; SFX dibatasi di bawah ucapan
```